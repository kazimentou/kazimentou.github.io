<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=>	'Введите код изображения',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);
?>

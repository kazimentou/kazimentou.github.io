<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=>	'Inserisci il codice',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);
?>

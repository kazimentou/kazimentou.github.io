<?php

if (!defined('PLX_ROOT'))
	exit;

/* ****************************
 * author Jean-Pierre Pourrez
 * date : 2014-02-13 
 * test� avec PluXml 5.3
 * mise � jour : 2015-09-21
 * test� avec PluXml 5.4
 * **************************** */

define('RESP_CAPTCHA_NAME', 'respCaptcha');
define('RESP_CAPTCHA_SHOW_NAME', 'id_rep');

class captchaImage extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# Ajouts des hooks
		$this->addHook('plxShowCapchaQ', 'plxShowCapchaQ');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminAuthPrepend', 'AdminAuthPrepend');
		$this->addHook('AdminAuthTop', 'AdminAuthTop');
		$this->addHook('AdminAuth', 'AdminAuth');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

	private function pluginRoot() {
		global $plxShow;
		
		if (isset($plxShow)) {
			return $plxShow->plxMotor->racine.$plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}
	
	private function showCapcha() {
		$pwd = $this->pluginRoot();
		$imagesize = getimagesize(dirname(__FILE__).'/capcha.png');
		$this->lang('L_CAPTCHA_MESSAGE'); echo "<br />\n"; ?>
		<img src="<?php echo $pwd; ?>capcha.php" alt="Captcha" id="capcha" <?php echo $imagesize[3] ?> />
<?php
	}
	
	public function plxShowCapchaQ() {

		$this->showCapcha();
		echo '<?php return true; ?>';
	}

	public function AdminTopEndHead() {
		global $plugin;

		if (!empty($plugin) && $plugin == __CLASS__) { ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo '../../'.__CLASS__.'/'.__CLASS__; ?>.css" />
<?php	}
	}

	// This is a hack for Pluxml 5.3. The response at captcha is limited at a word of one caractere
	public function ThemeEndBody() { ?>
		<script type="text/javascript">
			<!--
			var repId = document.getElementById('<?php echo RESP_CAPTCHA_SHOW_NAME; ?>');
			if (repId)
				repId.setAttribute('maxlength', '5');
			else
				console.log('Input with id: <?php echo RESP_CAPTCHA_SHOW_NAME; ?> not found');
			// -->
		</script>
<?php
	}

	public function AdminAuthPrepend() {
		
		if ($_SESSION['capcha'] !== sha1(strtolower($_POST[RESP_CAPTCHA_NAME]))) {
			global $plxAdmin;
			
			foreach ($plxAdmin->aUsers as $id=>$user) {
				if ($_POST['login'] == $user['login']) {
					$plxAdmin->aUsers[$id]['active'] = false;
					$this->msgCapcha = $this->aLang['L_CAPTCHA_ERROR'];
					break;
				}
			}
		}
	}

	public function AdminAuthTop() {
		global $msg;
		
		if (isset($this->msgCapcha)) {
			// On traite l'erreur sur le captcha
			$msg = $this->msgCapcha;
		}
	}
	
	public function AdminAuth() {
		$this->showCapcha(); ?><br />
		<input name="<?php echo RESP_CAPTCHA_NAME; ?>" type="text" size="5" maxlength="5" />
<?php
	}
	
}
?>

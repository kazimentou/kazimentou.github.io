<?php

/**
 * capcha
 *
 * @package PLX
 * version	1.0
 * @author	St�phane F
 **/

# Chemin absolu vers le dossier
if (!defined('ABSPATH')) define('ABSPATH', dirname(__FILE__).'/');

# tableau contenant les fontes disponibles
$fonts=array();
if ($dh = opendir(ABSPATH.'fonts')) {
	while (($file = readdir($dh)) !== false) {
		if(strtolower(strrchr($file,'.'))=='.ttf')
			$fonts[] = ABSPATH.'fonts/'.$file;
    }
	closedir($dh);
}

# Cr�ation de l'image de fond du capcha
$image = imagecreatefrompng(ABSPATH.'capcha.png');

# tableau des couleurs pour les lettres. imagecolorallocate() retourne un identifiant de couleur.
$colors=array(
	imagecolorallocate($image, 131,154,255), # bleu ciel
	imagecolorallocate($image, 89,186,255), # bleu turquoise
	imagecolorallocate($image, 119,151,173), # bleu gris
	imagecolorallocate($image, 242,67,149), # rose fonc�
	imagecolorallocate($image, 32,151,82) # vert sapin
);

# Retourne de fa�on al�atoire une donn�e d'un tableau
function random($tab) {
	return $tab[array_rand($tab)];
}

# G�n�re le code du capcha
function getCode($length) {
	$chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // Certains caract�res ont �t� enlev�s car ils pr�tent � confusion
	$rand_str = '';
	for ($i=0; $i<$length; $i++) {
		$rand_str .= $chars{ mt_rand( 0, strlen($chars)-1 ) };
	}
	return $rand_str;
}

session_start();

# Code du capcha
$theCode = getCode(count($colors));
$_SESSION['capcha'] = sha1(strtolower($theCode));

# imagettftext(image, taille police, angle inclinaison, coordonn�e X, coordonn�e Y, couleur, police, texte) �crit le texte sur l'image.
for ($i=0; $i<strlen($theCode); $i++) {
	imagettftext($image, 28, mt_rand(-15, 15),  mt_rand(1, 8) + $i*28,  mt_rand(32, 45), random($colors), random($fonts), $theCode[$i]);
}

# Envoi de l'image
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>

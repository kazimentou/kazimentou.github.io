<?php

$fields = array('book'=>'string', 'group_name'=>'string', 'template'=>'string');
$default_values = array();

define('BOOKS_REPO', '/books/'); // starts and ends with '/'

$fieldNames = array('_name', '_group', '_url', '_active', '_menu');

function initPost() {

	global $plxAdmin;

	$result = array(
		'selection'=>'',
		'update'=>'not empty',
		'staticNum'=>array()
	);
	$order = 1;
	foreach ($plxAdmin->aStats as $k=>$infos) {
		$result['staticNum'][] = $k; // must be 3 digits
		foreach ($fieldNames as $field)
			$result[$k.$field] =$infos[$field];	
		$result[$k.'_ordre'] = $order;
		$order++;
	}
	return $result;
}

function generator($filename, $group, $template) {
	// Process the epub file and create static pages
	
	global $plxAdmin;
	
	$zip = new ZipArchive();
	if ($res = $zip->open(__DIR__.BOOKS_REPO.$filename)) {
		$buf = $zip->getFromName('META-INF/container.xml');
		$container = new SimpleXMLElement($buf);
		$opfNode = $container->rootfiles->rootfile;
		$attrs = $opfNode->attributes();
		$opfPath = $attrs['full-path']->__toString();
		$path1 = dirname($opfPath);
		if (substr($path1, 0, -1) != '/')
			$path1 .= '/';
		$buf = $zip->getFromName($opfPath);
		$opf = new SimpleXMLElement($buf);
		$opf->registerXPathNamespace('c', 'http://www.idpf.org/2007/opf');
		$itemrefs = $opf->xpath('//c:spine[@toc="ncx"]/c:itemref');
		$firstStaticPage = true;
		// we prepare the posts from forms
		$post = initPost();
		$contents = array();
		if (count($plxAdmin->aStats) > 0) {
			$keys = array_keys($plxAdmin->aStats);
			rsort($keys);
		} else
			$keys = array(0);
		$new_staticid = $keys[0] + 1;
		$order = count($plxAdmin->aStats) + 1;
		foreach ($itemrefs as $itemref) {
			$attrs = $itemref->attributes();
			$idref = $attrs['idref']->__toString();
			$items = $opf->xpath('//c:manifest/c:item[@id="'.$idref.'"]');
			if ($item = $items[0]) {
				$attrsItem = $item->attributes();
				$href = $path1.$attrsItem['href']->__toString();
				$pageHTML = $zip->getFromName($href);
				$doc = new DOMDocument();
				$doc->loadHTML($pageHTML, LIBXML_NOBLANKS);
				$bodies = $doc->getElementsByTagName('body');
				if ($bodies->length > 0) {
					$body = $bodies->item(0);
					// A tester: h1s = $doc->query('//body/h1');
					// h1s = $doc->query('//body/p[@class="title-chapter"]'); // B.N.F.
					$h1s = $body->getElementsByTagName('h1');
					if ($h1s->length > 0){
						$h1 = $h1s->item(0);
						$title = trim($h1->textContent);
						$body->removeChild($h1);
					}
					else
						$title = '';
					$innerHTML = '';
					foreach ($body->childNodes as $child) {
						$temp = new DOMDocument();
						$temp->appendChild($temp->importNode($child, true));
						$tmp1 = trim($temp->saveHTML());
						if (strlen($tmp1) > 0)
							$innerHTML .= "$tmp1\n";
						unset($temp);
					}
					// save the static page
					$staticId = str_pad($new_staticid, 3, '0', STR_PAD_LEFT);
					$post['staticNum'][] = $staticId;
					// $fieldNames = array('_name', '_group', '_url', '_active', '_menu');
					$post[$staticId.'_name'] = $group.' '.$title;
					$post[$staticId.'_group'] = $group;
					$post[$staticId.'_url'] = '';
					$post[$staticId.'_active'] = 1;
					$post[$staticId.'_menu'] = ($firstStaticPage) ? 'oui' : 'non';
					$post[$staticId.'_ordre'] = $order;
					$contents[] = array(
						'id'				=>$staticId,
						'template'			=>$template,
						'title_htmltag'		=> $title,
						'meta_description'	=> '',
						'meta_keywords'		=>'',
						'content'			=>$innerHTML
					);
					// next chapter, please
					$firstStaticPage = false;
					$new_staticid++;
					$order++;
					$a = $innerHTML;
				}
			}
			 // creation pages as chapters
			$plxAdmin->editStatiques($post);
			// So, fill up each page
			foreach($contents as $page)
				$plxAdmin->editStatique($page);			
		}
		unset($opf);
		$zip->close();
	}
}

$magicBtn = 'generator';
if (! empty($_POST)) {
	if (isset($_POST[$magicBtn])) {
		generator($_POST['book'], $_POST['group_name'], $_POST['template']);
		header('Location: '.$_SERVER['REQUEST_URI']);
		exit;
	} else {
		// save parameters
		foreach ($fields as $field=>$type) {
			if (isset($_POST[$field])) {
				$value = trim($_POST[$field]);
				if (strlen($value) > 0) 
					$plxPlugin->setParam($field, $value, $type);
			}
		}
		$plxPlugin->saveParams();
	}
	header('Location: '.$_SERVER['REQUEST_URI']);
	exit;
}

// Mise à jour feuilles de styles globales
foreach (array('admin', 'site') as $typeCSS) {
	$filename = __DIR__.'/css/'.$typeCSS.'.css';
	if (file_exists($filename)) {
		if  (! file_exists(PLX_PLUGINS.$typeCSS.'.css') or 
			(filemtime(PLX_PLUGINS.$typeCSS.'.css') < filemtime($filename)))
				$plxAdmin->plxPlugins->cssCache($typeCSS);
	}
}

function printSelect($name, $aList, $ext, $currentValue='') { ?>
	<select name="<?php echo $name; ?>" id="<?php echo $field?>_id">
<?php
	foreach ($aList as $v) {
		$value = basename($v);
		$selected = ($value == $currentValue) ? ' selected' : ''; ?>
		<option value="<?php echo $value; ?>"<?php echo $selected; ?>><?php echo basename($v, $ext); ?></option>
<?php
	}
?>
	</select>
<?php
}

$templates = glob(PLX_ROOT.$plxAdmin->aConf['racine_themes'].$plxAdmin->style.'/static*.php');
$books = glob(__DIR__.BOOKS_REPO.'*.epub');
?>

<form id="form_<?php echo $plugin; ?>" method="post">
	<fieldset>
<?php
	foreach ($fields as $field=>$type) {
		$value = $plxPlugin->getParam($field); ?>
		<p>
			<label for="<?php echo $field?>_id"><?php echo $plxPlugin->lang('L_'.strtoupper($plugin.'_'.$field)); ?></label>
<?php
			switch ($field) {
				case 'book' :
					printSelect($field, $books, '.epub', $value);
					break;
				case 'template' :
					printSelect($field, $templates, '.php', $value);
					break;
				default : ?>
					<?php plxUtils::printInput($field, $value, 'text'); ?>
<?php		} ?>
		</p>
<?php
	}
?>
		<p>
			<input type="submit" name="<?php echo $magicBtn; ?>" value="<?php echo $plxPlugin->lang('L_'.strtoupper($plugin.'_GENERATOR')); ?>">
			<input type="submit" value="<?php echo $plxPlugin->lang('L_'.strtoupper($plugin.'_SAVE')); ?>">
		</p>
	</fieldset>
</form>

<?php
$LANG = array(
	'L_STATICGROUP_BOOK'		=> 'Livre au format epub',
	'L_STATICGROUP_GROUP_NAME'	=> 'Nom du groupe de pages',
	'L_STATICGROUP_TEMPLATE'	=> 'Modèle de page',
	'L_STATICGROUP_GENERATOR'	=> 'Générer les pages',
	'L_STATICGROUP_SAVE'		=> 'Enregistrer'
);
?>

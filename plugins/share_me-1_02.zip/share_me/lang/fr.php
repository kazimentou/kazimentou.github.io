<?php
$LANG = array(
	'L_SHARE_ME_TAGS'	=> 'Partager les mot-clés',
	'L_SHARE_ME_SAVE'	=> 'Enregistrer'
);
?>

<?php
	$LANG = array(
		'UNWRITABLE'	=> 'n\'est pas accessible en écriture',
		'DATA_FOLDER'	=> 'Dossier des données',
		'OLD_NAME'		=> 'Dossier actuel',
		'NEW_NAME'		=> 'Nouveau nom',
		'RENAME'		=> 'Renommer',
		'ALTER'			=> 'Modifier',
		'TITLE'			=> 'Renommez ou changez le dossier de vos données',
		'HELP'			=> 'Liste de tous les&nbsp;dossiers contenant un&nbsp;sous-dossier avec un&nbsp;fichier <strong>parametres.xml</strong>',
		'NEW_NAME_PLACEHOLDER'=> 'Pour ci-dessus ou un nouveau',
		'FOLDER'		=> 'Dossier',
		'NEW_FOLDER'	=> 'Nouveau dossier',
		'NAME_IN_USE'	=> 'Ce nom est déjà utilisé',
		'MISSING_NAME'	=> 'Précisez le nom\ndu nouveau dossier',
		'CONFIRM_RENAME'=> 'Voulez-vous renommer\nle dossier de données en cours',
		'EXISTS'		=> 'Le dossier #1 existe déjà.'
	);
?>
function myPagerOnsubmit(aForm) {
	var direct_pageInput = aForm.direct_page;
	var lastPageId = document.getElementById('last-page');
	var pattern = /^(.*page)(\d+)/;
	if (direct_pageInput && lastPageId) {
		var match1 = lastPageId.href.match(pattern);
		if (match1 && (match1.length == 3)) {
			var pageNu = parseInt(direct_pageInput.value);
			var lastPage = parseInt(match1[2]);
			if (/\d+/.test(pageNu) && (pageNu > 1) && (pageNu <= lastPage)) {
				document.location = match1[1] + pageNu;
			}
			else {
				direct_pageInput.focus();
				alert('<?php echo $msgError; ?>' + match1[2]);
			}
		}
	}
	else
		console.log('Input with direct_page name or node with "last-page" id not found');
	return false;
}

function callArticle(filename) {
	document.location = filename;
	return false;
}

// http://stackoverflow.com/questions/28975556/disable-keyboard-shortcut-when-colorbox-event-is-fired-and-then-restore-it-when
var canUseArrows = true;

function getRelLink(rel) {
	if (rel) {
		var query = 'link[rel^="' + rel + '"]';
		var node = document.querySelector(query);
		if (node)
			document.location = node.href
		else // javascript doesn't support associative arrays
			alert(msgMyPager[(rel == 'prev') ? 0 : 1]);
		return true;
	}
	return false;
}
$(document).ready(function() {
	console.log('init myPager');
	
	var prev = document.querySelector('head link[rel^="prev"]');
	var next = document.querySelector('head link[rel^="next"]');

	if ( prev || next ) {
		$(document).bind('keydown',
			function (e) {
				if (!e.altKey && !e.ctrlKey) {
					var rel = null;
					var key = e.keyCode;
					if (canUseArrows && (key == 37))
						rel = 'prev'
					else if (canUseArrows && (key == 39))
						rel = 'next'
					getRelLink(rel);
				}
			}
		);
	
		$(document).bind('cbox_open',
			function() {
				canUseArrows = false;
			}
		);
	
		$(document).bind('cbox_closed',
			function() {
				canUseArrows = true;
			}
		);
	
		// http://hammerjs.github.io
		var canvas = document.querySelector("main[role='main']");
		if (canvas) {
			var mc = new Hammer(canvas);
			mc.on('swipeleft', function(e) { getRelLink('next'); });
			mc.on('swiperight', function(e) { getRelLink('prev'); });
		} else
			console.log("main[role='main'] eleemnt not found");
	}
});

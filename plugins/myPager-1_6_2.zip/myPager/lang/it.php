<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Abilita il browser per gli articoli",
	'L_MYPAGER_BUTTONS'				=> "Mostra &lt;&lt; e &gt;&gt; pulsanti",
	'L_MYPAGER_DEFAULTCSS'			=> "Usa il foglio di stile predefinito",
	'L_MYPAGER_DELTA'				=> "Valore delta (<i> deve essere compreso tra 1 e 10 </i>) <sup>*</sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Input per un numero di pagina",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Salta alla pagina #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Visualizza la parola della pagina",
	'L_MYPAGER_FIRST_PAGE'			=> "Sei già sulla prima pagina!",
	'L_MYPAGER_INFO'				=> "<sup>*</sup> Il numero più alto di pulsanti visualizzati è uguale: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Sei già sull'ultima pagina!",
	'L_MYPAGER_NUMBER_ERROR'		=> "Il numero di pagina deve essere compreso tra 2 e",
	'L_MYPAGER_PAGE'				=> "pagine"
);
?>
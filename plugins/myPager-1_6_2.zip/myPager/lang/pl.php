<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Włącz przeglądarkę dla artykułów",
	'L_MYPAGER_BUTTONS'				=> "Wyświetl &lt; &lt; i  &gt;&gt; guziki",
	'L_MYPAGER_DEFAULTCSS'			=> "Użyj domyślnego arkusza stylów",
	'L_MYPAGER_DELTA'				=> "Wartość delta (<i> musi wynosić od 1 do 10 </i>) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Wprowadź numer strony",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Pomiń na stronie #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Wyświetl słowo strony",
	'L_MYPAGER_FIRST_PAGE'			=> "Jesteś już na pierwszej stronie!",
	'L_MYPAGER_INFO'				=> "<sup>*</ sup> Największa liczba wyświetlanych przycisków jest równa: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Jesteś już na ostatniej stronie!",
	'L_MYPAGER_NUMBER_ERROR'		=> "Numer strony musi należeć do zakresu od 2 do",
	'L_MYPAGER_PAGE'				=> "Strony"
);
?>

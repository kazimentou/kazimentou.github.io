<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Activer le navigateur d",
	'L_MYPAGER_BUTTONS'				=> "Afficher les boutons &lt;&lt; et &gt;&gt;",
	'L_MYPAGER_DEFAULTCSS'			=> "Utiliser feuille CSS par défault",
	'L_MYPAGER_DELTA'				=> "Valeur delta (<i>compris entre 1 et 10</i>)<sup>*</sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Saisir un n° de page",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Aller à la page",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Afficher le mot Page",
	'L_MYPAGER_FIRST_PAGE'			=> "Vous êtes déjà sur la première page !",
	'L_MYPAGER_INFO'				=> "<sup>*</sup> Le nombre le plus élevé de boutons affichés est égal à: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Vous êtes déjà sur la dernière page !",
	'L_MYPAGER_NUMBER_ERROR'		=> "Le numéro de page doit être compris entre 2 et",
	'L_MYPAGER_PAGE'				=> "Pages"
);
?>

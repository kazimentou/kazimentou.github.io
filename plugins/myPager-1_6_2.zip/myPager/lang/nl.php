<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Schakel de browser voor artikelen in",
	'L_MYPAGER_BUTTONS'				=> "Display &lt;&lt; en &gt;&gt; toetsen",
	'L_MYPAGER_DEFAULTCSS'			=> "Gebruik de standaard stylesheet",
	'L_MYPAGER_DELTA'				=> "Deltawaarde (<i> moet liggen tussen 1 en 10 </i>) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Invoer voor een paginanummer",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Skip op pagina #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Paginawoord weergeven",
	'L_MYPAGER_FIRST_PAGE'			=> "U staat al op de eerste pagina!",
	'L_MYPAGER_INFO'				=> "<sup>*</ sup> Het hoogste aantal weergegeven knoppen is gelijk: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "U bevindt zich al op de laatste pagina!",
	'L_MYPAGER_NUMBER_ERROR'		=> "Het paginanummer moet tussen 2 en",
	'L_MYPAGER_PAGE'				=> "Pages"
);
?>

<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Ativar o navegador para artigos",
	'L_MYPAGER_BUTTONS'				=> "Display &lt;&lt; e &gt;&gt; botões",
	'L_MYPAGER_DEFAULTCSS'			=> "Use a folha de estilos padrão",
	'L_MYPAGER_DELTA'				=> "O valor Delta (<i> deve estar entre 1 e 10 </i>) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Entrada para um número de página",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Salte na página #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Palavra da Página de exibição",
	'L_MYPAGER_FIRST_PAGE'			=> "Você já está na primeira página!",
	'L_MYPAGER_INFO'				=> "<sup>*</ sup> O número mais alto de botões exibidos é igual: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Você já está na última página!",
	'L_MYPAGER_NUMBER_ERROR'		=> "O número da página deve estar entre 2 e",
	'L_MYPAGER_PAGE'				=> "Páginas"
);
?>

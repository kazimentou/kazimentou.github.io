<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Habilitar el navegador para artículos",
	'L_MYPAGER_BUTTONS'				=> "Mostrar &lt;&lt; y & gt;&gt; botones",
	'L_MYPAGER_DEFAULTCSS'			=> "Use la hoja de estilo predeterminada",
	'L_MYPAGER_DELTA'				=> "El valor delta (<i> debe estar entre 1 y 10 </i>) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Entrada para un número de página",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Saltar en la página #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Mostrar palabra de página",
	'L_MYPAGER_FIRST_PAGE'			=> "¡Ya estás en la primera página!",
	'L_MYPAGER_INFO'				=> "<sup>*</sup> El mayor número de botones mostrados es igual: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "¡Ya estás en la última página!",
	'L_MYPAGER_NUMBER_ERROR'		=> "El número de página debe estar entre 2 y",
	'L_MYPAGER_PAGE'				=> "Páginas"
);
?>

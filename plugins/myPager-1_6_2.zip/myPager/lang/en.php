<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'=> 'Enable the browser for articles',
	'L_MYPAGER_BUTTONS'=> 'Display &lt;&lt; and &gt;&gt; buttons',
	'L_MYPAGER_DEFAULTCSS'=> 'Use the default stylesheet',
	'L_MYPAGER_DELTA'=> 'Delta value (<i>must be between 1 and 10</i>)<sup>*</sup>',
	'L_MYPAGER_DIRECT_PAGE'=> 'Innput for a page number',
	'L_MYPAGER_DIRECT_PAGE_LABEL'			=> 'Skip at page #',
	'L_MYPAGER_DISPLAY_PAGE'		=> 'Display Page word',
	'L_MYPAGER_FIRST_PAGE'=> 'You are already on the first page !',
	'L_MYPAGER_INFO'=> '<sup>*</sup>The most higher number of displayed buttons is equal : 2 x delta + 3.',
	'L_MYPAGER_LAST_PAGE'=> 'You are already on the last page !',
	'L_MYPAGER_NUMBER_ERROR'=> 'Page number must be between 2 and',
	'L_MYPAGER_PAGE'					=> 'Pages'
);
?>

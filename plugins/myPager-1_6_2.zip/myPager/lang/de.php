<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Aktivieren Sie den Browser für Artikel",
	'L_MYPAGER_BUTTONS'				=> "Anzeige &lt;&lt; und &gt;&gt; Tasten",
	'L_MYPAGER_DEFAULTCSS'			=> "Verwenden Sie das Standard-Stylesheet",
	'L_MYPAGER_DELTA'				=> "Delta-Wert (<i> muss zwischen 1 und 10 </i> sein) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Eingabe für eine Seitenzahl",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Überspringen auf Seite #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Seitenwort anzeigen",
	'L_MYPAGER_FIRST_PAGE'			=> "Du bist schon auf der ersten Seite!",
	'L_MYPAGER_INFO'				=> "<sup>*</sup> Die höchste Anzahl der angezeigten Schaltflächen ist gleich: 2 x Delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Sie sind bereits auf der letzten Seite!",
	'L_MYPAGER_NUMBER_ERROR'		=> "Seitenzahl muss zwischen 2 und liegen",
	'L_MYPAGER_PAGE'				=> "Seiten"
);
?>

<?php
$myPlugin = $plxAdmin->plxPlugins->aPlugins[$plugin];
?>
<h2><?php echo $myPlugin->getInfo('title'); ?></h2>
<h3>By <?php echo $myPlugin->getInfo('author'); ?></h3>
<div id="<?php echo get_class($myPlugin); ?>Help">
	<p>
		Le premier objectif de ce plugin est d'améliorer le côté esthétique de la pagination originelle de Pluxml. Il affiche un nombre constant de boutons dans la navigation des pages. On limite l'usage d'une langue comme le français pour faciliter un développement international. De plus la visualisation d'un signe "&lt;" est plus rapide que la lecture du mot "précèdent".
	</p><p>
		Si Pluxml a prévu une navigation entre pages, il n'existe rien pour naviguer entre articles dans une catégorie, pour un mot-clé, dans une archive, et même pour lire tous les articles en enfilade depuis la page d'accueil. Ce plugin remédie à cela. Le navigateur est affiché en bas de l'article. Vous pouvez le placer à l'endroit qu'il vous convient en utilisant le hook suivant comme ceci :
	</p>
	<code>
		&lt;?php eval($plxShow->callHook('showArticlesBar')); ?&gt;
	</code>
	<p>
		Plutôt que de cliquer sur les boutons pour naviguer, vous pouvez utiliser les flèches gauche et droite du clavier pour naviguer.
		Si vous avez une tablette ou un smartphone, vous pouvez faire votre doigt horizontalement sur l'écran tactile pour naviguer.
	</p><p>
		Afin d'améliorer le référencement du site sur Internet, le plugin insére dans l'entête de la page html, entre les balises &lt;head&gt; et &lt;/head&gt; les liens suivants :
		<ul>
			<li>&lt;link rel="prev" href="..." /&gt;</li>
			<li>&lt;link rel="next" href="..." /&gt;</li>
		</ul>
	</p>
	<p>
		Fait le 17/10/2015.
	</p>
</div>

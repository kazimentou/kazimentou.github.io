<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Включить браузер для статей",
	'L_MYPAGER_BUTTONS'				=> "Дисплей &lt;&lt; и &gt;&gt; &gt; кнопки",
	'L_MYPAGER_DEFAULTCSS'			=> "Использовать таблицу стилей по умолчанию",
	'L_MYPAGER_DELTA'				=> "Значение Delta (<i> должно быть от 1 до 10 </i>) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Вход для номера страницы",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Пропустить на странице #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Отображать слово страницы",
	'L_MYPAGER_FIRST_PAGE'			=> "Вы уже на первой странице!",
	'L_MYPAGER_INFO'				=> "<sup>*</ sup> Максимальное количество отображаемых кнопок равно: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Вы уже на последней странице!",
	'L_MYPAGER_NUMBER_ERROR'		=> "Номер страницы должен быть от 2 до",
	'L_MYPAGER_PAGE'				=> "страницы"
);
?>

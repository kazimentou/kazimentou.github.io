<?php
$LANG = array(
	'L_MYPAGER_ARTICLES_NAVIGATOR'	=> "Activați browserul pentru articole",
	'L_MYPAGER_BUTTONS'				=> "Afișați &lt;&lt; și &gt;&gt; butoane",
	'L_MYPAGER_DEFAULTCSS'			=> "Utilizați foaia de stil implicită",
	'L_MYPAGER_DELTA'				=> "Valoarea Delta (<i> trebuie să fie între 1 și 10 </i>) <sup>*</ sup>",
	'L_MYPAGER_DIRECT_PAGE'			=> "Introduceți un număr de pagină",
	'L_MYPAGER_DIRECT_PAGE_LABEL'	=> "Sari la pagina #",
	'L_MYPAGER_DISPLAY_PAGE'		=> "Afișați cuvântul paginii",
	'L_MYPAGER_FIRST_PAGE'			=> "Sunteți deja pe prima pagină!",
	'L_MYPAGER_INFO'				=> "<sup>*</ sup> Cel mai mare număr de butoane afișate este egal: 2 x delta + 3.",
	'L_MYPAGER_LAST_PAGE'			=> "Sunteți deja pe ultima pagină!",
	'L_MYPAGER_NUMBER_ERROR'		=> "Numărul paginii trebuie să fie între 2 și",
	'L_MYPAGER_PAGE'				=> "Pagini"
);
?>

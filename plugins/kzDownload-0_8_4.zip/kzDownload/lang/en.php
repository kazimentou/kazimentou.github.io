<?php
$LANG = array(
	'DOWNLOAD-FOLDER'	=> 'folder for downloading files',
	'SAVE'				=> 'Save',
	'DOWNLOADS'			=> 'Statistics of download',
	'FILENAME'			=> 'Filename',
	'SIZE'				=> 'Size',
	'DATE'				=> 'Last modification time.',
	'DESCRIPTION'		=> 'Description',
	'PUBLISHED'			=> 'Published on',
	'SUM'				=> 'Total',
	'AVERAGE'			=> 'Average',
	'WEEK'				=> 'Week #',
	'DELETE'			=> 'Delete',
	'CHART'				=> 'Chart',
	'MENU_NAME'			=> 'Hits Download',
	'MENU_TITLE'		=> 'Statistics per downloaded files',
	'NO_STAT'			=> 'No downloaded file'
);
?>

<?php

class MyZipArchive extends ZipArchive {

	public function __construct($filename, $root, $pattern='*.*', $comment='') {

		parent::__construct();

		$temp_dir = sys_get_temp_dir();
		if ($this->open($filename, ZipArchive::CREATE | ZipArchive::OVERWRITE) = true)) {
			if (!empty($comment))
				$this->setArchiveComment($comment);
			$this->add_dir($root, $pattern);
		}
		else
			die('building zipfile Aborted');
	}

	private add_dir($root, $pattern) {
	}
}

function export() {
	$root = '../../';
	$folders = array('articles', 'commentaires', 'configuration', 'configuration/plugins', 'statiques');
	$filename = $root.'data/archive-'.date('Y-m-d').'.zip';
	$zip = new ZipArchive();
	if ($zip->open($filename, ZipArchive::CREATE | ZipArchive::OVERWRITE) == true) {
		$zip->setArchiveComment('Archive du site');
		$zip->addFromString('lisezmoi.txt', 'coucou');
		foreach ($folders as $d) {
			$zip->addEmptyDir('data/'.$d); // for empty folder
			$pattern = $root.'data/'.$d.'/*.*';
			$zip->addGlob($pattern, GLOB_BRACE, array('add_path'=>'data/'.$d.'/', 'remove_all_path'=>true));
		}
		$zip->close();
	}
	else
		die('Création fichier zip impossible.')

	foreach (array(
		'Content-type: application/zip',
		'Pragma: public',
		'Cache-control: no-cache, must-revalidate',
		'Date: '.date('r'),
		'Expires: -1',
		'Content-Disposition: attachment; filename="'.basename($filename).'"',
		'Content-Length: '.filesize($filename)
		) as $v)
		header($v);
	readfile($filename);
	unlink($filename);
}

export();

?>

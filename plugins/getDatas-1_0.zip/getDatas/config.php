<?php

define('PASS_LENGTH', 20);

$params = array(
	'key1'=>'string', 'key2'=>'string',
	'duration'=>'numeric',
	'ip'=>'string', 'ip_mask_index'=>'numeric',
	'name'=>'string', 'from'=>'string'
	);
$hidden_params = array(	'pass1'=>'string', 'pass2'=>'string', 'lastdate'=>'numeric');
$default_params = array(
	'key1'=>'ali', 'key2'=>'baba',
	'pass1'=>plxUtils::charAleatoire(PASS_LENGTH), 'pass2'=>plxUtils::charAleatoire(PASS_LENGTH),
	'duration'=>10, 'lastdate'=>time(),
	'ip'=>'0.0.0.0', 'ip_mask_index'=>0,
	'from'=>'', 'name'=>'Webmaster'
	);
$ip_masks = array(32 , 24, 16, 8);

function send_passwords() {
	global $plxAdmin, $plxPlugin, $default_params;

	$user1 = $_SESSION['user'];

	$user = $plxAdmin->aUsers['001'];
	$name = $plxPlugin->getParam('name');
	$from = $plxPlugin->getParam('from');
	$to = $user['email'];
	$subject = 'New instructions to save your datas';
	$login = $user['login'];
	$key1 = $plxPlugin->getParam('key1');
	$key2 = $plxPlugin->getParam('key2');
	$pass1 = $default_params['pass1'];
	$pass2 = $default_params['pass2'];
	$duration = $plxPlugin->getParam('duration');
	$url = $plxAdmin->racine.'core/admin/auth.php';
	$body = <<<EOT
Dear $login,

Request at $url?$key1=$pass1,
Wait for $duration minutes,
Request at $url?$key2=$pass2&action=save to get zip archive of datas.
That' all.

Yours
EOT;
	plxUtils::sendMail($name, $from, $to, $subject, $body);
}

// controls that several $POST['key1'] exists with key1 in $list array
function post_exists($params1) {
	$result = true;
	foreach (array_keys($params1) as $k) {
		if (!($k == 'ip_mask_index') && empty($_POST[$k])) {
			$result = false;
			break;
		}
	}
	return $result;
}

$header = 'Location: parametres_plugin.php?p='.$plugin;

if (! empty($_POST['new_passwords'])) {
	foreach ($hidden_params as $param_name=>$param_type) {
		$value = $default_params[$param_name];
		if ($param != 'lastdate')
			$value = sha1($value);
		$plxPlugin->setParam($param_name, $value, $param_type);
	}
	$plxPlugin->saveParams();
	send_passwords();
	header($header);
	exit;
}
elseif (post_exists($params)) { // save the parameters
	foreach ($params as $param_name=>$param_type)
		$plxPlugin->setParam($param_name, $_POST[$param_name], $param_type);
	foreach (array_keys($folders) as $param_name)
		$plxPlugin->setParam($param_name, $_POST[$param_name], 'numeric');
	$plxPlugin->saveParams();
	header($header);
	exit;
}

$folders = array(
	'racine_articles'		=> L_CONFIG_ADVANCED_ARTS_FOLDER,
	'racine_commentaires'	=> L_CONFIG_ADVANCED_COMS_FOLDER,
	'racine_statiques'		=> L_CONFIG_ADVANCED_STATS_FOLDER,
	'images'				=> L_CONFIG_ADVANCED_PICS_FOLDER,
	'documents'				=> L_CONFIG_ADVANCED_DOCS_FOLDER,
	'racine_themes'			=> L_CONFIG_ADVANCED_THEMES_FOLDER,
	'racine_plugins'		=> L_CONFIG_ADVANCED_PLUGINS_FOLDER
);

?>

<!-- begin plugins/getDatas.php/config.php -->
		<h2><?php echo $plxPlugin->getInfo('title'); ?></h2>
		<p class="center"><?php $mail_ok = plxUtils::testMail(); ?></p>
		<form id="form_<?php echo ($plxPlugin->name); ?>" action="<?php echo ($$url); ?>" method="post" onsubmit="return getdatas_submit_click(this);">
<?php foreach ($params as $field=>$type) : ?>
			<p class="field">
				<label for="id_<?php echo ($field); ?>"><?php $plxPlugin->lang('L_PARAM_'.strtoupper($field)); ?></label>
<?php
	$value = $plxPlugin->getParam($field);
	if (empty($value)) $value = $default_params[$field];
	$tab1 = "\t\t\t\t";
	switch ($field) :
		case 'ip_mask_index' :
			echo ($tab1); plxUtils::printSelect($field, $ip_masks, $value);
			break;
		default :
			echo ($tab1); plxUtils::printInput($field, $value, 'text', '15-20');
			break;
	endswitch;
	switch ($field) :
		case 'duration' :
			echo 'minutes';
			break;
		case 'ip' ;
			echo '<input type="button" value="<< IP local" onclick="copy_remote_ip(\'id_ip\', \''.$_SERVER['REMOTE_ADDR'].'\')">';
			break;
	endswitch; ?>
			</p>
<?php
endforeach; ?>
			<p><label>Dossiers à archiver</label>&nbsp;:</p>
<?php
$items = array('1'=>L_YES, '0'=>L_NO);
foreach ($folders as $field=>$caption) :
	$value = $plxPlugin->getParam($field);
	if (empty($value))
		$value = '0'; ?>
		<p>
			<label for="id_<?php echo $field; ?>"><?php echo $caption; ?></label>
			<?php plxUtils::printSelect($field, $items, $value); ?>
		</p>
<?php endforeach; ?>
			<p class="field">
				<label><?php echo $plxPlugin->lang('L_SAVE_PARAMS'); ?></label>
				<input type="submit">
			</p>
		</form>
		<form method="post" onsubmit="return confirm('<?php echo $plxPlugin->lang('L_NEWPASS_CONFIRM'); ?>');">
			<p class="field">
				<label><?php $plxPlugin->lang('L_PARAM_NEW_PASSORDS'); ?></label>
				<input type="hidden" name="new_passwords" value="1" />
				<input type="submit" />
			</p>
		</form>
<!-- end plugins/getDatas.php/config.php -->

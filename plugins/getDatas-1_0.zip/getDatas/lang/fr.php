<?php

$LANG = array(

# config.php
'L_PARAM_KEY1'			=>'Clé n°1',
'L_PARAM_KEY2'			=>'Clé n°2',
'L_PARAM_DURATION'		=>'Temps d\'attente',
'L_PARAM_IP'			=>'Adresse IP autorisée',
'L_PARAM_IP_MASK_INDEX'	=>'Masque IP',
'L_PARAM_USER_TITLE'	=>'Sauvegarde des données',
'L_PARAM_NEW_PASSORDS'	=>'Envoi de nouveaux mots de passes',
'L_PARAM_NAME'			=>'Nom de l\'expéditeur',
'L_PARAM_FROM'			=>'Adresse email expéditeur',
'L_SAVE_PARAMS'			=>'Sauvegarder la configuration',
'L_NEWPASS_CONFIRM'		=>'Voulez-vous recevoir de nouveaux mots de passe',
);

?>

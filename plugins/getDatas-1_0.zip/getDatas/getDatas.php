<?php
if (!defined('PLX_ROOT')) exit;

class getDatas extends plxPlugin {

	/**
	 * Constructeur de la classe
	 *
	 * @param	default_lang	langue par défaut
	 * @return	stdio
	 * @author	Jean-Pierre P.
	 **/

	public $folders = array(
		'racine_articles'		=> L_CONFIG_ADVANCED_ARTS_FOLDER,
		'racine_commentaires'	=> L_CONFIG_ADVANCED_COMS_FOLDER,
		'racine_statiques'		=> L_CONFIG_ADVANCED_STATS_FOLDER,
		'images'				=> L_CONFIG_ADVANCED_PICS_FOLDER,
		'documents'				=> L_CONFIG_ADVANCED_DOCS_FOLDER,
		'racine_themes'			=> L_CONFIG_ADVANCED_THEMES_FOLDER,
		'racine_plugins'		=> L_CONFIG_ADVANCED_PLUGINS_FOLDER
	);


	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accèder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		# déclaration des hooks

		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminPrepend', 'AdminPrepend');

		if (plxUtils::checkMail($this->getParam('email'))) {
			// $this->addHook('Index', 'Index');
		//	$this->addHook('plxMotorPreChauffageBegin', 'plxMotorPreChauffageBegin');
		//	$this->addHook('plxShowStaticContent', 'plxShowStaticContent');
		//	$this->addHook('plxShowConstruct', 'plxShowConstruct');
		//	$this->addHook('plxShowStaticListEnd', 'plxShowStaticListEnd');
		//	$this->addHook('plxShowPageTitle', 'plxShowPageTitle');
		//	$this->addHook('ThemeEndHead', 'ThemeEndHead');
		//	$this->addHook('SitemapStatics', 'SitemapStatics');
		}
	}

	private function export() {
		global $plxAdmin;
		// $plxAdmin->aConf[];

		$filename = PLX_ROOT.'data/archive-'.date('Y-m-d').'.zip';
		$zip = new ZipArchive();
		if ($zip->open($filename, ZipArchive::CREATE | ZipArchive::OVERWRITE) == true) {
			$zip->setArchiveComment('Archive du site');
			$zip->addFromString('lisezmoi.txt', 'coucou');
			foreach (array_keys($this->folders) as $d) {
				$zip->addEmptyDir($d); // for empty folder
				$pattern = PLX_ROOT.$plxAdmin->aConf[$d].'*.*';
				$zip->addGlob($pattern, GLOB_BRACE, array('add_path'=>'data/'.$d.'/', 'remove_all_path'=>true));
			}
			$zip->close();
		}

		foreach (array(
			'Content-type: application/zip',
			'Pragma: public',
			'Cache-control: no-cache, must-revalidate',
			'Expires: -1',
			'Date: '.date('r'),
			'Content-Disposition: attachment; filename="'.basename($filename).'"',
			'Content-Length: '.filesize($filename)
			) as $v)
			header($v);
		readfile($filename);
		unlink($filename);
	}

	public function AdminTopEndHead() { ?>
		<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
<?php
	}

	public function AdminPrepend() {
		global $plxAdmin;

		if (defined('PLX_AUTHPAGE')) :
			$key1 = $this->getParam('key1');
			$key2 = $this->getParam('key2');
			if (!empty($_GET[$key1])) :
				$value = $_GET[$key1];
				$value = sha1($value);
				if ($value == $this->getParam('pass1')) :
					$this->setParam('lastdate', time(), 'numeric');
					$this->export();
					// envoi mail
					exit;
				endif;
			else :
				if (! empty($_GET[$key2])) :
				header('Content-Type: text/text; charset='.PLX_CHARSET);
				echo ("Coucou !!\n");
				die('$key2 has '.$_GET[$key2].' value.');
				endif;
			endif;
		endif;
	}
}
?>

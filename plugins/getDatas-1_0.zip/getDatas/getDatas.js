function validateEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}

function validateIp(ip) {
	var regex = /^[1-9][0-9]{1,2}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/;
	return regex.test(ip);
}

function getdatas_submit_click(aForm) {
	var result = true;
	for (var k in ['key1', 'key2', 'name']) {
		var elmt = aForm[k];
		if ( ! elmt || elmt.length == 0) {
			result = false;
			alert('No value for '+k+' entry !!');
		}
	}
	if (result) {
		var d = aForm['duration'];
		if (!d  || !(/^\d+$/.test(d.value))) {
			result = false;
			alert('Only number for duration');
		}
	}
	if (result) {
		var mail = aForm['from'];
		if ( !mail || ! validateEmail(mail.value)) {
			result= false;
			alert('Invalid e-mail address !!');
		}
	}
	if (result) {
		var ip = aForm['ip'];
		if (!ip || ! validateIp(ip.value)) {
			result = false;
			alert('Invalid IP address');
		}
	}
	return result;
}

/*
id="id_duration"
id="id_ip"
*/

function copy_remote_ip(target, value1) {
	var t = document.getElementById(target);
	if (t)
		t.value = value1;
}

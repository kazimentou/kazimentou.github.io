#!/bin/sh

# curl https://api.github.com/repos/tinymce/tinymce/tags | jq -r '.[0] | zipball_url' | wget ....
# sudo apt install nodejs-legacy npm
# npm --version
# node --version
# git clone --depth 1 https://github.com/tinymce/tinymce.git
# cd tinymce
# sudo npm update -g
# npm install
# grunt
# cd ..
# unzip tinymce/tmp/tinymce_X.X.X.zip
# mv dist tinymce

OLDDIR="$(pwd)"
TMPFILE=$(tempfile -p PluX_)

clear

msg () {
	echo "\033[1;32m${1}\033[0m"
}

cleanup () {
	rm ${TMPFILE}
	cd ${OLDDIR}
}

cd $(dirname $(realpath $0))

# what languages are useful for us ?
langs=$(\
ls -d ../../core/lang/* | \
sed '/index.html$/d; s/^.*\/\(\w\+\)/\1/; s/fr/fr_FR/; s/pt/pt_PT/' | \
tr '\n' ',' | \
sed 's/,$//')

trap "cleanup" SIGINT
url="https://tinymce-services.azurewebsites.net/1/i18n/download?langs=${langs}"
msg "Getting ${url}..."
wget -O ${TMPFILE} "${url}"
# stat ${TMPFILE}

# unzip all the languages in the right place
TARGET="tinymce/js/tinymce/"

# Maybe the minified library of Tinymce is on the cloud and we just need languages
[ -d ${TARGET} ] || mkdir -p ${TARGET}

msg "unzip in: $(realpath $TARGET)"
unzip -d "$TARGET" ${TMPFILE}
cleanup
msg "That's done. Congratulations !"

# pour construire le bundle de tinyMCE avec tous les plugins :
# grunt bundle --themes=modern --plugins=wordcount,fullscreen,save,visualchars,charmap,advlist,autolink,link,image,imagetools,media,lists,hr,anchor,emoticons,searchreplace,preview,visualblocks,nonbreaking,table,contextmenu,directionality,template,paste,textcolor,autoresize,help,autosave,code,codesample
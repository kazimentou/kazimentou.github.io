<?php
if (!defined('PLX_ROOT')) exit;

// from parametres_users.php
# Tableau des profils

$aProfils = array(L_PROFIL_ADMIN, L_PROFIL_MANAGER, L_PROFIL_MODERATOR, L_PROFIL_EDITOR, L_PROFIL_WRITER);
$aShortProfils = explode(' ', $plxPlugin->getLang('SHORT_PROFIL_NAMES'));

# Control du token du formulaire
plxToken::validateFormToken($_POST);

$params = array(
	'skin'			=> 'string',
	'cdn'			=> 'boolean',
	'article'		=> 'numeric',
	'statique'		=> 'numeric',
	'comment'		=> 'numeric',
	'comment_new'	=> 'numeric',
	'user'			=> 'numeric',
	// 'parametres_edittpl'=>'numeric',
	'codemirror'	=> 'numeric',
	'selector'		=> 'string',
	'comment_site'	=> 'boolean',
	'css_theme'		=> 'boolean', 'styleformats'=>'cdata',
	'style_formats_merge' => 'boolean',
);

foreach(array_keys($aProfils) as $k) {
	$params['plugins'.$k] = 'string';
}

if (!empty($_POST)) {
	foreach ($params as $field=>$type) {
		if (!empty($_POST[$field])) {
			switch ($type) {
				case 'boolean' :
					$value = 1;
					break;
				case 'numeric' :
					if(is_array($_POST[$field])) {
						$value = array_sum($_POST[$field]);
					} else {
						$value = filter_input(INPUT_POST, $field, FILTER_SANITIZE_NUMBER_INT);
						// $value = $_POST[$field];
					}
					break;
				case 'string' :
					if(is_array($_POST[$field])) {
						$buf = $_POST[$field];
						sort($buf);
						$value = implode(' ', $buf);
						break;
					}
				default : // Autres $field de type string ou cdata
					// $value = filter_input(INPUT_POST, $field, FILTER_SANITIZE_STRING,
/*
FILTER_FLAG_NO_ENCODE_QUOTES,
FILTER_FLAG_STRIP_LOW,
FILTER_FLAG_STRIP_HIGH,
FILTER_FLAG_STRIP_BACKTICK,
FILTER_FLAG_ENCODE_LOW,
FILTER_FLAG_ENCODE_HIGH,
FILTER_FLAG_ENCODE_AMP					);
* */
					$value = $_POST[$field];
			}
		} else {
			$value = false;
		}
		if(!empty($value))
			$plxPlugin->setParam($field, $value, ($type == 'boolean') ? 'numeric' : $type);
		else
			$plxPlugin->delParam($field);
	}
	$plxPlugin->saveParams();
	$_SESSION['mce-tabs'] = $_POST['mce-tabs']; // mémorise le dernier onglet utilisé dans le panneau de config
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

$tabs_list = array(
	'main'		=> 'Principal',
	'css'		=> 'CSS',
	'plugins'	=> 'Plugins'
);

if(empty($_SESSION['mce-tabs']) or !array_key_exists($_SESSION['mce-tabs'], $tabs_list)) {
	$_SESSION['mce-tabs'] = 'main';
}

function print_radio_tab($name) {
	$checked = ($_SESSION['mce-tabs'] == $name) ? ' checked' : '';
	echo <<< RADIO_BTN
		<input type="radio" id="$name-nav" name="mce-tabs" value="$name"$checked />

RADIO_BTN;
}
/* *********** display the form ************* */
define('MCE_PROFILS_LABEL', $plxPlugin->getLang('PROFIL_USERS'));
function print_profils_header($moreClass=false) {
	global $aProfils, $aShortProfils;

	$className = 'mce-profils-header';
	if (! empty($moreClass)) {
		$className .= ' '.$moreClass;
	} ?>
			<div class="<?php echo $className; ?>">
				<label><?php echo MCE_PROFILS_LABEL; ?></label>
				<div>
<?php
	foreach ($aProfils as $profil=>$caption) { ?>
				<span title="<?php echo $caption; ?>" data-profil="<?php echo $profil; ?>"><?php echo $aShortProfils[$profil]; ?>.</span>
<?php
	} ?>
				</div>
			</div>
<?php
}

if (! file_exists(PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.$plugin.'.xml')) {
	$plxPlugin->initValues();
}

$skins = $plxPlugin->get_skins();
$codemirror_plugin_lib = substr(__DIR__, 0, -strlen($plugin)).'codemirror/codemirror.min.js';
$is_codemirror_plugin_exists = array_key_exists('codemirror', $plxAdmin->plxPlugins->aPlugins) and file_exists(PLX_PLUGINS.'codemirror/tinymce/plugin.min.js');
?>

	<ul id="mce-config-nav">
<?php
	foreach($tabs_list as $for=>$caption) {
		$className = ($for == $_SESSION['mce-tabs']) ? ' class="active"' : '';
		echo <<< LABEL
		<li><label for="$for-nav"$className>$caption</li>

LABEL;
	}
?>
	</ul>
	<form id="form_<?php echo $plugin; ?>" method="post">
<?php print_radio_tab('main'); ?>
		<div id="tab1"> <!-- --------- onglet principal ----------- -->
<?php
$css_theme = false;
foreach ($params as $field=>$type) {

	if (strpos($field, 'plugins') === 0) {
		continue;
	}
	if ($field == 'css_theme') {
		// changement d'onglet ?>
		</div>
<?php print_radio_tab('css'); ?>
		<div id="css-rules"> <!-- ----- onglet régles CSS -------- -->
<?php
		$css_theme = true;
	}
	$value = $plxPlugin->getParam($field);
	if ($type == 'numeric')
		$value = intval($value);
	else
		$value = plxUtils::strCheck($value);

	switch($type) {
		case 'cdata':	$classLabel = ' class="large"'; break;
		case 'numeric':	$classLabel = ' class="multi-users"'; break;
		default :		$classLabel = '' ;
	}
	$forAttr = ($type == 'numeric') ? '' : ' for="id_'.$field.'"';
	// Adding titles of columns for users' profil
	if ($field == 'article') {
		print_profils_header('main-tab');
	}
?>
			<div <?php if($type == 'numeric') echo ' class="multi"';?>>
<?php
	if(!$css_theme or ($type == 'cdata')) { ?>
				<label <?php echo $classLabel.$forAttr; ?>><?php $plxPlugin->lang(strtoupper($field)); ?></label>
<?php
	}
		switch ($type) {
			case 'numeric' : // checkbox for each profil user
				$disabled = (($field != 'codemirror') or $is_codemirror_plugin_exists) ? '' : ' disabled';
?>
				<div>
<?php
				foreach (array_keys($aProfils) as $profil) {
					$checked = (($value & $plxPlugin->weightProfils[$profil]) > 0) ? ' checked' : '';
?>
					<input type="checkbox" name="<?php echo $field.'[]'; ?>" value="<?php echo $plxPlugin->weightProfils[$profil]; ?>"<?php echo $checked.$disabled; ?> />
<?php
				}
				if (($field == 'codemirror') and ! $is_codemirror_plugin_exists) {
					echo '<span>'.$plxPlugin->getLang('MISSING_PLUGIN').'</span>';
				}
?>
				</div>
<?php
				break;
			case 'boolean' :
				$checked = (empty($value)) ? '' : ' checked'; ?>
				<input id="id_<?php echo $field; ?>" type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
				if ($field == 'cdn') {
					$localLib = $plxPlugin->getLang(((is_readable(__DIR__.$plxPlugin::LOCAL_MINIFY_LIB) ? 'LIB_FOUND' : 'LIB_MISSING')));
					echo "<i>$localLib</i>\n";
				}
				break;
			case 'cdata' : ?>
				</div>
				<?php plxUtils::printArea($field, $value, 30, 10); ?>
				<div>
<?php
				break;
			default : // type string
				switch ($field) {
					case 'skin' :
						plxUtils::printSelect($field, $plxPlugin->get_skins(), $value);
						break;
					default :
						plxUtils::printInput($field, $value, 'text', '5-160', false);
						break;
				}
				break;
		}
	if($css_theme and ($type != 'cdata')) { ?>
				<label <?php echo $forAttr; ?>><?php $plxPlugin->lang(strtoupper($field)); ?></label>
<?php
	}
?>
			</div>
<?php
} // fin de: foreach ($params as $field=>$type) {
?>
		</div>
<?php print_radio_tab('plugins'); ?>
		<div id="mce-plugins"> <!-- list of plugins for each user profil -->
			<div> <!-- First column of plugins -->
<?php print_profils_header();
				$mce_plugins = explode(' ', $plxPlugin::MCE_PLUGINS);
				sort($mce_plugins);
				$n = intval(count($mce_plugins) / 2 + 0.5);
				$mcePluginsProfils = array();
				foreach (array_keys($aProfils) as $profil) {
					$buf = $plxPlugin->getParam('plugins'.$profil);
					$mcePluginsProfils[$profil] = (!empty($buf)) ? explode(' ', $buf) : array();
				}
				foreach($mce_plugins as $pl) { ?>
					<p class="multi">
						<label title="<?php $plxPlugin->lang(strtoupper('PLUGIN_'.$pl));?>"><?php echo $pl; ?></label>
<?php				foreach($mcePluginsProfils as $profil=>$plugins) {
						$checked = in_array($pl, $plugins) ? ' checked' : '';
						echo <<< PLUGIN_BY_PROFIL
					<input type="checkbox" name="plugins{$profil}[]" value="$pl"{$checked} />
PLUGIN_BY_PROFIL;
				}
?>
					</p>
<?php				$n--;
					if ($n == 0 ) { ?>
			</div><div>  <!-- Second column of plugins -->
<?php print_profils_header();
					}
				}
?>
			</div>
		</div>
		<div class="in-action-bar">
			<?php echo plxToken::getTokenPostMethod()."\n"; ?>
			<input type="submit" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>">
			<img class="plugin-logo" src="<?php echo $plxPlugin->plx_plugin_root; ?>icon.png" />
		</div>
	</form>
	<script type="text/javascript">
	(function() {
		"use strict;"

		function checkAllProfilsClick(event) {
			if (event.target.tagName == 'LABEL') {
				event.preventDefault();
				var target = event.target;
				var row = target.parentNode;
				if (row.classList.contains('multi')) {
					var checkboxes = row.querySelectorAll('input[type="checkbox"]');
					for (i=0, iMax=checkboxes.length; i<iMax; i++) {
						var elm = checkboxes[i];
						elm.checked = (event.detail > 1) ? false : ! elm.checked;
					}
				}
			}
		}

		document.querySelectorAll('.multi-users, #mce-plugins').forEach(function(item) {
			item.addEventListener('click', checkAllProfilsClick);
			item.addEventListener('dblclick', checkAllProfilsClick);
		});

		function profilClick(event) {
			if (event.target.tagName == 'SPAN') {
				event.preventDefault();
				var target = event.target;
				var profil = target.getAttribute('data-profil');
				if (profil) {
					var checkboxes = null;
					if (target.parentNode.classList.contains('main-tab')) {
						var weights = <?php echo json_encode($plxPlugin->weightProfils); ?>;
						checkboxes = document.querySelectorAll('#tab1 .multi input[value="'+weights[profil]+'"]');
					} else {
						checkboxes = document.querySelectorAll('#mce-plugins input[name="plugins'+profil+'[]"]');
					}
					for (i=0, iMax=checkboxes.length; i<iMax; i++) {
						var elm = checkboxes[i];
						elm.checked = (event.detail > 1) ? false : ! elm.checked;
					}
				}
			}
		}

		document.querySelectorAll('.mce-profils-header').forEach(function(item) {
			item.addEventListener('click', profilClick);
			item.addEventListener('dblclick', profilClick);
		});

		document.querySelectorAll('input[id][name="mce-tabs"]').forEach(function(input) {
			input.addEventListener('change', function(item) {
				var id1 = this.id;
				document.querySelectorAll('#mce-config-nav label[for]').forEach(function(label) {
					if(label.getAttribute('for') == id1) {
						label.classList.add('active');
					} else {
						label.classList.remove('active');
					}
				});
			});
		});
	})();
	</script>
<?php
$LANG = array(
	'DOWNLOAD-FOLDER'	=> 'Dossier de téléchargement',
	'SAVE'				=> 'Enregistrer',
	'DOWNLOADS'			=> 'Statistiques de téléchargements',
	'FILENAME'			=> 'Nom du fichier',
	'SIZE'				=> 'Taille',
	'DATE'				=> 'Date modif.',
	'DESCRIPTION'		=> 'Description',
	'PUBLISHED'			=> 'Publié le',
	'SUM'				=> 'Total',
	'AVERAGE'			=> 'Moyenne',
	'WEEK'				=> 'sem. n°',
	'DELETE'			=> 'Supprimer',
	'CHART'				=> 'Graphique',
	'MENU_NAME'			=> 'Stats Télécharg.',
	'MENU_TITLE'		=> 'Statistiques de téléchargement'
);
?>

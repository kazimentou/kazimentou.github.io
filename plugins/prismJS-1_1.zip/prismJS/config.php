<?php

if (!defined('PLX_ROOT')) exit;

$fields = array(
	'theme'	=> 'string'
);

if (!empty($_POST)) {
	plxToken::validateFormToken();

	foreach ($fields as $field=>$type) {
		$value = $_POST[$field];
		if(empty($value)) {
			$plxPlugin->delParam($field);
		} else {
			$plxPlugin->setParam($field, $value, $type);
		}
	}
	$plxPlugin->saveParams();

	$plxPlugin->build_themes();

	header('Location: parametres_plugin.php?p='.urlencode($plugin));
	exit;
}

$default_values = array();

$themes = array();
foreach(glob(__DIR__.'/prism/css/*.css') as $item) {
	$key = preg_replace('@^.*/prism-([^/]+)\.css$@', '$1', $item);
	$themes[$key] = $key;
}
$selects = array(
	'theme' => $themes
);

$value = trim($plxPlugin->getParam('theme'));
$theme_link = (!empty($value)) ? PLX_PLUGINS.$plugin.'/prism/css/prism-'.$value.'.css' : '';
/* ------------ HTML page starts here -------------- */
?>

		<form id="form_<?php echo $plugin; ?>" method="post">
<?php	foreach ($fields as $field=>$type) {
			$value = $plxPlugin->getParam($field);
			if (!empty($value))
				$value = plxUtils::strCheck($value);
			else
				$value = (array_key_exists($field, $default_values)) ? $default_values[$field] : '';
?>
			<p>
				<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.strtoupper($field)); ?></label>
<?php
			switch($type) {
				case 'string':
					if(array_key_exists($field, $selects)) {
						plxUtils::printSelect($field, $selects[$field], $value);
					} else {
						plxUtils::printInput($field, $value);
					}
					break;
			}
?>
			</p>
<?php
		}
?>
			<p>
				<?php echo plxToken::getTokenPostMethod(); ?>
				<label>&nbsp;</label>
				<input type="submit" />
			</p>
		</form>
		<div class="myprism-grid">
			<div>
				<p>Ex: &lt;pre class="line-numbers" data-src="&lt;?php echo PLX_PLUGINS.$plugin.'/demo-config.php'; ?>">&lt;/pre></p>
				<pre class="line-numbers" data-src="<?php echo PLX_PLUGINS.$plugin.'/demo-config.php'; ?>"></pre>
			</div>
			<div>
				<p>Ex: &lt;pre class="language-js" data-jsonp="https://api.github.com/repos/pluxml/PluXml/contents/core/lib/multifiles.js">&lt;/pre></p>
				<pre class="language-js" data-jsonp="https://api.github.com/repos/pluxml/PluXml/contents/core/lib/multifiles.js"></pre>
			</div>
		</div>
		<script type="text/javascript">
			(function() {

				'use strict';

				const href_template = '<?php echo $plxAdmin->aConf['racine_plugins'].$plugin; ?>/prism/css/prism-####.css';
				var themeSelect = document.getElementById('id_theme');
				if(themeSelect != null) {
					function loadStyleSheet() {
						var	theme = themeSelect.value,
							styleSheet = document.head.querySelector('link[rel="alternative stylesheet"][title="' + theme + '"]'),
							href = href_template.replace('####', theme);
						if(styleSheet == null) {
							styleSheet = document.createElement('LINK');
							styleSheet.title = theme;
							styleSheet.rel = 'alternative stylesheet';
							styleSheet.href = '<?php echo PLX_ROOT; ?>' + href;
							document.head.appendChild(styleSheet);
						}
						document.head.querySelectorAll('link[rel="alternative stylesheet"]').forEach(function(elmt) {
							elmt.disabled = (elmt.title != theme);
						});

						var caption = document.getElementById('theme-link');
						if(caption != null) {
							caption.innerHTML = href;
						}

						var copyClipboard = document.querySelector('#copy-clipboard[data-clipboard-text]');
						if(copyClipboard != null) {
							copyClipboard.setAttribute('data-clipboard-text', href);
						}

					}

					themeSelect.addEventListener('change', loadStyleSheet);

					loadStyleSheet();

				} else {
					console.log('unknown #id_theme element');
				}

			})();

		</script>
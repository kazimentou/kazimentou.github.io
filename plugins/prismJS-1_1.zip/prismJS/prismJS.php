<?php

if (!defined('PLX_ROOT')) exit;

# http://telechargements.pluxml.org/docs/PluXml_-_Plugins_Guide_du_developpeur.pdf
# http://prismjs.com/

class prismJS extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->setConfigProfil(PROFIL_ADMIN);

		# Ajouts des hooks
		$scriptname = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		if(
			($scriptname == 'parametres_plugin') and
			!empty($_REQUEST['p']) and
			($_REQUEST['p'] == __CLASS__)
		) {
			$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
			$this->addHook('AdminFootEndBody', 'ThemeEndBody');
		}
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

	public function build_themes() {
		global $plxAdmin;

		$theme = $this->getParam('theme');
		if(empty($theme)) {
			$theme = 'default';
		}

		$today = date('c');
		$header = "/* Build on $today. Do not change manually. */\n\n";
		$contents = array(
			'admin'	=> $header,
			'site'	=> $header
		);

		foreach(array_keys($contents) as $f) {
			$contents[$f] .= file_get_contents(__DIR__.'/css/'.$f.'.css')."\n";
		}

		$contents['site'] .= file_get_contents(__DIR__."/prism/css/prism-$theme.css")."\n";

		$buf = '';
		foreach(glob(__DIR__.'/prism/css/plugins/*.css') as $filename) {
			$buf .= file_get_contents($filename)."\n";
		}
		foreach(array_keys($contents) as $f) {
			$contents[$f] .= $buf;
			$filename = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.'.$f.'.css';
			if(!plxUtils::write($contents[$f], $filename) or !$plxAdmin->plxPlugins->cssCache($f)) {
				plxMsg::Error(L_SAVE_FILE_ERROR);
			}
		}
	}

	public function AdminTopEndHead() {
		switch(basename($_SERVER['PHP_SELF'], '.php')) {
			case 'article':
				$pluginRoot = PLX_PLUGINS.__CLASS__.'/';
				$theme = $this->getParam('theme');
				if(empty($theme)) {
					$theme = 'default';
				}
?>
	<link type="text/css" rel="stylesheet" href="<?php echo "{$pluginRoot}prism/css/prism-{$theme}.css"; ?>" />
<?php
				break;
		}

	}

	public function ThemeEndHead() {
		$theme = $this->getParam('theme');
		$pluginRoot = PLX_PLUGINS.__CLASS__;
		if(!empty($theme)) {
?>
	<link type="text/css" rel="stylesheet" href="<?php echo "{$pluginRoot}/prism/css/prism-{$theme}.css"; ?>" />
<?php
		}
	}

	public function ThemeEndBody() {
		global $plxShow, $plxAdmin;

		$pluginRoot = PLX_PLUGINS.__CLASS__.'/';
		// PLX_ROOT = './' plante PrimJS
		$data_path = preg_replace('@^'.PLX_ROOT.'@', (isset($plxShow)) ? $plxShow->plxMotor->racine : $plxAdmin->racine, $pluginRoot);
?>
	<script type="text/javascript" src="<?php echo $pluginRoot; ?>clipboard.min.js"></script>
	<script type="text/javascript" src="<?php echo $pluginRoot; ?>prism/prism.js" data-autoloader-path="<?php echo $data_path ?>prism/components/"></script>
	<script type="text/javascript">
<?php
	// Copie le lien de la feuille CSS dans le presse-papier pour être utilisé dans la configuration de Tinymce
	// https://clipboardjs.com/
?>
		if(document.getElementById('copy-clipboard') != null) {
			new Clipboard('#copy-clipboard');
		}
	</script>
<?php
	}

}

?>
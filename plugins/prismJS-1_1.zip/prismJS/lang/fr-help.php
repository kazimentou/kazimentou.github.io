<div class="myprism-help">
	<p>Ce plugin utilise la bibliothèque PrimsJS pour apporter une coloration syntaxique à un fragment de code (snippet).</p>
	<p>
		Pour afficher du code avec cette coloration, il existe 3 possibilités :
	</p>
	<ol>
		<li>Insérer le code dans la page web entre les balises :
	<pre><code>&lt;pre class="line-numbers language-xxxx">&lt;code>
    &lt;style type="text/css">
        body { background-color: #fff; }
    &lt;/style>
&lt;/code>&lt;/pre></code></pre>
		en remplaçant xxxx par le langage utilisé par le code (<em>html, php, css, ...</em>). La class <strong>line-numbers</strong>, qui n'est pas obligatoire, permet de numéroter les lignes.</li>
		<li>Insérer simplement le lien vers le fichier contenant le code à afficher avec une balise &lt;pre> vide avec un attribut <strong>data-src</strong> :
	<pre><code>&lt;pre data-src="data/medias/snippets/mon-fragment.html">&lt;/pre></code></pre>
		Il n'est pas nécessaire de préciser Le langage utilisé. Il sera déduit de l'extension du fichier.
		</li>
		<li>Le fichier peut être hébergé dans un dépôt Github, Github Gist ou Bitbucket. Préciser son URI et le type de langage dans une balise vide avec un attribut <strong>data-jsonp</strong> et une <strong>class</strong> :
	<pre><code>&lt;pre class="language-js"
  data-jsonp="https://api.github.com/repos/pluxml/PluXml/contents/core/lib/multifiles.js">
&lt;/pre></code></pre>
		</li>
		<p>Il est possible d'utiliser d'autres hébergement. <a href="http://prismjs.com/plugins/jsonp-highlight/" rel="noreferrer" target="_blank">Voir plus de détail sur PrismJS</a></p>
	</ol>
	<p><a href="parametres_plugin.php?p=<?php echo $page; ?>">Voir démonstration dans le panneau de configuration</a></p>
	<p><a href="http://prismjs.com" rel="noreferrer" target="_blank">Voir documentation originale en anglais sur http://prismjs.com</a></p>
</div>
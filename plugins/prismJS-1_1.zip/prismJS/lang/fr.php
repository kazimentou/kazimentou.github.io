<?php

if (!defined('PLX_ROOT')) exit;

$LANG = array(
	'L_THEME'	=> 'Thème',
	'L_LINK'	=>'Lien'
);
?>
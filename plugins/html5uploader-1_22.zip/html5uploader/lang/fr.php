<?php

$LANG = array(
	'L_DND_DROP_YOUR_FILES'=>'Glissez et déposez vos médias sur le tableau',
	'L_DND_DROP_READY_TO_SERVE'=>'prêt à servir',
	'L_DND_DROP_CONSTRAINTS_SERVER'=>'Limites imposées par le serveur',
	'L_DND_DROP_MAX_FILE_UPLOADS'=>'fichiers par envoi',
	'L_DND_DROP_UPLOAD_MAX_FILESIZE'=>'par fichier',
	'L_DND_DROP_POST_MAX_SIZE'=>'par envoi',
	'L_DND_DROP_KBYTES'=>' Ko',
	'L_DND_DROP_MAX_FILE_UPLOADS_WARN'=>'fichiers à la fois maximum.',
	'L_DND_DROP_UPLOAD_MAX_FILESIZE_WARN'=>'Les fichiers suivants ont une taille supérieure à ',
	'L_DND_DROP_POST_MAX_SIZE_WARN'=>"L envoi de fichiers dépasse",
	'L_DND_DROP_POST_IS_DONE_MSG'=>'Envoi des médias terminé<br />Médias en cours de traitement...'
);
?>

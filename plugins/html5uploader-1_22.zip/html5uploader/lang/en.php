<?php

$LANG = array(
	'L_DND_DROP_YOUR_FILES'=>'Drag and drop yours media files on the table',
	'L_DND_DROP_READY_TO_SERVE'=>'ready to serve',
	'L_DND_DROP_CONSTRAINTS_SERVER'=>'constraints by the server',
	'L_DND_DROP_MAX_FILE_UPLOADS'=>'files per upload',
	'L_DND_DROP_UPLOAD_MAX_FILESIZE'=>'per file',
	'L_DND_DROP_POST_MAX_SIZE'=>'per upload (all files included)',
	'L_DND_DROP_KBYTES'=>' Kbytes',
	'L_DND_DROP_MAX_FILE_UPLOADS_WARN'=>'files per upload.',
	'L_DND_DROP_UPLOAD_MAX_FILESIZE_WARN'=>'The size of some files exceeds :',
	'L_DND_DROP_POST_MAX_SIZE_WARN'=>"The size of the post is more than",
	'L_DND_DROP_POST_IS_DONE_MSG'=>'Uploading is done<br />Waiting for the server processing...'
);
?>

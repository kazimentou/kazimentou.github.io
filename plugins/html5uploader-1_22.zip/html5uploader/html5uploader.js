(function() {

	function AJAXSubmit2() {

	}

	const CSS_SELECTOR = '.uploaderInfo';
	var dropzone = null;

	const uploaderInfo = document.querySelector(CSS_SELECTOR);
	if(uploaderInfo != null) {
		const idTable = uploaderInfo.getAttribute('data-dropzone');
		const limits = uploaderInfo.getAttribute('data-limits');
		const messages = uploaderInfo.getAttribute('data-messages');
		const aForm = document.getElementById(uploaderInfo.getAttribute('data-form'));
		const url = uploaderInfo.getAttribute('data-uploader-url');
		const jsonEnabled = uploaderInfo.getAttribute('data-json');
		if(idTable != null && limits != null && messages != null && aForm != null && url != null) {
			dropzone = document.querySelector('#' + idTable + ' tbody');
			if(dropzone != null) {
				dropzone.addEventListener(
					'dragover',
					function(event) {
						event.stopPropagation();
						event.preventDefault();
						this.classList.add('html5Uploader-over');
					},
					true
				);
				dropzone.addEventListener(
					'dragleave',
					function(event) {
						this.classList.remove('html5Uploader-over');
					},
					true
				);
				dropzone.addEventListener(
					'drop',
					function(event) {
						event.preventDefault();
					 	const dt = event.dataTransfer;
					 	const files = dt.files;
					 	// We need the form_uploader form to retrieve some input values
						if (aForm && (aForm.nodeName.toUpperCase() == 'FORM'))
							AJAXSubmit2(files, aForm, url, jsonEnabled);
						else
							console.log('Element with id="' + formUploader + '" not found or not a form')
						this.classList.remove('html5Uploader-over');
					},
					true
				);

			} else {
				console.log('#' + idTable +' Table or his tbody are not found.');
			}
		} else {
			console.log('one or more attributes are missing for the .uploaderInfo element.');
		}
	} else {
		console.log('.uploaderInfo element not found.');
	}

	document.querySelector(CSS_SELECTOR + ' [type="button"]').addEventListener(
		'click', function(event) {
			event.preventDefault();
			this.parentElement.classList.add('fade');
		}
	);

	document.querySelector(CSS_SELECTOR).addEventListener(
		'transitionend', function(event) {
			if(event.propertyName == 'opacity') {
				event.preventDefault();
				this.classList.add('hide');
			}
		}
	);

	var timer1 = setTimeout(
		function() { document.querySelector(CSS_SELECTOR).classList.add('fade'); },
		5000
	);

})();



// id for element to fade in/out, duration in miliseconds
function fadeInOut(id, duration) {
	var el = document.getElementById(id);
	if (el) {
		if (typeof(duration) === 'undefined') duration = 5000;
		var val = 0, valMax = 20;
		var freq = 100;
		var timer1, timer2;
		var fadeIn1 = function() {
			if (val <= valMax) {
				var opacity1 = val / valMax;
				document.getElementById(id).style.opacity = opacity1.toFixed(2);
				val++;
			}
		}
		var fadeOut1 = function() {
			if (val >= 0) {
				var opacity1 = val / valMax;
				el.style.opacity =  opacity1.toFixed(2);
				val--;
			}
			else {
				clearTimeout(timer2);
				clearTimeout(timer1); // Hara-Kiri !!!
			}
		}
		var flipflop = function() {
			clearTimeout(timer1);
			timer1 = setInterval(fadeOut1, freq);
		}
		timer1 = setInterval(fadeIn1, freq);
		timer2 = setTimeout(flipflop, duration);
	}
	else
		console.log('Element with "' + id + '" id not found');
}

function progressBar(aPercent) {
	var progressBar1 = document.getElementById('progressBar');
	if (progressBar1) {
		if (aPercent > 0) {
			progressBar1.style.display = 'visible';
			var theBar = '▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒';
			var i = Math.round(theBar.length * aPercent / 100);
			progressBar1.innerHTML = theBar.substr(0, i);
		}
		else
			aPercent.style.display = 'none';
	}
}

function checkUploadOk(files) {
	var result = false;
	if ((max_file_uploads > 0) && (files.length > max_file_uploads))
		alert(max_file_uploads + max_file_uploadsWarn);
	else {
		var total = 0;
		var badFiles = '';
		for (var i=0; i < files.length; i++) {
			var file1 = files[i];
			var n = file1.size;
			if (n > upload_max_filesize)
				badFiles += '\n' + file1.name;
			else
				total +=  n;
		}
		if (badFiles.length > 0)
			alert(upload_max_filesizeWarn + '\n' + (upload_max_filesize / 1024) + Kbytes + ' :' + badFiles);
		else if (total > post_max_size)
			alert(post_max_sizeWarn + (post_max_size / 1024) + Kbytes);
		else
			result = true;
	}
	return result;
}

// list of files to transmit, aForm provides some inputs we need, aUrl is the url for uploading files
// status is the id of element to display the result of uploading
// fileReader.readAsBinary function is deprecated. Use FormData object instead. compatible with more browsers (IE) and easier
var AJAXSubmit2 = function(files, aForm, aUrl, status) {

	function ajaxSuccess(event) {
		if (isJSON) { // defined by html5uploader.php
			var result = JSON.parse(this.responseText);
		}
		else {
			// Free.fr doesn't support JSON in PHP ( version < 5.2 )
			var buf = this.responseText.split('aZErTy');
			var result = {};
			result.msg = buf[0];
			if (buf.length > 1)
				result.inner = buf[1];
		}
		console.log(result.msg);
		if (result.inner) {
			if (result.inner.length > 0) {
				if (dropZone) {
					dropZone.innerHTML = result.inner;
				} else
					console.log('dropZone is undefined');
			}
			var msg = document.getElementById(status);
			if (msg) {
				msg.innerHTML = result.msg;
				fadeInOut(status);
			}
		}
		else
			alert(result.msg);
	}

	function ajaxProgress(event) {
		if (event.lengthComputable) {
			//event.loaded the bytes browser receive
			//event.total the total bytes seted by the header
			progressBar((event.loaded / event.total) * 100);
		}
	}

	function ajaxError(event) {
		alert('Oups! Something goes wrong.');
		console.log('Error on Ajax transfer');
    }

	if (checkUploadOk(files)) {

		var data = new FormData();

		for (var i=0; i<aForm.elements.length; i++) {
			var field = aForm.elements[i];
			if ((field.nodeName.toUpperCase() == 'INPUT') && field.hasAttribute('name')) {
				var fieldType = (field.getAttribute('type')) ? field.getAttribute('type').toUpperCase() : 'TEXT';
				if ((fieldType == 'FILE') && (files.length > 0)) {
					for (var f=0; f < files.length; f++)
						data.append('myFiles[]', files[f])
					}
				else if (((fieldType !== 'RADIO') &&  (fieldType !== 'CHECKBOX')) || field.checked) {
					data.append(field.name, field.value);
				}
			}
		}

		// console.log('Uploading of the post in progress...!');
		var ajaxReq = new XMLHttpRequest();
		ajaxReq.addEventListener('load', ajaxSuccess);
		ajaxReq.addEventListener('progress', ajaxProgress);
		ajaxReq.addEventListener('error', ajaxError);
		ajaxReq.open('POST', aUrl, true);
		ajaxReq.send(data);
		status
		var msg = document.getElementById(status);
		if (msg) {
			msg.innerHTML = post_is_doneMsg;
			fadeInOut(status);
		}
		// console.log('Transfer is done !');
	}
}
<?php

if (!defined('PLX_ROOT')) exit;

class html5uploader extends plxPlugin {

	private $__scriptname = '';

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)

		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
	}

	public function AdminTopEndHead($params) {
		global $plxMedias;

		if (isset($plxMedias)) {
			global $plxAdmin, $folderMedias;

			// We have $_SESSION['folder'] and we have to add this $_SESSION
			if($plxAdmin->aConf['userfolders'] AND $_SESSION['profil']==PROFIL_WRITER)
				$folderMedias = $_SESSION['user'].'/'.$_SESSION['folder'];
			else
				$folderMedias = $_SESSION['folder'];
			$_SESSION['uploader_root'] = PLX_ROOT;
			$_SESSION['uploader_racine'] = $plxAdmin->racine;
			$_SESSION['uploader_lang'] = $plxAdmin->aConf['default_lang'];
			$_SESSION['uploader_folderMedias'] = $folderMedias;
		}
	}

	private function __getNumber($aString) {
		eval('$value=intval('.preg_replace(
			array('@K$@i', '@M$@i', '@G$@i'),
			array('*1024', '*1024*1024', '*1024*1024*1024'),
			$aString).');'
		);
		return $value;
	}

	private function __print_limitsJS() {
		$lines = array();
		foreach(explode(' ', 'max_file_uploads upload_max_filesize post_max_size') as $field) {
			$value = $this->__getNumber(ini_get($field));
			$message = $this->getLang('L_DND_DROP_'.strtoupper($field));
			$lines[] = <<< LIMIT
$field: { value: $value, message: '$message' }
LIMIT;
		}
		echo '{'.implode(',', $lines).'}';
	}

	private function __print_messagesJS() {
		$lines = array();
		foreach(explode(' ', 'kbytes post_is_done_msg') as $field) {
			$lines[] = "$field: '".$this->getLang('L_DND_DROP_'.strtoupper($field))."'";
		}
		echo '{'.implode(',', $lines).'}';
	}

	public function AdminMediasFoot($params) {
		$max_file_uploads = ini_get('max_file_uploads');
		$upload_max_filesize = ini_get('upload_max_filesize');
		$post_max_size = ini_get('post_max_size');
?>
		<div class="uploaderInfo"
			data-dropzone="medias-table"
			data-limits="<?php $this->__print_limitsJS(); ?>"
			data-messages="<?php $this->__print_messagesJS(); ?>"
			data-uploader-url="<?php echo PLX_PLUGINS.__CLASS__; ?>/uploader.php"
			data-form="form_uploader"
			data-json="<?php echo (function_exists('json_encode')) ? 'true' : 'false'; ?>"
		>
			<input type="button" value="✘" />
			<p>
				<?php $this->lang('L_DND_DROP_YOUR_FILES'); echo "\n"; ?>
			</p>
			<p>
				<?php $this->lang('L_DND_DROP_CONSTRAINTS_SERVER'); ?> : <br />
<?php if ($max_file_uploads > 0) { ?>
				<span><?php echo $max_file_uploads.'&nbsp;'; $this->lang('L_DND_DROP_MAX_FILE_UPLOADS');?></span>,
<?php } ?>
				<span><?php echo $this->__getNumber($upload_max_filesize) / 1024; echo '&nbsp;'; $this->lang('L_DND_DROP_KBYTES'); $this->lang('L_DND_DROP_UPLOAD_MAX_FILESIZE'); ?></span>,
				<span><?php echo $this->__getNumber($post_max_size) / 1024; $this->lang('L_DND_DROP_KBYTES'); echo '&nbsp;'; $this->lang('L_DND_DROP_POST_MAX_SIZE'); ?></span>
			</p>
		</div>
		<p id="progressBar">&nbsp;</p>
		<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
<?php
	}

}
?>
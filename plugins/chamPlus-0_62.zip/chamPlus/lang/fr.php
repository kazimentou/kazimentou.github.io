<?php
		$LANG = array(
			'L_CHAMPLUS_LABEL'			=> 'Entre l\'intitulé',
			'L_CHAMPLUS_NAME'			=> 'Entrez le nom',
			'L_CHAMPLUS_TEXTAREA'		=> 'type de<br />champ',
			'L_CHAMPLUS_GROUP'			=> 'Entrez le groupe si besoin',
			'L_CHAMPLUS_NEW_LABEL'		=> 'Entre le nouvel intitulé',
			'L_CHAMPLUS_NEW_NAME'		=> 'Entrez le nouveau nom',
			'L_CHAMPLUS_NEW_TEXTAREA'	=> 'type de<br />champ',
			'L_CHAMPLUS_NEW_GROUP'		=> 'Entrez le nouveau groupe si besoin',
			'L_CHAMPLUS_TITLE_LABEL'	=> 'Intitulé',
			'L_CHAMPLUS_TITLE_NAME'		=> 'Nom<sup>1</sup>',
			'L_CHAMPLUS_TITLE_TEXTAREA'	=> 'type de<br />champ',
			'L_CHAMPLUS_TITLE_GROUP'	=> 'Groupe',
			'L_CHAMPLUS_TITLE_STATIC'	=> 'Page<sup>2</sup><br />statique',
			'L_CHAMPLUS_BLOC'			=> 'Bloc texte',
			'L_CHAMPLUS_LASTARTLIST'	=> 'Activer le hook plxShowLastArtList',
			'L_CHAMPLUS_NO_INTEGRATION'	=> 'Désactiver l\'intégration automatique des médias',
			'L_CHAMPLUS_ADD'			=> 'Ajouter un champ',
			'L_CHAMPLUS_SAVE'			=> 'Enregistrer',
			'L_CHAMPLUS_WARNING'		=> <<< WARNING
<sup>1</sup> Les champs sans nom ne sauront pas sauvegardés<br />
<sup>2</sup> Les bloc-textes ne sont pas permis dans les pages statiques. Ils sont considérés comme des lignes.
WARNING
,
			'L_CHAMPLUS_BADNAME'		=> <<< BADNAME
Le nom doit être en minuscules,\\\ncommencer par une lettre et\\\nne contenir que des lettres ou des chiffres
BADNAME
,
			'L_CHAMPLUS_HELP_LABEL'		=> 'Aide',
			'L_CHAMPLUS_HELP'			=> <<< HELP
<p>
	Le plugin chamPlus permet d'ajouter des champs supplémentaires aux articles et aux pages statiques. Ils peuvent être d'un des trois types suivants:
</p>
<ul>
	<li>ligne</li>
	<li>bloc de texte, uniquement possible pour les articles</li>
	<li>média, qu'on peut choisir avec le gestionnaire de médias de Pluxml</li>
</ul>
<p>
	Pour afficher des champs supplémentaire sur votre site, utiliser le hook champlus dans vos gabarits (<i>template</i>) article.php ou static.php ou categorie.php comme ci-dessous. Vous pouvez bien sûr dupliquer et renommer vos gabarits.
</p>
<pre><code>&lt;?php eval(&dollar;plxShow->callHook('champlus', &dollar;params); ?>
</code></pre>
<p>
	<strong>&dollar;params</strong> peut être le nom du champ sous forme d'une chaine de caractères type string. Dans ce cas, la valeur du champ sera affichée à la place du hook.
</p>
<p>
	Si <strong>&dollar;params</strong> est un champ de <strong>type média</strong>, le média sera intégré dans la page automatiquement. Si la valeur du champ finit par l'extension d'un fichier image, comme "jpg", "jpeg", "png" ou "gif", alors la balise html <strong>&lt;img src="..." /></strong> sera utilisée pour afficher l'image.
	Dans le cas contraire, on utilise la balise html <strong>&lt;a href="..." target="_blank">étiquette</a></strong> pour afficher le média dans une autre fenêtre.
	Cette intégration automatique peut être désactivée dans le panneau de configuration, ou en précisant une chaîne de format comme expliqué dans le paragraphe suivant.
</p>
<p>
	<strong>&dollar;params</strong> peut être aussi un tableau de deux éléments. Le premier sera le nom du champ comme précédemment. Le deuxième sera une chaine de format avec un des choix suivants:
<ul>
<li>
	false: la valeur du champ sera uniquement affichée comme précèdemment. C'est le choix par défaut.</li>
<li>
	true: la valeur du champ sera retournée sans être affichée. Peut être utilisée dans une variable</li>
<li>
	une chaine de caractères, au format HTML, contenant un ou plusieurs motifs suivants : #name#, #value#, #label" ou #group#.<br />
	<ul>
		<li><strong>#name#</strong> affiche le nom du champ</li>
		<li><strong>#label#</strong> affiche son libellé comme dans le formulaire de saisie d'un article ou d'une page statique</li>
		<li><strong>#value#</strong> affiche sa valeur</li>
		<li><strong>#group#</strong> affiche le nom du groupe saisi dans le panneau de configuration</li>
	</ul>
</li>
</ul>
<p>	On peut ainsi avoir, par exemple :</p>
<pre><code>&lt;?php
&dollar;params = array(
  'price',
  'le #price# est à &lt;strong>#value#&lt;/strong> !'
);
eval(&dollar;plxShow->callHook('champlus', &dollar;params);
?>
</code></pre>
<p>
	Si le nom du champ est "monchamp", alors le nom du champ dans les fichiers d'articles ou dans le fichier statiques.xml sera "cps_monchamp". Le nom doit être en minuscules et commencer par une lettre, suivie d'au maximun 32 lettres ou chiffres. Il est conseillé de saisir le libellé en minuscules. Tous les caractères sont permis. Dans les éditions, la première lettre sera forcée en majuscule.
</p>
<p>Il ne peut y avoir de champ commun aux articles et aux pages statiques. Il n'est pas possible d'avoir un bloc de texte (<i>textarea</i>) dans les pages statiques. Pour l'édition des articles, les champs, qui ne sont pas de type bloc de texte, sont situés sur le panneau à droite de la fenêtre.</p>
<p>Il existe également le hook <strong>chamPlusList</strong>, sans paramètre, qui retourne l'ensemble des champs sous forme de tableau. On peut l'affecter à une variable ou l'afficher sur le site avec le code suivant dans un gabarit :</p>
<pre><code>&lt;pre>&lt;?php print_r(
  eval(&dollar;plxShow->callHook('chamPlusList'));
); ?>&lt;/pre></code></pre>
<p>
	Pluxml utilise le hook <strong>plxShowLastArtList</strong> pour afficher une courte liste des articles les plus récents. Le plugin chamPlus possède une option pour modifier l'affichage de ce hook. Il est nécessaire de passer une chaine de format à ce hook pour définir les champs de l'article à afficher. On peut bien sûr mélanger les champs gérés par Pluxml et les champs supplémentaires gérés par le plugin chamPlus. Les champs supplémentaires doivent être préfixés par <strong>cps_</strong>, sans oublier le caractère # comme pour tous les champs. Si la valeur d'un champ supplémentaire correspond au chemin d'un fichier image, alors l'image sera affichée automatiquement. Supposons qu'on est un champ nommé vignette et qui pointe vers un fichier image, alors le code suivant, à intégrer dans le gabarit sidebar.php du thème, affichera une image à côté du lien vers l'article :
</p>
<pre><code>&lt;?php
  &lt;h3 id="lastestArts">
    &lt;?php &dollar;plxShow->lang('LATEST_ARTICLES'); ?>
  &lt;/h3>
  &lt;ul>
    &lt;?php &dollar;plxShow->lastArtList('&lt;li>#cps_vignette&lt;a class="#art_status" href="#art_url">#art_title&lt;/a>&lt;/li>'."&#92;n"); ?>
  &lt;/ul>
?></code></pre>
<p>
	Pour afficher l'image à gauche du lien, il faudra utiliser la règle CSS suivante :
</p>
<pre><code>#lastestArts {display: flex;}</code></pre>
<p><input type="button" value="Masquer" onclick="help_me(false);"</p>
HELP
,
);
?>

<?php
/*
 * plugin ChamPlus
 * 
 * ré-écriture complète de champArt.
 * Nécessite Pluxml 5.4, HTML5, PHP 5.6
 * 
 * déplacement de la feuille de styles dans le dossier css et renommée admin.css. suppression du hook AdminTopEndHead
 * les paramètres champ, type et groupe sont renommés en name, textarea et group
 * le nouveau paramètre textarea est numérique (valeur 0 ou 1)
 * suppression des entités HTML dans le fichier de lang (UTF-8 !!!)
 * utilisation des attributs placehorder et required pour les balises <input type="text" />
 * suppression du hook AdminArticleTop
 * on peut préciser une chaîne de format pour afficher les champs (mot-clés #name#, #label#, #value#, #group")
 * suppression du fichier d'aide. Voir aide dans panneau de config.
 * 
 * Pas de textarea dans les pages statiques !!
 * */

define('CHAMPLUS_PREFIX', 'cps_');

class chamPlus extends plxPlugin {
	
	public $paramsNames = array('name', 'label', 'textarea', 'group', 'static');
	public $fieldTypes = array(0=>'ligne', 1=>'bloc-texte', 2=>'média');
	public $options = array('no_integration', 'lastartlist');	

	public function __construct($default_lang) {
		parent::__construct($default_lang);
		
		$this->setConfigProfil(PROFIL_ADMIN);

		/* ******** hooks inside top.php ****************** */
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');

		/* ******** hooks inside article.php ****************** */
		$this->addHook('AdminArticleSidebar', 'AdminArticleSidebar');
		$this->addHook('AdminArticleContent', 'AdminArticleContent');
		$this->addHook('AdminArticleInitData', 'AdminArticleInitData');
		$this->addHook('AdminArticlePreview', 'AdminArticlePreview');
		$this->addHook('AdminArticlePostData', 'AdminArticlePostData');
		$this->addHook('AdminArticleParseData', 'AdminArticleParseData');
		
		/* ******** hooks inside statique.php ***************** */
		$this->addHook('AdminStatic', 'AdminStatic');
		
		/* ******** hooks inside class.plx.admin.php ********** */
		$this->addHook('plxAdminEditArticleXml', 'plxAdminEditArticleXml');
		$this->addHook('plxAdminEditStatique', 'plxAdminEditStatique');
		$this->addHook('plxAdminEditStatiquesUpdate', 'plxAdminEditStatiquesUpdate');
		$this->addHook('plxAdminEditStatiquesXml', 'plxAdminEditStatiquesXml');
	
		/* ********** hooks inside class.plx.motor.php ******** */
		$this->addHook('plxMotorParseArticle', 'plxMotorParseArticle');
		$this->addHook('plxMotorGetStatiques', 'plxMotorGetStatiques');

		/* ******** hooks inside medias.php ***************** */
		$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
		
		/* ********** hooks inside class.plx.show.php ******** */
		$this->addHook('plxShowLastArtList', 'plxShowLastArtList');

		/* ********** new hooks for this plugin ********* */
		// Hook du plugin à utiliser sur le site dans un thème
		$this->addHook('chamPlus', 'chamPlus');
		// renvoie tous les champs sous forme de tableau
		$this->addHook('chamPlusList', 'chamPlusList');

	}

	// pour la saisie des champs dans config.php
	public function isBoolean($name) {
		return in_array($name, array('static'));
	}
	
	// retourne les indices des champs
	public function indices() {
		$names = array_filter(
			array_keys($this->getParams()),
			function($k) { return (strpos($k, 'name') === 0); }
		);
		return array_map(function($v) { return substr($v, strlen('name')); }, $names);
	}
	
	// the field is only for static pages
	private function isStatic($indice) {
		return ($this->getParam('static'.$indice) > 0);
	}

	private function isTextarea($indice) {
		return (! $this->isStatic($indice) and $this->getParam('textarea'.$indice) == 1);
	}

	private function isMediaArt($indice) {
		return (! $this->isStatic($indice) and $this->getParam('textarea'.$indice) == 2);
	}

	private function isMediaStatic($indice) {
		return ($this->isStatic($indice) and $this->getParam('textarea'.$indice) == 2);
	}

	private function isMedia($fieldName) {
		$result = false;
		foreach($this->indices() as $idx) {
			if ($this->getParam('name'.$idx) == $fieldName) {
				$result = ($this->getParam('textarea'.$idx) == 2);
				break;
			}
		}
		return $result;
	}
	
	public function AdminTopEndHead() {
		global $plxAdmin; ?>
		<script type="text/javascript" src="<?php echo $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/'.__CLASS__.'.js'; ?>"></script>
<?php
	}
	
	// ajoute les champs supplémentaires dans le panneau latéral droit de l'édition de l'article
	public function AdminArticleSidebar() {
		global $plxAdmin;
		
		$mediasManagerPath = $plxAdmin->racine.'core/admin/medias.php';
		$code = '';
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key) and ! $this->isTextarea($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$field = "\$$fieldName";
				$label = ucfirst($this->getParam('label'.$key));
				$style = '';
				$onclick = '';
				if ($this->isMediaArt($key)) {
					$label .= ' (Voir la liste des médias)';
					$onclick = <<< ON_CLICK
 onclick="return mediasManager.open(this, '$mediasManagerPath');"
ON_CLICK;
					$onclick .= ' style="cursor: pointer"';
				}
				$code .= <<< EOT
					<div>
						<label for="id_$fieldName"$onclick>$label&nbsp;:</label>
						<?php plxUtils::printInput('$fieldName',plxUtils::strCheck($field)); echo "\n"; ?>
					</div>

EOT;
			}
		}
		echo $code;
	}

	// ajoute les champs supplémentaires sous le contenu de l'article avec la balise textarea dans l'édition de l'article
	public function AdminArticleContent() {
		$code = '';
		foreach ($this->indices() as $key) {
			if ($this->isTextarea($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$field = "\$chamPlus['$fieldName']";
				$label = ucfirst($this->getParam('label'.$key));
				$display = L_ARTICLE_CHAPO_DISPLAY;
				$hide = L_ARTICLE_CHAPO_HIDE;
				$code .= <<< EOT
					<div>
						<label for="id_$fieldName">$label&nbsp;:&nbsp;<a id="toggler_$fieldName" href="javascript:void(0)" onclick="toggleDiv('toggle_$fieldName', 'toggler_$fieldName', '$display','$hide')"><?php echo \$$fieldName==''?'$display':'$hide' ?></a></label>
						<div id="toggle_$fieldName"<?php echo \$$fieldName!=''?'':' style="display:none"' ?>>
						<?php plxUtils::printArea('$fieldName',plxUtils::strCheck(\$$fieldName),35,8,false,'full-width'); ?>
						</div>
					</div>
EOT;
			}
		}
		echo $code;
	}

	// initialise les champs supplémentaires pour un nouvel article
	public function AdminArticleInitData() {
		echo "<?php\n";
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$field = "\$chamPlus['$fieldName']";
				$label = $this->getParam('label'.$key);
				echo "$field = ''\n";
			}
		}
		echo "?>\n";
	}

	public function AdminArticlePreview() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$art['$fieldName'] = \$_POST['$fieldName'];

RECORD;
				}
			}
		$code .= "?>\n";
		echo $code;
	}

	public function AdminArticlePostData() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$$fieldName = \$_POST['$fieldName'];

RECORD;
			}
		}
		$code .= "?>\n";
		echo $code;
	}

	public function AdminArticleParseData() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$$fieldName = \$result['$fieldName'];

RECORD;
				}
		}
		$code .= "?>\n";
		echo $code;
	}

	// ajoute des champs supplémentaires dans l'édition de la page statique dans statique.php
	public function AdminStatic() {
		// bug Pluxml 5.4: Pas de Hook dans le bloc "elseif (! empty($_GET['p'])) {...}"
		global $plxAdmin;

		$mediasManagerPath = $plxAdmin->racine.'core/admin/medias.php';
		$code = '';
		foreach ($this->indices() as $key) {
			if ($this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$label = ucfirst($this->getParam('label'.$key));
				$onclick = '';
				if ($this->isMediaStatic($key)) {
					$label .= ' (Voir la liste des médias)';
					$onclick = <<< ON_CLICK
 onclick="return mediasManager.open(this, '$mediasManagerPath');"
ON_CLICK;
					$onclick .= ' style="cursor: pointer"';
				}
				$code .= <<< RECORD
			<div>
				<label for="id_$fieldName"$onclick>$label</label>
				<?php plxUtils::printInput('$fieldName',plxUtils::strCheck(\$plxAdmin->aStats[\$id]['$fieldName']),'text','50-255'); echo "\n"; ?>
			</div>

RECORD;
			}
		}
		echo $code;
	}

	// Load the fields of article from XML file
	public function plxMotorParseArticle() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$art['$fieldName'] = (isset(\$iTags['$fieldName'])) ? plxUtils::getValue(\$values[\$iTags['$fieldName'][0]]['value']) : '';

RECORD;
			}
		}
		$code .= "?>\n";
		echo $code;
	}

	// load data from statiques.xml in class.plx.motor
	public function plxMotorGetStatiques() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if ($this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$this->aStats[\$number]['$fieldName']=plxUtils::getValue(\$values[\$iTags['$fieldName'][\$i]]['value']);

RECORD;
			}
		}
		$code .= "?>\n";
		echo $code;
	}

	// Save the  fields of article to XML file
	public function plxAdminEditArticleXml() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if (! $this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$xml .= "\t<$fieldName><![CDATA[".plxUtils::cdataCheck(trim(\$content['$fieldName']))."]]></$fieldName>\n";

RECORD;
			}
		}
		$code .= "?>\n";
		echo $code;
	}

	public function plxAdminEditStatique() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if ($this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
		\$this->aStats[\$content['id']]['$fieldName'] = \$content['$fieldName'];

RECORD;
				}
		}
		$code .= "?>\n";
		echo $code;
	}
	
	public function plxAdminEditStatiquesUpdate() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if ($this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$this->aStats[\$static_id]['$fieldName'] = (isset(\$this->aStats[\$static_id]['$fieldName']) ? \$this->aStats[\$static_id]['$fieldName'] : '');

RECORD;
				}
		}
		$code .= "?>\n";
		echo $code;
	}

	public function plxAdminEditStatiquesXml() {
		$code = "<?php\n";
		foreach ($this->indices() as $key) {
			if ($this->isStatic($key)) {
				$fieldName = CHAMPLUS_PREFIX.$this->getParam('name'.$key);
				$code .= <<< RECORD
	\$xml .= "<$fieldName><![CDATA[".plxUtils::cdataCheck(\$static['$fieldName'])."]]></$fieldName>";

RECORD;
			}
		}
		$code .= "?>\n";
		echo $code;
	}

	public function plxShowLastArtList() {
		
		if ($this->getParam('lastartlist') > 0)		
			$code = <<< CODE
<?php
\$cats = (! empty(\$cat_id)) ? str_pad(\$cat_id, 3, 0, STR_PAD_LEFT) : '(?:home,|\d{3},)*(?:'.\$this->plxMotor->activeCats.')(?:,\d{3}|,home)*';
# Génération de notre motif
\$motif = '/^\d{4}\.'.\$cats.'\.\d{3}\.\d{12}\.[\w-]+\.xml\$/';

# Nouvel objet plxGlob et récupération des fichiers
\$plxGlob_arts = clone \$this->plxMotor->plxGlob_arts;
if (\$aFiles = \$plxGlob_arts->query(\$motif, 'art', \$sort, 0, \$max, 'before')) {
	\$n1 = preg_match_all('/(#art_(?:title|url|id|status|author|date|hour|nbcoms)|#cat_list)/', \$format, \$matches1);
	// traiter #art_chapo(..), #art_content(..)
	\$n2 = preg_match_all('/(#art_(?:chapo|content))(?:\((\d+)\))?/', \$format, \$matches2);
	// traiter champs supplémentaires #cps_...
	\$n3 = preg_match_all('/(#cps_[a-z][a-z,0-9_]*)/', \$format, \$matches3);
	foreach(\$aFiles as \$v) { # On parcourt tous les fichiers
		\$art = \$this->plxMotor->parseArticle(PLX_ROOT.\$this->plxMotor->aConf['racine_articles'].\$v);
		\$num = intval(\$art['numero']);
		\$replaces = array();
		if (\$n1 > 0) {
			\$patterns = \$matches1[0];
			foreach (\$matches1[1] as \$k) {
				switch (\$k) {
					case '#art_title' :
						\$replaces[] = plxUtils::strCheck(\$art['title']);
						break;
					case '#art_url':
						\$replaces[] = \$this->plxMotor->urlRewrite('?article'.\$num.'/'.\$art['url']);
						break;
					case '#art_id':
						\$replaces[] = \$num;
						break;
					case '#art_status' :
						\$replaces[] = ((\$this->plxMotor->mode == 'article') and (\$num == \$this->plxMotor->cible)) ? 'active' : 'noactive';
						break;
					case '#art_author' :
						\$author = plxUtils::getValue(\$this->plxMotor->aUsers[\$art['author']]['name']);
						\$replaces[] = plxUtils::strCheck(\$author);
						break;
					case '#art_date' :
						\$replaces[] = plxDate::formatDate(\$art['date'],'#num_day/#num_month/#num_year(4)');
						break;
					case '#art_hour' :
						\$replaces[] = plxDate::formatDate(\$art['date'],'#hour:#minute');
						break;
					case '#art_nbcoms' :
						\$replaces[] = \$art['nb_com'];
						break;
					case '#cat_list' :
						\$catList = array();
						\$catIds = explode(',', \$art['categorie']);
						foreach (\$catIds as \$idx => \$catId) {
							if(isset(\$this->plxMotor->aCats[\$catId])) { # La catégorie existe
								\$catName = plxUtils::strCheck(\$this->plxMotor->aCats[\$catId]['name']);
								\$catUrl = \$this->plxMotor->aCats[\$catId]['url'];
								\$catList[] = '<a title="'.\$catName.'" href="'.\$this->plxMotor->urlRewrite('?categorie'.intval(\$catId).'/'.\$catUrl).'">'.\$catName.'</a>';
							} else {
								\$catList[] = L_UNCLASSIFIED;
							}
						}
						\$replaces[] = implode(', ',\$catList);
						break;
				}
			}
		} else
			\$patterns = array();
		if (\$n2 > 0) { // #artchapo, #art_content
			\$patterns = array_merge(\$patterns, \$matches2[0]);
			for (\$i=0; \$i<count(\$matches2[1]); \$i++) {
				\$strLength = (empty(\$matches2[2][\$i])) ? 100 : intval(\$matches2[2][\$i]);
				\$f = substr(\$matches2[1][\$i], 5);
				\$replaces[] = plxUtils::truncate(\$art[\$f],\$strlength,\$ending,true,true);
			}
		}
		if (\$n3 > 0) { // champs supplémentaires
			\$patterns = array_merge(\$patterns, \$matches3[0]);
			foreach (\$matches3[0] as \$k) {
				\$value = \$art[substr(\$k, 1)];
				# On teste si la valeur est un nom d'image
				if (preg_match('/\.(?:jpg|jpeg|png|gif)$/', \$value)) {
					\$title = basename(\$value);
					\$replaces[] = '<img src="'.\$value.'" alt="'.substr(\$k, 5).'" title="'.\$title.'" />';
				} else
					\$replaces[] = plxUtils::strCheck([\$value]);
			}
		}
		echo str_replace(\$patterns, \$replaces, \$format);
	}
}
return true;
?>
CODE;
	else
		$code = '<?php return false; ?>';
	echo $code;
	}

	public function AdminMediasFoot() {
		global $plxAdmin; ?>
		<script type="text/javascript">
			<!--
			mediasManager.init('<?php echo $plxAdmin->racine; ?>', 'Fermer', 'Ajouter le média');
			// -->
		</script>
<?php
	}

	/* ********************************************************************************
	 * si params est de type string, alors on affiche la valeur du champ correpsondant
	 * si params est de type array, il peut contenir jusqu'à 2 éléments
	 * le 1er élément est le nom du champ
	 * si le 2ème élement est égal à false, alors on affiche la valeur du champ comme dans le 1er cas
	 * si le ème élement est égal  à true, alors on renvoir la valeur du champ sans l'afficher
	 * sinon le 2ème élément, de type string, est un format pour afficher le champ
	 * ******************************************************************************* */
	public function chamPlus($params) {
		global $plxMotor;
		
		if (is_string($params)) {
			$name = $params;
			$format = false;
		} else
			list($name, $format) = array_pad($params, 2, false);
		$nameField = CHAMPLUS_PREFIX.$name;
		if ($plxMotor->mode == 'static') {
			$static_id =  $plxMotor->cible;
			$value = plxUtils::strCheck($plxMotor->aStats[$static_id][$nameField]);
		}
		else
			$value = $plxMotor->plxRecord_arts->f($nameField);

		if ($format === true)
			// pas d'affichage, on retourne simplement la valeur
			return $value;
		else if ($format === false) {
			if (($this->getParam('no_integration') > 0) or (! $this->isMedia($name))) {
				// on affiche uniquement la valeur
				echo $value;
			} else {
				if (preg_match('/\.(?:jpg|jpeg|gif|png)$/', $value)) {
					// le média est une image
					$imagesize = getimagesize();
					$attrs = $imagesize[3];
					$title = basename($value);
					echo <<< EOT
<img src="$value" alt="$value" title="$title" $attrs />				
EOT;
				} else {
					$label = basename($value);
					echo <<< EOT
<a href="$value" target="_blank">$label</a>
EOT;
				}
			}
		}
		else {
			$label = '';
			$group = '';
			foreach($this->indices() as $idx) {
				if ($this->getParam('name'.$idx) == $name) {
					$label = $this->getParam('label'.$idx);
					$group = $this->getParam('group'.$idx);
					break;
				}
			}
			$patterns = array('#name#', '#value#', '#label#', '#group#');
			$replaces = array($name, $value, $label, $group);					
			echo str_replace($patterns, $replaces, $format);
		}
		return $false;
	}

	public function chamPlusList() {
		global $plxMotor;
		
		$content = array();
		foreach($this->indices() as $idx) {
			$name = $this->getParam('name'.$idx);
			$nameField = CHAMPLUS_PREFIX.$name;
			if (($plxMotor->mode == 'static') and $this->isStatic($idx)) {
				$static_id =  $plxMotor->cible;
				$value = addslashes(plxUtils::strCheck($plxMotor->aStats[$static_id][$nameField]));
			}
			elseif (($plxMotor->mode != 'static') and ! $this->isStatic($idx))
				$value = addslashes($plxMotor->plxRecord_arts->f($nameField));
			else
				$value = false;
			if ($value !== false) {
				$label = addslashes($this->getParam('label'.$idx));
				$group = addslashes($this->getParam('group'.$idx));
				$type = $this->fieldTypes[$this->getParam('textarea'.$idx)];
				$content[] = "'$name'=>array('label'=>'$label', 'value'=>'$value', 'type'=>'$type', 'group'=>'$group')";
			}
		}
		
		if (empty($content))
			$code = '<?php return false; ?>';
		else {
			$a = implode(",", $content);
			$code = "\$a = array($a); return \$a;";
		}
		return $code;
	}

}
?>

<?php
$format = <<< FORMAT
<li>#cps_vignette<a href="#art_url" title="#art_title">#art_title</a>#art_chapo(10) #art_content #cat_list</li>
FORMAT;

# <li><a href="#art_url" title="#art_title">#art_title</a></li>

		// $format='<li><a href="#art_url" title="#art_title">#art_title</a></li>',$max=5,$cat_id='',$ending='', $sort='rsort'
?>
		
<?php
$cats = (! empty($cat_id)) ? str_pad($cat_id, 3, 0, STR_PAD_LEFT) : '(?:home,|\d{4},)*(?:'.$this->plxMotor->activeCats.')(?:,\d{4}|,home)*';
# Génération de notre motif
$motif = '/^\d{4}\.'.$cats.'\.\d{3}\.\d{12}\.[\w-]+\.xml$/';

# Nouvel objet plxGlob et récupération des fichiers
$plxGlob_arts = clone $this->plxMotor->plxGlob_arts;
if ($aFiles = $plxGlob_arts->query($motif, 'art', $sort, 0, $max, 'before')) {
	$n1 = preg_match_all('/(#art_(?:title|url|id|status|author|date|hour|nbcoms)|#cat_list)/', $format, $matches1);
	// traiter #art_chapo(..), #art_content(..)
	$n2 = preg_match_all('/(#art_(?:chapo|content))(?:\((\d+)\))?/', $format, $matches2);
	// traiter champs supplémentaires #cps_...
	$n3 = preg_match_all('/(#cps_[a-z][a-z,0-9_]*)/', $format, $matches3);
	foreach($aFiles as $v) { # On parcourt tous les fichiers
		$art = $this->plxMotor->parseArticle(PLX_ROOT.$this->plxMotor->aConf['racine_articles'].$v);
		$num = intval($art['numero']);
		$replaces = array();
		if ($n1 > 0) {
			$patterns = $matches1[0];
			foreach ($matches1[1] as $k) {
				switch ($k) {
					case '#art_title' :
						$replaces[] = plxUtils::strCheck($art['title']);
						break;
					case '#art_url':
						$replaces[] = $this->plxMotor->urlRewrite('?article'.$num.'/'.$art['url']);
						break;
					case '#art_id':
						$replaces[] = $num;
						break;
					case '#art_status' :
						$replaces[] = (($this->plxMotor->mode == 'article') and ($num == $this->plxMotor->cible)) ? 'active' : 'noactive';
						break;
					case '#art_author' :
						$author = plxUtils::getValue($this->plxMotor->aUsers[$art['author']]['name']);
						$replaces[] = plxUtils::strCheck($author);
						break;
					case '#art_date' :
						$replaces[] = plxDate::formatDate($art['date'],'#num_day/#num_month/#num_year(4)');
						break;
					case '#art_hour' :
						$replaces[] = plxDate::formatDate($art['date'],'#hour:#minute');
						break;
					case '#art_nbcoms' :
						$replaces[] = $art['nb_com'];
						break;
					case '#cat_list' :
						$catList = array();
						$catIds = explode(',', $art['categorie']);
						foreach ($catIds as $idx => $catId) {
							if(isset($this->plxMotor->aCats[$catId])) { # La catégorie existe
								$catName = plxUtils::strCheck($this->plxMotor->aCats[$catId]['name']);
								$catUrl = $this->plxMotor->aCats[$catId]['url'];
								$catList[] = '<a title="'.$catName.'" href="'.$this->plxMotor->urlRewrite('?categorie'.intval($catId).'/'.$catUrl).'">'.$catName.'</a>';
							} else {
								$catList[] = L_UNCLASSIFIED;
							}
						}
						$replaces[] = implode(', ',$catList);
						break;
				}
			}
		} else
			$patterns = array();
		if ($n2 > 0) { // #artchapo, #art_content
			$patterns = array_merge($patterns, $matches2[0]);
			for ($i=0; $i<count($matches2[1]); $i++) {
				$strLength = (empty($matches2[2][$i])) ? 100 : intval($matches2[2][$i]);
				$f = substr($matches2[1][$i], 5);
				$replaces[] = plxUtils::truncate($art[$f],$strlength,$ending,true,true);
			}
		}
		if ($n3 > 0) { // champs supplémentaires
			$patterns = array_merge($patterns, $matches3[0]);
			foreach ($matches3[0] as $k) {
				$value = $art[substr($k, 1)];
				# On teste si la valeur est un nom d'image
				if (preg_match('/\.(?:jpg|jpeg|png|gif)$/', $value)) {
					$title = basename($value);
					$replaces[] = '<img src="'.$value.'" alt="'.substr($k, 5).'" title="'.$title.'" />';
				} else
					$replaces[] = plxUtils::strCheck($value);
			}
		}
		echo str_replace($patterns, $replaces, $format);
	}
}
return true;
?>

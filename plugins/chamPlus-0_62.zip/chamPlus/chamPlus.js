var mediasManager =  {
	
	open : function(aLabel, url) {
		var frameId = 'chamPlus-medias';
		var myFrame = document.getElementById(frameId);
		if (! myFrame) {
			myFrame = document.createElement('iframe');
			myFrame.setAttribute('id', frameId);
			myFrame.src = url;
			aLabel.form.appendChild(myFrame);
		}
		myFrame.style.display = 'block';
		this.target = aLabel.getAttribute('for');
		this.test = 'a';
		return false;
	},
	
	setValue: function (aValue) {
		var target = document.getElementById(this.target);
		if (target)
			target.value = aValue;
	},
	
	init: function (urlBase, btnLabel, confirmLabel) {
		if (window.frameElement) {
			this.cibleId = window.frameElement.getAttribute('data-target');
			this.urlBase = urlBase;
			// cachez ces éléments que je ne veux pas voir !!
			var aside = document.querySelector('body > main > aside');
			aside.style.display = 'none';
			var anchors = document.querySelectorAll('#medias-table tbody td:nth-of-type(3) a');
			for (var i=0, j=anchors.length; i<j; i++) {
				var anchor = anchors.item(i);
				anchor.setAttribute('onclick', "return mediasManager.putValue(this);");
			}
			// ajouter un bouton pour fermer
			var btn = document.createElement('input');
			btn.type = 'button';
			btn.value = btnLabel;
			btn.setAttribute('onclick', "window.frameElement.style.display = 'none';");
			btn.id = 'chamPlus-medias-close';
			document.body.appendChild(btn);
			this.confirmLabel = confirmLabel;
		}
	},
	
	putValue: function (anchor1) {
		var value = anchor1.href;
		value = value.substr(this.urlBase.length);
		if (confirm(this.confirmLabel+':\n'+value)) {
			window.parent.mediasManager.setValue(value);
			window.frameElement.style.display = 'none';
		}
		return false;
	}
}

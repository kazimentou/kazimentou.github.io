<?php

class kzIpApiJS extends plxPlugin {

	const PROVIDER_URL = 'http://ip-api.com/batch';
	const COMMENTS_SELECTOR = '#comments-table:not(.flag) td.ip-address[data-ip]';
	const MAX_IPS = 256;
	const SPRITES = true;

	# const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT;
	const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE;

	public function __construct($default_lang) {
		parent::__construct($default_lang);

		if(
			!function_exists('geoip_country_code_by_name') and
			function_exists('json_decode') and
			function_exists('curl_init')
		) {
			# Pour sauvegarde des paramètres
			parent::setConfigProfil(PROFIL_EDITOR);

			$this->lang = $default_lang;
			parent::addHook('AdminCommentsFoot', 'AdminCommentsFoot');

			if(!empty(self::SPRITES) and is_file(__DIR__.'/flags.css')) {
				parent::addHook('AdminTopEndHead', 'AdminTopEndHead');
			}
		}
	}

	/* --------- Hooks ------------- */

	public function AdminCommentsFoot() {
?>
	<div class="in-action-bar ip-api-logo">
		<a href="http://ip-api.com" rel="noreferrer nofollow" target="_blank"><img src="<?php echo PLX_PLUGINS.__CLASS__;  ?>/icon.png"></a>
	</div>
<script type="text/javascript">
	(function(selectorCSS) {
		'use strict';

		const cells = Array.prototype.slice.call(document.body.querySelectorAll(selectorCSS));

		if(cells.length > 0) {
			const KEY_STORAGE = '<?php echo __CLASS__; ?>';
			const content = sessionStorage.getItem(KEY_STORAGE);
			var datas = (content == null) ? { ipList: {}, timeStamp: 0} : JSON.parse(content);
			var ipListUpdated = false;

			function saveDatas() {
				if(!ipListUpdated) { return; }

				const maxIPs = <?php echo intval(self::MAX_IPS); ?>;
				if(Object.keys(datas.ipList).length > maxIPs) {
					var index = new Array();
					for(var ip in datas.ipList) {
						index.push([ip, datas.ipList[ip].timeStamp]);
					}
					// Tri selon la valeur de timeStamp
					index.sort(function (a,b) {
						return b[1] - a[1]
					});
					console.log('Trop d\'IPs : ' + index.length);
					console.log(index);
					for(var i=maxIPs, iMax=index.length; i<iMax; i++) {
						delete datas.ipList[index[i][0]];
					}
				}
				console.log(Object.keys(datas.ipList).length + ' IPs enregistrés')
				sessionStorage.setItem(KEY_STORAGE, JSON.stringify(datas));
			}

			function setFlags() {
				cells.forEach(function (cell) {
					const ip = cell.getAttribute('data-ip');
					if(ip in datas.ipList) {
						datas.ipList[ip].timeStamp = datas.timeStamp;
						const infos = datas.ipList[ip];

						// Adds a flag in the HTML page. And more...
<?php
		if(!empty(self::SPRITES)) {
?>
						const flag = document.createElement('SPAN');
						flag.className = 'kz-flag ' + infos.countryCode;
<?php
		} else {
?>
						const flag = document.createElement('IMG');
						flag.src = '<?php echo PLX_FLAGS_32_PATH; ?>' + infos.countryCode + '.png';
						flag.className = 'flag';
						flag.alt = infos.countryCode;
<?php
		}
?>
						flag.title = infos.country;
						cell.appendChild(flag);

						if(infos.city.trim().length > 0) {
							const span = document.createElement('SPAN');
							span.innerHTML = infos.city + ',<br />' + infos.country;
							cell.appendChild(span);
						}
					}
				});
			}

			function extractIP(text) {
				const matches = text.match(/([1-9]\d{0,2}(?:\.[1-9]\d{0,2}){3})/);
				return (matches != null) ? matches[1] : null;
			}

			function requestForNewIpAddrs() {
				var newIpAddrList = new Array();
				cells.forEach(function (cell) {
					const ip = (cell.hasAttribute('data-ip')) ? cell.getAttribute('data-ip') : extractIP(cell.textContent);
					if(ip != null && !(ip in datas.ipList)) {
						newIpAddrList.push({
							query: ip,
							lang: '<?php echo $this->lang; ?>'
						});
					}
				});
				if(newIpAddrList.length > 0) {
					const postDatas = JSON.stringify(newIpAddrList);
					const XHR =  new XMLHttpRequest();
					XHR.onreadystatechange = function (event) {
					    if (this.readyState === XMLHttpRequest.DONE) {
					        if (this.status === 200) {
								const infosList = JSON.parse(this.responseText);
								infosList.forEach(function (infos) {
									if(infos.status == 'success') {
										const ip = infos.query;
										delete infos.query;
										infos.timeStamp = datas.timeStamp;
										datas.ipList[ip] = infos;
										ipListUpdated = true;
									}
								});
								setFlags();
								saveDatas();
					        } else {
					            console.log("Status de la réponse: %d (%s)", this.status, this.statusText);
					        }
					    }
					}

					XHR.open('POST', '<?php echo self::PROVIDER_URL; ?>', true);
					XHR.setRequestHeader('Accept', 'application/json');
					XHR.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
					XHR.send(postDatas);
				} else {
					setFlags();
				}
			}

			requestForNewIpAddrs();
		}
	})('<?php echo self::COMMENTS_SELECTOR; ?>');
</script>
<?php
	}

	public function AdminTopEndHead() {
		$href = PLX_PLUGINS.__CLASS__.'/flags.css';
		echo <<< LINK
		<link rel="stylesheet" href="$href" />
LINK;
	}

}

?>
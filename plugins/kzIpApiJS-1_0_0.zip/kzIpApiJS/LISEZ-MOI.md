Plugin pour le CMS [PluXml](http://pluxml.org)

Récupère les informations de géo-localisation pour un lot d'adresses IP à partir du site http://ip-api.com.

Pour limiter les requêtes vers le serveur, la demande est faite en une seule dois pour l'ensemble des adresses IP dans la limite de 100 adresses.
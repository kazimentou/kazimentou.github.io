# Addon for the [PluXml](http://pluxml.org) CMS (content management system)

It can get geographic informations about a batch of IP addresses from the site http://ip-api.com in one HTTP request until 100 items.

[Logo](http://static.pluxml.org/common/img/pluxml-logo-bleu.png) [PluXml](http://pluxml.org)
<?php
if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour HighlightJS
 * version Magnific Popup - 2014-03-07
 * http://highlightjs.org/ version 8.0
 *
 * */

class highlightJS extends plxPlugin {

	public  function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
	}

	public function AdminTopEndHead($params) {
		global $plugin;

		if (!empty($plugin) && $plugin == __CLASS__) {?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.css" />
<?php	}
	}

	public function ThemeEndHead($params) {

?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__; ?>/highlight/styles/<?php echo $this->getParam('style'); ?>.min.css" />
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__; ?>/highlight/highlight.min.js"></script>
	<script> hljs.initHighlightingOnLoad(); </script>
	<?php
	}

}
?>

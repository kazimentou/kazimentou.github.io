<?php

$LANG = array(
'L_HIGHLIGHT_STYLE' => 'Style',
'L_HIGHLIGHT_INFO' => 'Le code à colorier dans les pages HTML doit être placé entre les&nbsp;balises &lt;pre&gt;&lt;code&gt; et &lt;/code&gt;&lt;/pre&gt;.<br /><br />
Pour forcer à afficher un langage particulier, par exemple html, il&nbsp;faut ajouter une&nbsp;classe comme ceci : &lt;pre class="lang-html"&gt;. Dans le cas de code HTML, convertir les caractères &lt; et &gt; en leurs entités HTML respectives.',
'L_HIGHLIGHT_DEMO' => 'Aperçu'
);

?>

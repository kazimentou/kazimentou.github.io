<?php
if (!defined('PLX_ROOT')) exit;

$fields = array('style'=>'string');
$default_values = array('style'=>'default');

if (!empty($_POST)) {
	foreach ($fields as $field=>$type) {
		$value = $_POST[$field];
		if (empty($value) && array_key_exists($field, $default_values))
			$value = $default_values[$field];
		$plxPlugin->setParam($field, $value, $type);
	}
	$plxPlugin->saveParams();
}

$rep = PLX_PLUGINS.$plugin.'/highlight/styles/';
$styles = array();
$styleSheets = glob($rep.'*.min.css');
if (!empty($styleSheets)) {
	foreach ($styleSheets as $filename) {
		$value = substr(basename($filename), 0, -8);
		$styles[$value] = ucFirst($value);
	}
}
else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
	echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
	$dir = new DirectoryIterator($rep.'.');
	foreach ($dir as $fileinfo) {
		$filename = basename($fileinfo->getFilename());
	    if ((substr($filename, -8) == '.min.css')) {
			$value = substr($filename, 0, -8);
			$styles[$value] = ucFirst($value);
		}
	}
	asort($styles);
}
?>
		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<form id="form_<?php echo $plugin; ?>" method="post" onsubmit="return true;">
<?php foreach ($fields as $field=>$type) {
		$value = $plxPlugin->getParam($field);
		if (!empty($value))
			$value = plxUtils::strCheck($value);
		else
			$value = (array_key_exists($field, $default_values)) ? $default_values[$field] : '';
		$class = ($type == 'cdata') ? 'class="large"' : '' ?>
			<p>
				<label <?php echo $class;?>><?php $plxPlugin->lang('L_HIGHLIGHT_'.strtoupper($field)); ?></label>
<?php
		switch ($type) {
			case 'cdata' :
				plxUtils::printArea(BODY, $value, 70, 12);
				break;
			case 'numeric' :
				break;
			default :
				switch ($field) {
					case 'style' :
						plxUtils::printSelect($field, $styles, $value); ?>
				<a href="<?php echo PLX_PLUGINS.$plugin; ?>/highlight/test.html" target="blank"><?php echo $plxPlugin->lang('L_HIGHLIGHT_DEMO'); ?></a>
<?php
						break;
					default :
						plxUtils::printInput($field, $value, 'text', '50-80');
						break;
				}
				break;
		echo "\n";
		} ?>
			</p>
<?php } ?>
			<p>
				<?php echo $plxPlugin->lang('L_HIGHLIGHT_INFO'); ?>
			</p>
			<p>
				<label>&nbsp;</label>
				<input type="submit" />
			</p>
		</form>

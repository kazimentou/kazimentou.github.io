<?php

// download from http://highlightjs.org/static/
stylesheets = array(
	"Default"=>"styles/default.css">
	"Dark"=>"styles/dark.css">
	"FAR"=>"styles/far.css">
	"IDEA"=>"styles/idea.css">
	"Sunburst"=>"styles/sunburst.css">
	"Zenburn"=>"styles/zenburn.css">
	"Visual Studio"=>"styles/vs.css">
	"Ascetic"=>"styles/ascetic.css">
	"Magula"=>"styles/magula.css">
	"GitHub"=>"styles/github.css">
	"Google Code"=>"styles/googlecode.css">
	"Brown Paper"=>"styles/brown_paper.css">
	"School Book"=>"styles/school_book.css">
	"IR Black"=>"styles/ir_black.css">
	"Solarized - Dark"=>"styles/solarized_dark.css">
	"Solarized - Light"=>"styles/solarized_light.css">
	"Arta"=>"styles/arta.css">
	"Monokai"=>"styles/monokai.css">
	"Monokai Sublime"=>"styles/monokai_sublime.css">
	"XCode"=>"styles/xcode.css">
	"Pojoaque"=>"styles/pojoaque.css">
	"Rainbow"=>"styles/rainbow.css">
	"Tomorrow"=>"styles/tomorrow.css">
	"Tomorrow Night"=>"styles/tomorrow-night.css">
	"Tomorrow Night Bright"=>"styles/tomorrow-night-bright.css">
	"Tomorrow Night Blue"=>"styles/tomorrow-night-blue.css">
	"Tomorrow Night Eighties"=>"styles/tomorrow-night-eighties.css">
	"Railscasts"=>"styles/railscasts.css">
	"Obsidian"=>"styles/obsidian.css">
	"Docco"=>"styles/docco.css">
	"Mono Blue"=>"styles/mono-blue.css">
	"Foundation"=>"styles/foundation.css">
	"Atelier Dun - Dark"=>"styles/atelier-dune.dark.css">
	"Atelier Dun - Light"=>"styles/atelier-dune.light.css">
	"Atelier Forest - Dark"=>"styles/atelier-forest.dark.css">
	"Atelier Forest - Light"=>"styles/atelier-forest.light.css">
	"Atelier Heath - Dark"=>"styles/atelier-heath.dark.css">
	"Atelier Heath - Light"=>"styles/atelier-heath.light.css">
	"Atelier Lakeside - Dark"=>"styles/atelier-lakeside.dark.css">
	"Atelier Lakeside - Light"=>"styles/atelier-lakeside.light.css">
	"Atelier Seaside - Dark"=>"styles/atelier-seaside.dark.css">
	"Atelier Seaside - Light"=>"styles/atelier-seaside.light.css">
	"Paraíso - Dark"=>"styles/paraiso.dark.css">
	"Paraíso - Light"=>"styles/paraiso.light.css">
);
?>

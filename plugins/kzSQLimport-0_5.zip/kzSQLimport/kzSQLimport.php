<?php
if(!defined('PLX_ROOT')) { exit; }

/*
 * Utiliser le plugins moveMyDatas pour créer un dossier de données
 * (http://kazimentou.fr/pluxml-plugins2/index.php?plugin=moveMyDatas&download)
 *
 * https://www.spip.net/fr_article713.html ( structure des données )
 * */

class kzSQLimport extends plxPlugin {

	const MNU_LABEL = 'Import SQL';
	const PATTERN = '/configuration/parametres.xml';
	const TABLES = 'users categories articles';

	const SPIP_ARTICLES = <<< QUERY
select id_article, titre, chapo, texte, soustitre as meta_description, date, maj, date_modif, id_rubrique, id_secteur
	from spip_articles
	where id_article < 10000;
QUERY;

	private $__source = 'spip';
	private $__dsn = false;
	private $__login = false;
	private $__pass = false;
	private $__target = false;
	private $__queries = array(
		'spip' => array(
			'users'				=> 'select id_auteur as id, nom as name, bio as infos, email, login, lang, webmestre, statut from spip_auteurs where id_auteur < 1000;',
			'categories'		=> 'select id_rubrique as id_categorie, titre as name, texte as description, descriptif as meta_description from spip_rubriques where id_rubrique < 1000;',
			'articles'			=> self::SPIP_ARTICLES,
			'users_articles'	=> 'select id_article, id_auteur from spip_auteurs_articles order by id_article;',
			'tags_articles'		=> 'select id_article, titre as tag from spip_mots_articles as a, spip_mots as m where a.id_mot=m.id_mot order by id_article, tag;',
			'secteurs'			=> 'select id_rubrique, id_secteur from spip_rubriques where id_rubrique != id_secteur order by id_secteur;'
		),
		'wordpress' => array(
			'users'			=> '',
			'categories'	=> '',
			'tags'			=> '',
			'articles'		=> ''
		),
		'getgrav' => array(
			'users'			=> '',
			'categories'	=> '',
			'tags'			=> '',
			'articles'		=> ''
		)
	);

	public function __construct($default_lang='fr') {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		if(class_exists('PDO') and !empty(PDO::getAvailableDrivers())) {
			$this->setAdminProfil(PROFIL_ADMIN);
			$title = $this->getlang('TITLE');
			$this->setAdminMenu($this::MNU_LABEL, 0, $title);
		} else {
			plxMsg::Error('** One PDO driver is required **');
		}

		$this->addHook('plxAdminConstruct', 'plxAdminConstruct');

	}

	/**
	 * Retrouve la liste des dossiers contenant un fichier configuration/parametres.xml.
	 * */
	public function getFolders() {
		return array_map(
			function($item) {
				return preg_replace('@^.*/([^\/]+)'.kzSQLImport::PATTERN.'@', '$1', str_replace('\\', '/', $item));
			},
			glob(PLX_ROOT.'*'.kzSQLImport::PATTERN)
		);
	}

	public function getFoldersForSelect() {
		$result = array();
		foreach($this->getFolders() as $folder) {
			$result[$folder] = $folder;
		}
		return $result;
	}

	/**
	 * Détermine le paramètre de connection au SGBDr.
	 * */
	public function get_dsn() {
		$dsn = $this->getParam('dsn');
		$dbname = $this->getParam('dbname');
		if(!empty($dsn)) {
			return $dsn;
		} elseif(!empty($dbname)) {
			$server = $this->getParam('server');
			if(empty($server)) { $server = 'localhost'; }
			$dsn = $this->getParam('motorSQL').':';
			$dsn .= implode(';', array(
				'host='.$server,
				'dbname='.$dbname,
				'charset=utf8'
			));
			// plxUtils::debugJS($dsn);
			return $dsn;
		} else {
			return false;
		}
	}

	/**
	 * Ouvre la connection au SGBDr.
	 * */
	public function connectSQL() {
		$login = $this->getParam('login');
		$password = $this->getParam('password');
		$dsn = $this->get_dsn();
		if(!empty($login) and !empty($password) and !empty($dsn)) {
			try {
				$this->dbh = new PDO($dsn, $login, $password);
				return true;
			} catch(PDOException $err) {
				plxMsg::Error($err->getMessage());
				return false;
			}
		} else {
			return false;
		}
	}

	public function getCMSList() {
		return array_keys($this->__queries);
	}

	private function __save($filename, $items) {
		$cname = 'constante';//{$cname('PLX_CHARSET')}
		$doc_open = <<< DOCUMENT_START
<?xml version="1.0" encoding="UTF-8"?>
<document>

DOCUMENT_START;
		$doc_close = <<< DOCUMENT_END
</document>

DOCUMENT_END;

		if(plxUtils::write($doc_open.$items.$doc_close, $filename)) {
			return true;
		} else {
			return plxMsg::Error(L_SAVE_ERR.' '.path('XMLFILE_CATEGORIES'));
		}
	}

/* ============== users ================ */
	private function __import_users() {
		$current_login = $this->currentUser['login'];
		$found_login = false;
		$output = '';
		$lang = $this->lang;
		$spip_statut = array(
			'0minirezo'	=> PROFIL_MANAGER,
			'1comite'	=> PROFIL_MODERATOR,
			'5poubelle'	=> PROFIL_WRITER,
			'6forum'	=> PROFIL_WRITER
		);
		$last_id = 0;
		try {
			foreach($this->dbh->query($this->__queries['spip']['users'], PDO::FETCH_ASSOC) as $row) {
				if($last_id < $row['id']) {
					$last_id = $row['id'];
				}
				$number = str_pad($row['id'], 3, '0', STR_PAD_LEFT);
				if($current_login == $row['login']) {
					$salt = $this->currentUser['salt'];
					$password = $this->currentUser['password'];
					$found_login = true;
				} else {
					$salt = plxUtils::charAleatoire(10); // cf. install.php
					$password = sha1($salt.md5($row['login']));
				}

				if(in_array(strtolower($row['webmestre']), array('oui', 'yes', '1'))) {
					$profil = PROFIL_ADMIN;
				} elseif(array_key_exists($row['statut'], $spip_statut)) {
					$profil = $spip_statut[$row['statut']];
				} else {
					$profil = PROFIL_WRITER;
				}
				$delete = ($row['statut'] == '5poubelle') ? '1' : '0';
				$output .= <<< USER
	<user number="$number" active="1" profil="$profil" delete="$delete">
		<login><![CDATA[{$row['login']}]]></login>
		<name><![CDATA[{$row['name']}]]></name>
		<infos><![CDATA[{$row['infos']}]]></infos>
		<password><![CDATA[$password]]></password>
		<salt><![CDATA[$salt]]></salt>
		<email><![CDATA[{$row['email']}]]></email>
		<lang><![CDATA[$lang]]></lang>
	</user>

USER;
			}
			if(!$found_login) {
				$last_id++;
				$number = str_pad($last_id, 3, '0', STR_PAD_LEFT);
				$profil= PROFIL_ADMIN;
				$output .= <<< USER
	<user number="$number" active="1" profil="$profil" delete="0">
		<login><![CDATA[{$this->currentUser['login']}]]></login>
		<name><![CDATA[{$this->currentUser['name']}]]></name>
		<infos><![CDATA[{$this->currentUser['infos']}]]></infos>
		<password><![CDATA[{$this->currentUser['password']}]]></password>
		<salt><![CDATA[{$this->currentUser['salt']}]]></salt>
		<email><![CDATA[{$this->currentUser['email']}]]></email>
		<lang><![CDATA[{$this->currentUser['lang']}]]></lang>
	</user>

USER;
			}
			return $this->__save(path('XMLFILE_USERS'), $output);

		} catch(Exception $err) {
			plxMsg::Error($err->getMessage());
		}
	}
/* ============ categories ============= */
	private function __import_categories() {

		// Sous Spip, les catégories s'appellent rubriques.
		/*
		 * contrôler l'unicité des noms de catégories
		 * Voir plxAdmin::editCategories(..)
		 * */
		$output = '';
		$meta_keywords = ''; // voir table spip_mots_rubriques et spip_mots
		$title_htmltag = '';

		// récupère les paramètres par défaut de PluXml pour les éléments suivants :
		$tri = $this->tri;
		$bypage = $this->bypage;
		foreach($this->dbh->query($this->__queries['spip']['categories'], PDO::FETCH_ASSOC) as $row) {
			$cat_id = str_pad($row['id_categorie'], 3, '0', STR_PAD_LEFT);
			$name = plxUtils::cdataCheck($row['name']);
			$url = plxUtils::title2url($name);
			$description = plxUtils::cdataCheck($row['description']);
			$meta_description = plxUtils::cdataCheck($row['meta_description']);
			$output .= <<< CATEGORIE
	<categorie number="$cat_id" active="1" homepage="1" tri="$tri" bypage="$bypage" menu="1" url="$url" template="categorie.php">
		<name><![CDATA[$name]]></name>
		<description><![CDATA[$description]]></description>
		<meta_description><![CDATA[$meta_description]]></meta_description>
		<meta_keywords><![CDATA[$meta_keywords]]></meta_keywords>
		<title_htmltag><![CDATA[$title_htmltag]]></title_htmltag>
	</categorie>

CATEGORIE;
		}
		return $this->__save(path('XMLFILE_CATEGORIES'), $output);
	}

/* ============== articles ============= */

	/**
	 * Récupère les relations entre les auteurs et articles dans le SGBDr.
	 * */
	private function __users_articles() {
		$result = array();
		foreach($this->dbh->query($this->__queries['spip']['users_articles'], PDO::FETCH_ASSOC) as $row) {
			$result[$row['id_article']] = str_pad($row['id_auteur'], 3, '0', STR_PAD_LEFT);
		}
		return $result;
	}

	/**
	 * Récupère les relations entre les tags et articles dans le SGBDr.
	 * */
	private function __tags_articles() {
		$result = array();
		foreach($this->dbh->query($this->__queries['spip']['tags_articles'], PDO::FETCH_ASSOC) as $row) {
			$id = $row['id_article'];
			if(!array_key_exists($id, $result)) {
				$result[$id] = array();
			}
			$result[$id][] = trim($row['tag']);
		}
		return $result;
	}

	/**
	 * Récupère les groupes de rubriques de Spip pour les catégories des articles.
	 * */
	private function __spip_get_secteurs() {
		// SPIP peut regrouper les catégories, pas PluXml.
		$result = array();
		foreach($this->dbh->query($this->__queries['spip']['secteurs'], PDO::FETCH_ASSOC) as $row) {
			$secteur = $row['id_secteur'];
			if(!array_key_exists($secteur, $result)) {
				$result[$secteur] = array();
			}
			$result[$secteur][] = str_pad($row['id_rubrique'], 3, '0', STR_PAD_LEFT);
		}
		return $result;
	}

	/**
	 * Transforme une datetime stockée dans le SGBDr en tableau pour PluXml.
	 * */
	private function __formatDate($value) {
		// $value = '2008-12-07 11:47:27';
		list($date, $time) = explode(' ', $value);
		list($year, $month, $day) = explode('-', $date);
		return array(
			'year'	=> $year,
			'month'	=> $month,
			'day'	=> $day,
			'time'	=> substr($time,0, 5)
		);
	}

	private function __update_urls($content) {
		$mask = <<< MASK
@href="[^"]*spip\.php\?article(\d+)"@
MASK;
		return preg_replace($mask, 'href="index.php?article$1"', $content);
	}

	private function __import_articles() {
		global $plxAdmin;

		// Suppression de tous les articles
		foreach($plxAdmin->plxGlob_arts->aFiles as $filename) {
			$plxAdmin->delArticle(preg_replace('@^(_?\d{4}).*$@', '$1', $filename));
		}

		$authors = $this->__users_articles();
		$secteurs = $this->__spip_get_secteurs();
		$tags_list = $this->__tags_articles();

		$stmt = $this->dbh->query($this->__queries['spip']['articles'], PDO::FETCH_ASSOC);
		while($row = $stmt->fetch()) {
			$id =$row['id_article'];
			$art_id = str_pad($id, 4, '0', STR_PAD_LEFT);
			if(!empty($row['id_rubrique'])) {
				if($row['id_rubrique'] != $row['id_secteur'] and array_key_exists($row['id_secteur'], $secteurs)) {
					$categories = $secteurs[$row['id_secteur']];
					$categories[] = str_pad($row['id_secteur'], 3, '0', STR_PAD_LEFT);
				} else {
					$categories = array(
						str_pad($row['id_rubrique'], 3, '0', STR_PAD_LEFT)
					);
				}
			} else {
				$categories = array('000');
			}
			$creation = $this->__formatDate($row['date_modif']);
			$update = $this->__formatDate($row['maj']);
			$article = array(
				'artId'					=> $art_id, // may be empty
				'title'					=> $row['titre'],
				'url'					=> '',
				'allow_com'				=> '1',
				'template'				=> 'article.php',
				'chapo'					=> html_entity_decode($row['chapo']),
				'content'				=> $this->__update_urls(html_entity_decode($row['texte'])),
				'tags'					=> (array_key_exists($id, $tags_list)) ? implode(',', $tags_list[$id]) : '',
				'meta_description'		=> trim($row['meta_description']),
				'meta_keywords'			=> '',
				'title_htmltag'			=> '',
				'filename'				=> '',
				'author'				=> $authors[$row['id_article']],
				'thumbnail'				=> '',
				'thumbnail_title'		=> '',
				'thumbnail_alt'			=> '',
				'catId'					=> $categories,
				'date'					=> $this->__formatDate($row['date']),
				'date_creation_year'	=> $creation['year'],
				'date_creation_month'	=> $creation['month'],
				'date_creation_day'		=> $creation['day'],
				'date_creation_time'	=> $creation['time'],
				'date_publication_year'	=> $creation['year'],
				'date_publication_month'=> $creation['month'],
				'date_publication_day'	=> $creation['day'],
				'date_publication_time'	=> $creation['time'],
				'date_update_year'		=> $update['year'],
				'date_update_month'		=> $update['month'],
				'date_update_day'		=> $update['day'],
				'date_update_time'		=> $update['time'],
				'date_update_old'		=> $update['year'].$update['month'].$update['day'].str_replace(':', '', $update['time']),
				'nb_com'				=> 0
			);
			$plxAdmin->editArticle($article, $art_id);
		}
/*
<?xml version="1.0" encoding="UTF-8"?>
<document>
	<title><![CDATA[$title]]></title>
	<allow_com>1</allow_com>
	<template>article.php</template>
	<chapo><![CDATA[$chapo]]></chapo>
	<content><![CDATA[$content]]></content>
	<tags><![CDATA[$tags]]></tags>
	<meta_description></meta_description>
	<meta_keywords></meta_keywords>
	<title_htmltag></title_htmltag>
	<date_creation>$created</date_creation>
	<date_update>$published</date_update>
	<thumbnail><![CDATA[$thumbnail]]></thumbnail>
</document>
 * */
		return true;
	}

	/**
	 * Importe toutes les données nécessaires depuis le SGBDr pour PluXml.
	 * */
	public function import($tables) {
		if(!empty($tables) and $this->connectSQL()) {
			$this->__target = $this->getParam('folder');
			try {
				if(
					(!in_array('users', $tables) or $this->__import_users()) and
					(!in_array('categories', $tables) or $this->__import_categories()) and
					(!in_array('articles', $tables) or $this->__import_articles())
				) {
					plxMsg::Info(L_SAVE_SUCCESSFUL);
					return true;
				}
			} catch(PDOException $err) {
				plxMsg::Error($err->getMessage());
				header('Location: parametres_plugin.php?p='.__CLASS__);
			}
		} else {
			return false;
		}
	}

/* -------- Hooks ------- */
	public function plxAdminConstruct() {
		$code = <<< 'CODE'
<?php
	if(!empty($_SESSION['user'])) {
		$plugin = $this->plxPlugins->aPlugins['kzSQLimport'];
		$plugin->tri = $this->tri;
		$plugin->bypage = $this->bypage;
		$plugin->lang = $this->aConf['default_lang'];
		$plugin->currentUser = $this->aUsers[$_SESSION['user']];
	}
?>

CODE;
		echo $code;
	}

}

?>
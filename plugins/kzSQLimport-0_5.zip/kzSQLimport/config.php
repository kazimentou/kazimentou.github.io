<?php
if(!defined('PLX_ROOT')) { exit; }

/* --------- checks if we have any driver for SGBDr -------- */
if(!class_exists('PDO')) {
	plxMsg::Error($plxPlugin->getLang('L_MISSING_PDO_LIBRARY'));
	exit;
}
$pdo_drivers = PDO::getAvailableDrivers(); // (mysql, pgsql, sqlite)
if(empty($pdo_drivers)) {
	plxMsg::Error($plxPlugin->getLang('L_NO_DRIVER_FOR_SGBDR'));
	exit;
}
$known_motorSQL = array(
	'mysql'		=> 'MySQL',
	'pgsql'		=> 'PostgreSQL',
	'sqlite'	=> 'SQLite 3'
);
$motorSQL = array('' => 'v ---');
foreach($pdo_drivers as $driver) {
	if(array_key_exists($driver, $known_motorSQL)) {
		$motorSQL[$driver] = $known_motorSQL[$driver];
	} else {
		$motorSQL[$driver] = ucfirst(str_ireplace('sql', 'SQL', $driver));
	}
}

# Control du token du formulaire
plxToken::validateFormToken($_POST);

$params = array(
	'motorSQL'	=> 'select',
	'server'	=> 'string',
	'dbname'	=> 'string',
	'dsn'		=> 'string',
	'login'		=> 'string',
	'password'	=> 'string'
/*	'folder'	=> 'select' */
);

$go_home = 'Location: parametres_plugin.php?p='.$plugin;

function bad_post_value($field) {
	plxMsg::Error(sprintf($plxPlugin->getLang('L_BAD_VALUE_POST'), $plxPlugin->lang('L_'.strtoupper($field))));
	header($go_home);
	exit;
}

if(!empty($_POST)) {
	foreach(array_keys($params) as $field) {
		$value = trim($_POST[$field]);
		if(!empty($value)) {
			switch($field) {
				// checks any $value
				case 'motorSQL':
					if(!array_key_exists($value, $motorSQL)) { bad_post_value($field); }
					break;
				case 'dsn':
					$mask = '^(?:'.implode('|', array_filter(
						array_keys($motorSQL),
						function($item) {
							return !empty($item);
						}
					)).'):((?:host|charset)=\w+;)*dbname=\w+(;(?:host|charset)=\w+)*$';
					if(!preg_match($mask, $value)) { bad_post_value($field); }
					break;
				default :
					if(!preg_match('@^[ \w-]*$@')) { bad_post_value($field); }
			}
			$plxPlugin->setParam($field, $value, 'string');
		} else {
			$plxPlugin->delParam($field);
		}
	}
	$plxPlugin->saveParams();

	header($go_home);
	exit;
}

$selects = array(
	'motorSQL'	=> $motorSQL,
	'folder'	=> $plxPlugin->getFoldersForSelect()
);

function myPrintInput($name, $value, $type='text') {
	$placeholders = array(
		'server'	=> 'localhost by default',
		'dsn' 		=> 'mysql:dbname=my-database;host=my-server.com;charset=utf8'
	);
	$params = array(
		'id="id_'.$name.'"',
		'name="'.$name.'"',
		'type="'.$type.'"',
		'value="'.$value.'"'
	);
	if(array_key_exists($name, $placeholders)) { $params[] = 'placeholder="'.$placeholders[$name].'"'; }
	echo '<input '.implode(' ', $params).' />';

}
/* ------------ form starts here -----------------*/
?>
<form id="form_<?php echo $plugin; ?>" method="post">
	<input id="tab-0" type="radio" name="tab" value="0" checked>
	<label for="tab-0"><?php $plxPlugin->lang('L_CONNEXION'); ?></label>
	<div>
		<fieldset>
<?php
	foreach($params as $name=>$type) {
		$value = $plxPlugin->getParam($name);
?>
			<p>
				<label for="id_<?php echo $name; ?>"><?php $plxPlugin->lang('L_'.strtoupper($name)); ?></label>
<?php
		switch($type) {
			case 'select':
				if(array_key_exists($name, $selects)) {
					plxUtils::printSelect($name, $selects[$name], $value);
				} else {
					echo "Select not found";
				}
				break;
			default : /* string */
				myPrintInput($name, $value);
		}
?>
			</p>
<?php

	}
?>
		</fieldset>
	</div>
<?php
/* --------------- test de la connexion à la base de données SGBDr ---------------- */
$plxPlugin->connectSQL();
if(!empty($plxPlugin->dbh)) {
	$counter = 1;
	$limit = 10;
	$tables = array(
		'Tables'		=> 'show tables;',
		'Articles'		=> "select * from spip_articles limit $limit;",
		'Catégories'	=> "select * from spip_rubriques limit $limit;",
		'Utilisateurs'	=> "select * from spip_auteurs limit $limit;",
		'Tags'			=> "select * from spip_mots limit $limit;"
	);
	try {
		foreach($tables as $caption=>$query) {
?>
	<input id="tab-<?php echo $counter; ?>" type="radio" name="tab" value="<?php echo $counter; ?>">
	<label for="tab-<?php echo $counter; ?>"><?php echo $caption; ?></label>
	<div class="scrollable-table">
		<table>
<?php
			$first = true;
			$resp = $plxPlugin->dbh->query($query, PDO::FETCH_ASSOC);
			foreach($resp as $row) {
				if($first) {
?>
			<thead>
				<tr>
<?php
				foreach(array_keys($row) as $title) {
					echo "<th>$title</th>\n";
				}

?>
				</tr>
			</thead>
			<tbody>
<?php
					$first = false;
				}
?>
				<tr>
<?php
				foreach($row as $value) {
					$cell = htmlspecialchars($value);
					echo <<< CELL
					<td><pre>$cell</pre></td>

CELL;
				}
?>
				</tr>
<?php
			}
?>
			</tbody>
		</table>
	</div>
<?php
			$counter++;
		}
?>
	<div class="infos">
		<p class="text-center">
			<?php printf($plxPlugin->getLang('L_MAX_RECORDS'), $limit); ?>
		</p>
		<p class="connexion-infos">
<?php
		$attributes = array(
			'Driver'		 => 'DRIVER_NAME',
			'Version server'	=> 'SERVER_VERSION',
			'Connection'		=> 'CONNECTION_STATUS'
		);
		foreach ($attributes as $caption=>$val) {
			echo "<span>$caption : ".$plxPlugin->dbh->getAttribute(constant("PDO::ATTR_$val"))."</span>\n";
		}
	?>
		</p>
	</div>
<?php
	} catch(PDOException $err) {
		$msg = $err->getMessage();
		echo <<< DB_ERROR
<div>
	Erreur: $msg
</div>
DB_ERROR;
	}
}
?>
	<div class="in-action-bar">
		<?php echo plxToken::getTokenPostMethod()."\n"; ?>
		<input type="submit" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>" />
	</div>
</form>
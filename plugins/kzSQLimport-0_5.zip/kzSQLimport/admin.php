<?php
if(!defined('PLX_ROOT')) { exit; }


# Control du token du formulaire
plxToken::validateFormToken($_POST);

if(!empty($_POST['tables']) and $plxPlugin->import($_POST['tables'])) {
	$locations = array(
		'articles'		=> 'index.php',
		'categories'	=> 'categories.php',
		'users'			=> 'parametres_users.php'
	);
	foreach(array_keys($locations) as $table) {
		if(in_array($table, $_POST['tables'])) {
			header('Location: '.$locations[$table]);
			exit;
		}
	}
}

?>
<div>
	<?php $plxPlugin->lang('L_IMPORT_INFOS');?>
</div>
<form id="form_<?php echo $plugin; ?>" class="import" method="post">
	<fieldset>
<?php
	foreach(explode(' ', kzSQLimport::TABLES) as $table) {
?>
		<p>
			<input type="checkbox" id="import-<?php echo $table; ?>" name="tables[]" value="<?php echo $table; ?>" />
			<label for="import-<?php echo $table; ?>"><?php $plxPlugin->lang('L_IMPORT_'.strtoupper($table)); ?></label>
		</p>
<?php
	}
?>
	</fieldset>
	<div class="in-action-bar">
		<?php echo plxToken::getTokenPostMethod(); ?>
		<input type="submit" value="<?php $plxPlugin->lang('L_IMPORT'); ?>">
	</div>
</form>
<!-- p>
	<em><?php $plxPlugin->lang('L_TARGET_FOLDER'); echo ' : '.$plxPlugin->getParam('folder'); ?></em>
</p -->
<script type="text/javascript">
	(function() {
		'use strict';

		document.forms[0].addEventListener('submit', function(event) {
			const tables = event.target.querySelectorAll('input[name="tables[]"]:checked');
			if(tables.length == 0) {
				alert('<?php $plxPlugin->lang('L_ONE_OR_MORE_ELEMENTS'); ?>');
				event.preventDefault();
			}
		});
	})();
</script>
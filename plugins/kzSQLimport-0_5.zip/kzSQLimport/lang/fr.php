<?php
	const KZ_SQL_IMPORT_INFOS = <<< 'INFOS'
Au moins une table ci-dessous doit être sélectionnée.
Pour commencer, il est conseillé de cocher toutes les tables.
Toutes les données des utilisateurs et des catégories seront remplacées.
A l'importation le mot de passe de tous les utilisateurs sera ré-initialisé à la valeur de leurs identifiants (password=login).
Avant d'importer les articles depuis la base de données SQL, tous les articles et les commentaires seront effacés.

Cette version est limitée à l'importation depuis Spip version 2.
INFOS;
	$LANG = array(
		'L_MNU_TITLE'			=> 'Extraction de données depuis un server SQL',
		'L_MOTORSQL'			=> 'Type de base de données',
		'L_SERVER'				=> 'Serveur',
		'L_DBNAME'				=> 'Base de données',
		'L_DSN'					=> 'Data Source Name (DSN)',
		'L_LOGIN'				=> 'Nom d\'utilisateur',
		'L_PASSWORD'			=> 'Mot de passe',
		'L_FOLDER'				=> 'Dossier de données cible',
		'L_NEX_FOLDER'			=> 'Nouveau',
		'L_CONNEXION'			=> 'Connection',
		'L_IMPORT'				=> 'Importer les données',
		'L_IMPORT_USERS'		=> 'Profils',
		'L_IMPORT_CATEGORIES'	=> 'catégories',
		'L_IMPORT_TAGS'			=> 'Mots-clés',
		'L_IMPORT_ARTICLES'		=> 'Articles',
		'L_IMPORT_INFOS'		=> nl2br(KZ_SQL_IMPORT_INFOS),
		'L_ONE_OR_MORE_ELEMENTS'=> 'Au moins une case doit être cochée.',
		'L_MAX_RECORDS'			=> 'L\'affichage de chaque table est limité à %s enregistrements.',
		'L_TARGET_FOLDER'		=> 'Dossier de destination'
	);
?>
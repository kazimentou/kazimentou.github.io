<?php

/**
 * capchaImage
 *
 * @package capchaImage
 * version	1.0
 * @author	Stéphane F
 **/

# tableau contenant les fontes disponibles
$fonts = glob(__DIR__.'/fonts/*.ttf');

# Création de l'image de fond du capcha
$backgrounds = glob(__DIR__.'/backgrounds/capcha*.png');
$filename = $backgrounds[array_rand($backgrounds)];
$image = imagecreatefrompng($filename);

# tableau des couleurs pour les lettres. imagecolorallocate() retourne un identifiant de couleur.
$colors=array(
	imagecolorallocate($image, 131,154,255), # bleu ciel
	imagecolorallocate($image, 89,186,255), # bleu turquoise
	imagecolorallocate($image, 119,151,173), # bleu gris
	imagecolorallocate($image, 242,67,149), # rose foncé
	imagecolorallocate($image, 32,151,82) # vert sapin
);

# Génère le code du capcha
function getCode($length) {

	$chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZ:!#&%?=';
	$rand_str = '';
	for ($i=0; $i<$length; $i++) {
		$rand_str .= $chars{ mt_rand( 0, strlen($chars)-1 ) };
	}
	return $rand_str;
}

session_start();

# Code du capcha
$theCode = getCode(count($colors));
$_SESSION['capcha'] = sha1(strtolower($theCode));

// header('Content-Type: text/plain');

# imagettftext(image, taille police, angle inclinaison, coordonnée X, coordonnée Y, couleur, police, texte) écrit le texte sur l'image.
define('FONT_SIZE', 28);

for ($i=0; $i<strlen($theCode); $i++) {
	$angle = mt_rand(-15, 15);
	$fontName = $fonts[array_rand($fonts)];
	$theChar = $theCode[$i];
	$sizeBox = imagettfbbox(FONT_SIZE, $angle, $fontName, $theChar);
	$w = abs($sizeBox[4] - $sizeBox[0]); if ($w > 32) $w = 0;
	$h = abs($sizeBox[5] - $sizeBox[1]);
	// echo "$w - $h\n";
	imagettftext($image, FONT_SIZE, $angle,  mt_rand(-2, 32 - $w) + $i*30,  mt_rand(30,47), $colors[array_rand($colors)], $fontName, $theChar);
}
// exit;

# Envoi de l'image
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>
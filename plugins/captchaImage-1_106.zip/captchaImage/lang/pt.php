<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=>	'D&iacute;gite o c&oacute;digo da imagem ',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);

?>

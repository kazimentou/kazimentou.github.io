<?php

if (!defined('PLX_ROOT'))
	exit;

/* ****************************
 * author Jean-Pierre Pourrez
 * date : 2014-02-13
 * testé avec PluXml 5.3
 * mise à jour : 2015-11-16
 * testé avec PluXml 5.4
 * date : 2017-02-05
 * mise à jour pour Pluxml 5.6
 * **************************** */

define('RESP_CAPTCHA_NAME', 'respCaptcha');

class captchaImage extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# Ajouts des hooks
		$this->addHook('plxShowCapchaQ', 'plxShowCapchaQ');
		$this->addHook('AdminAuthPrepend', 'AdminAuthPrepend');
		$this->addHook('AdminAuthTop', 'AdminAuthTop');
		$this->addHook('AdminAuth', 'AdminAuth');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

	private function pluginRoot() {
		global $plxShow;

		if (isset($plxShow)) {
			return $plxShow->plxMotor->racine.$plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}

	private function showCapcha() {

		$backgrounds = glob(__DIR__.'/backgrounds/capcha*.png');
		$filename = $backgrounds[array_rand($backgrounds)];
		$imagesize = getimagesize($filename);
		$widthAttribute = $imagesize[3];

		$msg = $this->getLang('L_CAPTCHA_MESSAGE');
		// PLX_ROOT n'est pas encore défini dans la page d'authentification
		$pwd = $this->pluginRoot();
		 echo <<< EOT
		$msg<br />
		<img src="${pwd}capcha.php" alt="Captcha" id="capcha" $widthAttribute />
EOT;
	}

	public function plxShowCapchaQ() {

		$this->showCapcha();
		echo '<?php return true; ?>';
	}

	public function ThemeEndBody() {
		global $plxShow;
		if (defined('PLX_VERSION')) {
			if (version_compare(PLX_VERSION, '5.4', '>=')) {
				$id = 'id_rep';
			}
		} else {
			$id = 'id_capcha_rep';
		}
?>
		<script type="text/javascript"> <!-- captchaImage -->
			<!--
			var repId = document.getElementById('<?php echo $id; ?>');
			if (repId) {
				repId.setAttribute('maxlength', '5');
				repId.style.width = '5em';
			}
			else
				console.log('Input with id: <?php echo $id; ?> not found');
			// -->
		</script>
<?php
	}

	public function AdminAuthPrepend() {

		if (isset($_SESSION['capcha']) and isset($_POST[RESP_CAPTCHA_NAME]))  {
			if ($_SESSION['capcha'] !== sha1(strtolower($_POST[RESP_CAPTCHA_NAME]))) {
				global $plxAdmin;

				foreach ($plxAdmin->aUsers as $id=>$user) {
					if ($_POST['login'] == $user['login']) {
						$plxAdmin->aUsers[$id]['active'] = false;
						$this->msgCapcha = $this->aLang['L_CAPTCHA_ERROR'];
						break;
					}
				}
			}
		}
	}

	public function AdminAuthTop() {
		global $msg;

		if (isset($this->msgCapcha)) {
			// On traite l'erreur sur le captcha
			$msg = $this->msgCapcha;
		}
	}

	public function AdminAuth() { ?>
		<div class="col sml-12 text-center">
			<?php $this->showCapcha(); ?><br />
			<input name="<?php echo RESP_CAPTCHA_NAME; ?>" type="text" size="5" maxlength="5" />
		</div>
<?php
	}

}
?>
/*
  jQuery Colorbox language configuration
  language: French (fr)
  translated by: oaubert
*/
jQuery.extend(jQuery.colorbox.settings, {
	current: "image {current} sur {total}",
	previous: "précèdente",
	next: "suivante",
	close: "fermer",
	xhrError: "Impossible de charger ce contenu.",
	imgError: "Impossible de charger cette image.",
	slideshowStart: "démarrer le diaporama",
	slideshowStop: "arrêter le diaporama"
});

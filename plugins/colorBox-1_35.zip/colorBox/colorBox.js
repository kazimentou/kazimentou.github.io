// https://developers.google.com/web/updates/2011/10/Let-Your-Content-Do-the-Talking-Fullscreen-API
// http://johndyer.name/native-fullscreen-javascript-api-plus-jquery-plugin/

var isMobile =  /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Opera Mobile|Kindle|Windows Phone|PSP|AvantGo|Atomic Web Browser|Blazer|Chrome Mobile|Dolphin|Dolfin|Doris|GO Browser|Jasmine|MicroB|Mobile Firefox|Mobile Safari|Mobile Silk|Motorola Internet Browser|NetFront|NineSky|Nokia Web Browser|Obigo|Openwave Mobile Browser|Palm Pre web browser|Polaris|PS Vita browser|Puffin|QQbrowser|SEMC Browser|Skyfire|Tear|TeaShark|UC Browser|uZard Web|wOSBrowser|Yandex.Browser mobile/i.test(navigator.userAgent);
// isMobile = true;
document.cancelFullScreen = document.webkitExitFullscreen || document.mozCancelFullScreen || document.exitFullscreen;

function requestFullscreen() {
	if (isMobile) {
		var cb = document.getElementById('colorbox'); // cboxWrapper
		// document.addEventListener('mozfullscreenchange', function(event) { console.log('mozfullscreenchange'); $.colorbox.resize(); });
		if (cb) {
			var parent = cb.parentNode;
			if (parent.webkitRequestFullscreen)
				parent.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
			else if (parent.mozRequestFullScreen)
				parent.mozRequestFullScreen();
			else if (parent.msRequestFullscreen)
				parent.msRequestFullscreen();
			else if (parent.requestFullscreen)
				parent.requestFullscreen();
		}
	}
}

function exitFullscreen() {
	if (isMobile) {
		document.cancelFullScreen();
	}
}

var cbDefaultOptions;

$(document).ready(function() {

	cbDefaultOptions.onLoad = requestFullscreen,
	cbDefaultOptions.onCleanup = exitFullscreen,
	jQuery.extend(jQuery.colorbox.settings, cbDefaultOptions);

	// par défaut
	$("a[rel^='lightbox']").colorbox();

	var options = {};
	// medias de Pluxml dans article
	options.title = function() { var t = $(this).attr('title'); return (t) ? t : $(this).attr('alt'); };
	options.rel = 'lightbox-art*';
	options.href = function() { return $(this).attr('src').replace(/\.tb(\.\w+)$/i,'$1'); };
	$("article img[src$='\\.tb\\.jpg'], article img[src$='\\.tb\\.png'], article img[src$='\\.tb\\.gif'], article img[src$='\\.tb\\.jpeg']").colorbox(options);

	// themes/defaut/sidebar.php
	options.rel = 'lightbox-aside';
	options.href = function() { return $(this).attr('src').replace(/\.tb(\.\w+)$/i,'$1'); };
	$("aside img[src$='\\.tb\\.jpg'], aside img[src$='\\.tb\\.png'], aside img[src$='\\.tb\\.gif'], aside img[src$='\\.tb\\.jpeg']").colorbox(options);

	// pour core/admin/medias.php
	options.rel = 'lightbox-medias';
	options.href = function() { return $(this).attr('src').replace(/\/\.thumbs\//i, '/'); };
	$("img[src*='/\\.thumbs/']").colorbox(options);

	// Flickr
	// https://www.flickr.com/services/api/misc.urls.html
	options.rel = 'lightbox-flickr*';
	options.href = function() { return $(this).attr('src').replace(/\w(\.(?:jpg|jpeg|png|gif))$/i,'b$1'); };
	$("article img[src*='staticflickr']").colorbox(options);

	var resizeTimer;
	window.addEventListener(
		'orientationchange',
		function (event) {
			if (resizeTimer) clearTimeout(resizeTimer);
			resizeTimer = setTimeout(function() { $.colorbox.resize(); }, 300);
		});

	var touchscreen = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0);
	if (! touchscreen) {
		var a = document.body;
		if (a.classList) {
		    a.classList.add('no-touchscreen');
		} else {
		    a.className += ' no-touchscreen';
		}
	}
});

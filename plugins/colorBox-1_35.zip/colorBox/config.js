// all functions for config.php
function styleClick(selectId, root) {
	var e = document.getElementById(selectId);
	if (e) {
		var style = e.value;
		var w=900, h=630, l=(screen.width-w)/2, t=(screen.height-h)/2;
		var options = 'width='+w+', height='+h+', left='+l+', top='+t;
		// var win = window.open(root+'index.php?style='+style, '_blank', 'width='+w+',height='+h+',left='+l+',top='+t+'titlebar=no,location=no,status=no,scrollbars=yes');
		var win = window.open(root+'index.php?style='+style, '_blank', 'width='+w+',height='+h+',left='+l+',top='+t+'titlebar=no,location=no,status=no,scrollbars=yes');
	}
	else
		console.log('Element with id="'+selectId+'" not found.');
	return false;
	}

function colorBoxOnSubmit(aForm) {
	var result = true;
	var classNum = /\bnum\b/i;
	var classPx = /\bpx\b/i;
	for (i = 0; i <aForm.elements.length; i++) {
		var e = aForm.elements[i];
		if (e.getAttribute('type') == 'text') {
			var value1 = e.value.trim();
			if (e.value.length > 0) {
				if (classNum.test(e.className) && ! /^[1-9][\d]*$/.test(value1)) {
					e.focus();
					alert('The entry must be a strict number');
					result = false;
					console.log('num: '+e.value+' for '+e.name);
					break;
				}
				else if (e.name == 'opacity' && (value1 > 1000)) {
					e.focus();
					alert('The value must be less or equal to 1000.');
					result = false;
					break;
				}
				else if (classPx.test(e.className) && ! /^[1-9]\d*(px|%)*$/.test(value1)) {
					e.focus();
					alert('The entry must be a integer number of px or %');
					result = false;
					console.log('px: '+e.value+' for '+e.name);
					break;
				}
			}
		}
	}
	return result;
}

function setDefaultsValues(aForm, aOptions) {
	for (i = 0; i < aForm.elements.length; i++) {
		var e = aForm.elements[i];
		if (e.name != '') {
			if (aOptions[e.name]) {
				e.value = aOptions[e.name];
				// console.log('Default value for ' + e.name + ': '+aOptions[e.name]);
			}
			else
				e.value = '';
		}
	}
}

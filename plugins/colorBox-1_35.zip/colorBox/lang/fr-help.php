<article id="colorbox-help">
	<h2>Galerie avec photos sur le serveur</h2>
	<p>Insérer dans l'article ou la page statique, le code HTML suivant :</p>
	<pre><code>&lt;div id="pl_gallery" data-src="dossier_des_photos">&lt;/div></code></pre>
	<p>Le plugin ajoute dans le bloc &lt;div&gt; toutes les miniatures des photos de dossier_des_photos</p>
	<h2>Galerie avec photos hébergées par Flickr</h2>
	<p>Insérer dans l'article ou la page statique le code suivant :</p>
	<pre><code>&lt;div id="cb_gallery"
	   data-tags="liste_des_tags"
	   data-user_id="identifiant_utilisateur_flickr"
       data-service="service_xxx">
&lt;/div></code></pre>
	<p>Selon les cas, Les attributs data-xxx ne sont pas tous obligatoires, mais il est conseillé dans spécifier un ou deux.</p>
	<p>L'identifiant_utilisateur_flickr peut être retrouvé par un des deux moyens suivants :</p>
	<ul>
		<li>par son nom d'utilisateur (<i>login</i>), à cette page sur <a href="https://www.flickr.com/services/api/explore/flickr.people.findByUsername" target="_blank">Flickr</a>, en renseignant le champ "<strong>username</strong>", et en notant la valeur de "<strong>id</strong>" dans la réponse après validation.</li>
		<li>par son adresse courriel (<i>email</i>), à cette page <a href="https://www.flickr.com/services/api/explore/flickr.people.findByEmail" target="_blank">Flickr</a>, en renseignant le champ "<strong>find_email</strong>", et en notant la valeur de "<strong>id</strong>" dans la réponse après validation.</li>
	</ul>
	<p>La valeur de l'attribut data-service est à choisir parmi un des éléments ci-dessous :</p>
	<ul>
		<li><a href="https://www.flickr.com/services/feeds/docs/photos_public/" target="_blank">photos_public</a> (Photos publiques) C'est le service par défaut, aucun attribut data-xxx n'est obligatoire. Il est possible de spécifier un ou plusieurs utilisateurs séparés par une virgule. C'est le seul service où l'attribut data-tags sera pris en compte.</li>
		<li><a href="https://www.flickr.com/services/feeds/docs/photos_friends/" target="_blank">photos_friends</a> (Photos des amis) L'attribut data-user_id est obligatoire et doit correspondre à un utilisateur unique.</li>
		<li><a href="https://www.flickr.com/services/feeds/docs/photos_faves" target="_blank">photos_faves</a> (Photos favorites) L'attribut data-user_id est obligatoire et doit correspondre à un utilisateur unique.</li>
		<li><a href="https://www.flickr.com/services/feeds/docs/groups_pool" target="_blank">groups_pool</a> (Photos d'un groupe d'utilisateurs) data-user_id doit correspondre à l'identifiant du groupe. Seuls les membres du groupe peuvent l'obtenir.</li>
	</ul>
	<h2>Infos utiles pour les photos hébergées par Flickr</h2>
	<ul>
		<li><a href="https://www.flickr.com/services/api/explore/flickr.people.findByUsername" target="_blank">Retrouver l'identifiant d'une personne par son nom d'utilisateur (login)</a></li>
		<li><a href="https://www.flickr.com/services/api/explore/flickr.people.findByEmail" target="_blank">Retrouver l'identifiant d'une personne par son courriel (email)</a></li>
		<li><a href="https://www.flickr.com/services/api/explore/flickr.people.getInfo" target="_blank">Retrouver toutes les infos d'une personne par son identifiant</a></li>
		<li><a href="https://www.flickr.com/services/feeds/">Flux RSS disponibles</a></li>
	</ul>
	<?php $plugin_root = $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].$plugin.'/'; ?><p><a href="http://www.flickr.com"><img src="<?php echo $plugin_root; ?>white-flickr.png" width="60" height="26" alt="Flickr" /></a></p>
</article>

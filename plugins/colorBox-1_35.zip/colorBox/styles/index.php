<!DOCTYPE html>
<html>
	<head>
		<meta charset='utf-8'/>
		<title>Colorbox Examples</title>
		<style>
			body{font:12pt verdana, sans-serif; padding:0 10px; background: #EEF3F9}
			#header { display: flex; justify-content: space-around; vertical-align: bottom; }
			#header * { margin-bottom: 0; }
			.id1 { display: flex; justify-content: space-around; }
			h1 { color: rgb(227, 69, 42); }
			h1 + p label { font-size: 140%; margin-right: 0.5em; }
			a:link, a:visited{text-decoration:none; color:#416CE5; border-bottom:1px solid #416CE5;}
			h2 {font-size:130%; margin:15px 0 0 0; text-align: center; }
			ul {	list-style: none; max-width: 450px;
					padding: 10px; margin: .5em .8em;
					background-color: #F0EEE1;
					border: 1px solid #BFB5B5; border-radius: 10px;
			}
		</style>
<?php
$dirlist = glob(dirname(__FILE__).'/*', GLOB_ONLYDIR);
$style = (!empty($_GET['style'])) ? $_GET['style'] : 'style'.mt_rand(1, 5);
$start = strlen(dirname(__FILE__).'/');
foreach ($dirlist as $dir1) {
	$href = substr($dir1, $start);
	$alternate = ($style != $href) ? 'alternate ' : '';
	echo <<< STYLE
		<link type="text/css" title="{$href}" href="{$href}/colorbox.css" rel="{$alternate }stylesheet" />

STYLE;
}
?>
		<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
		<script src="../colorBox/jquery.colorbox.js"></script>
		<script>
			function fillSelect() {
				var aSelect = document.querySelector('select'), innerHTML = '';
				if (aSelect) {
					var styleSheetsList = document.styleSheets;
					for (i=0, iMax=styleSheetsList.length; i<iMax; i++) {
						var st = styleSheetsList[i], title = st.title;
						if (title.length > 0) {
							var selected = (! st.disabled) ? ' selected' : '';
							innerHTML += '<option value="'+title+'">'+title+'</option>';
						}
					}
				}
				aSelect.innerHTML = innerHTML;
			}

			function changeStyle(aValue) {
				var styleSheetsList = document.styleSheets;
				for (i=0, iMax=styleSheetsList.length; i<iMax; i++) {
					var st = styleSheetsList[i], title = st.title;
					if (title.length > 0) {
						st.disabled = (title != aValue);
					}
				}
			}

			$(document).ready(function(){
				var baseUrl = 'http://www.jacklmoore.com/colorbox/content/';
				var href = function() { return baseUrl+$(this).attr('href'); };

				//Examples of how to assign the Colorbox event to elements
				$(".group1").colorbox({rel:'group1', href:href});
				$(".group2").colorbox({rel:'group2', href:href, transition:"fade"});
				$(".group3").colorbox({rel:'group3', href:href, transition:"none", width:"75%", height:"75%"});
				$(".group4").colorbox({rel:'group4', href:href, slideshow:true});
				$(".ajax").colorbox({href: href});
				$(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
				$(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
				$(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
				$(".inline").colorbox({inline:true, width:"50%"});
				$(".callbacks").colorbox({
					href: href,
					onOpen:function(){ alert('onOpen: colorbox is about to open'); },
					onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
					onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
					onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
					onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
				});

				$('.non-retina').colorbox({rel:'group5', href:href, transition:'none'})
				$('.retina').colorbox({rel:'group5', href:href, transition:'none', retinaImage:true, retinaUrl:true});

				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
	</head>
	<body>
		<div id="header">
			<h1>Colorbox Demonstration</h1>
			<p>
				<label for="id_style">Style</label>
				<select id="id_style" onchange="changeStyle(this.value);">
				</select>
			</p>
		</div>
		<div class="id1">
			<div>
				<h2>Elastic Transition</h2>
				<ul>
					<li><a class="group1" href="ohoopee1.jpg" title="Me and my grandfather on the Ohoopee.">Grouped Photo 1</a></li>
					<li><a class="group1" href="ohoopee2.jpg" title="On the Ohoopee as a child">Grouped Photo 2</a></li>
					<li><a class="group1" href="ohoopee3.jpg" title="On the Ohoopee as an adult">Grouped Photo 3</a></li>
				</ul>
				<h2>Fade Transition</h2>
				<ul>
					<li><a class="group2" href="ohoopee1.jpg" title="Me and my grandfather on the Ohoopee">Grouped Photo 1</a></li>
					<li><a class="group2" href="ohoopee2.jpg" title="On the Ohoopee as a child">Grouped Photo 2</a></li>
					<li><a class="group2" href="ohoopee3.jpg" title="On the Ohoopee as an adult">Grouped Photo 3</a></li>
				</ul>
			</div><div>
				<h2>No Transition + fixed width and height<br />(75% of screen size)</h2>
				<ul>
					<li><a class="group3" href="ohoopee1.jpg" title="Me and my grandfather on the Ohoopee.">Grouped Photo 1</a></li>
					<li><a class="group3" href="ohoopee2.jpg" title="On the Ohoopee as a child">Grouped Photo 2</a></li>
					<li><a class="group3" href="ohoopee3.jpg" title="On the Ohoopee as an adult">Grouped Photo 3</a></li>
				</ul>
				<h2>Slideshow</h2>
				<ul>
					<li><a class="group4"  href="ohoopee1.jpg" title="Me and my grandfather on the Ohoopee.">Grouped Photo 1</a></li>
					<li><a class="group4"  href="ohoopee2.jpg" title="On the Ohoopee as a child">Grouped Photo 2</a></li>
					<li><a class="group4"  href="ohoopee3.jpg" title="On the Ohoopee as an adult">Grouped Photo 3</a></li>
				</ul>
			</div>
		</div>
		<div class="id1">
			<div>
				<h2>Other Content Types</h2>
				<ul>
					<li><a class='ajax' href="ajax.html" title="Homer Defined">Outside HTML (Ajax)</a></li>
					<li><a class='youtube' href="http://www.youtube.com/embed/VOJyrQa_WR4?rel=0&amp;wmode=transparent">Flash / Video (Iframe/Direct Link To YouTube)</a></li>
					<li><a class='vimeo' href="http://player.vimeo.com/video/2285902" title="R&ouml;yksopp: Remind Me">Flash / Video (Iframe/Direct Link To Vimeo)</a></li>
					<li><a class='iframe' href="http://wikipedia.com">Outside Webpage (Iframe)</a></li>
					<li><a class='inline' href="#inline_content">Inline HTML</a></li>
				</ul>
			</div><div>
				<div>
					<h2>Demonstration of using callbacks</h2>
					<ul>
						<li><a class='callbacks' href="marylou.jpg" title="Marylou on Cumberland Island">Example with alerts</a><br />Callbacks and event-hooks allow users to extend functionality without having to rewrite parts of the plugin.</li>
					</ul>
				</div><div>
					<h2>Retina Images</h2>
					<ul>
						<li><a class="retina" href="daisy.jpg" title="Retina">Retina</a></li>
						<li><a class="non-retina" href="daisy.jpg" title="Non-Retina">Non-Retina</a></li>
					</ul>
				</div>
			</div>
		</div>

		<!-- This contains the hidden content for inline calls -->
		<div style='display:none'>
			<div id='inline_content' style='padding:10px; background:#fff;'>
			<p><strong>This content comes from a hidden element on this page.</strong></p>
			<p>The inline option preserves bound JavaScript events and changes, and it puts the content back where it came from when it is closed.</p>
			<p><a id="click" href="#" style='padding:5px; background:#ccc;'>Click me, it will be preserved!</a></p>

			<p><strong>If you try to open a new Colorbox while it is already open, it will update itself with the new content.</strong></p>
			<p>Updating Content Example:<br />
			<a class="ajax" href="ajax.html">Click here to load new content</a></p>
			</div>
		</div>
		<script type="text/javascript">
			fillSelect();
		</script>
	</body>
</html>

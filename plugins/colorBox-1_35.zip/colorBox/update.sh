#!/bin/sh

wget "https://github.com/jackmoore/colorbox/archive/master.zip"
unzip master.zip
mv colorbox-master colorBox
rm master.zip
rm -R styles/style*
rm colorBox/colorbox.ai
rm colorBox/*.json
rm colorBox/jquery.colorbox.js
for i in `seq 5`; do
mkdir -p "styles/style$i"
cp -av "colorBox/example$i/*" "styles/style$i/"
rm "styles/style$i/*.html"
done

echo 'Done...'

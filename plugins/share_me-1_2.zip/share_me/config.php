<?php
if (! defined('PLX_ROOT')) exit;

# Control du token du formulaire
plxToken::validateFormToken($_POST);

if (!empty($_POST)) {
	// Saving parameters
	foreach (array_keys($plxPlugin->networks) as $id) {
		$value = (isset($_POST[$id])) ? 1 : 0;
		$plxPlugin->setParam($id, $value, 'numeric');
		$accountName = 'account_'.$id;
		if (isset($_POST[$accountName]))
			$plxPlugin->setParam($accountName, trim(filter_input(INPUT_POST, $accountName, FILTER_SANITIZE_STRING)), 'string');
	}
	$value = (isset($_POST[SHARE_ME_TAGS])) ? 1 : 0;
	$plxPlugin->setParam(SHARE_ME_TAGS, $value, 'numeric');
	$plxPlugin->setParam('media', filter_input(INPUT_POST, 'media', FILTER_SANITIZE_STRING), 'string');
	$plxPlugin->saveParams();
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}
?>
		<form id="form_<?php echo $plugin; ?>" method="post">
			<p class="center">
				<a href="http://ogp.me" referrer="noreferrer" target="_blank"><?php $plxPlugin->lang('L_OPENGRAPH'); ?></a>
				<img id="logo-opengraph" src="<?php echo PLX_ROOT.$plxAdmin->aConf['racine_plugins'].$plugin?>/icon.png" alt="logo Opengraph">
			</p>
			<div class="networks">
<?php echo plxToken::getTokenPostMethod(); echo "\n"; ?>
<?php	$use_tags = ($plxPlugin->getParam(SHARE_ME_TAGS) > 0) ? ' checked' : '';
		$iconsPath = PLX_ROOT.$plxAdmin->aConf['racine_plugins'].$plugin.'/icons/';
		foreach (array_keys($plxPlugin->networks) as $id) {
			$value = $plxPlugin->getParam($id);
			$checked = ($value > 0) ? ' checked' : ''; ?>
			<p>
				<label for="id_<?php echo $id; ?>"><?php echo ($id != 'google_p') ? ucfirst($id): 'Google+'; ?></label>
				<input id="id_<?php echo $id; ?>" name="<?php echo $id; ?>" type="checkbox" value="1"<?php echo $checked; ?> />
				<img class="icon" src="<?php echo $iconsPath.(($id != 'google_p') ? $id : 'googleplus'); ?>.svg"/>
				<?php	if (in_array($id, $plxPlugin->account_networks)) {
					$param_name = 'account_'.$id;
					$value = $plxPlugin->getParam($param_name); ?>
					<?php plxUtils::printInput($param_name, $value, 'text', '15-30'); ?>
				<?php	} ?>
			</p>
<?php	}
?>
			</div>
			<p>
				<label for="id_<?php echo SHARE_ME_TAGS; ?>"><?php echo $plxPlugin->lang('L_TAGS'); ?></label>
				<input id="id_<?php echo SHARE_ME_TAGS; ?>" name="<?php echo SHARE_ME_TAGS; ?>" type="checkbox" value="1"<?php echo $use_tags; ?> />
			</p>
			<p class="expand">
				<label><?php $plxPlugin->LANG('L_MEDIA'); ?></label>
				<?php plxUtils::printInput('media', $plxPlugin->getParam('media'), 'text', ''); ?>
				<input id="media_selection" type="button" value="&#x1f5c1;" title="<?php echo $plxPlugin->lang('L_MEDIA_TITLE'); ?>"/>
			</p>
			<p id="id_media_img">
<?php
	$img = $plxPlugin->getParam('media');
	if(!empty($img)) {
?>
				<img src="<?php echo PLX_ROOT.$img; ?>">
<?php
	}
?>
			</p>
			<p class="center"><a href="https://developers.facebook.com/docs/sharing/best-practices/#images" referrer="noreferrer" target="_blank"><?php echo $plxPlugin->lang('L_IMAGE_INFO'); ?></a></p>
			<p class="center">
				<input type="submit" value="<?php echo $plxPlugin->lang('L_SAVE'); ?>"/>
			</p>
		</form>
		<script type="text/javascript">
			var selector = document.getElementById('media_selection');
			if(selector != null) {
				selector.addEventListener('click', function(event) {
					mediasManager.openPopup('id_media', true);

				});
			}
		</script>
<?php
$LANG = array(
	'L_TAGS'		=> 'Partager les mot-clés',
	'L_SAVE'		=> 'Enregistrer',
	'L_MEDIA'		=> 'Image par défault',
	'L_MEDIA_TITLE'	=> 'parcourir le dossiers des médias',
	'L_OPENGRAPH'	=> 'En savoir plus sur le protocole Open Graph',
	'L_IMAGE_INFO'	=> 'A propos des dimensions des images'
);
?>
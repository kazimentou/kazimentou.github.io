<?php $LANG = array('BAD_CAPTCHA'	=> 'The text doesn\'t match with the picture'); ?>

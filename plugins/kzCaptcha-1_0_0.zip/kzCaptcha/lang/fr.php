<?php
$LANG = array(
	'BAD_CAPTCHA'	=> 'Mauvaise réponse pour l\'image'
);
?>
<?php $LANG = array('BAD_CAPTCHA'	=> 'Der Text stimmt nicht mit dem Bild überein'); ?>

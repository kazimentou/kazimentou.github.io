<?php $LANG = array('BAD_CAPTCHA'	=> 'el texto no coincide con la imagen'); ?>

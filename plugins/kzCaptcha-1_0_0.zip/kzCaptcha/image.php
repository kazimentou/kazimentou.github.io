<?php
include('vendor/autoload.php');
use Gregwar\Captcha\CaptchaBuilder;

const MY_SALT = '$2a$07$usesomesillystringforsalt$';

$FONTS = array(
	'action_jackson.ttf',
	'Erika Ormig.ttf',
	'gabriele-bad.ttf',
	'gabriele-br.ttf',
	'gabriele-d.ttf',
	'glimstick.ttf',
	'Kingthings Trypewriter 2.ttf',
	'quebrada-defharo.ttf',
	'Vanthian Ragnarok.ttf'
);

# $phraseBuilder = new PhraseBuilder(5, '0123456789');

# $builder = new CaptchaBuilder(null, $phraseBuilder);
$builder = new CaptchaBuilder();
$builder->build(150, 50, __DIR__.'/fonts/'.$FONTS[mt_rand(0, count($FONTS) - 1)]);

# Required by plxMotor::newCommentaire(..)
session_start();
$_SESSION['capcha'] = sha1($builder->getPhrase());

header('Content-Type: image/jpeg');
$builder->output();

?>
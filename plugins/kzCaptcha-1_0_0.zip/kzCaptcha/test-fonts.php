<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Testing my fonts</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<style type="text/css" rel="stylesheet">
		body { background-color: wheat; }
<?php
	// http://www.1001fonts.com/monospaced-fonts.html

	// list of fonts
	$fonts = glob(__DIR__.'/fonts/*.ttf');
	for($i=0; $i<count($fonts); $i++) {
		$fontName = basename($fonts[$i]);
		echo <<< EOT
@font-face {
    font-family: myFont$i; src: url('fonts/$fontName');
}
.class$i {font-family: myFont$i; }

EOT;

	}

	// list of backgrounds
	$backgrounds = glob(__DIR__.'/capcha*.png');
	$options = array();
	for($i=0; $i<count($backgrounds); $i++) {
		$filename = basename($backgrounds[$i]);
		$options["bg$i"] = $filename;
		echo <<< EOT
		.bg$i { background: url('$filename'); }

EOT;
	}
	$bg = 'bg'.rand(0, count($backgrounds) - 1);

?>
		p span:first-of-type {
			display: inline-block;
			width: 250px;
			background-color: white;
			margin: 0 5px 2px 10px;
			padding: 4px 15px;
			text-align: right;
		}
		span[class] {
			font-size: 24pt;
			font-weight: normal;
			margin: 10px 0;
			padding: 10px;
		}
		p {
			margin-top: 10px;
			border-top: solid 1px black;
			border-bottom: solid 1px black;
		}
		p:last-of-type {
			margin-bottom: 10px;
		}
	</style>
</head>
<body>
	<div id="div1" class="<?php echo $bg; ?>">
<?php
$chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZ:!#&%?=';

	for($i=0; $i<count($fonts); $i++) {
		$fontName = basename($fonts[$i]);
		echo <<< EOT
	<p>
		<span>$fontName</span>
		<span class="class$i">$chars</span>
	</p>
EOT;
	}
?>
	</div>
	<div>
		<img src="image.php" />
	</div>
</body>
</html>
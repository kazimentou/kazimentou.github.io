<?php
if(!defined('PLX_ROOT')) { exit('Run away, bad guy !'); }

class kzCaptcha extends plxPlugin {

	const MY_SALT = '$2a$07$usesomesillystringforsalt$'; # same as in image.php
	const INPUT_AUTH = 'rep';

	public function __construct($lang) {
		parent::__construct($lang);
		parent::addHook('plxShowCapchaQ', 'plxShowCapchaQ');
		parent::addHook('AdminAuthPrepend', 'AdminAuthPrepend');
		parent::addHook('AdminAuth', 'AdminAuth');
		parent::addHook('AdminAuthEndHead', 'AdminAuthEndHead');
		parent::addHook('AdminAuthEndBody', 'printJS');
		parent::addHook('ThemeEndBody', 'ThemeEndBody');
	}

	/**
	 * Affiche le défi captcha.
	 * */
	public function printCaptcha() {
		$src = PLX_PLUGINS.__CLASS__.'/image.php';
		$btn = PLX_PLUGINS.__CLASS__.'/refresh.png';
		$name = self::INPUT_AUTH;
		echo <<< IMAGE
	<img id="captcha-img" src="$src" />
					<button id="captcha-btn">
					<img src="$btn" /></button>
					<input id="id_rep-kzCaptcha" name="$name" type="text" maxlength="5" autocomplete="off" required="required" />\n
IMAGE;
	}

	public function printJS() {
?>
<script type="text/javascript"> <!-- kzCaptcha -->
	(function() {
		'use strict';
<?php
		if(defined('PLX_AUTHPAGE') and version_compare(PLX_VERSION, '5.6', '<=')) {
			echo <<< BODY_AUTH
		document.body.id = 'auth';\n
BODY_AUTH;
		}
?>
		const btn = document.getElementById('captcha-btn');
		if(btn != null) {
			btn.addEventListener('click', function(event) {
				const img = document.getElementById('captcha-img');
				if(img != null) {
					const d = new Date();
					img.src = img.src.replace(/(?:\?d=\d*)?$/, '?d=') + (parseInt(d.getTime() / 1000) % 86400);
				}
			});
		}
	})();
</script>
<?php
	}

/* ========== Hooks ============ */

	public function plxShowCapchaQ() {
		$value = sha1(uniqid(rand(), true));
		$_SESSION['capcha_token'] = $value;
		if(!defined('PLX_AUTHPAGE')) {
			self::printCaptcha();
			echo <<< ECHO
			<input type="hidden" name="capcha_token" value="$value" />
<?php return true; ?>
ECHO;
		}
	}

	public function ThemeEndBody() {
		global $plxMotor;

		if(
			($plxMotor->mode === 'article') and
			!empty($plxMotor->aConf['allow_com']) and
			!empty($plxMotor->plxRecord_arts->f('allow_com'))
		) {
			self::printJS();
			$code = <<< 'CODE'
<?php
$output = preg_replace('@<input\s+id="id_rep"[^>]* />@', '', $output)
?>
CODE;
			echo $code;
		}
	}

	/**
	 * Désactive tous les utilisateurs si la réponse au captcha est invalide sur la page d'authentification de la partie admin.
	 * */
	public function AdminAuthPrepend() {
		if(
			empty($_POST[self::INPUT_AUTH]) or
			$_SESSION['capcha'] != sha1(strtolower(filter_input(INPUT_POST, self::INPUT_AUTH, FILTER_SANITIZE_STRING)))
		) {
			if(!empty($_POST[self::INPUT_AUTH])) { $this->error = true; }
			echo <<< 'CODE'
<?php
foreach($plxAdmin->aUsers as $userid => $user) {
	$plxAdmin->aUsers[$userid]['active'] = false;
}
?>
CODE;
		}
	}

	public function AdminAuthEndHead() {
		if(version_compare(PLX_VERSION, '5.6', '<=')) {
			echo <<< EOT
	<style type="text/css">\n
EOT;
			readfile(__DIR__ .'/css/admin.css');
			echo <<< EOT

	</style>\n
EOT;
		}

		if(!empty($this->error)) {
			printf('<?php $msg = "%s"; ?>', parent::getLang('BAD_CAPTCHA'));
		}
	}

	public function AdminAuth() {
		echo <<< DIV_STARTS
	<div class="kzCaptcha-container">\n
DIV_STARTS;
		self::printCaptcha();
		echo <<< DIV_ENDS
</div>
DIV_ENDS;
	}

}
?>
<?php if(!defined('PLX_ROOT')) { exit; } ?>

<pre>
Csv file format:

The first non-empty line must contain the field names.
Only the fields recognized by PluXml are taken into account, namely:
Login, name, active, profile, password, lang, email, infos
Only the login field is required.
Upper and lower case are not counted.

For each user:
If the name field is null, it will be initialized with the value of the login field.
If the password field is null, its value will be initialized to: PluXml.
If the email field does not have a correct format, it will be set to zero
The characters & lt; And & gt; Will be replaced by their respective entities.

Empty rows are not taken into account, nor are those whose login value is null.

If there is already a user with the specified login, its other values will be updated.
</pre>
<?php
	$LANG = array(
		'MENU_NAME'			=> 'Import utilisateurs',
		'MENU_TITLE'		=> 'Importe ou exporte une liste d\'utilisateurs à partir d\'un fichier au format CSV',
		'MESSAGE'			=> '##COUNT## utilisateurs ajoutés ou mis à jour',
		'LOGIN_REQUIRED'	=> 'le champ login est obligatoire',
		'PASSWORD'			=> 'Pour un nouvel utilisateur, si le mot de passe n\'est pas précisé, il sera initialisé à <strong>##PASSWORD##</strong> par défaut.',
		'SEPARATOR'			=> 'Séparateur de champs',
		'ENCLOSURE'			=> 'Encadrement des textes',
		'SPACE'				=> 'espace',
		'TABULATION'		=> 'tabulation',
		'EMPTY'				=> 'aucun',
		'PREVIEW'			=> 'Aperçu',
		'CLOSE'				=> 'Fermer',
		'IMPORT'			=> 'Importer',
		'EXPORT'			=> 'Exporter'
	);
?>

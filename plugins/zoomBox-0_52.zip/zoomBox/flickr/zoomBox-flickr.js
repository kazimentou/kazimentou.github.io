/* *************************** Pour Flickr **************** */
var previousScript;

function jsonFlickrFeed(response) {
	// https://www.flickr.com/services/api/misc.urls.html
	var gallery = document.getElementById('cb_gallery');
	var innerHTML = '';
	if (gallery) {
		response.items.forEach(function (element, index, array) {
			title = element.title;
			if (title.length == 0) title = element.tags;
			if (title.length == 0) title = '&nbsp;';
			innerHTML += '\
<div>\
<img src="'+element.media.m+'" alt="Image Flickr" title="'+title+'">\
<p><a href="'+element.link+'" target="_blank">'+title+'</a></p>\
</div>';
		});
		gallery.innerHTML = innerHTML;
		$("#cb_gallery img[src*='staticflickr']").zoombox();
	}
}

// fils de discution Flickr
/*
 * https://api.flickr.com/services/feeds/photos_public.gne	https://www.flickr.com/services/feeds/docs/photos_public/
 * https://api.flickr.com/services/feeds/photos_friends.gne	https://www.flickr.com/services/feeds/docs/photos_friends/
 * https://api.flickr.com/services/feeds/photos_faves.gne	https://www.flickr.com/services/feeds/docs/photos_faves/
 * https://api.flickr.com/services/feeds/groups_pool.gne	https://www.flickr.com/services/feeds/docs/groups_pool/
 * */

function flickGallery() {
	var gallery = document.getElementById('cb_gallery');
	if (gallery) {
		var
			tags = gallery.getAttribute('data-tags'),
			user_id = gallery.getAttribute('data-user_id'),
			service = gallery.getAttribute('data-service'),
			ok = false,
			options = {lang: 'fr-fr', format: 'json'},
			pattern1 = /^(\w+)(?:[\s,]+(\w+))*$/,
			userPattern = /^[\w@]{12,}$/;
		if (tags) tags = tags.trim();
		if (user_id) user_id = user_id.trim();
		service = (service) ? service.trim() : 'photos_public';
		switch (gallery.getAttribute('data-service')) {
			case 'friends':
				service = 'photos_friends';
				if (user_id) {
					if (user_id.match(userPattern)) {
						options.user_id = user_id;
						ok = true;
					}
				}
				break;
			case 'faves' :
				service = 'photos_faves';
				if (user_id) {
					if (user_id.match(userPattern)) {
						options.id = user_id.trim();
						ok = true;
					}
				}
				break;
			case 'groups' :
				service = 'groups_pool';
				if (user_id) {
					if (user_id.match(userPattern)) {
						options.id = user_id;
						ok = true;
					}
				}
				break;
			default:
				service = 'photos_public';
				ok = true;
				if (tags) {
					if (tags.match(pattern1))
						options.tags = tags;
				}
				if (user_id) {
					if (matches = user_id.match(userPattern)) {
						if (matches[2])
							options.ids = user_id.split(/[\s ]+/).join(',');
						else
							options.id = matches[0];
					}
				}
		}
		if (ok) {
			var url = 'https://api.flickr.com/services/feeds/'+service+'.gne';
			var buf = []
			for (k in options) { buf.push(k+'='+encodeURIComponent(options[k])) }
			var params = buf.join('&');
			// $.getJSON(url+'?'+params, jsonFlickrFeed);
			if (previousScript)
				document.head.removeChild(previousScript);
			previousScript = document.createElement('script');
			previousScript.type = 'text/javascript';
			previousScript.src = url+'?'+params;
			document.head.appendChild(previousScript);
		} else
			alert('Something is wrong');
	}
}

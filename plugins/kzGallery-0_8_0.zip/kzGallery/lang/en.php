<?php
$LANG = array(
	'ARTICLE_GALLERY_FOLDER'	=> 'Folder of pictures for the gallery',
	'LIGHTBOX2_CONFIG'			=> 'Ignore Lightbox2',
	'LINK_CONFIG'				=> 'No link to the pictures',
	'TITLE_CONFIG'				=> 'Without title',
	'ART_HINT'					=> 'Otherwise, insert : &#34;&lt;div data-gallery="mon-voyage/photos/"&gt;souvenirs&lt;/div&gt;&#34; inside the HTML code',
	'PASTE'						=> 'Paste',
	'COPY'						=> 'Copy'
);
?>
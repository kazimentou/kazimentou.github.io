<?php
if(!defined('PLX_ROOT')) { exit; }

class kzLostPassword extends plxPlugin {

	const PASSWORD_REQUEST = 'kzLostPassword-request';
	const PASSWORD_MAIL = 'kzLostPassword-mail';

	public function __construct($default_lang) {

		parent::__construct($default_lang);
		parent::setConfigProfil(PROFIL_ADMIN);
		if(defined('PLX_AUTHPAGE')) {
			parent::addHook('AdminAuthPrepend', 'AdminAuthPrepend');
			parent::addHook('AdminAuthTop', 'AdminAuthTop');
			parent::addHook('AdminAuth', 'AdminAuth');
			parent::addHook('AdminAuthEndBody', 'AdminAuthEndBody');
		}
	}

	private function __new_password($userId, $mail) {
		global $plxAdmin;

		$new_password = plxUtils::charAleatoire();
		$salt = $plxAdmin->aUsers[$userId]['salt'];
		$plxAdmin->aUsers[$userId]['password'] = sha1($salt.md5($new_password));
		if($plxAdmin->editUsers(null, true)) {
			$replaces = array(
				'#LOGIN'		=> $plxAdmin->aUsers[$userId]['login'],
				'#PASSWORD'		=> $new_password,
				'#IP'			=> $_SERVER['REMOTE_ADDR'],
				'#USER-AGENT'	=> $_SERVER['HTTP_USER_AGENT'],
				'#SITE'			=> $plxAdmin->racine
			);
			$bcc = (!empty($this->getParam('bcc'))) ? $this->getParam('bcc') : false;

			return plxUtils::sendMail(
				$this->getParam('sender'),
				$this->getParam('from'),
				$mail,
				str_replace('#TITLE', $plxAdmin->aConf['title'], $this->getParam('subject')),
				str_replace(array_keys($replaces), array_values($replaces), $this->getParam('body')),
				'text', false, $bcc
			);
		}
		return false;
	}

	/* ==================== Hooks =========================== */
	public function AdminAuthPrepend() {
		global $plxAdmin;

		if(
			!empty($_POST[self::PASSWORD_REQUEST]) and
			$_POST[self::PASSWORD_REQUEST] == '1' and
			!empty($_POST['login'])
		) {
			$mail = filter_input(INPUT_POST, self::PASSWORD_MAIL, FILTER_VALIDATE_EMAIL);
			if(empty($_POST)) {
				$this->error = parent::getLang('INVALIDATE_MAIL');
				return;
			}
			$login = filter_input(INPUT_POST, 'login', FILTER_SANITIZE_STRING);
			if(empty($login)) {
				$this->error = parent::getLang('INVALIDATE_LOGIN');
				return;
			}
			foreach($plxAdmin->aUsers as $userId=>$infos) {
				if(
					!empty($infos['active']) and
					empty($infos['delete']) and
					!empty($infos['email']) and
					$infos['login'] == $login and
					$infos['email'] == $mail
				) {
					if(self::__new_password($userId, $mail)) {
						$this->success = true;
						$this->error = parent::getLang('SENT_PASSWORD');
					} else {
						$this->error = parent::getLang('FAILURE_MAIL');
					}
					$plxAdmin->aUsers[$userId]['active'] = false;
					break;
				}
			}
		}
	}

	public function AdminAuthTop() {
		global $msg, $error;

		if(!empty($this->error)) {
			$msg = $this->error;
			$error = (!empty($this->success)) ? 'success' : 'error';
		}
	}

	public function AdminAuth() {
?>
						<div class="grid">
							<div class="col sml-12 <?php echo __CLASS__; ?>">
								<label for="id_<?php echo self::PASSWORD_REQUEST; ?>" class="text-center"><?php echo $this->lang('LOST_PASSWORD'); ?></label>
								<input type="checkbox" name="<?php echo self::PASSWORD_REQUEST; ?>" id="id_<?php echo self::PASSWORD_REQUEST; ?>" value="1" />
								<input type="email" name="<?php echo self::PASSWORD_MAIL; ?>" id="id_<?php echo self::PASSWORD_MAIL; ?>" placeholder="<?php echo $this->lang('AUTH_PLACEHOLDER'); ?>" maxlength="30" autocomplete="email" inputmode="email" class="full-width" autocomplete="off" />
							</div>
						</div>
<?php
	}

	public function AdminAuthEndBody() {
?>
	<script type="text/javascript">
		(function() {
			'use strict';
			const login = document.getElementById('id_login');
			const chk = document.getElementById('id_<?php echo self::PASSWORD_REQUEST; ?>');
			const email = document.getElementById('id_<?php echo self::PASSWORD_MAIL; ?>');

			login.required = true;
			chk.addEventListener('change', function(event) {
				email.required = chk.checked;
				event.preventDefault();
			});
		})();
	</script>
<?php
	}
}
?>
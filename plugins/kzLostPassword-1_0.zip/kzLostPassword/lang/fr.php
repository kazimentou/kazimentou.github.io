<?php
const BODY_FIELD_DEFAULT = <<< BODY_FIELD_DEFAULT
Cher #LOGIN,

Veuillez découvrir ci-dessous votre nouveau mot de passe :
#PASSWORD

Changez-le dès que possible.

Votre adresse IP: #IP
Votre navigateur: #USER-AGENT

A bientôt sur :
#SITE
Cordialement.
Le Webmaster

BODY_FIELD_DEFAULT;

$LANG = array(
	'SENDER_FIELD'			=> 'Expéditeur',
	'FROM_FIELD'			=> 'Adresse courriel',
	'BCC_FIELD'				=> 'Copie cachée à',
	'SUBJECT_FIELD'			=> 'Objet du courriel',
	'SUBJECT_FIELD_HINT'	=> 'Il est reccommandé d\'avoir la balise  #TITLE',
	'BODY_FIELD'			=> 'Corps du message',
	'BODY_FIELD_HINT'		=> 'balises obligatoires : #LOGIN et #PASSWORD, balises optionnelles : #SITE, #IP et #USER-AGENT',
	'SENDER_FIELD_DEFAULT'	=> 'Webmaster',
	'SUBJECT_FIELD_DEFAULT'	=> 'Nouveau mot de passe pour #TITLE',
	'BAD_MESSAGE'			=> "Le corps du message doit contenir\\nles balises #LOGIN et #PASSWORD",
	'BODY_FIELD_DEFAULT'	=> BODY_FIELD_DEFAULT,
	'LOST_PASSWORD'			=> 'Mot de passe perdu',
	'AUTH_PLACEHOLDER'		=> 'Votre adresse courriel',
	'BAD_VALUE'				=> 'Mauvaise valeur pour le champ %s',
	'INVALIDATE_LOGIN'		=> 'Login inconnu',
	'SENT_PASSWORD'			=> 'Nouveau mot de passe envoyé',
	'FAILURE_MAIL'			=> 'Impossible de joindre cette adresse'
);
?>
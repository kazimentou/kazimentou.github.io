<?php
if(!defined('PLX_ROOT')) { exit; }

plxToken::validateFormToken();

$fields = array(
	'sender'	=> 'text',
	'from'		=> 'email',
	'bcc'		=> 'email',
	'subject'	=> 'text',
	'body'		=> 'textarea'
);
$required = explode(' ', 'sender from subject body');

if(!empty($_POST)) {
	$inputs = filter_input_array(INPUT_POST, array(
		'sender'	=> FILTER_SANITIZE_STRING,
		'from'		=> FILTER_VALIDATE_EMAIL,
		'bcc'		=> FILTER_VALIDATE_EMAIL,
		'subject'	=> FILTER_SANITIZE_STRING,
		'body'		=> FILTER_SANITIZE_STRING,
	));
	$requiredOk = true;
	foreach(array_keys($fields) as $field) {
		$type = ($fields[$field] == 'textarea') ? 'cdata' : 'string';
		$plxPlugin->setParam($field, $inputs[$field], $type);
		if(
			$requiredOk === true and
			in_array($field, $required) and
			empty($inputs[$field])
		) {
			$requiredOk = $field;
		}
	}
	if($requiredOk === true) {
		$plxPlugin->saveParams();
		header("Location: parametres_plugin.php?p=$plugin");
		exit;
	} else {
		plxMsg::Error(sprintf($plxPlugin->getLang('BAD_VALUE'), $field));
	}
}

if (plxUtils::testMail(true, "<p><span style=\"color:#color\">#symbol #message</span></p>\n")) {
?>
<form id="form_<?php echo $plugin; ?>" method="post" class="inline-form">
	<div class="in-action-bar">
		<?php echo plxToken::getTokenPostMethod(); ?>
		<input type="submit" value="<?php echo L_COMMENT_SAVE_BUTTON; ?>" />
	</div>
<?php
	foreach($fields as $key=>$type) {
		$value = $plxPlugin->getParam($key);
		if(empty(trim($value))) {
			$idx = strtoupper($key).'_FIELD_DEFAULT';
			$value = $plxPlugin->getLang($idx);
			if($value == $idx) { $value =''; }
		}
?>
	<div <?php if($type == 'textarea' or $key == 'subject') { echo ' class="wide"'; } ?>>
		<label for="id_<?php echo $key; ?>"><?php $plxPlugin->lang(strtoupper($key).'_FIELD'); ?></label>
<?php
	if(in_array($key, array('body', 'subject'))) {
		$hint = $plxPlugin->getLang(strtoupper($key).'_FIELD_HINT');
		echo <<< HINT
		<a href="#" class="hint"><span>$hint</span></a>\n
HINT;
	}
		if($type == 'textarea') {
			echo <<< TEXTAREA
			<textarea name="$key">$value</textarea>\n
TEXTAREA;
		} else {
			$params = array();
			if(in_array($key, $required)) { $params[] = 'required'; }
			if($type == 'email') {
			   $params[] = <<< PARAM
autocomplete="email"
PARAM;
			   $params[] = <<< PARAM
inputmode="email"
PARAM;
		}
			$extras = (!empty($params)) ? ' '.implode(' ', $params) : '';
			echo <<< INPUT
		<input type="$type" name="$key" id="id_{$key}" value="$value"{$extras} maxlength="30" />\n
INPUT;
		}
?>
	</div>
<?php
	}
?>
</form>
<script>
	(function() {
		'use strict';
		document.forms[0].addEventListener('submit', function(event) {
			const value = event.target.elements.body.value;
			if(!/#LOGIN/.test(value) || !/#PASSWORD/.test(value)) {
				alert("<?php $plxPlugin->lang('BAD_MESSAGE'); ?>");
				event.preventDefault();
			}
		});
	})();
</script>
<?php
}
?>
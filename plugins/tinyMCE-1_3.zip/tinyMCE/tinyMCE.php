<?php

/*
 * Plugin pour utiliser TinyMCE dans l'édition des articles et des pages statiques
 * Utilise le script core/admin/medias.php pour choisir les images et les documents de
 * la bibliothèque de médias
 *
 * Dans le tableau de la bibliothèque de médias, cliquez sur un des liens pour insérer
 * un document/image dans l'article ou la page statique
 *
 * On utilise un cookie créé avec le script plugins/tinymce/js/myCallback.js pour masquer
 * panneau de navigation dans la bibliothèque
 *
 * Tous les liens vers les documents/images insérés dans les articles et pages statiques
 * sont transformés en liens absolus par TinyMCE
 * ( voir options : relative_urls, remove_script_host et document_base_url )
 *
 * version TinyMCE 4.2
 * http://www.tinymce.com/
 * http://www.tinymce.com/wiki.php/TinyMCE pour la documentation
 * http://www.tinymce.com/wiki.php/Tutorial:Using_CDN
 *
 * */

// pour le codage des entités, voir http://www.tinymce.com/wiki.php/Configuration:entity_encoding

if (! defined('JQUERY_LIB'))
	define('JQUERY_LIB', 'jquery-1.11.3.min.js');
if (! defined('JQUERY_SRC')) {
	define('JQUERY_SRC', '//code.jquery.com/'.JQUERY_LIB);
}

if (! defined('TINYMCE_LIB'))
	define('TINYMCE_LIB', '//tinymce.cachefly.net/4.2/tinymce.min.js');

class tinyMCE extends plxPlugin {
	
	public $default_values = array(
		'article'=>248, // 128+64+32+16+8
		'statique'=>192, // 128+64
		'comment'=>248, // 128+64+32+16+8
		// 'parametres_edittpl'=>128,
		'selector'=>'textarea',
		'codemirror'=>0,
		'cdn'=>1
	);
	public $weightProfils = array(PROFIL_ADMIN=>128, PROFIL_MANAGER=>64, PROFIL_MODERATOR=>32, PROFIL_EDITOR=>16, PROFIL_WRITER=>8);

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->default_values['styleformats'] = <<<EOT
{title: 'Image Left', selector: 'img', styles: {'float': 'left', 'margin': '0 10px 0 10px'}},
{title: 'Image Right', selector: 'img', styles: {'float': 'right', 'margin': '0 10px 0 10px'}}
EOT;
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
	}

	private function pluginRoot() {
		global $plxAdmin;
		return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
	}

	public function get_skins() {
		$folder = PLX_PLUGINS.__CLASS__.'/'.__CLASS__.'/skins/';
		$items = array(''=>'Par défaut');
		$files = glob($folder.'*');
		if (!empty($files)) {
			foreach ($files as $file1) {
				if (is_dir($file1)) {
					$value = substr(strrchr($file1, '/'), 1);
					$items[$value] = ucfirst($value);
				}
			}
		}
		else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
			echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
			$dir = new DirectoryIterator($folder.'.');
			foreach ($dir as $fileinfo) {
				if ($fileinfo->isDir() && !$fileinfo->isDot()) {
					$filename = $fileinfo->getFilename();
					$items[$filename] = ucfirst($filename);
				}
			}
			asort($items);
		}
		return $items;
	}

	private function print_tinymce_library_setup() {
		/*
		 * pour avoir la bibliothèque de tinymce en local :
		 * aller sur le site http://www.tinymce.com/download/custom_package.php
		 * télécharger un package "Basic package" en ajoutant des plugins si besoin ou "Full package"
		 * Ouvrer l'archive zip téléchargée avec le gestionnaire de fichiers
		 * sélectionner tout le contenu du dossier tinymce de l'archive
		 * coller-le dans le dossier tinyMCE du plugin
		 * sous Linux, corriger les droits d'accès aux fichiers par : "sudo chmod -R a+rX *" depuis le dossier du plugin
		 * décommenter la ligne ci-après pour la variable $tinyMCE_lib
		 * */

		$tinyMCE_filename = 'tinyMCE/tinymce.min.js';
		if ((intval($this->getParam('cdn')) == 1) or ! is_readable($tinyMCE_filename))
			$tinyMCE_lib = TINYMCE_LIB; // for CDN
		else
			$tinyMCE_lib = $this->pluginRoot().$tinyMCE_filename;
?>
	<script type="text/javascript" src="<?php echo $tinyMCE_lib; ?>"></script>
<?php
	}

	private function parametres_plugin_setup() { ?>
	<link rel="stylesheet" type="text/css" href="<?php echo $this->pluginRoot().__CLASS__; ?>.css" />
<?php
	}

	private function edition_setup($script_name) {
		// Voir les plugins disponibles pour TinyMCE à: http://www.tinymce.com/wiki.php/Plugins
		
		$tinyMCE_base = $this->pluginRoot();

		$param = intval($this->getParam($script_name)); // getParam returns a string value
		$mask_user = $this->weightProfils[$_SESSION['profil']];
		$ok = (($param & $mask_user) > 0); // bits mask

		if ($ok) {
			global $plxAdmin;

			$document_base_url = $plxAdmin->racine;
			if (! preg_match('!^https?://[\w-\.]+\.[a-z]{2,6}[^/]!', $document_base_url))
				// we add protocol and hostname
				$document_base_url = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$plxAdmin->racine;
			$external_root = $tinyMCE_base.'tinyMCE/';
			$external_plugins_root = $external_root.'plugins/';
			$skin = $this->getParam('skin'); // look at tinyMCE/skins/ folder in the plugin
			if (!empty($skin) and ($skin != 'lightGray') and is_dir(PLX_PLUGINS.__CLASS__.'/tinyMCE/skins/'.$skin)) {
				$external_skin = $external_root.'skins/'.$skin;
				$option_skin = "skin: '$skin', skin_url: '$external_skin',";
			}
			else
				$option_skin = '';
			$i18N = array('en'=>'en_GB', 'fr'=>'fr_FR', 'pt'=>'pt_PT');
			$lang = $plxAdmin->aConf['default_lang'];
			if (array_key_exists($lang, $i18N))
				$lang = $i18N[$lang];
			$language_url = $external_root.'langs/'.$lang.'.js';
			$codemirror_ok = ((intval($this->getParam('codemirror')) & $mask_user) > 0);
			$selector = $this->getParam('selector');
			if (strlen($selector) == 0)
				$selector = 'textarea';
			if (! defined('JQUERY_LOADED')) {
?>
	<!-- TinyMCE plugin -->
	<script type="text/javascript">
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src='+'"<?php echo JQUERY_SRC; ?>"></scr'+'ipt>');
	</script>
<?php
				define('JQUERY_LOADED', true);
			}
			$this->print_tinymce_library_setup(); ?>
	<script type="text/javascript" src="<?php echo $tinyMCE_base.__CLASS__; ?>.js"></script>
	<script type="text/javascript">
		tinymce.init({
			// selector:'textarea',
			selector:'<?php echo $selector; ?>',
			plugins: 'advlist autolink link image lists charmap hr anchor charmap searchreplace wordcount visualblocks visualchars fullscreen media nonbreaking code save table contextmenu directionality template paste textcolor autoresize',
			toolbar1: 'undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media anchor | forecolor backcolor |<?php if ($codemirror_ok) echo ' code'; ?> fullscreen',
			language: '<?php echo $lang; ?>',
			language_url:'<?php echo $language_url; ?>',
			<?php echo $option_skin; ?>
			image_advtab: true,
//			entities : "160,nbsp,38,amp,34,quot,162,cent,8364,euro,163,pound,165,yen,169,copy,174,reg,8482,trade,8240,permil,60,lt,62,gt,8804,le,8805,ge,176,deg,8722,minus",
			entities : "160,nbsp,38,amp,34,quot,162,cent,169,copy,174,reg,8482,trade,8240,permil,60,lt,62,gt,8804,le,8805,ge,176,deg,8722,minus",
			file_browser_callback: myCallback,
			content_css: '<?php echo $external_root; ?>content.css',
<?php	if ($codemirror_ok) { ?>
			external_plugins: {
				'codemirror': '<?php echo $external_plugins_root; ?>codemirror/plugin.min.js'
				 },
			codemirror: {
			    indentOnInit: true, // Whether or not to indent code on init.
			    config: {           // CodeMirror config object
					mode: 'application/x-httpd-php',
					lineNumbers: true,
					indentUnit: 2,
					tabSize: 2
			    },
			    cssFiles: ['theme/elegant.css']
		    },
<?php	} ?>
			document_base_url: '<?php echo $document_base_url; ?>',
			rel_list: [
				{title: 'Lightbox',  value: 'lightbox'},
				{title: 'Galerie 1', value: 'lightbox-1'},
				{title: 'Galerie 2', value: 'lightbox-2'},
				{title: 'Galerie 3', value: 'lightbox-3'},
				{title: 'Galerie 4', value: 'lightbox-4'}
			],
<?php
		$style_formats = $this->getParam('styleformats');
		if (!empty($style_formats)) { ?>
			style_formats: [
<?php echo $style_formats; ?>
			],
<?php	} ?>
			nonbreaking_force_tab: true
		});
	</script>
	<style> .mce-fullscreen {z-index: 9001;} </style>
<?php
		}
	}

	private function medias_setup() {
		global $plxAdmin, $plxMedias;
		$versionPluxml = strval($plxAdmin->version);
		$img_exts = $plxMedias->img_exts;
		// $doc_exts = $plxMedias->doc_exts;
		// dans doc_exts, conserver les extensions des images pour utiliser Lightbox
		$doc_exts = '/\.(jpg|gif|png|jpeg|7z|csv|doc|docx|gz|gzip|ods|odt|odp|pdf|ppt|pptx|pxd|qt|ram|rar|rm|rmi|rmvb|rtf|sxc|sxw|tar|tgz|txt|xls|xlsx|zip)$/i';
		$media_exts = '/\.(pdf|aiff|asf|avi|fla|flv|mid|mov|mp3|mp4|mpc|mpeg|mpg|ogg|pxd|qt|ram|rm|rmi|rmvb|swf|sxc|sxw|wav|wma|wmv)$/i';
		// echo("<!--\n$img_exts\n$doc_exts\n-->\n");
?>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script>
	<script type="text/javascript">
		var filtres = {
			image: <?php echo $img_exts; ?>,
			file: <?php echo $doc_exts; ?>,
			media: <?php echo $media_exts; ?>
		};
    </script>
<?php
	}

// ------------- Hooks start here ----------------------------------
	public function AdminTopEndHead($params=false) {
		$script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		switch ($script_name) {
			case 'parametres_pluginhelp' :
			case 'parametres_plugin' :
				$this->parametres_plugin_setup();
				break;
			case 'article' :
			case 'statique' :
			// case 'comment':
			case 'parametres_edittpl' :
				$this->edition_setup($script_name);
				break;
		}
	}

	public function AdminMediasFoot($params=false) {
		global $plxAdmin;
		
		$this->medias_setup();
		$versionPluxml = strval($plxAdmin->version);
		$idTable = ($versionPluxml < 5.4) ? 'list-files' : 'medias-table'; ?>
		<script type="text/javascript">
			setMediasForTinyMCE('<?php echo $idTable; ?>', '<?php echo $versionPluxml; ?>');
		</script>
<?php
	}
}

?>

/*
 * See documentation at following links :
 * http://www.tinymce.com/wiki.php/Configuration:file_browser_callback
 * http://www.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 * */
// updated on 2015-09-25

function updateLinksTable(aTable) {
	var rows = aTable.getElementsByTagName('tr');
	for (i=1; i<rows.length; i++) { // skip the first rows of <th>
		var anchors = rows[i].getElementsByTagName('a');
		for (j=1 ;j<anchors.length; j++) {
			if (anchors[j].hasAttribute('rel'))
				anchors[j].removeAttribute('rel');
			anchors[j].setAttribute('onclick', 'return tinyMCE_Set(this);');
		}
	}
}

function setMediasForTinyMCE(idTable, versionPluxml) {
	/* ******* pour PluxXml version < 5.4; à tester !
	#sidebar, div.files > p,
	div.browser input.delete,
	div.files table td:first-child, div.files table th:first-child {display: none;}
	#content {position: absolute; left: 0; margin: 5px; padding: 0}
	div#files_manager {min-width: 500px;}
	* */
	/*
	var selectorsCSS = [
		'#nav_id + label', 'aside',
		'section h2:first-of-type',
		'#form_medias div div:first-of-type',
		'#form_medias > div:nth-of-type(2)',
		'#form_medias input'
	];
	* */
	var selectorsCSS = [
		'#nav_id + label', 'aside',
		'#id_folder + input[name="btn_delete"]'
	];
	var myFrame = window.frameElement;
	if (myFrame) {
		// search for links in table tag to add  'return tinyMCE_Set(this);' as onclick property
		console.log('You are in an iFrame');
		var listFiles = document.getElementById(idTable);
		if (listFiles) {
			updateLinksTable(listFiles);
			for (i=0; i<selectorsCSS.length; i++) {
				var aList = document.querySelectorAll(selectorsCSS[i]);
				if (aList) {
					for (j=0; j<aList.length; j++)
						aList[j].style.display = 'none';
				}
			}
		}
		else {
			console.log('Id ' + idTable + ' element not found');
			var files_manager = document.getElementById('files_manager');
			if (files_manager) {
				var tables = files_manager.getElementsByTagName('table');
				if (tables.length > 0) {
					var noSuccess = true;
					for (i = 0; i < tables.length; i++) {
						if (tables[i].className.match(/(?:^|\s)table(?!\S)/)) {
							console.log('We are found one or more table elements with class="table"');
							updateLinksTable(tables[i]);
							noSuccess = false;
							break;
						}
					}
					if (noSuccess)
						console.log('No table with class table.');
					else
						window.onunload = cleanUp;
				}
				else
					console.log('No table element in the id files_manager element');
			}
			else
				console.log('Id files_manager element not found');
		}
	} else
		console.log('You are not in an iFrame !');
}

function tinyMCE_Set(anchor1) {
	// copy the url of the file in TinyMCE
	if (confirm('Ajouter dans l\'éditeur\n' + anchor1.href.split(/[\\/]/).pop())) {
		var args = top.tinymce.activeEditor.windowManager.getParams();
		var field = args.win.document.getElementById(args.field_name);
		if (field)
			field.value = anchor1.href;
		else
			alert('Field '+args.field_name+' not found');
		// fermer la fenetre
		top.tinymce.activeEditor.windowManager.close();
		}
	return false;
}

var myCallback = function (field_name1, url1, type1, win1) {
	// Launch the file/image browser
	//  type1 value in ('image', 'file', 'media')
	tinymce.activeEditor.windowManager.open({
		title: "Médias",
		url: 'medias.php',
		width: 700,
		height: 600},
		{win: win1, field_name: field_name1, type: type1, url: url1}
	);
}

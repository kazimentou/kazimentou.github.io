/*
 * This is a part of the users_csv plugin for using with PluXml cms
 * author: Jean-Pierre Pourrez aka bazooka07
 * date: 2017-03-15
 *
 * */

(function(idTable, idSelection) {

	usersTable = document.getElementById(idTable);

	if(usersTable != null) {
		var
			rowsCount = usersTable.rows.length,
			lastRow = usersTable.rows[rowsCount-1],
			input1 = lastRow.querySelector('input[name="userNum[]"]');

		if(input1 != null) {
			var
				lastIdStr = input1.value,

				setRequiredInputs = function(parent, selector) {
					selector.split(' ').forEach(function(field) {
						var input = parent.querySelector('input[name$="_' + field + '"]');
						if(input != null) {
							input.setAttribute('required', true);
						}
					});
				},

				deleteRow = function(event) {
					if(confirm(event.target.title)) {
						var
							row = this.parentElement,
							parent = row.parentElement;
						parent.removeChild(row);
					}
				},

				// callback function when user clicks on the "new user" button
				addNewRow = function(event) {

					// the event is attached to the last row in the users table
					if(event.target.classList.contains('users-csv')) {
						event.preventDefault();

						// this is the last row of the table
						// Add a new row in the users table before this and drop colspan="2" attribute
						var
							innerHTML = this.innerHTML,
							tr = document.createElement('TR'),
							td = document.createElement('TD'),
							oldCell0;
						tr.innerHTML = innerHTML;
						td.innerHTML = '<span class="delete-row" title="' + this.deleteTitle + '">&cross;</span>';
						this.parentElement.insertBefore(tr, this);
						oldCell0 = tr.cells[0];
						tr.insertBefore(td, oldCell0);
						setRequiredInputs(tr, 'name login password');
						td.addEventListener('click', deleteRow);

						// So, update the last row with the user for the next user
						var
							oldLastIdStr = ('00' + this.lastId.toString()).substr(-3),
							newLastIdStr;
						this.lastId++;
						oldCell0.innerHTML = oldLastIdStr;
						oldCell0.classList.remove('users-csv');
						oldCell0.removeAttribute('colSpan');
						newLastIdStr = ('00' + this.lastId.toString()).substr(-3);

						var pattern = new RegExp(oldLastIdStr+'_', 'g')
						this.innerHTML = innerHTML.replace('value="'+oldLastIdStr+'"', 'value="'+newLastIdStr+'"').replace(pattern, newLastIdStr+'_');
					}
				};

			if(! isNaN(lastIdStr)) {
				lastRow.lastId = parseInt(lastIdStr);
				lastRow.table = usersTable;
				lastRow.addEventListener('click', addNewRow);
				lastRow.cells[0].classList.add('users-csv');

				var emailCell = lastRow.querySelectorAll('input[name$="email"]');
				if((emailCell != null) && (emailCell.type != 'email')) {
					emailCell.type = 'email';
				}

				var
					deleteOption = document.querySelector('#' + idSelection+ ' option[value="delete"]');
				lastRow.deleteTitle = (deleteOption != null) ? deleteOption.textContent : 'delete';
			}
		}
	}

})('users-table', 'id_selection');
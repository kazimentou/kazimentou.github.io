<?php

# http://telechargements.pluxml.org/docs/PluXml_-_Plugins_Guide_du_developpeur.pdf

if (!defined('PLX_ROOT')) { exit; }

define('DEFAULT_PASSWORD', 'PluXml');

class users_csv extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->setConfigProfil(PROFIL_ADMIN);

		# Accès au menu admin réservé au profil administrateur
		$this->setAdminProfil(PROFIL_ADMIN);

		# Personnalisation du menu admin
		$this->setAdminMenu($this->getLang('MENU_NAME'), 0, $this->getLang('MENU_TITLE'));

		# Ajouts des hooks
		$this->addHook('AdminUsersFoot', 'AdminUsersFoot'); # formulaire saisie multi_users
		$this->addHook('plxAdminEditUsersUpdate', 'plxAdminEditUsersUpdate');
	}

	public function printForm($admin=false) {

		$scriptname = PLX_PLUGINS.__CLASS__.'/'.__CLASS__.'.js';
?>
	<div id="div_users-csv">
		<h3 title="<?php $this->lang('MENU_TITLE'); ?>"><?php $this->lang('MENU_NAME'); ?> <span>( with <?php echo __CLASS__; ?> plugin )</span></h3>
		<form id="form_users-csv" method="POST" enctype="multipart/form-data" <?php if(! $admin) { echo 'action="'.PLX_PLUGINS.__CLASS__.'/admin.php"'; } ?>>
<?php
		if(! $admin) {
?>
			<input type="hidden" name="users-csv" value="<?php echo $this->signature(); ?>">
<?php
		}
?>
			<input id="users-csv-file" name="users-csv-file" type="file" accept=".csv" required />
			<input type="submit">
		</form>
		<p><?php echo str_replace('##PASSWORD##', DEFAULT_PASSWORD, $this->getLang('PASSWORD')); ?></p>
<?php
	if(isset($_SESSION[__CLASS__])) {
		echo '<p>'.$_SESSION[__CLASS__]."</p>\n";
		unset($_SESSION[__CLASS__]);
	}
?>
	</div>
	<script type="text/javascript" src="<?php echo $scriptname; ?>"></script>
<?php
	}

	public function AdminUsersFoot() {
		$this->printForm();
	}

	public function plxAdminEditUsersUpdate() {

		echo <<< 'EOT'
<?php
foreach(explode(' ', 'lang email infos') as $csv_fld) {
	if(! empty($content[$user_id.'_'.$csv_fld])) {
		$this->aUsers[$user_id][$csv_fld] = $content[$user_id.'_'.$csv_fld];
	}
}
?>
EOT;

	}

	public function signature() {
		return filemtime(__FILE__);
	}

}
?>
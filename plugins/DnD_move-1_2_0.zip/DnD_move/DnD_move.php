<?php

if (!defined('PLX_ROOT')) exit;

/**
 * Ordonner les catégories, plugins, et pages statiques en glissant chaque rangée des tableaux à l'aide de la souris.
 * Pour PluXml version 5.5 - Fonctionnement non garanti pour PluXml 5.6
 * @author J.P. Pourrez alias bazooka07
 * @version 2017-11-25
 * */
class DnD_move extends plxPlugin {

	const SCRIPT_JS = 'drag-and-drop.js';

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# Ajouts des hooks
		$this->addHook('AdminCategoriesFoot', 'FootEndBody');
		$this->addHook('AdminStaticsFoot', 'FootEndBody');
		$this->addHook('AdminSettingsPluginsFoot', 'AdminSettingsPluginsFoot');
	}

	public function FootEndBody() {
		if(!is_readable(PLX_CORE.'lib/'.$this::SCRIPT_JS)) {
			$extra = (defined('PLX_VERSION') and version_compare(PLX_VERSION, '5.6') == 0) ? ' data-cleanup' : '';
			$src = PLX_PLUGINS.__CLASS__.'/'.$this::SCRIPT_JS;
			echo <<< SCRIPT
	<script type="text/javascript" src="$src"$extra></script>
SCRIPT;
		}
	}

	public function AdminSettingsPluginsFoot() {
		global $sel;

		if($sel == 1) {
			$this->FootEndBody();
		}
	}

}
?>
(function() {

	'use strict';

	// Utilisé par PHP 5.6
	const THE_CLASS = 'tb-drag-icon';

	var dragSrcEl = null;
	var dragEvents = 'start enter over leave end'.split(' ').map(function(item) {
		return 'ondrag' + item;
	});
	var reOrder = null;

	function handleDragStart(e) {
		// Target (this) element is the source node.
		dragSrcEl = this;
		dragSrcEl.classList.add('dragElem');

		e.dataTransfer.effectAllowed = 'move';
		e.dataTransfer.setData('text/html', dragSrcEl.outerHTML);

	}

	function handleDragOver(e) {
		if (e.preventDefault) {
			e.preventDefault(); // Necessary. Allows us to drop.
		}
		this.classList.add('over');

		e.dataTransfer.dropEffect = 'move';  // See the section on the DataTransfer object.

		return false;
		}

	function handleDragEnter(e) {
		// this / e.target is the current hover target.
	}

	function handleDragLeave(e) {
		this.classList.remove('over');  // this / e.target is previous target element.
	}

	function handleDrop(e) {
		// this/e.target is current target element.

		if (e.stopPropagation) {
			e.stopPropagation(); // Stops some browsers from redirecting.
		}

		// Don't do anything if dropping the same column we're dragging.
		if (dragSrcEl != this) {
			this.parentNode.removeChild(dragSrcEl);
			this.parentNode.insertBefore(dragSrcEl, this);
		}
		this.classList.remove('over');

		if(typeof(reOrder) == 'string') {
			// On renumérote les rangées du tableau
			var stickers = document.querySelectorAll(reOrder);
			if((stickers != null) && (stickers.length > 1)) {
				for(var i=0, iMax=stickers.length; i<iMax; i++) {
					var node = stickers[i];
					var counter = i+1;
					if(node.hasAttribute('value')) {
						node.value = counter;
					} else {
						node.innerHTML = counter;
					}
				}
			}
		}
		return false;
	}

	function handleDragEnd(e) {
		// this/e.target is the source node.
		this.classList.remove('over');
		if(dragSrcEl != null) {
			dragSrcEl.classList.remove('dragElem');
			dragSrcEl = null;
		}
	}

	function addDnDHandlers(elem, cleanUp) {

		// On supprime toute la gestion de Drag & Drop par PluXml
		if(cleanUp === true) {
			dragEvents.forEach(function(ev){
				if(elem.hasAttribute(ev)) {
					elem.removeAttribute(ev);
				}
			});
			if(elem.hasAttribute('drop')) {
				elem.removeAttribute('drop');
			}
			var cell = elem.querySelector('td.' + THE_CLASS);
			if(cell != null) {
				cell.classList.remove(THE_CLASS);
			}
		}

		elem.setAttribute('draggable', true);
		elem.addEventListener('dragstart', handleDragStart, false);
		elem.addEventListener('dragenter', handleDragEnter, false)
		elem.addEventListener('dragover', handleDragOver, false);
		elem.addEventListener('dragleave', handleDragLeave, false);
		elem.addEventListener('drop', handleDrop, false);
		elem.addEventListener('dragend', handleDragEnd, false);
	}

	function setup(node, params) {
		var rows = node.querySelectorAll('tbody ' + params.rows);
		if((rows != null) && (rows.length > 1)) {
			for(var i=0, iMax=rows.length; i<iMax; i++) {
				addDnDHandlers(rows[i], params.cleanUp);
			}

			node.classList.add('dnd-move');
			reOrder = '#' + node.id +
				' tbody ' + params.rows +
				' input[' + params.inputName + ']';

			return true;
		}

		return false;
	};

	var script = document.getElementsByTagName('script');
	script = script[script.length -1];
	const PLUXML_CLEAN_UP = script.hasAttribute('data-cleanup');
	[
		/* Categories */
		{
			name	: 'categories',
			rows	: 'tr:not(.new)',
			inputName	: 'name$="_ordre"',
			cleanUp	: PLUXML_CLEAN_UP
		},
		/* Plugins */
		{
			name	: 'plugins',
			rows	: 'tr',
			inputName	: 'name^="plugOrdre"',
			cleanUp: false
		},
		/* Statics */
		{
			name	: 'statics',
			rows	: 'tr:not(:last-of-type)',
			inputName	: 'name$="_ordre"',
			cleanUp	: PLUXML_CLEAN_UP
		}
	].some(function(table) {
		const node = document.getElementById(table.name + '-table');
		return (node != null && setup(node, table));
	});

})();
<?php
if (!defined('PLX_ROOT')) exit;

if (!empty($_POST)) {
	foreach ($plxPlugin->fields as $field=>$type) {
		switch ($type) {
			case 'numeric' :
				$value = intval($_POST[$field]);
				if ($value == 0 && array_key_exists($field, $plxPlugin->default_values))
					$value = intval($plxPlugin->default_values[$field]);
				break;
			case 'boolean' :
				$value = (!empty($_POST[$field])) ? 1 : 0;
				break;
			default :
				$value = $_POST[$field];
				if (empty($value) && array_key_exists($field, $plxPlugin->default_values))
					$value = $plxPlugin->default_values[$field];
				break;
		}
		$plxPlugin->setParam($field, $value, ($type == 'boolean') ? 'numeric' : $type);
	}
	$plxPlugin->saveParams();
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

$flickr_sizes = array(
	's'=>'75x75',	// small square 75x75
	'q'=>'150x150',	// large square 150x150
	't'=>'100',		// thumbnail, 100 on longest side
	'm'=>'240',		// small, 240 on longest side
	'n'=>'320',		// small, 320 on longest side
	'-'=>'500',		// medium, 500 on longest side
	'z'=>'640',		// medium 640, 640 on longest side
	'c'=>'800',		// medium 800, 800 on longest side†
	'b'=>'1024',	// large, 1024 on longest side*
	'h'=>'1600',	// large 1600, 1600 on longest side†
	'k'=>'2048',	// large 2048, 2048 on longest side†
	'o'=>'original'	// original image, either a jpg, gif or png, depending on source format
);
?>
		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<form id="form_<?php echo $plxPlugin->getInfo('title'); ?>" method="post" >
			<div>
<?php
define('TAB1', "\t\t\t\t");
define('MASK1', strtoupper($plugin));
$items = array();
foreach($plxPlugin->themes as $k)
	$items[$k] = ucfirst($k);

foreach ($plxPlugin->fields as $field=>$type) {
	$value = $plxPlugin->getParam($field);
	if (isset($value))
		$value = plxUtils::strCheck($value);
	else
		$value = (array_key_exists($field, $plxPlugin->default_values)) ? $plxPlugin->default_values[$field] : '';
?>
				<p>
					<label for="id_<?php echo $field; ?>" title="<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.MASK1.'_'.strtoupper($field)); ?></label>
<?php
		switch ($type) {
			case 'boolean' :
				$checked = ($value > 0) ? ' checked' : '';
?>
					<input type="checkbox" id="id_<?php echo $field; ?>" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
				break;
			case 'numeric' :
				$max = "1000";?>
				<input type="number" id="id_<?php echo $field; ?>" name="<?php echo $field; ?>" value="<?php echo $value; ?>" class="num" min="0" max="<?php echo $max; ?>" step="10" maxlength="4" pattern="\d{1,4}"/>
<?php
				if (in_array($field, array('duration')))
					echo 'ms';
				break;
			default :
				switch ($field) {
					case 'theme' :
						plxUtils::printSelect($field, $items, $value);
						break;
					case 'flickr_size' :
					case 'flickr_thumbnail' :
						plxUtils::printSelect($field, $flickr_sizes, $value);
						break;
					case 'flickr_user_id' :
						plxUtils::printInput($field, $value, 'text', '13-12');
						break;
					default :
						plxUtils::printInput($field, $value, 'text', '5-10', false, $class1);
						break;
				}
				break;
		}
?>
				</p>
<?php
}
?>
				<p class="in-action-bar">
					<input type="button" value="<?php $plxPlugin->lang('L_'.MASK1.'_DEFAULT'); ?>" onclick="return resetValues();" />
					<input type="submit" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>"/>
				</p>
			</div>
		</form>
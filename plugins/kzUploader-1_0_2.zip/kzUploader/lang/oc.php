<?php
$LANG = array(
	'L_NEW_PLUGIN'				=> 'Nòva extension',
	'L_NEW_THEMA'				=> 'Nòu tèma',
	'L_UPLOAD'					=> 'Mandar',
	'L_INVALIDATE_ZIP'			=> 'Archiu Zip invalid. Deu conténer solament un dorsièr.',
	'L_PLUGIN_ALREADY_EXISTS'	=> 'Una extension amb lo meteis nom existís ja',
	'L_THEMA_ALREADY_EXISTS'	=> 'Un tèma amb lo meteis nom existís ja',
	'L_MISSING_LIBRARY'			=> 'Bibliotèca ZipArchive mancanta',
	'L_UNWRITABLE_FOLDER'		=> 'Lo dorsièr %s es pas accessible en escritura.'
);
?>
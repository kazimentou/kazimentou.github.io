<?php
$LANG = array(
	'L_NEW_PLUGIN'				=> 'Nouveau plugin',
	'L_NEW_THEMA'				=> 'Nouveau thème',
	'L_UPLOAD'					=> 'Envoyer',
	'L_INVALIDATE_ZIP'			=> 'Archive Zip invalide. Doit contenir uniquement un dossier',
	'L_PLUGIN_ALREADY_EXISTS'	=> 'Un plugin de même nom existe déjà',
	'L_THEMA_ALREADY_EXISTS'	=> 'Un thème de même nom existe déjà',
	'L_MISSING_LIBRARY'			=> 'Bibliothèque ZipArchive manquante',
	'L_UNWRITABLE_FOLDER'		=> 'Le dossier %s n\'est pas accessible en écriture.'
);
?>
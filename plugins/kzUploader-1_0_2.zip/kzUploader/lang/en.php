<?php
$LANG = array(
	'L_NEW_PLUGIN'				=> 'New plugin',
	'L_NEW_THEMA'				=> 'New theme',
	'L_UPLOAD'					=> 'Upload',
	'L_INVALIDATE_ZIP'			=> 'Invalid Zip file. Must have only one folder',
	'L_PLUGIN_ALREADY_EXISTS'	=> 'A plugin with the same name already exists',
	'L_THEMA_ALREADY_EXISTS'	=> 'A theme with the same name already exists',
	'L_MISSING_LIBRARY'			=> 'The ZipArchive library is missing',
	'L_UNWRITABLE_FOLDER'		=> 'The folder %s is unwritable.'
);
?>
<?php
$LANG = array(
	'ARTICLE_GALLERY_FOLDER'	=> 'Dossier de photos pour la galerie',
	'ARTICLE_GALLERY_FIRST'		=> 'En début d\'article',
	'LIGHTBOX2_CONFIG'			=> 'Utiliser Lightbox2',
	'LINK_CONFIG'				=> 'Liens vers les images réelles',
	'NO-TITLE_CONFIG'			=> 'Afficher le titre',
	'THUMBNAIL_CONFIG'			=> 'Vignettes obligatoires',
	'ART_HINT'					=> 'Ou bien insérer : &#34;&lt;div data-gallery="mon-voyage/photos/"&gt;souvenirs&lt;/div&gt;&#34; dans le code HTML',
	'PASTE'						=> 'Coller',
	'COPY'						=> 'Copier',
	'GALLERY_NAME'				=> 'Galerie #FOLDER#',
	'COPY_BTN_TITLE'			=> 'Copier le code HTML pour la galerie d\'images'
);
?>

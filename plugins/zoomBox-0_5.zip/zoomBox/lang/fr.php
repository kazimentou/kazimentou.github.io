<?php
$LANG = array(
	'L_ZOOMBOX_THEME'		=>'Thème',
	'L_ZOOMBOX_OPACITY'		=>'Opacité',
	'L_ZOOMBOX_DURATION'	=>'Durée animation',
	'L_ZOOMBOX_ANIMATION'	=>'Activer l\'animation',
	'L_ZOOMBOX_WIDTH'		=>'Largeur par défaut pour vidéos/iframes',
	'L_ZOOMBOX_HEIGHT'		=>'Hauteur par défaut pour vidéos/iframes',
	'L_ZOOMBOX_GALLERY'		=>'Afficher galerie de vignettes',
	'L_ZOOMBOX_AUTOPLAY'	=>'Lancer la vidéo automatiquement',
	'L_ZOOMBOX_OVERFLOW'	=>'L`image peut dépasser l\'écran',
	'L_ZOOMBOX_FULLSCREEN'	=>'Plein écran sur tablette, smartphone',
	'L_ZOOMBOX_DEFAULT'		=>'Valeurs par défaut',
	'L_ZOOMBOX_MOBILEGALLERY'=>'Afficher galerie sur tablette, smartphone'
);
?>

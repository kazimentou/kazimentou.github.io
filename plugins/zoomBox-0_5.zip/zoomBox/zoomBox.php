<?php

if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour Zoombox
 * http://grafikart.github.io/Zoombox/
 *
 * */

if (! defined('JQUERY_LIB'))
	define('JQUERY_LIB', 'jquery-1.11.3.min.js');
if (! defined('JQUERY_SRC')) {
	define('JQUERY_SRC', '//code.jquery.com/'.JQUERY_LIB);
}

class zoomBox extends plxPlugin {

	public $fields = array(
		'theme'=>'string', 'opacity'=>'numeric', 'duration'=>'numeric', 'animation'=>'boolean',
		'width'=>'numeric', 'height'=>'numeric',
		'gallery'=>'boolean', 'autoplay'=>'boolean', 'overflow'=>'boolean',
		'fullscreen'=>'boolean', 'mobileGallery'=>'boolean'
	);
	public $default_values = array(
		'theme'=>'zoombox', 'opacity'=>'800', 'duration'=>'800', 'animation'=>'1',
		'width'=>'600', 'height'=>'400', 'gallery'=>'1', 'autoplay'=>'0', 'overflow'=>'0',
		'fullscreen'=>'1', 'mobileGallery'=>0
	);

	public $themes = array('zoombox', 'lightbox', 'prettyphoto', 'darkprettyphoto', 'simple', 'golden');

	public  function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
		$this->addHook('FeedEnd', 'FeedEnd');
	}

	public function onActivate() {
		foreach($this->params as $field=>$type) {
			if (array_key_exists($field, $this->params_default)) {
				$this->setParam($field, $this->params_default[$field], ($type != 'boolean') ? $type : 'numeric');
			}
		}
		$this->saveParams();
	}

	private function pluginRoot() {
		global $plxShow;

		$root = $_SERVER['DOCUMENT_ROOT'];
		if (is_link($root)) {
			$root = readlink($root);
		}
		$dir1 = dirname(__FILE__).'/';
		if (strpos($dir1, $root) === 0) {
			return substr($dir1, strlen($root));
		} else {
			// problème avec hébergeur LWS, inutile chez Free, OVH
			if (isset($plxShow)) {
				return dirname($_SERVER['SCRIPT_NAME']).'/'.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				global $plxAdmin;
				if (isset($plxAdmin)) {
					return preg_replace('#[^/]+/[^/]+$#',dirname('', $_SERVER['SCRIPT_NAME'])).'/'.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
				} else {
					return '/';
				}
			}
		}
	}

	private function _get_jquery() {
		// More infos about CDN here : http://encosia.com/3-reasons-why-you-should-let-google-host-jquery-for-you/
		// src'+'=" is a hack for abusing PluXml in plxUtils::rel2abs function
		if (! defined('JQUERY_LOADED')) {
?>
	<script type="text/javascript"> <!-- zoomBox -->
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src'+'="<?php echo JQUERY_SRC; ?>"></scr'+'ipt>');
	</script>
<?php
			define('JQUERY_LOADED', true);
		}
	}

	public function AdminTopEndHead($params) {
		global $plxAdmin, $plugin;

		switch ($this->script_name) {
			case 'parametres_pluginhelp' :
				break;
			case 'medias' :
				$this->ThemeEndHead();
				break;
			case 'parametres_plugin' :
				if ($plugin == __CLASS__) {
					$buf = array();
					foreach ($this->default_values as $k=>$v) {
						if (array_key_exists($k, $this->fields)) {
							$type = $this->fields[$k];
							if ($type == 'boolean')
								$value = ($v > 0) ? 'true' : 'false';
							else
								$value = ($type == 'numeric') ? $v : "'$v'";
						}
						else
							$value = "'$v'";
						array_push($buf, $k.': '.$value);
					} ?>
	<script type="text/javascript">
		<!--
		function resetValues() {
			var defaultValues = {<?php echo implode(", ", $buf); ?>};
			for (option in defaultValues) {
				var elm = document.getElementById('id_'+option);
				if (elm) {
					if (elm.hasAttribute('type') && elm.getAttribute('type') == 'checkbox') {
						elm.checked = defaultValues[option];
					} else if (elm.value) {
						elm.value = defaultValues[option];
					}
				}
			}
			return true;
		}
		// -->
	</script>
<?php			}
				break;
		}
	}

	public function AdminMediasFoot() { ?>
	<script type="text/javascript">
		<!--
		var options = {<?php $this->printOptionsJS(); ?>};
		jQuery.extend(jQuery.zoombox.options, options);
			var set1 = $("img[src*='/\\.thumbs/']").zoombox();
		-->
	</script>
<?php
	}

	public function ThemeEndHead($params) {

		$this->_get_jquery();
?>
	<link type="text/css" href="<?php echo $this->pluginRoot().__CLASS__; ?>/zoombox.css" rel="stylesheet" media="screen" />
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>/zoombox.js"></script>
	<!-- script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script -->
	<script type="text/javascript" src="<?php echo $this->pluginRoot(); ?>flickr/<?php echo __CLASS__; ?>-flickr.js"></script>
	<script type="text/javascript">
		<!--
		cbDefaultOptions = {<?php echo $options;?> rel: 'lightbox' };
		// -->
	</script>
<?php	}

	private function _get_plumxl_gallery() {
		global $plxShow, $output;

		// crée une galerie pour les images stockées par Pluxml
		if (preg_match('#(<(?:div|p)\s+[^>]*id="pl_gallery"[^>]*>)[^<]*</div>#', $output, $matches)) {
			if (preg_match('#data-src="([^"]+)"#', $matches[1], $match_src)) {
				$folder = $match_src[1];
				if (substr($folder, -1) != '/')
					$folder .= '/';
				$root = substr(dirname(__FILE__), 0, -strlen($plxShow->plxMotor->aConf['racine_plugins'].__CLASS__));
				$filesList = glob($root.$plxShow->plxMotor->aConf['medias'].$folder.'*.tb.{jpg,jpeg,png,gif}', GLOB_BRACE);
				$innerHTML = "\n";
				foreach ($filesList as $filename) {
					$src = substr($filename, strlen($root));
					$sizes = getimagesize($filename);
					$title = ucfirst(substr(pathinfo($filename, PATHINFO_FILENAME), 0, -3));
					$innerHTML .= <<< INNER_HTML
						<div><img src="$src" alt="image" {$sizes[3]} title="$title" /><p>$title</p></div>

INNER_HTML;
				}
				$output = str_replace($matches[0], $matches[1].plxUtils::rel2abs($plxMotor->racine, $innerHTML).'</div>', $output);
			}
		}
	}

	private function printOptionsJS() {
		$options = array();
		foreach($this->fields as $field=>$type) {
			$value = $this->getParam($field);
			if (! isset($this->default_values[$field]) or ($value != $this->default_values[$field])) {
				switch ($type) {
					case 'numeric' :
						if ($field == 'opacity') {
							$value = $value / 1000;
						}
						$options[] = "$field: {$value}";
						break;
					case 'boolean' :
						$status = ($value > 0) ? 'true' : 'false';
						$options[] = "$field: {$status}";
						break;
					default :
						$options[] = "$field: '{$value}'";
				}
			}
		}
		echo implode(', ', $options);
	}

	public function ThemeEndBody($params) {

		$this->_get_plumxl_gallery();
		// Crée une galerie pour les images hébergées par Flickr
		$size = $this->getParam('flickr_size');
		if (empty($size)) $size = 'b';
		$thumbnail = $this->getParam('flickr_thumbnail');
		if (empty($thumbnail)) $thumbnail = 'd';
 ?>
	<script type="text/javascript">
		var optionsFlickr = { imageSize: '<?php echo $size; ?>', thumbnailSize: '<?php echo $thumbnail; ?>'};
		flickGallery();
	</script>
	<script type="text/javascript">
		var options = {<?php $this->printOptionsJS(); ?>};
		jQuery.extend(jQuery.zoombox.options, options);
		var set2 = $("img[src*='\\.tb\\.']").zoombox();
		var set3 = $("a.zoombox").zoombox();
		var set4 = $("img[src*='flickr']").zoombox();
	</script>

<?php
	}

	public function FeedEnd() {
		global $plxFeed;

        // protect some HTML entities between tags (required by XML files)
        $code = "\$pats = ['&lt;', '&gt;', '&quot;'];\n";
        $code .= "\$reps = ['<<<<', '>>>>', '\"\"\"\"'];\n";

        $root = $plxFeed->racine;
        $host = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'];
        if (substr($root, 0, strlen($host)) != $host)
			$root = $host.$root;
        $_pattern1 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*\.)(tb\.)(jpg|png|gif)([^>]*))>>>>!';
        $_pattern2 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*)(/\.thumbs)(/\w[^"]*\.)(jpg|png|gif)([^>]*))>>>>!';
        $_replace1 = '<<<<a href="\3\5">>>><<<<\1>>>><<<</a>>>>';
        $_replace2 = '<<<<a href="\3\5\6">>>><<<<\1>>>><<<</a>>>>';

        $code .= "\$patterns = [\n\t'$_pattern1',\n\t'$_pattern2'\n];\n";
        $code .= "\$replaces = ['$_replace1', '$_replace2'];\n";
        $code .= "\$tmp = str_replace(\$pats, \$reps, \$output);\n";
		$code .= "\$tmp = preg_replace(\$patterns, \$replaces, \$tmp);\n";
        // deprotect some HTML entities and output
        $code .= "\$output = str_replace(\$reps, \$pats, \$tmp);\n";

		echo "<?php $code ?>";
	}

}

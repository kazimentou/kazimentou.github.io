<?php

if (!defined('PLX_ROOT')) exit;

class phpinfo extends plxPlugin {

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->addHook('AdminTopMenus', 'AdminTopMenus');
	}

	// ajoute une entrée au menu ddans la partie Admin
	public function AdminTopMenus() {
		global $menus;
		global $plxAdmin;

		if ($_SESSION['profil'] <= PROFIL_ADMIN) {
			$href1 = $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			$title1 = 'Affiche des informations sur le serveur';
			$onclick1 = "window.open('".$href1."'); return false; ";

			array_splice($menus, -1, 0, plxUtils::formatMenu(plxUtils::strCheck($this->getInfo('title')), '#', $title1, false, $onclick1));
		}
	}

}
?>

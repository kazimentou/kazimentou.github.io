# plxForkAwesome
PluXml plugin: Ajouter Fork Awesome 1.0.3 à votre thème PluXml

![Font-Awesome](https://cloud.githubusercontent.com/assets/13441278/10660837/31652daa-78aa-11e5-8c78-e07ad0694b1a.png)

Permet d'ajouter la police d'icônes Fork Awesome à PluXml sans effort, activer simplement le plugin!

Le plugin est disponible sur mon [dépôt de plugins pour Pluxml](http://blog.niqnutn.com/plugins/repository/index.php) 

[Fork Awesome](https://forkawesome.github.io/Fork-Awesome/):  Fork Awesome 1.0.3 (A fork of Font Awesome, originally created by Dave Gandy)         

* The Fork Awesome font is licensed under the SIL OFL 1.1:
	* http://scripts.sil.org/OFL
* Fork Awesome CSS, LESS, and Sass files are licensed under the MIT License:
	* https://opensource.org/licenses/mit-license.html
* The Fork Awesome documentation is licensed under the CC BY 3.0 License:
	* https://creativecommons.org/licenses/by/3.0/

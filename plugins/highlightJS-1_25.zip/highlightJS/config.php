<?php
if (!defined('PLX_ROOT')) exit;

$fields = array('style'=>'string', 'repo'=>'string');
$default_values = array('style'=>'default', 'repo'=>'cdnjs');

if (!empty($_POST)) {
	foreach ($fields as $field=>$type) {
		$value = $_POST[$field];
		if (empty($value) && array_key_exists($field, $default_values))
			$value = $default_values[$field];
		$plxPlugin->setParam($field, $value, $type);
	}
	$plxPlugin->saveParams();
}

$styles = array('default'=>'Default');
$filename = dirname(__FILE__).'/styles.txt';
if (is_file($filename)) {
	$content = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	foreach ($content as $value)
		if ($value != 'default')
			$styles[$value] = ucFirst($value);
} else {
	$rep = dirname(__FILE__).'/'.$plxPlugin->stylesPath;
	if (is_dir($rep)) {
		$styleSheets = glob($rep.'/*.css');
		if (!empty($styleSheets)) {
			foreach ($styleSheets as $filename) {
				$value = substr(basename($filename), 0, -4);
				if ($value != 'default')
					$styles[$value] = ucFirst($value);
			}
		}
		else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
			echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
			$dir = new DirectoryIterator($rep.'.');
			foreach ($dir as $fileinfo) {
				$filename = basename($fileinfo->getFilename());
			    if ((substr($filename, -4) == '.css')) {
					$value = substr($filename, 0, -4);
					$styles[$value] = ucFirst($value);
				}
			}
			asort($styles);
		}
	}
}

?>
		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<form id="form_<?php echo $plugin; ?>" method="post" onsubmit="return true;">
<?php	foreach ($fields as $field=>$type) {
			$value = $plxPlugin->getParam($field);
			if (!empty($value))
				$value = plxUtils::strCheck($value);
			else
				$value = (array_key_exists($field, $default_values)) ? $default_values[$field] : '';
			$class = ($type == 'cdata') ? 'class="large"' : '' ?>
			<p>
				<label <?php echo $class;?>><?php $plxPlugin->lang('L_HIGHLIGHT_'.strtoupper($field)); ?></label>
<?php
			switch ($field) {
				case 'style' :
					plxUtils::printSelect($field, $styles, $value); ?>
				<a href="http://highlightjs.org/static/demo/" target="blank"><?php echo $plxPlugin->lang('L_HIGHLIGHT_DEMO'); ?></a>
<?php
					break;
				case 'repo':
					plxUtils::printSelect($field, $plxPlugin->repos_list(), $value);
					break;
			} ?>
			</p>
<?php } ?>
			<p>
				<label>&nbsp;</label>
				<input type="submit" />
			</p>
		</form>
		<p>
			<?php echo $plxPlugin->lang('L_HIGHLIGHT_INFO'); ?>
		</p>

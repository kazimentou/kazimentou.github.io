<?php
if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour HighlightJS
 * https://highlightjs.org/ - version 8.9.1
 * https://github.com/isagalaev/highlight.js
 * */

define('HIGHLIGHT_JS_VERSION', '8.9.1');

class highlightJS extends plxPlugin {
	
	private $repos = array (
		'cdnjs'		=> '//cdnjs.cloudflare.com/ajax/libs',
		'jsdelivr'	=> '//cdn.jsdelivr.net'
	);
	
	public $stylesPath = 'highlightJS/src/styles/';

	public  function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->addHook('ThemeEndHead', 'ThemeEndHead');
        $this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

	public function pluginRoot() {
		global $plxShow;
		
		if (isset($plxShow)) {
			return $plxShow->plxMotor->racine.$plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}
	
	public function repos_list() {
		$result = array();
		foreach (array_keys($this->repos) as $repo)
			$result[$repo] = ucfirst($repo);
		return $result;
	}
	
	private function site_ok() {
		global $plxShow;
		
		return ($plxShow->plxMotor->mode != 'home');
	}

	private function print_header() {
		// Ex: //cdnjs.cloudflare.com/ajax/libs/highlight.js/8.9.1/styles/default.min.css
		$style = $this->getParam('style');
		if (empty($style))
			$style = 'default';
		$key = $this->getParam('repo');
		if (empty($key)) {
			$buf = array_keys($this-repos);
			$key = $buf[0];
		}
		$repo = $this->repos[$key];
		$version = HIGHLIGHT_JS_VERSION;
		echo <<< SRC
	<link rel="stylesheet" href="$repo/highlight.js/$version/styles/$style.min.css">
	<script src="$repo/highlight.js/$version/highlight.min.js"></script>

SRC;
	}

	public function ThemeEndHead() {
		
		if ($this->site_ok())
			$this->print_header();
	}
	
	public function ThemeEndBody() {
		
		if ($this->site_ok()) {
?>
	<script language="javascript">
		<!--
		var elements = document.querySelectorAll('textarea[data-lang]');
		if (elements)
			for (var i=0; i<elements.length; i++) {
				var src = elements[i];
				var lang = src.getAttribute['data-lang'];
				src.style.display = 'none';				
				var result = hljs.highlightAuto(src.value, lang);
				var target = document.createElement('pre');
				target.innerHTML = result.value;
				var parent = src.parentNode;
				parent.insertBefore(target, src);
			}
		// -->
	</script>
<?php	}
	}

}
?>

<?php

/*
$help_hljs = <<< EOT
<div id="hljs-help">
	<p>
		Le code à colorier dans les pages HTML doit être placé à l'intérieur d'un bloc &lt;textarea&gt; avec l'attribut "data-lang".
		Il n'est pas nécessaire de convertir en entités HTML les caractères &lt; et &gt;, sauf pour les balises &lt;body&gt; et &lt;html&gt;.
	</p>
	<pre>
		<code>&lt;textarea data-lang="php">
&lt?php
echo "Bonjour&#92;n";
?>
&lt;/textarea></code>
	</pre>
	<p>
		Les langages suivants sont reconnus automatiquement :
	</p>
	<ul>
	    <li>Apache</li>
	    <li>Bash</li>
	    <li>C#</li>
	    <li>C++</li>
	    <li>CSS</li>
	    <li>CoffeeScript</li>
	    <li>Diff</li>
	    <li>HTML, XML</li>
	    <li>HTTP</li>
	    <li>Ini</li>
	    <li>JSON</li>
	    <li>Java</li>
	    <li>JavaScript</li>
	    <li>Makefile</li>
	    <li>Markdown</li>
	    <li>Nginx</li>
	    <li>Objective</li> <li>C</li>
	    <li>PHP</li>
	    <li>Perl</li>
	    <li>Python</li>
	    <li>Ruby</li>
	    <li>SQL</li> 
	</ul>
	<p>
		<a href="http://highlightjs.org/" target="_blank">Site de Highlght.js</a>
	</p>
</div>

EOT;
* */
$LANG = array(
	'L_HIGHLIGHT_STYLE' => 'Théme',
	'L_HIGHLIGHT_INFO' => <<< EOT
<div id="hljs-help">
	<p>
		Le code à colorier dans les pages HTML doit être placé à l'intérieur d'un bloc &lt;textarea&gt; avec l'attribut "data-lang".
		Il n'est pas nécessaire de convertir en entités HTML les caractères &lt; et &gt;, sauf pour les balises &lt;body&gt; et &lt;html&gt;.
	</p>
	<pre>
<code>&lt;textarea data-lang="php">
&lt?php
	echo "Bonjour tout le Monde;&#92;n";
?>
&lt;/textarea></code></pre>
	<p>
		Les langages suivants sont reconnus automatiquement :
	</p>
	<ul>
	    <li>Apache</li>
	    <li>Bash</li>
	    <li>C#</li>
	    <li>C++</li>
	    <li>CSS</li>
	    <li>CoffeeScript</li>
	    <li>Diff</li>
	    <li>HTML, XML</li>
	    <li>HTTP</li>
	    <li>Ini</li>
	    <li>JSON</li>
	    <li>Java</li>
	    <li>JavaScript</li>
	    <li>Makefile</li>
	    <li>Markdown</li>
	    <li>Nginx</li>
	    <li>Objective</li> <li>C</li>
	    <li>PHP</li>
	    <li>Perl</li>
	    <li>Python</li>
	    <li>Ruby</li>
	    <li>SQL</li> 
	</ul>
	<p>
		<a href="http://highlightjs.org/" target="_blank">Site de Highlght.js</a>
	</p>
</div>

EOT
,
	'L_HIGHLIGHT_DEMO' => 'Aperçu',
	'L_HIGHLIGHT_REPO'	=> 'Dépôt pour highlight.min.js',
	'L_HIGHLIGHT_THEME_ERROR'	=> 'La copie du thème a eéchouée'
);

?>

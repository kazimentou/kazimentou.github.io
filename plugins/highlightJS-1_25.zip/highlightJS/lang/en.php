<?php

$LANG = array(
'L_HIGHLIGHT_STYLE' => 'Style',
'L_HIGHLIGHT_INFO' => 'In the HTML pages, the code to colorize has to put between &lt;pre&gt;&lt;code&gt; and &lt;/code&gt;&lt;/pre&gt;.<br /><br />
For a particular language, for example html, add the class attribute like this : &lt;pre class="lang-html"&gt;. For HTML language, use html entities for &lt; and &gt; characters.',
'L_HIGHLIGHT_DEMO' => 'Aperçu'
);

?>

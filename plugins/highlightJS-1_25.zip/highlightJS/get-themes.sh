#!/bin/sh

OLD_PWD=`pwd`
TARGET='highlightJS'
SRC='https://github.com/isagalaev/highlight.js/archive/master'
FILENAME='highlightJS.zip'

SCRIPT="https://raw.githubusercontent.com/isagalaev/highlight.js/master/src/highlight.js"
CLOSURE_URL='http://closure-compiler.appspot.com/compile'

TEMP1=`mktemp -d`
wget -O $TEMP1/$FILENAME $SRC.zip
rm -R $TARGET # purge all !
mkdir $TARGET

cd $TEMP1
unzip $FILENAME
for folder in src demo; do
cp -a highlight.js-master/$folder $OLD_PWD/$TARGET/
done
cd $OLD_PWD
cd $OLD_PWD/$TARGET/highlightJS/src/styles/
ls *.css | sed 's/\.css$//' > $OLD_PWD/styles.txt
echo Liste des styles dans styles.txt
cd $OLD_PWD
rm -R $TEMP1
exit
wget -O highlight.min.js --post-data "\
output_format=json&\
output_info=compiled_code&\
compilation_level=SIMPLE_OPTIMIZATIONS&\
output_file_name=highlight.min.json&\
code_url=$SCRIPT&\
output_format=text" \
	$CLOSURE_URL

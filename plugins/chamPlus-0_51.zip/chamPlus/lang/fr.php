<?php
		$LANG = array(
			'L_CHAMPLUS_LABEL'			=> 'Entre l\'intitulé',
			'L_CHAMPLUS_NAME'			=> 'Entrez le nom',
			'L_CHAMPLUS_TEXTAREA'		=> 'Cochez pour un bloc-texte',
			'L_CHAMPLUS_GROUP'			=> 'Entrez le groupe si besoin',
			'L_CHAMPLUS_NEW_LABEL'		=> 'Entre le nouvel intitulé',
			'L_CHAMPLUS_NEW_NAME'		=> 'Entrez le nouveau nom',
			'L_CHAMPLUS_NEW_TEXTAREA'	=> 'Cochez pour un nouveau bloc-texte',
			'L_CHAMPLUS_NEW_GROUP'		=> 'Entrez le nouveau groupe si besoin',
			'L_CHAMPLUS_TITLE_LABEL'	=> 'Intitulé',
			'L_CHAMPLUS_TITLE_NAME'		=> 'Nom<sup>1</sup>',
			'L_CHAMPLUS_TITLE_TEXTAREA'	=> 'Bloc<br />texte',
			'L_CHAMPLUS_TITLE_GROUP'	=> 'Groupe',
			'L_CHAMPLUS_TITLE_STATIC'	=> 'Page<sup>2</sup><br />statique',
			'L_CHAMPLUS_BLOC'			=> 'Bloc texte',
			'L_CHAMPLUS_ADD'			=> 'Ajouter un champ',
			'L_CHAMPLUS_SAVE'			=> 'Enregistrer',
			'L_CHAMPLUS_WARNING'		=> <<< WARNING
<sup>1</sup> Les champs sans nom ne sauront pas sauvegardés<br />
<sup>2</sup> Les bloc-textes ne sont pas permis dans les pages statiques. Ils sont considérés comme des lignes.
WARNING
,
			'L_CHAMPLUS_BADNAME'		=> <<< BADNAME
Le nom doit être en minuscules,\\\ncommencer par une lettre et\\\nne contenir que des lettres ou des chiffres
BADNAME
,
			'L_CHAMPLUS_HELP_LABEL'		=> 'Aide',
			'L_CHAMPLUS_HELP'			=> <<< HELP
<p>
	Pour afficher des champs supplémentaire sur votre site, utiliser le hook champlus dans vos gabarits (<i>template</i>) article.php ou static.php ou categorie.php comme ci-dessous. Vous pouvez bien sûr dupliquer et renommer vos gabarits.
</p>
<pre><code>&lt;?php eval(&dollar;plxShow->callHook('champlus', &dollar;params); ?>
</code></pre>
<p>
	<strong>&dollar;params</strong> peut être le nom du champ sous forme d'une chaine de caractères type string. Dans ce cas, la valeur du champ sera affichée à la place du hook.
</p>
<p>
	<strong>&dollar;params</strong> peut être aussi un tableau de deux éléments. Le premier sera le nom du champ comme précédemment. Le deuxième sera une chaine de format avec un des choix suivants:
<ul>
<li>
	false: la valeur du champ sera uniquement affichée comme précèdemment. C'est le choix par défaut.</li>
<li>
	true: la valeur du champ sera retournée sans être affichée. Peut être utilisée dans une variable</li>
<li>
	une chaine de caractères, au format HTML, contenant un ou plusieurs motifs suivants : #name#, #value#, #label" ou #group#.<br />
	<ul>
		<li><strong>#name#</strong> affiche le nom du champ</li>
		<li><strong>#label#</strong> affiche son libellé comme dans le formulaire de saisie d'un article ou d'une page statique</li>
		<li><strong>#value#</strong> affiche sa valeur</li>
		<li><strong>#group#</strong> affiche le nom du groupe saisi dans le panneau de configuration</li>
	</ul>
</li>
</ul>
<p>	On peut ainsi avoir, par exemple :</p>
<pre><code>&lt;?php
&dollar;params = array(
  'price',
  'le #price# est à &lt;strong>#value#&lt;/strong> !'
);
eval(&dollar;plxShow->callHook('champlus', &dollar;params);
?>
</code></pre>
<p>
	Si le nom du champ est "monchamp", alors le nom du champ dans les fichiers d'articles ou dans le fichier statiques.xml sera "cps_monchamp". Le nom doit être en minuscules et commencer par une lettre, suivie d'au maximun 32 lettres ou chiffres. Il est conseillé de saisir le libellé en minuscules. Tous les caractères sont permis. Dans les éditions, la première lettre sera forcée en majuscule.
</p>
<p>Il ne peut y avoir de champ commun aux articles et aux pages statiques. Il n'est pas possible d'avoir un bloc de texte (<i>textarea</i>) dans les pages statiques. Pour l'édition des articles, les champs, qui ne sont pas de type bloc de texte, sont situés sur le panneau à droite de la fenêtre.</p>
<p>Il existe également le hook <strong>chamPlusList</strong>, sans paramètre, qui retourne l'ensemble des champs sous forme de tableau. On peut l'affecter à une variable ou l'afficher sur le site avec le code suivant dans un gabarit :</p>
<pre><code>&lt;pre>&lt;?php print_r(
  eval(&dollar;plxShow->callHook('chamPlusList'));
); ?>&lt;/pre></code></pre>
<p><input type="button" value="Masquer" onclick="help_me(false);"</p>
HELP
,
);
?>

<?php

if (!defined('PLX_ROOT')) exit;

$fields = array('nb_pages'=>'numeric', 'category'=>'boolean', 'tags'=>'boolean', 'no_tags'=>'string', 'template'=>'string',
	'archive'=>'string', 'author'=>'string');
$default_values = array('nb_pages'=>5, 'category'=>true, 'tags'=>true, 'template'=>'article',
	'no_tags'=>'a,à,au,ayant,celles,contre,dans,d,de,des,du,devant,en,entre,et,l,le,la,les,on,par,pour,que,qui,s,sa,se,ses,son,un,une');
$field_sizes =  array('nb_pages'=>'2-5', 'no_tags'=>'30-255');

function getTags($aString, $enabled=true) {
	global $plxPlugin;

	if ($enabled) {
		// catching keywords in $aString
		$noTags = explode(',', $plxPlugin->getParam('no_tags'));
		$buf1 = strtolower(str_replace(array('Â','Ê','É'), array('â', 'ê', 'é'), $aString));
		if (preg_match_all('#(^|[^\wàâéèêîôùû])*([\wàâéèêîôùû]+)([^\wàâéèêîôùû]|$)*#', $buf1, $buf)) {
			$result = $buf[2];
			for ($i = count($result) - 1; $i >= 0; $i--) {
				if (in_array($result[$i], $noTags))
					unset($result[$i]);
			}
			return implode(',', array_unique($result));
		}
		else
			return '';
	}
	else
		return '';
}

function addCat($newCat, $add=true) {
	global $plxAdmin;

	$result = '000'; // It's default category
	if ($add) {
		// checking if $newCat is registered
		$notFound = true;
		foreach (array_keys($plxAdmin->aCats) as $k) {
			if ($plxAdmin->aCats[$k]['name'] == $newCat) {
				$notFound = false;
				$result = $k;
				break;
			}
		}
		if ($notFound) {
			// Really, $newCat is new
			$content = array('new_category'=>1, 'new_catname'=>$newCat);
			$plxAdmin->editCategories($content);
			$keys = array_keys($plxAdmin->aCats);
			$result = $keys[count($keys) - 1];
		}
	}
	return $result;
}

function getSrcDispo($zipfile) {
	global $plxAdmin;

	$lignes = explode("\n", $zipfile->getFromName('index.csv'));
	$result = array();
	foreach ($lignes as $ligne) {
		list($livre, $title, $src) = explode("\t", $ligne);
		$src = trim($src);
		if (!empty($src))
			$result[$src] = array('title'=>$title, 'cat'=>$livre);
	}
	ksort($result);
	foreach ($plxAdmin->plxGlob_arts->aFiles as $k=>$v) {
		$url = preg_replace('!^[\d\.]*\.(.*)\.xml!', '$1', $v);
		if  (array_key_exists($url, $result))
			unset($result[$url]);
	}
	return $result;
}

function readArticles($filename, $nb_articles) {
	global $plxAdmin, $plxPlugin;

	$zipfile = new ZipArchive();
	if ($zipfile->open($filename)) {
		$liste = getSrcDispo($zipfile);
		$nextIdArticle = $plxAdmin->nextIdArticle();
		for ($i = 0; $i < $nb_articles; $i++) {
			if (count($liste) > 0) {
				mt_srand();
				$k = mt_rand(0, count($liste) - 1);
				$src = array_keys($liste)[$k];
				$content = $zipfile->getFromName($src.'.inc');
				$temp = explode("\n", trim($content));
				$n = mt_rand(3, 7);
				$lines = (count($temp) > $n + 2) ? $n : count($temp) - 2; // balise <p> sur 1ère et dernière ligne
				$chapo = array_splice($temp, 1, $lines);
				$x = count($chapo) - 1;
				$chapo[$x] = preg_replace('#\s*<br\s*/>\s*$#', '', $chapo[$x]);
				list($year, $month, $day, $time1) = explode("\t", date("Y\tm\td\tH:i", time() - mt_rand(7*24*3600, 365*24*3600)));
				$title = $liste[$src]['title'];
				$enabledTags = ($plxPlugin->getParam('tags') > 0);
				$article = array(
					'url'=>$src,
					'title'=>$title,
					'allow_com'=>'0',
					'template'=>$plxPlugin->getParam('template'),
					'chapo'=>'<p>'.implode("\n", $chapo).'</p>',
					'content'=>implode("\n", $temp),
					'tags'=>getTags($title, $enabledTags),
					'meta_description'=>'',
					'meta_keywords'=>'',
					'title_htmltag'=>str_replace('_', ' ', substr($plxPlugin->getParam('archive'), 0, -4)),
					'moderate'=>'',
					'publish'=>'1',
					'year'=>$year,
					'month'=>$month,
					'day'=>$day,
					'time'=>$time1,
					'catId'=>array(addCat($liste[$src]['cat'], $plxPlugin->getParam('category'))),
					'author'=>$plxPlugin->getParam('author'),
					'publish'=>'1'
				);
				// $artId = '0000';
				$artId = str_pad($nextIdArticle + $i, 4, '0', STR_PAD_LEFT);
				$plxAdmin->editArticle($article, $artId);
				unset($liste[$src]);
			}
			else {
				// Toutes les fables sont publiées
				plxMsg::error($plxPlugin->getLang('L_LESFABLES_ALL_PUBLISHED'));
				break;
			}
		}
	}
}

if (!empty($_POST)) {
	// Saving parameters
	foreach ($fields as $field=>$type) {
		switch ($type) {
			case 'numeric' :
				$value = (!empty($_POST[$field])) ? intval($_POST[$field]) : '';
				break;
			case 'boolean' :
				$value = (isset($_POST[$field])) ? 1 : 0;
				break;
			default :
				$value = (!empty($_POST[$field])) ? $_POST[$field] : '';
				break;
		}
		if (empty($value) and in_array($field, array_keys($default_values)))
			$value = $default_values[$field];
		$plxPlugin->setParam($field, $value, $type);
	}
	$plxPlugin->saveParams();

	// publishing some articles
	readArticles(PLX_PLUGINS.$plugin.'/'.$plxPlugin->getParam('archive'), $plxPlugin->getParam('nb_pages'));
}

// --- And now, the Form ! -------

# what templates have we ?
$files = plxGlob::getInstance(PLX_ROOT.$plxAdmin->aConf['racine_themes'].$plxAdmin->aConf['style']);
if ($array = $files->query('/^article(-[a-z0-9-_]+)?.php$/')) {
	foreach($array as $k=>$v)
		$aTemplates[$v] = $v;
}

$files = plxGlob::getInstance(PLX_PLUGINS.get_class($plxPlugin).'/');
if ($array = $files->query('/^.*\.zip$/')) {
	foreach($array as $k=>$v)
		$aArchives[$v] = substr($v, 0, -4);
}

foreach ($plxAdmin->aUsers as $id=>$infos) {
	if (!empty($infos['active']))
		$aAuthors[$id] = $infos['name'];
}
?>

		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<form id="form_<?php echo $plugin; ?>" method="post">
			<p>
<?php
foreach ($fields as $field=>$type) {
	$value = $plxPlugin->getParam($field);
	if (empty($value) && array_key_exists($field, $default_values))
		$value = $default_values[$field]; ?>
				<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.strtoupper($plugin.'_'.$field)); ?></label>
<?php
	switch ($type) {
		case 'numeric' : ?>
				<?php plxUtils::printInput($field, $value, 'text', '2-8');
			break;
		case 'boolean' :
				$checked = ($value) ? ' checked' : '' ?>
				<input id="id_<?php echo $field; ?>" type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
			break;
		default :
			switch ($field) {
				case 'template' :
					plxUtils::printSelect($field, $aTemplates, $value);
					break;
				case 'archive' :
					plxUtils::printSelect($field, $aArchives, $value);
					break;
				case 'author' :
					plxUtils::printSelect($field, $aAuthors, $value);
					break;
				default :
					// $size =  (in_array($field, $field_sizes)) ? $field_sizes[$field] : '20-50';
					$size =  (!empty($field_sizes[$field])) ? $field_sizes[$field] : '20-50'; ?>
				<?php plxUtils::printInput($field, $value, 'text', $size);
					break;
			}
			break;
	} ?>
			</p><p>
<?php
}
?>
				<?php $plxPlugin->lang('L_'.strtoupper($plugin.'_info')); ?>
			</p><p>
				<label>&nbsp;</label>
				<input type="submit" />
			</p>
		</form>

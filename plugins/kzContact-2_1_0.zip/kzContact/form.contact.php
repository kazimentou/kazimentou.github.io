<?php
$params = array(
	'your-name'		=> array('type' => 'text', 'required' => true),
	'your-email'	=> array('type' => 'email'),
	'your-phone'	=> array('type' => 'tel'),
	'your-subject'	=> array('type' => 'text', 'large' => true),
	'your-message'	=> array('type' => 'textarea', 'required' => true)
);

include 'my-form.inc.php';
?>

<?php
if(
	empty($params) or (
		!defined('PLX_ADMIN') and
		!defined('PLX_ROOT')
	)
) {
	header('Content-Type: text/plain; charset=utf-8');
	readfile('hymne-a-la-beaute.txt');
	exit;
}

$inActionBarClassName = '';
if(!defined('PLX_ADMIN') and isset($error) and $error === false) {
	# Courriel envoyé
?>
			<p class="success"><?php echo nl2br(plxUtils::strCheck($plxPlugin->getParam('thankyou'))); ?></p>
			<p><input type="button" value="Retour à l'accueil" onclick="window.location.replace('<?php echo $this->plxMotor->racine; ?>');" /></p>
<?php
} else {
	if(defined('PLX_ADMIN')) { /* ---------- côté admin ------------- */
		$inActionBarClassName = ' class="in-action-bar"';
		if(function_exists('mail')) {
			$color = 'green'; $msg = $plxPlugin->getLang('L_MAIL_AVAILABLE');
		} else {
			$color = 'red'; $msg = $plxPlugin->getLang('L_MAIL_NOT_AVAILABLE');
		}
			echo <<< EOT

		<p style="color:$color"><strong>$msg</strong></p>\n
EOT;
	} else { /* ------------------ côté site ------------------ */
		# le script s'execute à l'interieur d'une fonction de $plxShow, donc $this égal à $plxShow
		include_once(PLX_CORE.'lib/class.plx.token.php');
		plxToken::validateFormToken();

		$plxPlugin = $this->plxMotor->plxPlugins->getInstance('kzContact');

		if (!empty($_POST)) {
			$plxPlugin->params = $params;
			$error = $plxPlugin->sendMessage();
		}

		// Entête dan la page HTML
		echo " <!----- begin of kzContact plugin -------->\n";
		if(!empty($error)) {
			# Il y a une erreur
			echo <<< EOT
				<p class="contact_error">$error</p>\n
EOT;
		}

		$mnuText = $plxPlugin->getParam('mnuText');
		$myForm = $plxPlugin->getParam('content');
		if(! empty($mnuText)) {
			echo <<< EOT
					<div class="kz-contact header-$myForm">
$mnuText
					</div>\n
EOT;
		}
	}

	$fieldset_num = 1;
?>
					<form class="inline-form kz-contact" method="post">
						<fieldset id="fieldset-<?php echo substr('0'.$fieldset_num, -2); ?>">
<?php
		foreach ($params as $field=>$infos) {
			if(!empty($infos['break-before'])) {
				$fieldset_num++;
				$id = substr('0'.$fieldset_num, -2);
				echo <<< SEPARATOR
						</fieldset><fieldset id="fieldset-$id">\n
SEPARATOR;
			}
			// some values by default
			if(!array_key_exists('type', $infos)) { $infos['type'] = ' text'; }
			if($infos['type'] == 'tel') {
				if(!array_key_exists('pattern', $infos)) { $infos['pattern'] = kzContact::TEL_PATTERN; }
				if(!array_key_exists('placeholder', $infos)) { $infos['placeholder'] = '01 23 45 67 89'; }
			}

			$filtered = array_filter(
				$infos,
				function($value, $key) {
					return (!in_array(
						$key,
						array('type', 'required', 'default', 'options', 'large', 'multiple', 'break-before')
					));
				},
				ARRAY_FILTER_USE_BOTH
			);
			$extras = (!empty($filtered)) ? ' '.implode(' ', array_map(
				function($a, $b) { return trim($a).'="'.trim($b).'"'; },
				array_keys($filtered),
				array_values($filtered)
			)) : '';

			$caption = $plxPlugin->getLang('L_'.strtoupper($field));
			echo <<< FIELD_STARTS
							<label for="id_{$field}">$caption</label>\n
FIELD_STARTS;
			$value = (defined('PLX_ADMIN')) ? $plxPlugin->getParam($field) : '';
			if(empty($value) and !empty($infos['default'])) {
				$value = $infos['default'];
			}

			$required = (!empty($infos['required'])) ? ' required' : '';
			switch($infos['type']) {
				case 'textarea':
					echo <<< TEXTAREA
							<textarea id="id_{$field}" name="$field"{$extras}{$required}>$value</textarea>\n
TEXTAREA;
					break;
				case 'select' :
					if(!empty($infos['noKey'])) {
						$options = implode("\n", array_map(function($caption) use($value) {
							$selected = ($caption == $value) ? ' selected' : '';
							return <<< OPTION
								<option$selected>$caption</option>
OPTION;
						}, $infos['options']));
					} else {
						$options = implode("\n", array_map(function($option, $caption) use($value) {
							$selected = ($option == $value) ? ' selected' : '';
							return <<< OPTION
								<option value="$option"$selected>$caption</option>
OPTION;
						}, array_keys($infos['options']), array_values($infos['options'])));
					}
					echo <<< SELECT
							<select name="$field"{$extras}>
$options
							</select>\n
SELECT;
					break;
				case 'checkbox':
					$checked = (!empty($value)) ? ' checked' : '';
					echo <<< CHECKBOX
							<input type="checkbox" id="id_{$field}" name="$field" value="1"{$extras}$checked />\n
CHECKBOX;
					break;
				default:
					$multiple = ($infos['type'] == 'email' and !empty($infos['multiple'])) ? ' multiple' : '';
					echo <<< INPUT
							<input type="{$infos['type']}" id="id_{$field}" name="$field" value="$value"{$extras}{$required}{$multiple} />\n
INPUT;
			}
		}
?>
						</fieldset>
						<div class="kz-contact-footer">
<?php
	if(
		!defined('PLX_ADMIN') and
		!empty($plxPlugin->getParam('capcha')) and
		$this->plxMotor->aConf['capcha']
	) {
		$this->plxMotor->plxCapcha = new plxCapcha(); # Création objet captcha
?>
							<div id="captcha-bloc">
								<?php $this->capchaQ(); ?>
								<input id="id_rep" name="rep" type="text" size="6" maxlength="6" data-type="antispam"/>
							</div>
<?php
	}
?>
							<div <?php if(!empty($inActionBarClassName)) { echo $inActionBarClassName; } ?>>
								<?php echo plxToken::getTokenPostMethod(); ?>

								<input type="submit" />
							</div>
						</div>
					</form>
<!------- end of kzContact plugin --------->
<?php
}
?>

<?php
if(!defined('PLX_ROOT')) {
	header('Content-Type: text/plain; charset=utf-8');
	readfile('hymne-a-la-beaute.txt');
	exit;
}

/**
 * Plugin myContact
 * @author: Bazooka07
 * from plxMyContact written by	Stephane F
 * @lastdate: 2018-02-25
 * */
class kzContact extends plxPlugin {

	const PREFIX_CONTACT = 'form';
	const TEL_PATTERN = '@^(\+33\s+0?|0)[1-9]((?:\s|\.)?\d{2}){4}@';
	/*
	 * +33 1 23 45 67 89
	 * +33 01 23 45 67 89
	 * 01 23 45 67 89
	 * +33 1.23.45.67.89
	 * 01.23.45.67.89
	 * * */

	public $patterns = false;

	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		self::setConfigProfil(PROFIL_ADMIN);

		# déclaration des hooks
		if(function_exists('mail') and !defined('PLX_ADMIN')) {
			self::addHook('plxMotorPreChauffageBegin', 'plxMotorPreChauffageBegin');
			self::addHook('plxMotorDemarrageBegin', 'plxMotorDemarrageBegin');
			self::addHook('plxShowConstruct', 'plxShowConstruct');
			self::addHook('plxShowPageTitle', 'plxShowPageTitle');
			self::addHook('plxShowStaticListEnd', 'plxShowStaticListEnd');
			self::addHook('SitemapStatics', 'SitemapStatics');
		}

	}

	public function getCaption($key) {
		if(array_key_exists($field, $this->aLang)) {
			return strtoupper($this->aLang['$field']);
		} else {
			return preg_replace('@^L_YOUR-@', '', $field);
		}
	}

	private function __filter_values() {
		$filters = array();
		foreach($this->params as $field=>$infos) {
			$type = (!empty($infos['type'])) ? $infos['type'] : 'text';
			switch($type) {
				case 'email' :
					$filter = FILTER_SANITIZE_EMAIL; break;
				case 'number':
				case 'tel':
					$filter = FILTER_SANITIZE_NUMBER_INT; break;
				default:
					$filter = FILTER_SANITIZE_STRING; break;
			}
		}
		if(!empty($filter)) { $filters[$field] = $filter; }
		return filter_input_array(INPUT_POST, $filters);
	}

	/**
	 * Envoie par courriel le POST du formulaire de contact avec
	 * les renseignements sur l'expéditeur fournis par le serveur.
	 * */
	public function sendMessage() {

		$error=false;
		$capcha = $_SESSION['capcha'];
		if (!empty(self::getParam('capcha')) and (empty($capcha) or ($capcha != sha1($inputs['rep'])))) {
			# Erreur de vérification capcha
			return self::getLang('L_ERR_ANTISPAM');
		} elseif(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
			$error = parent::getLang('L_ERR_CONTEXT');
		} else {

			$inputs = $this->__filter_values($patterns);
			if(is_string($inputs)) { return $inputs; }
			# envoi des courriels
			$body = '';
			foreach($inputs as $field=>$value) {
				$sep = (preg_match('@(?:message|subject)$@', $field)) ? " :\n" : ' : ';
				$body .= $this->getCaption($field).$sep.$value."\n";
			}

			$body .= str_repeat('-', 40)."\n";

			foreach(explode(' ', 'HTTP_REFERER REMOTE_ADDR REMOTE_HOST HTTP_USER_AGENT HTTP_ACCEPT_LANGUAGE HTTP_ACCEPT HTTP_ACCEPT_ENCODING') as $field) {
				if(!empty($_SERVER[$field])) {
					$caption = ucfirst(strtr( str_replace('HTTP_', '', $field), '_', '-'));
					$value = filter_input(INPUT_SERVER, $fullname, FILTER_SANITIZE_STRING);
					$body .= "$caption : $value\n";
				}
			}

			if (!empty(self::getParam('envoiSepare'))) {
				$recipients = array_merge(
					explode(',', self::getParam('email')),
					explode(',', self::getParam('email_cc'))
				);
				if (count($recipients) > 1)
					$body .= "\n\n".self::getLang('L_SENT_TO').":\n".implode(', ', $recipients);
				$succes = false;
				foreach(array_merge($recipients, explode(',', self::getParam('email_cc'))) as $to) {
					if (plxUtils::sendMail(
							$name, $mail, trim($to),
							self::getParam('subject'), $body
							)) {
						$success = true;
					}
				}
				if(empty($success))
					return self::getLang('L_ERR_SENDMAIL');
			} else {
				if (!plxUtils::sendMail(
						$name, $mail, self::getParam('email'),
						self::getParam('subject'), $body, 'text',
						self::getParam('email_cc'), self::getParam('email_bcc')
					))
					return self::getLang('L_ERR_SENDMAIL');
			}
		}
		return false; # Pas d'erreur
	}

	/* ==================== Hooks ====================== */

	public function plxMotorPreChauffageBegin() {
		# Le traitement ne s'effectuera que pour l'affichage du formulaire de contact
		$code = <<< 'CODE'
<?php
if(!empty($this->get) and $this->get == '##FORM##') {
	$this->mode = '##MODE##';
	$this->cible = str_repeat('../', substr_count($this->aConf['racine_statiques'], '/')).$this->aConf['racine_plugins'].'##PREFIX##';
	$this->template = '##TEMPLATE##';
	return true;
}
?>
CODE;
		echo strtr($code, array(
			'##FORM##'		=> self::getParam('content'),
			'##MODE##'		=> self::getParam('content'),
			'##PREFIX##'	=> __CLASS__.'/'.self::PREFIX_CONTACT,
			'##TEMPLATE##'	=> self::getParam('template')=='' ? 'static.php' : self::getParam('template')
		));
	}

	public function plxMotorDemarrageBegin() {
		$code = <<< 'CODE'
<?php
if($this->mode == '##MODE##') { return true; }
?>
CODE;
		echo strtr($code, '##MODE##', self::getParam('content'));
	}

	// infos sur la page statique
	public function plxShowConstruct() {

		# dans plxShow::staticContent()
		# $file = PLX_ROOT.$this->plxMotor->aConf['racine_statiques'].$this->plxMotor->cible;
		# $file .= '.'.$this->plxMotor->aStats[ $this->plxMotor->cible ]['url'].'.php';
		# Le traitement ne s'effectuera que pour l'affichage du formulaire de contact
		$code  = <<< 'CODE'
<?php
if($this->plxMotor->mode=='##FORM##') {
	$statique = array(
		$this->plxMotor->cible=>array(
			'name'		=> '##NAME##',
			'url'		=> '##FORM##',
			'active'	=> 1,
			'menu'		=> '',
			'readable'	=> 1
		)
	);
	$this->plxMotor->aStats = array_merge($this->plxMotor->aStats, $statique);
}
?>
CODE;
		# infos sur la page statique
		echo strtr($code, array(
			'##NAME##'	=> addslashes(self::getParam('mnuName')),
			'##FORM##'	=> self::getParam('content')
		));
	}

	/**
	 * Affiche une entrée dans le menu de navigation pour le formulaire de contact.
	 * */
	public function plxShowStaticListEnd() {
		/*
		 * From PlxShow::staticList() :
		 * $format = <<< EOT
		 * 		<li class="#static_class #static_status" id="#static_id" >
		 * 			<a href="#static_url" title="#static_name">#static_name</a>
		 * 		</li>
		 * EOT;
		 * */
		if(!empty(self::getParam('mnuDisplay'))) {
			# ajout au menu pour accéder à la page de contact
			$code = <<< 'CODE'
<?php
	$active = ($this->plxMotor->mode == '##FORM##');
	$entry = strtr($format, array(
			'#static_id'		=> 'static-kz-contact',
			'#static_class'		=> 'static menu',
			'#static_url'		=> $this->plxMotor->urlRewrite('?##FORM##'),
			'#static_name'		=> plxUtils::strCheck('##CAPTION##'),
			'#static_status'	=> ($active) ? 'active':'noactive'
	));
	$group = '##GROUP##';
	$position = ##POSITION##;
	if(!empty($group)) {
		if(array_key_exists($group, $menus)) {
			if($position >= 0 or $position <= count($menus)) {
				array_splice($menus[$group], $position, 0, array($entry));
			} else {
				$menus[$group][] = $entry;
			}
		} else {
			$menus[$group] = array($entry);
		}
		if($active) { $group_active = $group; }
	} else {
		if($position >= 0 or $position <= count($menus)) {
			array_splice($menus, $position, 0, array($entry));
		} else {
			$menus[] = $entry;
		}
	}
?>
CODE;
			echo strtr($code, $replaces = array(
				'##FORM##'		=> self::getParam('content'),
				'##POSITION##'	=> intval(self::getParam('mnuPos')) - 1,
				'##GROUP##'		=> self::getParam('mnuGroup'),
				'##ENTRY##'		=> (!empty($group)) ? "['$group']" : '',
				'##CAPTION##'	=> addslashes(self::getParam('mnuName'))
			));
		}
	}

	/**
	 * Affiche le titre de la page pour le formulaire de contact.
	 * */
	public function plxShowPageTitle() {
		$code = <<< 'CODE'
<?php
if($this->plxMotor->mode == '##FORM##') {
	echo '##TITLE##'.plxUtils::strCheck($this->plxMotor->aConf['title']);
	return true;
}
?>
CODE;
		$title = self::getParam('title_htmltag');
		if (empty($title)) { $title = self::getParam('mnuName'); }
		if (!empty($title)) { $title .= ' - '; }
		echo strtr($code, array(
			'##FORM##'	=> self::getParam('content'),
			'##TITLE##'	=> $title
		));
	}

	public function SitemapStatics() {
		if(!empty(self::getParam('sitemap'))) {
			global $plxMotor;
			$location = $plxMotor->urlRewrite('?'.self::getParam('content'));
?>
		<url>
			<loc><?php echo $location; ?></loc>
			<changefreq>monthly</changefreq>
			<priority>0.8</priority>
		</url>
<?php
		}
	}

}
?>

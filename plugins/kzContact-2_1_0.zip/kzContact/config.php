<?php
if(!defined('PLX_ROOT')) {
	header('Content-Type: text/plain; charset=utf-8');
	readfile('hymne-a-la-beaute.md');
	exit;
}

# Control du token du formulaire
plxToken::validateFormToken($_POST);

# On récupère les templates des pages statiques
$files = plxGlob::getInstance(PLX_ROOT.'themes/'.$plxAdmin->aConf['style']);
if ($array = $files->query('/^static(-\w[\w-]*)?.php$/')) {
	$aTemplates = array();
	foreach($array as $k=>$v)
		$aTemplates[$v] = ucfirst(substr($v, 0, -4));
}

// liste des formulaires disponibles
$prefix = kzContact::PREFIX_CONTACT;
$forms = glob(PLX_PLUGINS."$plugin/{$prefix}.*.php");
$formSelect = array();
foreach ($forms as $f) {
	$value = substr(basename($f, '.php'), strlen($prefix)+1);
	$formSelect[$value] = ucfirst($value);
}

$groups = array('');
foreach($plxAdmin->aStats as $statId=>$infos) {
	$gr = $infos['group'];
	if(!empty($gr) and !in_array($gr, $groups)) {
		$groups[] = $gr;
	}
}
if(count($groups) > 1) {
	$mnuGroup = array(
		'type'		=> 'select',
		'options'	=> $groups,
		'noKey'		=> true
	);
} else {
	$mnuGroup = array('type' => 'text');
}

$params = array(
	'mnuDisplay'	=> array('type' => 'checkbox'),
	'mnuName'		=> array(
		'type' => 'text',
		'default' => $plxPlugin-> getLang('L_DEFAULT_MENU_NAME'),
		'required' => true
	),
	'mnuPos'		=> array(
                'type' => 'number',
		'extras' => array('min' => '0', 'max' => count($plxAdmin->aStats))
        ),
	'mnuGroup'		=> $mnuGroup,
	'sitemap'		=> array('type' => 'checkbox'),
	'title_htmltag'	=> array('type' => 'text', 'break-before' => true),
	'template'		=> array(
		'type' => 'select',
		'default' => 'static.php',
		'options' => $aTemplates
	),
	'content'		=> array(
		'type' => 'select',
		'default' => 'form',
		'options' => $formSelect
	),
	'mnuText'		=> array(
		'type' => 'textarea',
		'default' => $plxPlugin-> getLang('L_MSG_WELCOME')
	),
	'capcha'		=> array('type' => 'checkbox'),
	'subject'		=> array(
		'type' => 'text',
		'default' => $plxPlugin-> getLang('L_DEFAULT_OBJECT'),
		'large' => true,
		'break-before' => true
	),
	'email'			=> array('type' => 'email', 'required' => true),
	'email_cc'		=> array('type' => 'email', 'multiple' => true),
	'email_bcc'		=> array('type' => 'email', 'multiple' => true),
	'envoiSepare'	=> array('type' => 'checkbox'),
	'thankyou'		=> array(
		'type' => 'textarea',
		'default' => $plxPlugin-> getLang('L_DEFAULT_THANKYOU'),
		'break-before' => true
	)
);

// Traitement du $_POST[]
if(!empty($_POST)) {
	$newLocation = "Location: parametres_plugin.php?p=$plugin";
	foreach ($params as $field=>$infos) {
		$paramType = false;
		switch($infos['type']) {
			case 'select':
				$value = trim(filter_input(INPUT_POST, $field, FILTER_SANITIZE_STRING));
				if(
					(!empty($infos['noKey']) and in_array($value, $infos['options'])) or
					array_key_exists($value, $infos['options'])
				) {
					$paramType = 'string';
				} else {
					plxMsg::Error(sprintf($plxPlugin->getLang('L_BAD_VALUE'), $plxPlugin->getLang('L_'.strtoupper($field))));
				}
				break;
			case 'number':
				$value = intVal(filter_input(INPUT_POST, $field, FILTER_SANITIZE_NUMBER_INT));
				$paramType = 'numeric';
				break;
			case 'checkbox':
				if(filter_has_var(INPUT_POST, $field)) {
					$value = intVal(filter_input(INPUT_POST, $field, FILTER_SANITIZE_NUMBER_INT));
					if($value === 1) {
						$paramType = 'numeric';
					} else {
						plxMsg::Error(sprintf($plxPlugin->getLang('L_BAD_VALUE'), $plxPlugin->getLang('L_'.strtoupper($field))));
					}
				} else {
					$value = false;
					$paramType = 'numeric';
				}
				break;
			case 'textarea':
				$value = preg_replace('@(<\?(?:php)?|\?>|https?://|s?ftp://)@i', '', $_POST[$field]);
				$paramType = 'cdata';
				break;
			case 'email':
				if(filter_input(INPUT_POST, $field, FILTER_VALIDATE_EMAIL)) {
					$value = trim(filter_input(INPUT_POST, $field, FILTER_SANITIZE_EMAIL));
					$paramType = 'string';
				}
				break;
			default:
				$value = trim(filter_input(INPUT_POST, $field, FILTER_SANITIZE_STRING));
				$paramType = 'string';
		}
		if(!empty($paramType)) {
			if(empty($value) and array_key_exists('required', $infos)) {
				plxMsg::Error(sprintf($plxPlugin->getLang('L_MISSING_VALUE'), $plxPlugin->getLang('L_'.strtoupper($field))));
				header($newLocation);
				exit;
			} elseif(!empty($value)) {
				$plxPlugin->setParam($field, $value, $paramType);
			} else {
				$plxPlugin->delParam($field);
			}
		}
	}
	$plxPlugin->saveParams();
	header($newLocation);
	exit;
}

// Affichage du formulaire
include 'my-form.inc.php';
?>

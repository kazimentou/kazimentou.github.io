<?php
$params = array(
	'your-name'		=> array('type' => 'text', 'required' => true),
	'your-email'	=> array('type' => 'email'),
	'your-phone'	=> array('type' => 'tel'),
	'your-date'		=> array('type' => 'date'),
	'your-time'		=> array('type' => 'time'),
	'your-repas'	=> array('type' => 'select', 'noKey' => true, 'options' => array(
		'A préciser', 'Privé', 'Affaires', 'Marketing', 'Club sportif', 'entre amis', 'Autre'
	)),
	'your-personns'	=> array('type' => 'number', 'min' => 1, 'max' => 35),
	'your-subject'	=> array('type' => 'text'),
	'your-message'	=> array('type'	=> 'textarea', 'required' => true)
);

include 'my-form.inc.php';
?>

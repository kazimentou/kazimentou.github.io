<?php
$LANG = array(
	'ARTICLE_GALLERY_FOLDER'	=> 'Dossier de photos pour la galerie',
	'LIGHTBOX2_CONFIG'			=> 'Ignorer Lightbox2',
	'LINK_CONFIG'				=> 'Aucun lien vers les images',
	'TITLE_CONFIG'				=> 'Sans titre',
	'ART_HINT'					=> 'Ou bien insérer : &#34;&lt;div data-gallery="mon-voyage/photos/"&gt;souvenirs&lt;/div&gt;&#34; dans le code HTML',
	'PASTE'						=> 'Coller',
	'COPY'						=> 'Copier',
	'GALLERY_NAME'				=> 'Galerie #FOLDER#'
);
?>

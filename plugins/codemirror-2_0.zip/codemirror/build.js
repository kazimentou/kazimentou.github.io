/* Used by r.js for optimize */

({
	name: '../app',
	out: 'main.js',
	baseUrl: './codemirror-5.31.0'
})

<?php
if (!defined('PLX_ROOT')) exit;

// from parametres_users.php
# Tableau des profils
$aProfils = array(
	PROFIL_ADMIN => L_PROFIL_ADMIN,			// can moderate everything
	PROFIL_MANAGER => L_PROFIL_MANAGER,		// can moderate static pages
	PROFIL_MODERATOR => L_PROFIL_MODERATOR, // can moderate comments
	PROFIL_EDITOR => L_PROFIL_EDITOR,		// can moderate categories
	PROFIL_WRITER => L_PROFIL_WRITER		// can moderate only articles
);

# Control du token du formulaire
plxToken::validateFormToken($_POST);

$params = array(
	'skin'=>'string', 'cdn'=>'boolean', 'article'=>'numeric',
	'statique'=>'numeric', 'comment'=>'numeric', 'user'=>'numeric', /* 'parametres_edittpl'=>'numeric', */
	'selector'=>'string',
	'codemirror'=>'numeric', 'codemirror_repo'=>'string', 'styleformats'=>'cdata');
foreach(array_keys($aProfils) as $k) {
	$params['plugins'.$k] = 'string';
}

if (!empty($_POST)) {
	foreach ($params as $field=>$type) {
		if (isset($_POST[$field])) {
			switch ($type) {
				case 'boolean' :
					$value = 1;
					break;
				case 'numeric' :
					$value = array_sum($_POST[$field]);
					break;
				case 'string' :
					if (strpos($field, 'plugins') === 0) {
						$value = implode(' ', $_POST[$field]);
					} else {
						$value = $_POST[$field];
					}
					break;
				default :
					$value = $_POST[$field];
			}
		}
		else
			$value = ($type == 'string') ? '' : 0;
		$plxPlugin->setParam($field, $value, ($type == 'boolean') ? 'numeric' : $type);
	}
	$plxPlugin->saveParams();
	$filename = $plxPlugin->abs_config_filename();
	if ($result = $plxPlugin->create_JS_lib())
		plxMsg::Info(intval($result).' octets écrits dans le fichier '.$filename);
	else
		plxMsg::Error('Impossible d\'écriture le fichier '.$filename);
	header('Location: '.basename($_SERVER['REQUEST_URI']));
	exit;
}
/* *********** display the form ************* */
define('MCE_PROFILS_LABEL', $plxPlugin->getLang('L_'.strtoupper($plugin).'_PROFIL_USERS'));
function print_profils_header($moreClass=false) {
	global $aProfils;
	$className = 'mce-profils-header';
	if (! empty($moreClass)) {
		$className .= ' '.$moreClass;
	} ?>
				<p class="<?php echo $className; ?>">
					<label><?php echo MCE_PROFILS_LABEL; ?></label>
<?php
	foreach ($aProfils as $profil=>$caption) { ?>
					<span title="<?php echo $caption; ?>" data-profil="<?php echo $profil; ?>"><?php echo mb_substr($caption, 0, 3, PLX_CHARSET); ?>.</span>
<?php
	} ?>
				</p>
<?php
}

if (! file_exists(PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.$plugin.'.xml')) {
	$plxPlugin->initValues();
}

$prefix = 'L_'.strtoupper($plugin);
$skins = $plxPlugin->get_skins();
$codemirror_plugin_lib = substr(dirname(__FILE__), 0, -strlen($plugin)).'codemirror/codemirror.min.js';
?>
	<h2 id="plugin-config"><?php echo(L_PLUGINS_CONFIG.': '.$plxPlugin->getInfo('title')); ?></h2>
	<p><i><?php echo $plxPlugin->getInfo('description'); ?></i></p>
	<ul id="mce-config-nav">
		<li><label for="tab1-nav" class="active">Principal</li>
		<li><label for="mce-plugins-nav">Plugins</li>
	</ul>
	<form id="form_<?php echo $plugin; ?>" method="post">
<!-- onglet principal -->
		<input id="tab1-nav" name="tabs" type="radio" checked>
		<div id="tab1">
<?php
foreach ($params as $field=>$type) {

	if (strpos($field, 'plugins') === 0) {
		continue;
	}
	$value = $plxPlugin->getParam($field);
	if ($type == 'numeric')
		$value = intval($value);
	else
		$value = plxUtils::strCheck($value);

	$classLarge = ($field == 'styleformats') ? ' class="large"' : '';
	// Adding titles of columns for users' profil
	if ($field == 'article') {
		print_profils_header('main-tab');
	}
?>
			<p<?php echo (($type == 'numeric') ? ' class="multi"' : ''); ?>>
				<label<?php echo $classLarge; ?>><?php $plxPlugin->lang('L_'.strtoupper($plugin).'_'.strtoupper($field)); ?></label>
<?php
		switch ($type) {
			case 'numeric' : // checkbox for each profil user
				foreach (array_keys($aProfils) as $profil) {
					$checked = (($value & $plxPlugin->weightProfils[$profil]) > 0) ? ' checked' : '';
?>
				<input type="checkbox" name="<?php echo $field.'[]'; ?>" value="<?php echo $plxPlugin->weightProfils[$profil]; ?>"<?php echo $checked; ?> />
<?php			$pass1 = false;
				}
				break;
			case 'boolean' :
				$checked = (empty($value)) ? '' : ' checked'; ?>
				<input id="id_<?php echo $field; ?>" type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
				$filename = dirname(__FILE__).'/'.$plxPlugin->localMinifyLib;
				if ($field == 'cdn') {
					$localLib = $plxPlugin->getLang($prefix.((is_readable($filename) ? '_LIB_FOUND' : '_LIB_MISSING')));
					$download = $plxPlugin->getLang($prefix.'_DOWNLOAD');
					$href = 'https://www.tinymce.com/download/';
					echo <<< MINIFY_LIB
				<i>$localLib</i><sup>**</sup><a href="$href" target="_blank">$download</a>
MINIFY_LIB;
				}
				break;
			case 'cdata' : ?>
				</p>
				<?php plxUtils::printArea($field, $value, 30, 10); ?>
				<p>
<?php
				break;
			default :
				switch ($field) {
					case 'skin' : ?>
				<?php plxUtils::printSelect($field, $plxPlugin->get_skins(), $value);
						break;
					case 'codemirror_repo' : ?>
				<?php plxUtils::printInput($field, $value, 'text', '30-80', false); ?>
<?php					if (is_readable($codemirror_plugin_lib)) { ?>
					<input type="button" value="<?php $plxPlugin->lang('L_TINYMCE_CODEMIRROR_PLUGIN'); ?>" onclick="getCodemirrorPluginLib();" />
<?php						}
						else {
							if (is_readable(dirname(__FILE__).'/extras/plugins/codemirror/codemirror.min.js')) {
								$plxPlugin->lang('L_TINYMCE_CODEMIRROR_LOCAL');
							} else {
								$plxPlugin->lang('L_TINYMCE_CODEMIRROR_MISSING');
							}
						}
						break;
					default : ?>
				<?php plxUtils::printInput($field, $value, 'text', '5-50', false);
						break;
				}
				break;
		}
	}
	?>			</p>
			<p><sup>**</sup><?php $plxPlugin->lang($prefix.'_HELP_DOWNLOAD'); ?></p>
		</div>
<!-- list of plugins for each user profil -->
		<input name="tabs" id="mce-plugins-nav" type="radio">
		<div id="mce-plugins">
			<div>
<?php print_profils_header();
				$mce_plugins = explode(' ', $plxPlugin->mce_pluginsFull);
				$n = intval(count($mce_plugins) / 2 + 0.5);
				$mcePluginsProfils = [];
				foreach (array_keys($aProfils) as $profil) {
					$mcePluginsProfils[] = $plxPlugin->getParam('plugins'.$profil);
				}
				foreach($mce_plugins as $pl) { ?>
					<p class="multi">
						<label title="<?php $plxPlugin->lang(strtoupper('L_'.$plugin.'_PLUGIN_'.$pl));?>"><?php echo $pl; ?></label>
<?php				foreach (array_keys($aProfils) as $profil) {
						$checked = (strpos($mcePluginsProfils[$profil], $pl) === false) ? '' : ' checked';
?>
					<input type="checkbox" name="plugins<?php echo $profil.'[]'; ?>" value="<?php echo $pl; ?>"<?php echo $checked; ?> />
<?php				}
?>
					</p>
<?php				$n--;
					if ($n == 0 ) { ?>
			</div><div>
<?php print_profils_header();
					}
				}
?>
			</div>
		</div>
		<div>
			<p>
				<label>&nbsp;</label>
				<?php echo plxToken::getTokenPostMethod()."\n"; ?>
				<input type="submit" value="<?php echo L_SAVE_FILE; ?>">
			</p>
		</div>
	</form>
	<script type="text/javascript">
		function getCodemirrorPluginLib() {
			var input1 = document.getElementById('id_codemirror_repo');
			if (input1) {
				var path1 = '<?php echo $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].'codemirror/codemirror.min.js'; ?>';
				input1.value = path1;
			} else
				console.log('#id_codemirror_repo element not found');
		}

		function checkAllProfilsClick(event) {
			if (event.target.tagName == 'LABEL') {
				event.preventDefault();
				var target = event.target;
				var row = target.parentNode;
				if (row.classList.contains('multi')) {
					var checkboxes = row.querySelectorAll('input[type="checkbox"]');
					for (i=0, iMax=checkboxes.length; i<iMax; i++) {
						var elm = checkboxes[i];
						elm.checked = ! elm.checked;
					}
				}
			}
		}

		var mainTab = document.getElementById('tab1');
		mainTab.addEventListener('click', checkAllProfilsClick);
		var mcePlugins = document.getElementById('mce-plugins');
		mcePlugins.addEventListener('click', checkAllProfilsClick);

		function profilClick(event) {
			if (event.target.tagName == 'SPAN') {
				event.preventDefault();
				var target = event.target;
				var profil = target.getAttribute('data-profil');
				if (profil) {
					var checkboxes = null;
					if (target.parentNode.classList.contains('main-tab')) {
						var weights = <?php echo json_encode($plxPlugin->weightProfils); ?>;
						checkboxes = document.querySelectorAll('#tab1 .multi input[value="'+weights[profil]+'"]');
					} else {
						checkboxes = mcePlugins.querySelectorAll('input[name="plugins'+profil+'[]"]');
					}
					for (i=0, iMax=checkboxes.length; i<iMax; i++) {
						var elm = checkboxes[i];
						elm.checked = ! elm.checked;
					}
				}
			}
		}

		var profilsCol = document.querySelectorAll('.mce-profils-header');
		for(i=0, iMax=profilsCol.length; i<iMax; i++) {
			profilsCol[i].addEventListener('click', profilClick);
		}
		function tabActive(event) {
			var id1 = event.target.id;
			var labels = document.querySelectorAll('#mce-config-nav label');
			for (i=0, iMax=labels.length; i<iMax; i++) {
				var lbl = labels[i];
				if (lbl.getAttribute('for') == id1) {
					lbl.classList.add('active');
				} else {
					lbl.classList.remove('active');
				}
			}
		}
		var tabs = document.querySelectorAll('input[name="tabs"]');
		for(i=0, iMax=tabs.length; i<iMax; i++) {
			tabs[i].addEventListener('change', tabActive);
		}
	</script>
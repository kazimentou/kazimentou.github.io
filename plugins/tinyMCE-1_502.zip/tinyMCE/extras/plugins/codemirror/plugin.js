/*jshint unused:false */
/*global tinymce:true */

tinymce.PluginManager.requireLangPack('codemirror');

tinymce.PluginManager.add('codemirror', function(editor, url) {

	function showSourceEditor() {

		var id = 'CmCaRet', bookmark = '<span id="'+id+'" style="display: none;">X</span>';
		editor.insertContent(bookmark);

		var isMac = /macintosh|mac os/i.test(navigator.userAgent);
		var helpMe = '\
	<p class="mce-mc-help"><span>'+(isMac ? '&#8984;-F' : 'Ctrl-F')+'</span><span>'+tinymce.translate('Start search')+'</span></p>\
	<p class="mce-mc-help"><span>'+(isMac ? '&#8984;-G' : 'Ctrl-G')+'</span><span>'+tinymce.translate('Find next')+'</span></p>\
	<p class="mce-mc-help"><span>'+(isMac ? '&#8984;-Alt-F' : 'Shift-Ctrl-F')+'</span><span>'+tinymce.translate('Find previous')+'</span></p>\
	<p class="mce-mc-help"><span>'+(isMac ? '&#8984;Alt-G' : 'Shift-Ctrl-G')+'</span><span>'+tinymce.translate('Replace')+'</span></p>\
	<p class="mce-mc-help"><span>'+(isMac ? 'Shift-&#8984;-Alt-F' : 'Shift-Ctrl-R')+'</span><span>'+tinymce.translate('Replace all')+'</span></p>\
';

		// Open editor window
		var fullscreenStatus = false;
		var homePage = (tinyMCE.settings.codemirror.repo) ? '/index.php?repo=1' : '/index.php';
		tinyMCE.settings.codemirror.homePage = homePage;
		var win = editor.windowManager.open({
			title: tinymce.translate('HTML source code'),
			url: url + homePage,
			width: 900,
			height: 600,
			resizable : true,
			maximizable : true,
			buttons: [
				{ text: 'Fullscreen', onclick: function() {
					fullscreenStatus = ! fullscreenStatus;
					win.fullscreen(fullscreenStatus); }
				},
				{ text: 'Help',
					onclick: function() {
						var win1 = editor.windowManager.open({
							title:  tinymce.translate('Shortcuts keyboard'),
							items: [
								{type: 'container', html: helpMe, width: '100%'}
							],
							buttons: [
								{ text: 'Close', onclick: function () { win1.close(); } }
							]
						});
						}
				},
				{ text: 'Cancel', onclick: 'close' },
				{ text: 'Save', subtype: 'primary', onclick: function(){
					var elt = document.querySelector('iframe[src$="'+tinyMCE.settings.codemirror.homePage+'"]');
					elt.contentWindow.submit();
					win.close();
				}}
			]
		},
		{
			id: id, bookmark: bookmark
		});
	};

	// Add a button to the button bar
	editor.addButton('code', {
		title: 'Source code',
		icon: 'code',
		tooltip: tinymce.translate('HTML source code'),
		onclick: showSourceEditor
	});

	// Add a menu item to the tools menu
	editor.addMenuItem('code', {
		icon: 'code',
		text: tinymce.translate('HTML source code'),
		context: 'tools',
		onclick: showSourceEditor
	});
});
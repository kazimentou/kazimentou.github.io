// some parts are from https://github.com/christiaan/tinymce-codemirror

var	codemirror, editor,
	indentOnInit = false,
	cm_config;

function findDepth(haystack, needle) {
	"use strict";

	var idx = haystack.indexOf(needle), depth = 0, x;
	for (x = idx; x >= 0; x--) {
		switch(haystack.charAt(x)) {
			case '<': depth--; break;
			case '>': depth++; break;
		}
	}
	return depth;
}

// This function is called by plugin.js, when user clicks 'Ok' button
function submit() {
	"use strict";

	var cc = '&#x0;',
		isDirty = codemirror.isDirty,
		doc = codemirror.doc;

	if (doc.somethingSelected()) {
		// Clear selection:
		doc.setCursor(doc.getCursor());
	}

	// Insert cursor placeholder (&#x0;)
	doc.replaceSelection(cc);

	var pos = codemirror.getCursor(),
		curLineHTML = doc.getLine(pos.line);

	if (findDepth(curLineHTML, cc) !== 0) {
		// Cursor is inside a <tag>, don't set cursor:
		curLineHTML = curLineHTML.replace(cc, '');
		doc.replaceRange(curLineHTML, CodeMirror.Pos(pos.line, 0), CodeMirror.Pos(pos.line));
	}

	// Submit HTML to TinyMCE:
	editor.setContent(codemirror.getValue().replace(cc, '<span id="CmCaReT"></span>'));
	editor.isNotDirty = !isDirty;
	if (isDirty) {
		editor.nodeChanged();
	}

	// Set cursor:
	var el = editor.dom.select('span#CmCaReT')[0];
	if (el) {
		editor.selection.scrollIntoView(el);
		editor.selection.setCursorLocation(el,0);
		editor.dom.remove(el);
	}
}

var tinymce = null;

function setFullscreen(cm) {
    var wrap = cm.getWrapperElement();
    wrap.style.width = "";
    wrap.style.height = "auto";
    wrap.className += " CodeMirror-fullscreen";
    document.documentElement.style.overflow = "hidden";
    cm.refresh();
}

function launchEditor(event) {
	if (CodeMirror) {

		editor = tinymce.activeEditor;
		var html = editor.getContent();
		cm_config.value = html;
		// Set CodeMirror cursor to same position as cursor was in TinyMCE:
		var params = editor.windowManager.getParams();
		var elts = editor.dom.select('#'+params.id);
		if (elts) {
			editor.dom.remove(elts[0]);
		}

		CodeMirror.defineInitHook(function(inst) {
			// Move cursor to correct position:
			inst.focus();
			var cursor = inst.getSearchCursor(params.bookmark, false);
			if (cursor.findNext()) {
				inst.setCursor(cursor.to());
				cursor.replace('');
			}

			// Indent all code, if so requested:
			if (indentOnInit) {
				var last = inst.lineCount();
				inst.operation(function() {
					for (var i = 0; i < last; ++i) {
						inst.indentLine(i);
					}
				});
			}
		});

		// Instantiante CodeMirror:
		document.body.innerHTML = '';
		codemirror = CodeMirror(document.body, cm_config);
		codemirror.isDirty = false;
		codemirror.on('change', function(inst) {
			inst.isDirty = true;
		});
		setFullscreen(codemirror);
	} else {
		alert('CodeMirror not found');
	}
}

function start() {
	if (window.frameElement) {
		tinymce = window.parent.tinymce;
		if (tinymce) {
			if (tinymce.settings.codemirror.stylesheet.length > 0) {
				var elmt = document.createElement('link');
				elmt.type = 'text/css';
				elmt.rel = 'stylesheet';
				elmt.href = tinymce.settings.codemirror.stylesheet;
				document.head.appendChild(elmt);
			}
			if (tinymce.settings.codemirror.repo.length > 0) {
				var elmt = document.createElement('script');
				elmt.type = 'text/javascript';
				elmt.src = tinymce.settings.codemirror.repo;
				elmt.onload = launchEditor;
				document.head.appendChild(elmt);
			} else {
				launchEditor();
			}
		} else
			alert('Please, use Tinymce editor');
	} else
		alert('You must open this page in an IFRAME window');
}
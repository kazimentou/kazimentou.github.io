git clone --depth 1 https://github.com/bazooka07/prism.git -b gh-pages
git clone --depth 1 https://github.com/PrismJS/prism-themes.git

cd prism
npm install
gulp

cd ../prism-themes
npm install

mkdir css
cp themes/*.css css/
cp ../prism-themes/themes/*.css css/
cd ..
./build-prism-plugins-css.sh

Aller sur le serveur et à la page de config du plugin et télécharger le fichier prism.js à :
http://prismjs.com/download.html?themes=prism-funky&languages=markup+css+clike+javascript+apacheconf+bash+nginx+php+php-extras+python&plugins=line-numbers+autolinker+file-highlight+toolbar+jsonp-highlight+previewer-base+previewer-color+autoloader+normalize-whitespace+data-uri-highlight+show-language+copy-to-clipboard
et enregistrer le à la racine du plugin

Si la liste des plugins est modifiée, relancer
./build-prism-plugins-css.sh

#!/bin/sh

GREEN_COLOR="\033[32m"
YELLOW_COLOR="\033[33m"
NORMAL_COLOR="\033[0m"

CURRENT_PWD=$(pwd)
cd "$(dirname $0)"

PLUGIN_NAME=$(basename $PWD)
VERSION=$(sed '/<version>/!d; s/^\s*<version>\([^<]*\)<\/version>.*$/\1/' infos.xml)
PRISM="${PLUGIN_NAME}/prism/"
PRISM_VERSION="$(jq -r .version prism/package.json)"
cd ..

ZIP_NAME="${CURRENT_PWD}/${PLUGIN_NAME}-$(echo ${VERSION} | sed 's/\./_/g').zip"
echo "

${YELLOW_COLOR}Plugin ${PLUGIN_NAME} : version ${VERSION}
Librairie PrismJS : version ${PRISM_VERSION}
Archive : ${ZIP_NAME}${NORMAL_COLOR}
"

zip -r -o ${ZIP_NAME}  \
	${PLUGIN_NAME}/*.* \
	${PLUGIN_NAME}/css/*.* \
	${PLUGIN_NAME}/lang/*.* \
	${PRISM}/package.json \
	${PRISM}/css/* \
	${PRISM}/css/plugins/* \
	${PRISM}/components/*.min.js \
	${PRISM}/package.json && \
echo "\nNom complet de l'archive du plugin:\n${GREEN_COLOR}${ZIP_NAME}${NORMAL_COLOR}\n"

cd $OLDPWD

echo "Done !"
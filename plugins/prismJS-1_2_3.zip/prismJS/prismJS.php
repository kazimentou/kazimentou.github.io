<?php

if (!defined('PLX_ROOT')) exit;

# http://telechargements.pluxml.org/docs/PluXml_-_Plugins_Guide_du_developpeur.pdf
# http://prismjs.com/

class prismJS extends plxPlugin {

	const PLUGINS_CSS  = '/prism/css/plugins/plugins.css';

	public $plx_plugin_root = PLX_PLUGINS.__CLASS__.'/';

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->setConfigProfil(PROFIL_ADMIN);

		# Ajouts des hooks
		$scriptname = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');

		$this->addHook('plxMotorConstruct', 'plxMotorConstruct');

		if((
			($scriptname == 'parametres_plugin') and
			!empty($_REQUEST['p']) and
			($_REQUEST['p'] == __CLASS__)
		) or (
			($scriptname == 'parametres_help') and
			!empty($_REQUEST['page']) and
			($_REQUEST['page'] == __CLASS__)
		)) {
			if($scriptname == 'parametres_help') {
				$this->addHook('AdminFootEndBody', 'ThemeEndBody');

			}
		}

		/* Ne pas utiliser le hook ThemeEndHead !
		 * A l'enregistrement de la config du plugin, la feuille de style
		 * du thème est fusionnée avec celles des autres plugins.
		 * */
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

/* ------------ Methods for this plugin ------------- */
	public function build_themes() {
		global $plxAdmin;

		$theme = $this->getParam('theme');
		if(!empty($theme)) {
			/* Le thème par défaut prism-default.css a été renonmmé prism.css
			 * depuis la dernière version de Prism.
			 * */
			$theme = '-'.$theme;
		}

		$today = date('c');
		$header = "/* Build by PrismJS::build_themes() on $today. Do not change manually. */\n\n";
		$contents = array(
			'admin'	=> $header,
			'site'	=> $header
		);

		foreach(array_keys($contents) as $f) {
			$contents[$f] .= file_get_contents(__DIR__.'/css/'.$f.'.css')."\n";
		}

		$contents['site'] .= file_get_contents(__DIR__."/prism/css/prism$theme.css")."\n";

		foreach(array_keys($contents) as $f) {
			$contents[$f] .= file_get_contents(__DIR__.$this::PLUGINS_CSS);
		}
		$buf = <<< CSS_BONUS
pre[class*="language"] div.toolbar {
	opacity : 0.3;
}
pre[class*="language"] div.toolbar .toolbar-item {
	margin-right : 1rem;
}

CSS_BONUS;
		foreach(array_keys($contents) as $f) {
			$contents[$f] .= $buf;
			$filename = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.'.$f.'.css';
			if(!plxUtils::write($contents[$f], $filename) or !$plxAdmin->plxPlugins->cssCache($f)) {
				plxMsg::Error(L_SAVE_FILE_ERROR);
			}
		}
	}

	public function getStylesheetsList() {
		return (!empty($this->plx_racine)) ? false : array(
			'css/admin.css',
			'prism/css/plugins/plugins.css'
		);
	}

	private function __checkCacheCss() {
		$filename0 = __DIR__.$this::PLUGINS_CSS;
		if(file_exists($filename0)) {
			$dateRef0 = filectime($filename0);
			$filename1 = preg_replace('@'.__CLASS__.'$@', '', __DIR__).'admin.css'; // cache pour tous les plugins
			$filename2 = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.admin.css'; // cache pour ce plugin
			if(
				!file_exists($filename1) or
				filectime($filename1) < $dateRef0 or
				(file_exists($filename2) and filectime($filename1) < filectime($filename2))
			) {
				plxMsg::Error($this->getLang('OBSOLETE_CSS'));
			}
		}
	}
/* ============= Hooks start here ========================== */

	public function plxMotorConstruct() {
		$code = <<< 'CODE'
<?php
	$prismJS_plugin = $this->plxPlugins->aPlugins['__CLASS__'];
	$prismJS_plugin->plx_racine = $this->racine;
	$prismJS_plugin->plx_plugin_root = $this->racine.$this->aConf['racine_plugins'].'__CLASS__/';
?>
CODE;
		echo str_replace('__CLASS__', __CLASS__, $code);
	}

	public function ThemeEndBody() {

		// Préciser une adresse absolue !
		// PluXml ne prend pas en charge l'attribut data-autoloader-path pour les adresses relatives
		$path = $this->plx_plugin_root.'prism/components/';
		echo <<< THEME_END_BODY
	<script type="text/javascript" src="{$this->plx_plugin_root}clipboard.min.js"></script>
	<script type="text/javascript" src="{$this->plx_plugin_root}prism.js" data-autoloader-path="$path"></script>\n
THEME_END_BODY;
		if(defined('PLX_ADMIN')) {
		/* Uniquement appelé si :
		 *   basename(strtolower($_SERVER['SCRIPT_NAME']),'.php') == 'parametres_help') et
		 *   $_REQUEST['page'] == __CLASS__
		 * L'ordre de chargement des feuilles de style est important !
		 * */
		$theme = $this->getParam('theme');
		$href = $this->plx_plugin_root.'prism/css/';
		$href .= 'prism'.((!empty($theme)) ? '-'.$theme : '');
		$this->__checkCacheCss();
?>
	<script type="text/javascript">
		(function() {
			'use strict';

			const styleSheet = document.createElement('LINK');
			styleSheet.rel = 'stylesheet';
			styleSheet.href = '<?php echo $href; ?>.css';
			const adminCss = document.head.querySelector('link[href$="/plugins/admin.css"]');
			if(adminCss != null) {
				document.head.insertBefore(styleSheet, adminCss);
			} else {
				document.head.appendChild(styleSheet);
			}

			const help = document.querySelector('div.in-action-bar p.prismjs-warning');
			if(help != null) {
				help.style.display = 'none';
			}
		})();
	</script>
<?php
		}
	}

}

?>
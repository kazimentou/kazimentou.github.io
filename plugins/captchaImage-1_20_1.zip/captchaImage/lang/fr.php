<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=>	'Entrez le code de l\'image',
'L_CAPTCHA_ERROR'	=> 'Le code de l\'image est erroné',

);

?>

<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=> 'Enter picture code',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);
?>

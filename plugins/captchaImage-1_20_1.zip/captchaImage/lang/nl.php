<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=>	'Geef de code van de afbeelding',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);

?>

<?php if(!defined('PLX_ROOT')) exit; ?>
<div id="capcha-aide">
	<h3>Principe du plugin</h3>
	<div>Pour lutter contre le spam et les attaques par des robots, le plugin affiche une image contenant un mot de 5 lettres que l'utilisateur doit recopier dans un formulaire ou une page d'authentification.</div>
	<div>
		<h4>Pour Pluxml version 5.4 :</h4>
		Le plugin s'intégre directement dans Pluxml version 5.4 pour les commentaires, la page d'authentification de la zone administrative du site et le plugin officiel plxMyContact.<br />
		Pour les pages HTML contenant un formulaire, voir les remarques ci-dessous.<br />
		Pour plus de confort, ajoutez la règle suivante dans votre feuille de style :<br />
		<code>
			#id_rep {width: 4em; text-align: center;}
		</code>
	</div>
	<div>
		<h4>Pour Pluxml version 5.3 :</h4>
		<p>
			Dans le formulaire à contrôler par le captcha, il faut insérer 2 éléments :
			<ol>
				<li>
					le code <span>&lt;?php $plxShow->capchaQ(); ?&gt;</span> . Lorsque la page web sera appelée par le navigateur, ce code générera un petit message et un lien vers une image à afficher. Celle-ci contiendra un mot que l'utilisateur devra taper au clavier.
				</li>
				<li>
					un champ input pour saisir le mot affiché par l'image : <span>&lt;input id="id_rep" name="rep" type="text" size="5" maxlength="5" /&gt;</span> . Notez bien la valeur de l'attribut name.
				</li>
			</ol>
		</p>
		<p>
			Lorsque l'image ci-dessus sera téléchargée, le plugin fera trois choses :
			<ol>
				<li>
					Le plugin génére un mot aléatoire de 5 caractères en majuscules et chiffres.
					Pour des raisons de lisibilité, certaines caractères trop proches ont été écartés.
				</li>
				<li>
					On génére une copie de ce mot en transformant tout en minuscules et en le chiffrant avec la fonction <span>sha1</span>.
					Le résultat est stocké dans le cookie de session <span>$_SESSION['capcha']</span> et envoyé au navigateur de l'utilisateur (Firefoc, Chrome, ..) par le serveur Web.
				</li>
				<li>
					En même temps, on crée une image contenant le mot initial avec une orientation, une position et une couleur aléatoire pour chaque caractère. Cette image sera appelée par le navigateur et l'utilisateur devra taper au clavier le mot qui s'affiche.
				</li>
			</ol>
		</p>
		<p>
			Avant de traiter la réponse du formulaire, on vérifie que le cookie de session <span>$_COOKIE['capcha']</span> et la valeur du champ de saisie <span>$_POST['rep'] ou $_GET['rep']</span>, selon la méthode du formulaire employée correspondent à un cryptage près :
		</p>
	<pre>
&lt;?php
if ($_SESSION['capcha'] == sha1(strtolower($rep)) {
	# code qui traite la réponse du formulaire
}
else {
	$msg = L_NEWCOMMENT_ERR_ANTISPAM;
	$error = 'error';
}
?&gt;</pre>
		<p>
			Testé sur une version standard de PluXml version 5.3. Vérifiez dans ses futures versions, s'il n'existe pas une function type <span>plxMotor::capchaOk($value)</span> testant la réponse au captcha pour simplifier et rationaliser votre code.
		</p>
	</div>
</div>
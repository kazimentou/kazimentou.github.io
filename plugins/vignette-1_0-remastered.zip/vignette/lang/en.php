<?php
	$LANG = array(
		'L_PATH'		=>	'Thumbnail',
		'L_VIGNETTE_TOGGLER_TITLE' => 'Select a picture file',
		'L_VIGNETTE_FIELD_TITLE'	=>	'Thumbnail picture of the article.',
		'L_CONFIG_TITLE'	=>	'Thumbnail',
		'L_CONFIG_DESCRIPTION'	=>	'Thumbnail plugin configuration',
		'L_CONFIG_DISABLE_AUTO'	=>	'Disable auto integration',
		'L_SAVE'	=>	'Save'
	);
?>

<?php
	$LANG = array(
		'L_PATH'		=>	'Vignette',
		'L_VIGNETTE_TOGGLER_TITLE' => 'Selectionner une image',
		'L_VIGNETTE_FIELD_TITLE'	=>	'Image d\'illustration de l\'article.',
		'L_CONFIG_TITLE'	=>	'Vignette',
		'L_CONFIG_DESCRIPTION'	=>	'Configuration du plugin Vignette',
		'L_CONFIG_DISABLE_AUTO'	=>	'Désactiver l\'intégration automatique',
		'L_SAVE'	=>	'Enregistrer'
	);
?>

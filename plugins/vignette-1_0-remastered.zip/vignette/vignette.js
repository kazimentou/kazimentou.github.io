var myVignette =  {
	
	openPopup : function(fichier,nom,width,height) {
		var left = (screen.width - width) / 2;
		var top = (screen.height - height) / 2;
		var options = '\
directories=no, toolbar=no, menubar=no, location=no, \
resizable=yes, scrollbars=yes, \
width='+width+' , height='+height+', \
left='+left+', top='+top;
		popup = window.open(unescape(fichier) , nom, options);
		if(popup) {
			popup.focus();
		} else {
			alert('Ouverture de la fenêtre bloquée par un anti-popup!');
		}
		return;
	},
	
	initMediasManager: function (windowName, cibleId, urlBase) {
		if (window.name == windowName) {
			this.cibleId = cibleId;
			this.urlBase = urlBase;
			var aside = document.querySelector('body > main > aside');
			aside.style.display = 'none';
			var anchors = document.querySelectorAll('#medias-table tbody td:nth-of-type(3) a');
			for (var i=0, j=anchors.length; i<j; i++) {
				var anchor = anchors.item(i);
				anchor.setAttribute('onclick', "return myVignette.setVignette(this);");
			}
		}
	},
	
	setVignette: function (anchor1) {
		var value = anchor1.href;
		value = value.substr(this.urlBase.length);
		if (confirm('Ajouter vignette \n'+value)) {
			var cible = window.opener.document.getElementById(this.cibleId);
			if (cible) {
				cible.value = value;
				window.close();
			}
			else
				console.log('Element #'+this.cibleId+' introuvable');
		}
		return false;
	}
}

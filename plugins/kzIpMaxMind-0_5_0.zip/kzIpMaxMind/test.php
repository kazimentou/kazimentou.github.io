<?php
if(!empty($_GET['ip']) and (preg_match('@^[1-9]\d{0,2}(?:\.[1-9]\d{0,2}){3}$@', $_GET['ip']))) {
	$ipAddress = $_GET['ip'];
} else {
	$ipAddress = '146.185.223.132';
	#$ipAddress = '90.32.214.153';
}

require_once 'vendor/autoload.php';

use MaxMind\Db\Reader;

$databaseFile = __DIR__.'/GeoIP/GeoLite2-City.mmdb'; # Size: 61M
// $databaseFile = __DIR__.'/GeoIP/GeoLite2-Country.mmdb'; # Size: 3.2M

$reader = new Reader($databaseFile);

header('Content-type: text/plain; charset=utf-8');
echo <<< EOT
Addresse IP: $ipAddress
Données extraites depuis la base locale de http://maxmind.com :

EOT;
print_r($reader->get($ipAddress));

$reader->close();
?>
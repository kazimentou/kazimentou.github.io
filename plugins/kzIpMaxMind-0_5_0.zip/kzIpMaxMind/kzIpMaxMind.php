<?php
if(!defined('PLX_ROOT')) { exit('What did you expect ?'); }

/*
 * Liste de fournisseurs de géo-localisation:
 * https://ahmadawais.com/best-api-geolocating-an-ip-address/
 * */

require_once __DIR__.'/vendor/autoload.php';
use MaxMind\Db\Reader;

/**
 * Affiche des informations de géo-localisation dans la liste des commentaires.
 * Les données sont stockées dans la base de données locale GeoLite2 distribuée par http://maxmind.com.
 * Le chemin d'accès aux images des drapeaux est définie par la constante PLX_FLAGS_32_PATH.
 * Pour connaitre les données de géolocalisation disponibles, afficher le fichier test.php.
 * Voir le fichier NOTES.md
 * Source: http://dev.maxmind.com/geoip/
 * */
class kzIpMaxMind extends plxPlugin {

	const COMMENTS_SELECTOR = '#comments-table:not(.flag) td.ip-address[data-ip]';

	const DATABASE_COUNTRIES_FILENAME = '/GeoIP/GeoLite2-Country.mmdb'; # Must start with '/'. Size: 3.2M
	const DATABASE_CITIES_FILENAME = '/GeoIP/GeoLite2-City.mmdb'; # Must start with '/'. Size: 61M

	# const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT;
	const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE;

	private $IP_list = false;

	public function __construct($default_lang) {
		parent::__construct($default_lang);

		parent::setConfigProfil(PROFIL_ADMIN);

		if(!function_exists('geoip_country_code_by_name')) {
			parent::addHook('AdminCommentsFoot', 'AdminCommentsFoot');
		}
	}

	private function print_license() {
		$title = 'This product includes GeoLite2 data\ncreated by MaxMind, available\nfrom http://www.maxmind.com';
		$src = PLX_PLUGINS.__CLASS__.'/maxmind-logo.svg';
		echo <<< EOT
		const container = document.querySelector('#form_comments div.action-bar');
		if(container != null) {
			const div = document.createElement('DIV');
			div.className = 'maxmind-logo';
			div.innerHTML = 'Géolocalisation<a href="http://www.maxmind.com" rel="noreferrer" target="_blank"><img src="{$src}" alt="MaxMind" title="{$title}" /></a>';
			container.appendChild(div);
		}
EOT;
	}

	public function add_IP($ip) {
		if(empty($this->IP_list)) {
			$this->IP_list = array(
				$ip	=> false
			);
		} elseif(!array_key_exists($ip, $this->IP_list)) {
			$this->IP_list[$ip] = false;
		}
	}

	/**
	 * Extrait les infos de géo-localisation de la base de données pour
	 * les adresses IP collectées dans les commentaires.
	 * */
	private function __getGeoIP() {

		$translations = array(
			'de'	=> 'de',
			'en'	=> 'en',
			'es'	=> 'es',
			'fr'	=> 'fr',
			'it'	=> 'en',
			'nl'	=> 'en',
			'oc'	=> 'fr',
			'pl'	=> 'de',
			'pt'	=> 'pt-BR',
			'ro'	=> 'de',
			'ru'	=> 'ru'
		);
		$lang = $translations[$this->default_lang];
		$reader = new Reader(__DIR__.self::DATABASE_CITIES_FILENAME);
		foreach(array_keys($this->IP_list) as $ip) {
			$record = $reader->get($ip);
			if(!empty($record)) {
				$this->IP_list[$ip] = array(
					'country'	=> array(
						'iso_code'	=> $record['country']['iso_code'],
						'name'		=> $record['country']['names'][$lang]
					)
				);
				if(!empty( $record['location'])) {
					$this->IP_list[$ip]['location'] = array(
						'latitude'	=> $record['location']['latitude'],
						'longitude'	=> $record['location']['longitude']
					);
				}
				if(!empty($record['city']['names'][$lang])) {
					$this->IP_list[$ip]['city'] = $record['city']['names'][$lang];
				}
				if(!empty($record['postal']['code'])) {
					$this->IP_list[$ip]['zipcode'] = $record['postal']['code'];
				}
				if(!empty($record['location']['time_zone'])) {
					$this->IP_list[$ip]['location']['time_zone'] = $record['location']['time_zone'];
				}
			}
		}
		$reader->close();
	}

	private function __print_ipList() {
		switch(self::getParam('service')) {
			case 'local':
?>


			printFlags();
<?php
				# Building of a small snippet of javascript
				break;
		}
	}

	/**
	 * Insère un script Javascript dans la page générée pour afficher les images
	 * de drapeaux en fonction de l'adresse IP du visiteur.
	 *
	 * Le paramètre "service" du plugin définit la source des informations
	 * de géo-localisation.
	 * */
	public function set_flags($cssSelector) {
		if(empty($this->IP_list)) { return; }

		self::__getGeoIP();
?>
<script type="text/javascript">
	(function() {
		const cells = document.body.querySelectorAll('<?php echo $cssSelector; ?>');

		if(cells.length > 0) {
			const ipList = JSON.parse('<?php echo json_encode($this->IP_list, SELF::JSON_OPTIONS); ?>');

			function printFlags() {
				if(ipList != null) {
					for(var i=0, iMax=cells.length; i<iMax; i++) {
						const cell = cells[i];
						const ip = cell.getAttribute('data-ip');

						if(typeof ipList[ip] != 'undefined') {
							const iso_code = ipList[ip].country.iso_code;
							const caption = (typeof ipList[ip].city !== 'undefined') ? [ipList[ip].city, ipList[ip].country.name].join('<br />') : ipList[ip].country.name;
							const flag = document.createElement('IMG');
							flag.src = '<?php echo PLX_FLAGS_32_PATH; ?>' + iso_code + '.png';
							flag.className = 'flag';
							flag.alt = iso_code;
							flag.title = caption;
							cell.appendChild(document.createElement('BR'));
							cell.appendChild(flag);
							const span = document.createElement('SPAN');
							span.innerHTML = caption;
							cell.appendChild(document.createElement('BR'));
							cell.appendChild(span);
						}
					}
				}
			}

			printFlags();
<?php self::print_license(); ?>
		}
	})();
</script>
<?php
	}

	/**
	 * Renvoie le code ISO d'un pays en fonction d'une adresse IP.
	 * */
	public function get_country($ipAddr) {
		$reader = new Reader(__DIR__.self::DATABASE_COUNTRIES_FILENAME);
		$record = $reader->get($ipAddr);
		return $record['country']['iso_code'];
	}

	/* --------- Hooks ------------- */
	public function AdminCommentsFoot() {
		$code = <<< 'CODE'
<?php
foreach($plxAdmin->plxRecord_coms->result as $com) {
	$plxAdmin->plxPlugins->aPlugins['##CLASS##']->add_IP($com['ip']);
}
$plxAdmin->plxPlugins->aPlugins['##CLASS##']->set_flags('##CSS_SELECTOR##');
?>

CODE;
		$replaces = array(
			'##CLASS##'	=> __CLASS__,
			'##CSS_SELECTOR##'	=> self::COMMENTS_SELECTOR
		);
		echo str_replace(array_keys($replaces), array_values($replaces), $code);
	}

}
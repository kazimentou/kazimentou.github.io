# Under Ubuntu:
sudo apt-add-repository ppa:maxmind/ppa
sudo apt update
sudo apt install geoipupdate

wget -O GeoIP.conf https://raw.githubusercontent.com/maxmind/geoipupdate/master/conf/GeoIP.conf.default
echo "DatabaseDirectory ./GeoIP" >> GeoIP.conf

# Be patient. That's take a while
geoipupdate -f GeoIP.conf

composer init
composer require maxmind-db/reader
composer install

<?php

# http://telechargements.pluxml.org/docs/PluXml_-_Plugins_Guide_du_developpeur.pdf

if (!defined('PLX_ROOT')) { exit; }

class users_csv extends plxPlugin {

	const DEFAULT_PASSWORD = 'PluXml';

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		if(defined('PLX_ADMIN')) {
			# parent::setConfigProfil(PROFIL_ADMIN);

			# Accès au menu admin réservé au profil administrateur
			parent::setAdminProfil(PROFIL_ADMIN);

			# Personnalisation du menu admin
			parent::setAdminMenu(parent::getLang('MENU_NAME'), 0, parent::getLang('MENU_TITLE'));

			# Ajouts des hooks
			parent::addHook('AdminUsersFoot', 'AdminUsersFoot'); # formulaire saisie multi_users
			parent::addHook('AdminUsersTop', 'AdminUsersTop');
			parent::addHook('plxAdminEditUsersUpdate', 'plxAdminEditUsersUpdate');
		}
	}

	public function printForm($admin=false) {
		$phpScript = glob(__DIR__.'/{admin,xxxx*}.php', GLOB_BRACE)[0];
		$signature = md5(filemtime($phpScript));
		$action = (!$admin) ? ' action="'.PLX_PLUGINS.__CLASS__.'/'.basename($phpScript).'"' : '';

		if(! empty($_SESSION[__CLASS__]['warning'])) {
			$warning = <<< WARNING
		<p>{$_SESSION[__CLASS__]['warning']}</p>\n
WARNING;
			unset($_SESSION[__CLASS__]['warning']);
		}

		$minify = (is_readable(__DIR__.'/'.__CLASS__.'.min.js')) ? '.min' : '';
		$scriptname = PLX_PLUGINS.__CLASS__.'/'.__CLASS__.$minify.'.js';
?>
	<div id="div_users-csv">
		<h3 title="<?php $this->lang('MENU_TITLE'); ?>"><?php $this->lang('MENU_NAME'); ?> <span>( with <?php echo __CLASS__; ?> plugin )</span></h3>
		<form id="form_users-csv" method="POST" class="inline-form" enctype="multipart/form-data"<?php echo $action; ?>>
			<div>
				<label for="id_separator"><?php $this->lang('SEPARATOR')?></label>
				<select id="id_separator" name="separator">
					<option value=",">,</option>
					<option value=";" selected>;</option>
					<option value="tab"><?php $this->lang('TABULATION'); ?></option>
					<option value=" "><?php $this->lang('SPACE'); ?></option>
				</select>
				<label for="id_enclosure"><?php $this->lang('ENCLOSURE')?></label>
				<select id="id_enclosure" name="enclosure">
					<option value=""><?php $this->lang('EMPTY'); ?></option>
					<option value="&quot;" selected>&quot;</option>
					<option value="'">'</option>
				</select>
			</div><div class="expand-flex">
				<input type="hidden" name="users-csv-token" value="<?php echo $signature; ?>">
				<input id="users-csv-file" name="users-csv-file" type="file" accept=".csv" required />
				<input type="submit" id="users-csv-import-btn" value="<?php $this->lang('IMPORT'); ?>" disabled />
				<input type="button" id="users-csv-preview-btn" value="<?php $this->lang('PREVIEW'); ?>" disabled />
			</div>
<?php
			if(!$admin) {
?>
			<div class="in-action-bar">
				<input type="submit" id="users-csv-export" name="users-csv-export" value="<?php $this->lang('EXPORT'); ?>">
			</div>
<?php
			}
?>
		</form>
		<p><?php echo str_replace('##PASSWORD##', self::DEFAULT_PASSWORD, $this->getLang('PASSWORD')); ?></p>
		<div id="users-csv-preview" class="hide">
			<table>
			</table>
			<p><input type="button" value="<?php $this->lang('CLOSE'); ?>" /></p>
		</div>
	</div>
<?php if(!empty($warning)) { echo $warning; } ?>
	<script type="text/javascript" src="<?php echo $scriptname; ?>"></script>
<?php
	}

/* =========== Hooks ================== */

	public function AdminUsersTop() {
		ob_start();
	}

	public function AdminUsersFoot() {
		echo <<< 'CODE'
<?php
	$replaces = array(
		'@(<tr(?:\s+\w+="[^"]*")*\s+class="new"(?:\s+\w+="[^"]*")*>\s*<td(?:\s+\w+="[^"]*")*\s+colspan="2">)([^<]*)(</td>)@' => '\1<button id="newUser" type="button" disabled>\2</button>\3'
	);
	echo preg_replace(array_keys($replaces), array_values($replaces), ob_get_clean());
?>
CODE;
		$this->printForm();
	}

	public function plxAdminEditUsersUpdate() {
		echo <<< 'EOT'
<?php
foreach(explode(' ', 'lang email infos') as $csv_fld) {
	if(!empty($content[$user_id.'_'.$csv_fld])) {
		$this->aUsers[$user_id][$csv_fld] = $content[$user_id.'_'.$csv_fld];
	}
}
?>
EOT;
	}

}
?>

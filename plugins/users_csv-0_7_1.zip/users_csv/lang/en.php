<?php
	$LANG = array(
		'MENU_NAME'			=> 'Import users',
		'MENU_TITLE'		=> 'Import or export a list of users from a CSV file',
		'MESSAGE'			=> '##COUNT## new or updated users',
		'LOGIN_REQUIRED'	=> 'the login field is required',
		'PASSWORD'			=> 'for a new user, if the password is empty, the default value will be : <strong>##PASSWORD##</strong>.',
		'SEPARATOR'			=> 'fiedl separator',
		'ENCLOSURE'			=> 'enclosure for texts',
		'SPACE'				=> 'space',
		'TABULATION'		=> 'tabulation',
		'EMPTY'				=> 'without',
		'PREVIEW'			=> 'Preview',
		'CLOSE'				=> 'Close',
		'IMPORT'			=> 'Import',
		'EXPORT'			=> 'Export'
	);
?>

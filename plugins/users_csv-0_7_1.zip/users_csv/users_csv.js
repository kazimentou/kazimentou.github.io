/*
 * This is a part of the users_csv plugin for using with PluXml cms
 * author: Jean-Pierre Pourrez aka bazooka07
 * date: 2017-03-15
 * updated: 2018-04-18
 *
 * */

(function(idTable, idSelection) {

	/* add one row at the end of the table on each click */

	'use strict';
	const usersTable = document.getElementById(idTable);
	if(usersTable != null) {
		const
			lastRow = usersTable.rows[usersTable.rows.length - 1],
			input1 = lastRow.querySelector('input[name="userNum[]"]');
		if(input1 != null) {

			const newUserInputs = lastRow.querySelectorAll('input[type="text"], input[type="password"]');
			const newUserBtn = lastRow.cells[0].querySelector('button');
			const LAST_ID = parseInt(input1.value);

			var
				// update id users for every last row
				setIdNewUsers = function() {
					const newRows = usersTable.querySelectorAll('tr.users-csv');
					var newId = LAST_ID;

					for(var i=0, iMax=newRows.length; i<iMax; i++) {
						const
							row = newRows.item(i),
							newIdStr = ('00' + newId.toString()).substr(-3);
						if(!row.classList.contains('new')) {
							row.cells[1].innerHTML = newIdStr;
						}
						// Overwriting innerHTML loses events and changed values !
						const elements = row.querySelectorAll('input, select');
						for(var j=0, jMax=elements.length; j<jMax; j++) {
							const elmnt = elements.item(j);
							if(elmnt.name == 'userNum[]') {
								elmnt.value = newIdStr;
							}
							if(elmnt.hasAttribute('id')) {
								elmnt.id = elmnt.id.replace(/\d{3}_/, newIdStr+'_');
							}
							if(elmnt.hasAttribute('name')) {
								elmnt.name = elmnt.name.replace(/\d{3}_/, newIdStr+'_');
							}
						}
						newId++;
					}
				},

				deleteRow = function(event) {
					if(confirm(lastRow.deleteTitle)) {
						var
							row = this.parentElement,
							parent = row.parentElement;
						parent.removeChild(row);
						setIdNewUsers();
					}
				},

				// callback function when user clicks on the "new user" button
				addNewRow = function(event) {

					// the event is attached to the last row in the users table
					event.preventDefault();

					// this is the last row of the table
					// Add a new row in the users table before this and drop colspan="2" attribute
					const
						parent = lastRow.parentElement,
						newRow = document.createElement('TR'),
						td = document.createElement('TD');
					var oldCell0;
					newRow.innerHTML = lastRow.innerHTML;
					newRow.className = 'users-csv';
					td.innerHTML = '<span class="delete-row" title="' + this.deleteTitle + '">&cross;</span>';
					parent.insertBefore(newRow, lastRow);
					const inputs = lastRow.querySelectorAll('input[type="text"], input[type="password"], input[type="email"], select');
					for(var i=0, iMax=inputs.length; i<iMax; i++) {
						const tag = inputs[i].tagName.toLowerCase();
						const el = newRow.querySelector(tag + '[name="' + inputs[i].name + '"]');
						if(el != null) {
							el.value = inputs[i].value;
							if(tag != 'select') {
								inputs[i].value = null;
								if(inputs[i].type == 'password') {
									inputs[i].style = '';
								}
							} else {
								const select = inputs[i];
								select.selectedIndex = select.options.length - 1;
							}
						}
					}
					oldCell0 = newRow.cells[0];
					oldCell0.innerHTML = '000';
					oldCell0.removeAttribute('colSpan');
					newRow.insertBefore(td, oldCell0);
					td.addEventListener('click', deleteRow);
					setIdNewUsers();

				},

				enableNewUser = function(event) {
					event.preventDefault();
					for(var i=0, iMax=newUserInputs.length; i<iMax; i++) {
						if(newUserInputs[i].value.trim().length == 0) {
							return;
						}
					}
					newUserBtn.disabled = false;
				};

			if(newUserBtn != null) {
				newUserBtn.addEventListener('click', addNewRow);
				if(newUserInputs != null) {
					for(var i=0, iMax=newUserInputs.length; i<iMax; i++) {
						newUserInputs[i].addEventListener('change', enableNewUser);
					}
				}
				lastRow.classList.add('users-csv'); // required for updating id new-users
				lastRow.table = usersTable;
				const deleteOption = document.querySelector('#' + idSelection+ ' option[value="delete"]');
				lastRow.deleteTitle = (deleteOption != null) ? deleteOption.textContent : 'delete';
			}
		}
	}

})('users-table', 'id_selection');

(function(idButton, idInputFile) {

	/* export every user into a .CSV file */

	'use strict';
	const btn = document.getElementById(idButton);
	if(btn != null) {

		var
			idTimer = null,
			restore = function() {
				btn.inputFile.removeAttribute('disabled');
				if(typeof(idTimer) == 'number') {
					console.log(idTimer);
					clearTimeout(idTimer);
				}
			};

		const inputFile = document.getElementById(idInputFile);
		if(inputFile != null) {
			btn.inputFile = inputFile;
			btn.addEventListener('click', function(event) {
				if(typeof(this.inputFile) == 'object') {
					this.inputFile.setAttribute('disabled', true);
					// downloading file attachment is running outside Javascript, So, fire a timer to return at initial state
					idTimer = setTimeout(restore, 2000);
				}
			});
		}
	}

})('users-csv-export', 'users-csv-file');

(function(idPreviewBtn, idInputFile, idLayer, idImportBtn) {
	/* create preview for the import csv file */

	'use strict';

	var
		previewBtn = document.getElementById(idPreviewBtn),
		importBtn = document.getElementById(idImportBtn),
		input = document.getElementById(idInputFile),
		layer = document.getElementById(idLayer),
		csvToArray = function(text, options) {
			var
				defaultOptions = {
			        'fSep': ',',
			        'quot': '"',
			        'head': false,
			        'trim': false
				};

			if(typeof(options) == 'undefined') {
				options = defaultOptions;
			} else {
				for(var key in defaultOptions) {
					if(! key in options) {
						options[key] = defaultOptions[key];
					}
				}
			}
			var
				result = [];

			text.split(/\r\n|\r|\n/).forEach(function(row) {
				if((row.trim().length > 0) && (row.charAt(0) != '#')) {
					var
						insideQuotes = false,
						cell = [],
						line = [],
						addCell = function(line, cell) {
							var buf = (options.trim) ? cell.join('').trim() : cell.join('');
							line.push(buf);
						};
					row.split('').forEach(function(char) {
						switch(char) {
							case options.quot:
								insideQuotes = !insideQuotes;
								break;
							case options.fSep:
								if(! insideQuotes) {
									addCell(line, cell);
									cell = [];
									break;
								}
							default:
								cell.push(char);
						}
					});
					addCell(line, cell);
					result.push(line);
				}
			});
			return result;
		};

	if((previewBtn != null) && (input != null) && (layer != null)) {

		const closeBtn = layer.querySelector('input[type="button"]');
		if(closeBtn != null) {

			closeBtn.layer = layer;
			closeBtn.addEventListener('click', function(event) {
				this.layer.classList.add('hide');
			});

			previewBtn.form.layer = layer;
			previewBtn.addEventListener('click', function(event) {
				var reader = new FileReader;
				reader.form = this.form;
				reader.addEventListener('load', function(event) {
					var table = this.form.layer.querySelector('table');
					if(table != null) {
						var
							buf = event.target.result,
							datas = csvToArray(buf, {
								fSep: this.form.elements['separator'].value,
								quot: this.form.elements['enclosure'].value
							}),
							head = '<th>'+datas[0].join('</th>\n<th>')+'</th>\n',
							rows = [];
						// limit display at first 10 lines
						datas.slice(1,11).forEach(function(cells) {
							rows.push('<td>'+cells.join('</td>\n<td>')+'</td>\n');
						});
						table.innerHTML =
							'<thead><tr>' + head + '</tr></thead>' +
							'<tbody><tr>' + rows.join('</tr><tr>\n') + '</tr></tbody>';
						this.form.layer.classList.add('display');
					}
				});
				var file = this.form.elements['users-csv-file'].files[0];
				if(file) {
					reader.readAsText(file);
					this.form.layer.classList.remove('hide');
				}
			});

			input.previewBtn = previewBtn;
			input.importBtn = importBtn;
			input.addEventListener('change', function(event) {
				this.previewBtn.removeAttribute('disabled');
				this.importBtn.removeAttribute('disabled');
			});

		}
	}
})('users-csv-preview-btn', 'users-csv-file', 'users-csv-preview', 'users-csv-import-btn');

(function(idForm) {

	'use strict';
	if(typeof(sessionStorage) == 'object') {
		const form = document.getElementById(idForm);
		if(form != null) {

			var
				store = function(event) {
					sessionStorage.setItem(event.target.name, event.target.value);
				},

				setSelected = function(select, value) {
					if(value != null) {
						for(var i=0, iMax=select.options.length; i<iMax; i++) {
							if(select.options[i].value == value) {
								select.selectedIndex = i;
								break;
							}
						}
					}
				},

				selects = form.querySelectorAll('select');

			if(selects.length > 0) {
				for(var i=0, iMax=selects.length; i<iMax; i++) {
					const item = selects.item(i);
					setSelected(item, sessionStorage.getItem(item.name));
					item.addEventListener('change', store);
				}
			}

		}
	}
})('form_users-csv');

function csv_onclick() {
	var element = document.getElementById('');
	alert('Ok');
	return true;
}

function computeLink(aForm) {
	/*
	folder
	documents
	skip_lines
	repeat_col
	cols_group
	format_cell
	* */
	aForm['link'].value =
		'<p><a href="'+aForm['documents'].value+'/monfichier.cvs"'+
		' rel="list('+
		aForm['skip_lines'].value+','+
		aForm['repeat_col'].value+','+
		aForm['cols_group'].value+','+
		aForm['format_cell'].value+','+
		aForm['folder'].value+')">'+
		'Title'+
		'</a></p>';
}

<?php if(!defined('PLX_ROOT')) exit; ?>
<h2>Aide</h2>
<div id="csv2table-help">
	<p>
		Ce plugin permet d'afficher un tableau dans les pages statiques à partir des données contenues dans un fichier type CSV, généralement créé par un tableur comme Calc, Excel ou Google Docs.
	</p>
	<h3>Principe du plugin <?php echo $plugin; ?></h3>
	<p>
		On compare une expression régulière à tous les attributs href des balises de liens &lt;a href="data/documents/liste.csv"&gt;Mon fichier CSV&lt;/a&gt;. En cas de succès, on attend un fichier type CSV (<i>comma separated values</i>) qui sera transformé en table HTML.
	</p>
	<p>
		En complément, une feuille de style CSS permet d'alterner les couleurs entre les lignes paires et impaires. De plus, un script javascript permet de trier les rangées en cliquant sur un titre de colonne.
	</p>
	<p>
		Les fichiers peuvent être stockés sur le serveur qui héberge votre site, ou bien sur sur un serveur distant si votre type d'hébergement le permet.
	</p>
	<p>
		Le plugin est paramétré pour reconnaitre des fichiers hébergés sur Google Docs et Dropbox.
	</p>
	<p>
		Si vous avez de solides connaissances en expressions régulières, vous pouvez ajouter une expression pour un autre site.
	</p>
	<p>
		Dans le cas de Google Docs, il faut aller dans le menu Fichier/Publier sur le Web, sélectionner une feuille, sélectionner un lien pour publier au format CSV et cocher republier automatiquement. Recopier le lien obtenu dans le contenu de votre page statique. Les mises à jour de votre tableau dans Google Docs se retrouveront automatiquement sur votre site.
	</p>
</div>

<?php
$LANG = array(
# name fields
'L_CSV_DELIMITER'		=> 'Séparateur de champs',
'L_CSV_ENCLOSURE'		=> 'caractères d\'encadrement des chaînes de texte',
'L_CSV_ESCAPE'			=> 'caractère d\'échappement',
'L_CSV_LOCAL'			=> 'Rechercher des fichiers dans le dossier Documents',
'L_CSV_GOOGLE'			=> 'Rechercher des fichiers de Google Docs',
'L_CSV_DROPBOX'			=> 'Rechercher des fichiers de Dropbox',
'L_CSV_OTHER_FILTER'	=> 'Expression régulière pour un autre site (href dans la balise &lt;a&gt;)',
'L_CSV_DEBUG'			=> 'Affiche un compte-rendu en cas d\'échec de Curl()',
'L_CSV_ADVANCED_EDITION'=> 'Edition avancée',
'L_CSV_FOLDER'			=> 'Dossier photos',
'L_CSV_DOCUMENTS'		=> 'Dossier documents',
'L_CSV_SKIP_LINES'		=> 'Sauter les n premières lignes, n =',
'L_CSV_REPEAT_COL'		=> 'Groupe de n colonnes se répétant à partir de la colonne, n =',
'L_CSV_COLS_GROUP'		=> 'Nombre de colonnes par groupe',
'L_CSV_FORMAT_CELL'		=> 'Format d\'édition pour chaque cellule ( <i>séparé par \'|\'</i> )',
'L_CSV_LINK'			=> 'Lien à copier dans la page statique.<br />( <i>Remplacer monfichier par le nom de votre fichier</i> )',
'L_CSV_WARNING'			=> 'Selon le type d\'hébergement de votre site, en particulier en cas d\'hébergement mutualisé ou gratuit, le téléchargement de fichiers depuis d\'autres sites peut être bloqué pour des raisons de sécurité.<br />Dans ce cas, seul l\'utilisation de fichiers CSV depuis votre site sera possible.'
);
?>

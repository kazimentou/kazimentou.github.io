<?php
if(!defined('PLX_ROOT')) { exit; }

/**
 * Assure le suivi des commentaires par courriel pour l'auteur et les visiteurs.
 *
 * Dans le courrier figurent le titre et l'URL de l'article.
 *
 * Dans chaque courriel à destination des visiteurs, un lien de désabonnement
 * est fourni, comprenant numéro d'article, mail et nom sous forme cryptée.
 * La liste des visiteurs abonnés est stockée au format JSON dans le dossier de
 * configuration des plugins.
 * */
class kzMailCommentAlert extends plxPlugin {

	const CODE_ADD_COMMENT = <<< 'CODE'
<?php
if(
	!empty($_POST['subscribe']) and
	$_POST['subscribe'] === '1'
) {
	$this->plxPlugins->aPlugins['kzMailCommentAlert']->newFollower = array(
		'author'	=> $content['author'],
		'mail'		=> $content['mail']
	);
}
	return false; # must to be continued
?>
CODE;

	const CODE_NEW_COMMENT = <<< 'CODE'
<?php
if(($retour[0] == 'c') or ($retour == 'mod')) {
	$this->plxPlugins->aPlugins['kzMailCommentAlert']->alertMail(
		$this,
		($retour[0] == 'c')
	);
}
?>
CODE;
	const CODE_THEME_END_BODY = <<< 'CODE'
<?php
	$content = <<< CONTENT
</textarea>
		<input type="checkbox" name="subscribe" value="1" id="id_subscribe" disabled />
		<label for="id_subscribe">##SUBSCRIBE##</label>\n
CONTENT;
	$output = str_replace('</textarea>', $content, $output);
	$mail_mask = '@(<input\s+[^>]*name=(?:"mail"|\'mail\')[^>]*>)@';
	if(preg_match($mail_mask, $output, $matches)) {
		$replace = preg_replace('@type=(?:"text"|\'text\')@', 'type="email"', $matches[1]);
		$output = preg_replace($mail_mask, $replace, $output);
	}
?>
	<script type="text/javascript"> <!-- kzMailCommentAlert -->
		(function() {
			'use strict';

			const el = document.body.querySelector('form input[type="email"]');
			if(el != null) {
				el.addEventListener('change', function(event) {
					const chk = document.body.querySelector('form input[type="checkbox"][name="subscribe"]')
					chk.disabled = !event.target.checkValidity();
					if(chk.disabled) { chk.checked = false; }
					event.preventDefault();
				})
			}
		})();
	</script>

CODE;

	public $newFollower = false;

	public function __construct($default_lang) {

		parent::__construct($default_lang);

		parent::setConfigProfil(PROFIL_ADMIN);

		# For unsubscribing
		parent::addHook('IndexBegin', 'IndexBegin');

		if(
			!empty(parent::getParam('recipients')) and
			!empty(parent::getParam('from')) and
			function_exists('mail')
		) {
			parent::addHook('ThemeEndBody', 'ThemeEndBody');
			parent::addHook('plxMotorDemarrageNewCommentaire', 'plxMotorDemarrageNewCommentaire');
			parent::addHook('plxMotorAddCommentaire', 'plxMotorAddCommentaire');
			$this->data_filename = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.json';
		}
	}

	/**
	 * Collects the list of followers 's mail for this article.
	 * Returns an array. May be empty.
	 * */
	private function __getFollowers($artId=false) {
		if(file_exists($this->data_filename)) {
			$followers = json_decode(file_get_contents($this->data_filename), true);
			if(!empty($artId)) {
				return (array_key_exists($artId, $followers)) ? $followers[$artId] : false;
			} else {
				return $followers;
			}
		} else {
			return array();
		}
	}

	private function __updateFollower($artId, $author, $mail, $delete=false) {
		$followers = $this->__getFollowers();
		if(!array_key_exists($artId, $followers)) {
			$followers[$artId] = array();
		}
		if(!array_key_exists($mail, $followers[$artId])) {
			if($delete) {
				unset($followers[$artId][$mail]);
			} else {
				$followers[$artId][$mail] = $author;
			}
			$content = json_encode($followers, JSON_UNESCAPED_UNICODE + JSON_UNESCAPED_SLASHES + JSON_PRETTY_PRINT);
			file_put_contents($this->data_filename, $content);
		}
	}

	private function __get_key_encryption() {
		return sha1(date('ldSaF', filectime(__FILE__)));
	}

	/**
	 * Sends mail to the author, and perhaps to the administrator.
	 * Also, to the followers if the comment is published.
	 * */
	public function alertMail(&$plxMotor, $published) {
		$record_arts = $plxMotor->plxRecord_arts;
		$artId = $record_arts->f('numero');

		$recipients = explode(',', parent::getParam('recipients'));

		$replaces = array(
			'##ART_TITLE##'	=> $record_arts->f('title'),
			'##ART_URL##'	=> $record_arts->f('url')
		);

		$name		= 'Webmaster';
		$from		= parent::getParam('from');
		$subject	= sprintf($this->getLang('MSG_SUBJECT'), $plxMotor->aConf['title']); # title of the site
		$cc			= (
			in_array('admin', $recipients) and
			!empty($plxMotor->aUsers['001']['email'])
		) ? $plxMotor->aUsers['001']['email'] : false;

		# checks if the author of article has a mail
		if(!empty($plxMotor->aUsers[$record_arts->f('author')]['email'])) {
			$to = $plxMotor->aUsers[$record_arts->f('author')]['email'];
		} else {
			$to = $cc;
			$cc = false;
		}
		if(!empty($to)) {
			$body = str_replace(
				array_keys($replaces),
				array_values($replaces),
				$this->getLang('MSG_CONTENT_AUTHOR')
			);
		}

		if(plxUtils::sendMail($name, $from, $to, $subject, $body, 'html', $cc)) {
			if($published) {
				# checks if we have followers
				$followers = self::__getFollowers($artId);
				if(!empty($followers)) {
					$replaces['##COMMENT_LINK_URL##'] = '';
					$key = self::__get_key_encryption();
					foreach($followers as $email=>$name) {
						$replaces['##NAME##'] = $name;
						$replaces['##UNSUBSCRIBE_URL##'] = mcrypt_encrypt(MCRYPT_BLOWFISH, $key, implode('|', array($artId, $to, $name)));
						$body = str_replace(array_keys($replaces), array_value($replaces), $this->getLang('MSG_CONTENT_FOLLOWERS'));
						if(!plxUtils::sendMail($name, $from, $email, $subject, $body, 'html')) {
							# echec à l'envoi
						}
					}
				}

				if(!empty($this->newFollower)) {
					self::__updateFollower(
						$artId,
						$this->newFollower['author'],
						$this->newFollower['mail']
					);
				}
			}
		}
	}

/* -------------- Hooks ------------------- */

	/**
	 * Se desincrire du suivi de commentaires.
	 * */
	public function IndexBegin() {
		if(!empty($_GET['unsubscribe'])) {
			$key = self::__get_key_encryption();
			$unsubscribe = filter_input('INPUT_GET', 'unsubscribe', FILTER_SANITIZE_STRING);
			if(!empty($unsubscribe)) {
				$decodeStr = mcrypt_decrypt(MCRYPT_BLOWFISH, $key);
				list($artId, $to, $author) = explode('', $decodeStr);
				self::__updateFollower($artId, $to, $author, true);
				header('Content-Type: text/plain; charset=UTF-8');
				printf(parent::getLang('SUCCESS_UNSUBCRIPTION', $author));
				exit;
			}
			header('Location: http://linux.org');
			exit;
		}
	}

	/**
	 * Ajoute une case à cocher dans le formulaire du commentaire d'un article
	 * pour être averti par courriel d'un nouveau commentaire.
	 * */
	public function ThemeEndBody() {
		global $plxMotor;

		if(
			($plxMotor->mode === 'article') and
			!empty($plxMotor->aConf['allow_com']) and
			!empty($plxMotor->plxRecord_arts->f('allow_com')) and
			in_array('followers', explode(',', self::getParam('recipients')))
		) {
			echo str_replace('##SUBSCRIBE##', $this->getLang('SUBSCRIBE'), self::CODE_THEME_END_BODY);
		}
	}

	/**
	 * Stores mail and author into $this->newFollower attribute for using with
	 * $this->alertMail(..) procedure.
	 * */
	public function plxMotorAddCommentaire() {
		if(in_array('followers', explode(',', self::getParam('recipients')))) {
			echo self::CODE_ADD_COMMENT;
		}
	}

	/**
	 * Send an email if the comment is valid.
	 * */
	public function plxMotorDemarrageNewCommentaire() {
		echo self::CODE_NEW_COMMENT;
	}

}
?>
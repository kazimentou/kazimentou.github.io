<?php
if(!defined('PLX_ROOT')) { exit('You are a looser !'); }

# Control du token du formulaire
plxToken::validateFormToken();

$recipients = array('admin', 'author', 'followers');

if(!empty($_POST)) {
	if(!empty($_POST['recipients']) and is_array($_POST['recipients'])) {
		$values = array();
		foreach($_POST['recipients'] as $value) {
			if(in_array($value, $recipients)) {
				$values[] = $value;
			}
		}
		if(!empty($values)) {
			$plxPlugin->setParam('recipients', implode(',', $values), 'string');
		} else {
			$plxPlugin->delParam('recipients');
		}
	}
	$from = filter_input(INPUT_POST, 'from', FILTER_VALIDATE_EMAIL);
	if(!empty($from)) {
		$plxPlugin->setParam('from', $from, 'string');
	} else {
		$plxPlugin->delParam('from');
	}
	$plxPlugin->saveParams();
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

?>
<form id="form_<?php echo $plugin; ?>" class="normal" method="post">
	<h3><?php $plxPlugin->lang('RECIPIENTS_TITLE'); ?> :</h3>
<?php
	$str1 = $plxPlugin->getParam('recipients');
	$recipientsValues = (!empty($str1)) ? explode(',', $str1) : false;
	foreach($recipients as $name) {
		$caption = $plxPlugin->getLang(strtoupper($name));
		$checked = (!empty($recipientsValues) and in_array($name, $recipientsValues)) ? ' checked' : '';
		echo <<< RECIPIENT
	<div>
		<label for="id_$name">$caption</label>
		<input type="checkbox" name="recipients[]" id="id_$name" value="$name"$checked />
	</div>
RECIPIENT;
	}
?>
	<div class="small-full">
		<label for="id_from"><?php $plxPlugin->lang('FROM'); ?></label>
		<input type="email" name="from" id="id_from" value="<?php echo $plxPlugin->getParam('from'); ?>" />
	</div>
	<div class="in-action-bar">
		<?php echo plxToken::getTokenPostMethod(); ?>
		<input type="submit" value="<?php $plxPlugin->lang('SAVE'); ?>">
	</div>
</form>
<div>
	<?php $plxPlugin->lang('FOOTER'); ?>
</div>
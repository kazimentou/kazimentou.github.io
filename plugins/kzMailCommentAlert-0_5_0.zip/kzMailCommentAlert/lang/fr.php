<?php

const KZ_MAIL_COMMENT_MSG_CONTENT_AUTHOR = <<< MSG1
Bonjour ##NAME##,

Un nouveau commentaire a été posté pour l'article suivant :
<a href="##ART_URL##">##ART_TITLE##</a>

Cordialement,
Le Webmaster\n
MSG1;

const KZ_MAIL_COMMENT_MSG_CONTENT_FOLLOWERS = <<< MSG2
Bonjour ##NAME##,

Un Nouveau commentaire a été posté pour l'article :
<a href="##ART_URL##">##ART_TITLE##</a>

Cordialement

Pour ne plus recevoir de courriel, veuillez cliquer sur le lien suivant :
<a href="##UNSUBSCRIBE##">##UNSUBSCRIBE##</a>

Cordialement,
Le Webmaster\n
MSG2;

$LANG = array(
	'ADMIN'					=> 'Administrateur',
	'AUTHOR'				=> 'Auteur de l\'article',
	'FOLLOWERS'				=> 'Abonnés aux commentaires<sup>*</sup>',
	'FROM'					=> 'Adresse de l\'expéditeur',
	'RECIPIENTS_TITLE'		=> 'Pour chaque nouveau commentaire posté, envoyer un courriel à',
	'FOOTER'				=> '<sup>*</sup> <em>Uniquement à la publication du commentaire.</em>',
	'SAVE'					=> 'Enregistrer',
	'MSG_SUBJECT'			=> '[%s] Un nouveau commentaire a été posté',
	'MSG_CONTENT_AUTHOR'	=> KZ_MAIL_COMMENT_MSG_CONTENT_AUTHOR,
	'MSG_CONTENT_FOLLOWERS'	=> KZ_MAIL_COMMENT_MSG_CONTENT_FOLLOWERS,
	'SUBSCRIBE'				=> 'Etre alerté pour un nouveau commentaire, par courriel'
);
?>
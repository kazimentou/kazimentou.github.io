<?php
// Exemple de template pour une catégorie à intégrer dans le thème utilisé
?>

<?php include(dirname(__FILE__).'/header.php'); ?>
	<main>
		<section id="vignettes-cat">
			<nav id="pagination"><?php $plxShow->pagination(); ?></nav>
			<p><?php $plxShow->lang('CATEGORIES'); echo ':&nbsp;'; $plxShow->catName(); $plxShow->catDescription(' : #cat_description'); ?></p>
<?php while($plxShow->plxMotor->plxRecord_arts->loop()) { ?>
			<article id="post-<?php echo $plxShow->artId(); ?>">
<?php
$written = $plxShow->getLang('WRITTEN_BY');
$classified_in = $plxShow->getLang('CLASSIFIED_IN');
$tags = $plxShow->getLang('TAGS');
$format = <<< FORMAT
				<h2><a href="#art_url">#art_title</a></h2>
				<small>
					$written #art_author -
					<time datetime="#art_date_time">#art_date</time> -
					#art_nbcoms
				</small>
				<section>
					<p>
						#cps_vignette
					</p>
					<div>
						#art_chapo
					</div>
				</section>
				<footer>
					<small>
						$classified_in : #cat_list - $tags : #tag_list
					</small>
				</footer>
FORMAT;
eval($plxShow->callHook('chamPlusArticle', $format));
?>
			</article>
<?php } ?>
			<?php $plxShow->artFeed('rss', $plxShow->catId()); ?>
		</section>
<?php include(dirname(__FILE__).'/sidebar.php'); ?>
	</main>
<?php include(dirname(__FILE__).'/footer.php'); ?>

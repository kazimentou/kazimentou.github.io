<?php
if(!defined('PLX_ROOT')) {
	header('HTTP/1.0 404 No girl here. Keep away !');
	exit;
}

if(is_writable(MDD_CONFIG_FILE)) {
	if (isset($_POST['new_folder']) and !empty($_POST['new_name'])) {
		// création d'un nouveau dossier de données
		$plxPlugin->createFolderData($_POST['new_name']);
		header('Location: index.php');
		exit;
	} elseif (!empty($_POST['old_name'])) {
		// On renomme le dossier actuel
		$plxPlugin->renameFolder($_POST['old_name'], $_POST['new_name']);
		header('Location: index.php');
		exit;
	}
} else {
	// Impossible de modifier le fichier config.php à la racine du site
	plxMsg::Error(MDD_CONFIG_FILE.' '.$plxPlugin->getLang('UNWRITABLE'));
}

function getOptions($array, $selection) {
	$options = array();
	if (array_values($array) == $array) {
		foreach($array as $v) {
			$selectMe = (!empty($selection) and ($v == $selection)) ? ' selected' : '';
			$options[] = <<< OPTION
<option value="{$v}"{$selectMe}>{$v}</option>
OPTION;
		}
	} else {
		foreach($array as $k=>$v) {
			if (is_array($v)) {
				$more = getOptions($v, $selection);
				$options[] = <<< OPTGROUP
<optgroup label="$k"> <!-- group {$k} -->
{$more}
</optgroup>
OPTGROUP;
			} else {
			$selectMe = (!empty($selected) and ($selected == $v)) ? ' selected' : '';
			$options[] = <<< OPTION
<option value="{$k}"{$selectedMe}>{$v}</option>
OPTION;
			}
		}
	}
	return $options;
}

function printSelect($name, $array, $selection='', $readonly=false, $className='', $id=true) {

	if(!is_array($array)) $array=array();

	if($id === true)
		$id = ' id="id_'.$name.'"';
	else if (!empty($id))
		$id = ' id="id_'.$id.'"';
	else
		$id = '';

	if ($readonly === true)
		$extras =  ' disabled class="readonly"';
	else if (!empty($className))
		$extras = ' class="'.$className.'"';
	else
		$extras = '';

	$options = implode("\n\t\t\t", getOptions($array, $selection));
	echo <<< SELECT
		<select{$id} name="{$name}"{$extras}>
			{$options}
		</select>

SELECT;
}

define('PARAMS_FILE', 'parametres.xml');
$extract = function($str) {
	return preg_replace('#^'.PLX_ROOT.'([^/]+/).*'.PARAMS_FILE.'$#', '$1', $str);
};
$dataDirs = array_map($extract, glob(PLX_ROOT.'*/*/'.PARAMS_FILE));
?>
<script type="text/javascript">
	function checkName(aForm) {
		var newName = aForm.elements.new_name.value.trim();
		var result = true;
		if (newName.length > 0) {
			if (newName.substr(-1) != '/') {
				newName += '/';
			}
			var options = aForm.elements.old_name.options;
			for (i=options.length-1; i>=0; i--) {
				if (options[i].value == newName) {
					alert('<?php $plxPlugin->lang('NAME_IN_USE'); ?>');
					result = false;
					break;
				}
			}
			result = result && (aForm.elements.new_folder.checked || confirm('<?php $plxPlugin->lang('CONFIRM_RENAME'); ?>'));
		} else {
			// checkbox
			if (aForm.elements.new_folder.checked) {
				alert('<?php $plxPlugin->lang('MISSING_NAME'); ?>');
				result = false;
			}
		}
		return result;
	}
</script>
<div class="action-bar">
<h2>Move my datas</h2>
</div>
<form method="post" id="form_<?php echo $plugin; ?>" onsubmit="return checkName(this);">
	<h3><?php $plxPlugin->lang('DATA_FOLDER') ?></h3>
	<fieldset>
		<p>
			<label for="id_old_name"><?php $plxPlugin->lang('OLD_NAME') ?><sup>*</sup></label>
<?php printSelect('old_name', $dataDirs, dirname(PLX_CONFIG_PATH).'/') ?>
		</p><p>
			<label for="id_new_name"><?php $plxPlugin->lang('NEW_NAME') ?></label>
			<input type="text" id="id_new_name" name="new_name" maxlength="30" placeholder="<?php $plxPlugin->lang('NEW_NAME_PLACEHOLDER'); ?>"/>
		</p><p>
			<label for="id_new_folder"><?php $plxPlugin->lang('NEW_FOLDER') ?></label>
			<input type="checkbox" id="id_new_folder" name="new_folder" />
		</p><p class="help">
			<sup>*</sup> <?php $plxPlugin->lang('HELP'); ?>
		</p><p>
			<label>&nbsp;</label>
			<input type="submit" value="<?php $plxPlugin->lang('ALTER'); ?>" />
		</p>
	</fieldset>
</form>
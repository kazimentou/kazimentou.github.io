<?php
	$LANG = array(
		'UNWRITABLE'	=> 'is forbidden for writing',
		'DATA_FOLDER'	=> 'Data directory',
		'OLD_NAME'		=> 'Folder in use',
		'NEW_NAME'		=> 'New name',
		'RENAME'		=> 'Rename',
		'ALTER'			=> 'Change',
		'TITLE'			=> 'Rename or swap the data folder',
		'HELP'			=> 'Lists every folder with a <strong>parametres.xml</strong> file inside',
		'NEW_NAME_PLACEHOLDER'=> 'For previous or a new one',
		'FOLDER'		=> 'Folder',
		'NEW_FOLDER'	=> 'New folder',
		'NAME_IN_USE'	=> 'This name already is in use.',
		'MISSING_NAME'	=> 'Input a new name',
		'CONFIRM_RENAME'=> 'Would you change\nthe name of the current directory',
		'UNWRITABLE_FOLDER'	=> 'Unable to create the %s folder.',
		'FOLDER_EXISTS'	=> 'The %s folder already exists.',
		'L_LITERATURE'	=> 'Literature'
	);
?>
// http://stackoverflow.com/questions/23331546/how-to-use-javascript-to-read-local-text-file-and-read-line-by-line

var
	users_csv_form = document.getElementById('users-csv');

if(users_csv_form != null) {

	var processFile = function(event) {
		var lines = this.result.split('\n');
		if(lines.length > 2) {

			var	newUser = function(line) {
					var fields = line.split(',');
					if(fields[cols['login']].trim().length() > 0) {

					}
				};

			// tester s'il y a une colonne login obligatoire
			newUser.init = function(header) {
				var	cols = header.tolower().split(',');
				var input = user_new.querySelector('input[name^="userNum"]');
				this.table = document.getElementById('users-table'),
				this.user_new = table.querySelector('tr:last-of-type'),
				this.last_id_user = null;
				this.last_id_user = (input != null) ? input.value : users_table.rows.length;
				this.fields = {};
				for(var i=0, iMax = cols.length; i< iMax; i++) {
					this.fields[cols[i]] = i;
				}
				this.logins = [];
				return true;
			};

			if(newUser.init(lines[0])) {
				for(var l=1, lMax < lines.length; l++) {
					if(lines[l].trim().length > 0) {
						newUser.add(lines[l]);
					}
				}
			}
		}
	});

	users_csv_form.addEventListener('submit', function(event) {

		var
			users_csv_file = document.getElementById('users-csv-file');
			reader = new FileReader();

		reader.addEventListener('load', processFile);
		event.preventDefault();
		reader.readAsText(users_csv_file.files[0]);
	});
}
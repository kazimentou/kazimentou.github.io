<?php

if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour Colorbox
 * http://www.jacklmoore.com/colorbox/
 *
 * */

if (! defined('JQUERY_LIB'))
	define('JQUERY_LIB', 'jquery-1.11.3.min.js');
if (! defined('JQUERY_SRC')) {
	define('JQUERY_SRC', '//code.jquery.com/'.JQUERY_LIB);
}

class colorBox extends plxPlugin {

	public $fields = array(
		'style'=>'string', 'transition'=>'string', 'responsive_design'=>'boolean', 'speed'=>'numeric', 'scalePhotos'=>'boolean', 'scrolling'=>'boolean',
		'opacity'=>'numeric', 'preloading'=>'boolean', 'loop'=>'boolean', 'fadeOut'=>'numeric', 'closeButton'=>'boolean',
		// Dimensions
		'width'=>'string', 'height'=>'string', 'innerWidth'=>'string', 'innerHeight'=>'string',
		'initialWidth'=>'string', 'initialHeight'=>'string', 'maxWidth'=>'string', 'maxHeight'=>'string',
		// Slideshow
		'slideshow'=>'boolean', 'slideshowSpeed'=>'numeric', 'slideshowAuto'=>'boolean',
		// Positioning
		'fixed'=>'boolean', 'top'=>'string', 'bottom'=>'string', 'left'=>'string', 'right'=>'string', 'reposition'=>'boolean'
		);

	public $default_values = array( // divide opacity by 1000 before sending to colorbox
		'responsive_design'=>1, 'transition'=>'elastic', 'speed'=>350, 'scalePhotos'=>1, 'scrolling'=>1,
		'opacity'=>850, 'preloading'=>1, 'loop'=>1, 'fadeOut'=>300, 'closeButton'=>1,
		'initialWidth'=>'300', 'initialHeight'=>'100',
		'slideshow'=>0, 'slideshowSpeed'=>2500, 'slideshowAuto'=>0
	);

	public  function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('FeedEnd', 'FeedEnd');
	}

	private function pluginRoot() {
		global $plxShow;
		
		if (isset($plxShow)) {
			return $plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}

	private function setup($lang='en') {

		$style = $this->getParam('style');
		if (empty($style))
			$style = 'style1'; ?>
	<link href="<?php echo $this->pluginRoot().'/styles/'.$style; ?>/colorbox.css" rel="stylesheet" type="text/css" media="screen" />
<?php		
		$responsive = ($this->getParam('responsive_design') == '1');
		// We compile all options for colorBox
		$options = '';
		foreach ($this->fields as $field=>$type) {
			if ($field != 'responsive_design') { // responsive_design is not an option for colorbox library
				$value = $this->getParam($field); // getParam renvoie une chaine pour une valeur numérique !!!
				if (!empty($value)) {
					if (in_array($type, array('boolean', 'numeric')))
						$value = intval($value);
					if (!array_key_exists($field, $this->default_values) || ($value != $this->default_values[$field])) {
						switch ($field) {
							case 'opacity' :
								$value = round($value / 1000, 3);
								break;
							case 'maxWidth' :
							case 'maxHeight' :
								if ($responsive)
									$value = '100%';
								break;
						}
						$options .= $field.": '$value',\n";
					}
				}
			}
		}
		// More infos about CDN here : http://encosia.com/3-reasons-why-you-should-let-google-host-jquery-for-you/
		// src'+'=" is a hack for abusing PluXml in plxUtils::rel2abs function
	if (! defined('JQUERY_LOADED')) {
?>
	<script type="text/javascript"> <!-- colorBox -->
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src'+'="<?php echo JQUERY_SRC; ?>"></scr'+'ipt>');
	</script>
<?php
		define('JQUERY_LOADED', true);
	}
?>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>/jquery.colorbox.js"></script>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>/i18n/jquery.colorbox-<?php echo $lang; ?>.js"></script>
	<script type="text/javascript">
		<!--
		$(document).ready(function() {
			console.log('init colorBox');
			$("a[rel^='lightbox']").colorbox({<?php echo $options; ?>rel: 'lightbox*'});

			var thumbnails1 = "img[src$='\\.tb\\.jpg'], img[src$='\\.tb\\.png'], img[src$='\\.tb\\.gif'], img[src$='\\.tb\\.jpeg']";
			$(thumbnails1).colorbox({
<?php echo $options; ?>
rel: 'lightbox*',
href: function() { return $(this).attr('src').replace(/\.tb(\.\w+)$/i,'$1'); },
title: function() { var t = $(this).attr('title'); return (t) ? t : $(this).attr('alt'); }
			});
			$(thumbnails1).css('cursor', 'pointer');
			
			var thumbnails2 = "img[src*='/\\.thumbs/']";
			$(thumbnails2).colorbox({
				<?php echo $options; ?>
				rel: 'lightbox*',
				href: function() { return $(this).attr('src').replace(/\/\.thumbs\//i, '/'); },
				title: function() { var t = $(this).attr('title'); return (t) ? t : $(this).attr('alt'); }
			});
			$(thumbnails2).css('cursor', 'pointer');
<?php
		// for responsive design
		// http://davidwalsh.name/orientation-change
		if ($this->getParam('responsive_design') == '1') {
			// for debugging in javascript : alert(window.innerWidth + ' x ' + window.innerHeight + ' (wxh)');
?>

	var resizeTimer;
	function resizeColorBox(event) {
		if (resizeTimer) clearTimeout(resizeTimer);
		resizeTimer = setTimeout(function() { $.colorbox.resize(); }, 300);
	}

	window.addEventListener('orientationchange', resizeColorBox, false);
<?php
		}
?>
		});
		// -->
	</script>
<?php	}

	public function AdminTopEndHead($params) {
		global $plxAdmin, $plugin;
		
		switch ($this->script_name) {
			case 'parametres_pluginhelp' :
				break;
			case 'medias' :
				$this->setup($plxAdmin->aConf['default_lang']); // add language
				break;
			case 'parametres_plugin' :
			if ($plugin == __CLASS__) {?>
	<link href="<?php echo $this->pluginRoot().__CLASS__; ?>.css" rel="stylesheet" type="text/css" media="screen" />
	<script type="text/javascript">
		<!--
		var defaultValues = {
			<?php
		$buf = array();
		foreach ($this->default_values as $k=>$v) {
			if (array_key_exists($k, $this->fields)) {
				$type = $this->fields[$k];
				if ($type == 'boolean')
					$value = ($v > 0) ? 'true' : 'false';
				else
					$value = ($type == 'numeric') ? $v : "'$v'";
			}
			else
				$value = "'$v'";
			array_push($buf, $k.': '.$value);
		}
		echo implode(", \n\t\t\t", $buf)."\n";
?>
		}
		// -->
	</script>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script>
<?php }
				break;
		}
	}

	public function ThemeEndHead($params) {
		global $plxShow;

		$this->setup($plxShow->plxMotor->aConf['default_lang']);
	}

	public function FeedEnd() {
		global $plxFeed;

        // protect some HTML entities between tags (required by XML files)
        $code = "\$pats = ['&lt;', '&gt;', '&quot;'];\n";
        $code .= "\$reps = ['<<<<', '>>>>', '\"\"\"\"'];\n";

        $root = $plxFeed->racine;
        $host = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'];
        if (substr($root, 0, strlen($host)) != $host)
			$root = $host.$root;
        $_pattern1 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*\.)(tb\.)(jpg|png|gif)([^>]*))>>>>!';
        $_pattern2 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*)(/\.thumbs)(/\w[^"]*\.)(jpg|png|gif)([^>]*))>>>>!';
        $_replace1 = '<<<<a href="\3\5">>>><<<<\1>>>><<<</a>>>>';
        $_replace2 = '<<<<a href="\3\5\6">>>><<<<\1>>>><<<</a>>>>';

        $code .= "\$patterns = [\n\t'$_pattern1',\n\t'$_pattern2'\n];\n";
        $code .= "\$replaces = ['$_replace1', '$_replace2'];\n";
        $code .= "\$tmp = str_replace(\$pats, \$reps, \$output);\n";
		$code .= "\$tmp = preg_replace(\$patterns, \$replaces, \$tmp);\n";
        // deprotect some HTML entities and output
        $code .= "\$output = str_replace(\$reps, \$pats, \$tmp);\n";
		
		echo "<?php $code ?>";
	}

}

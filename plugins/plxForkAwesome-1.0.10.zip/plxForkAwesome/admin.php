<?php if(!defined('PLX_ROOT')) exit; ?>

<?php 	include 'doc/examples.html'; ?>

<?php 	include 'doc/cheatsheet.html'; ?>


<hr />
<ul>
	<li>The Fork Awesome font is licensed under the SIL OFL 1.1:
		<ul>
			<li>http://scripts.sil.org/OFL</li>
		</ul>
	</li>
	<li>Fork Awesome CSS, LESS, and Sass files are licensed under the MIT License:
		<ul>
			<li>https://opensource.org/licenses/mit-license.html</li>
		</ul>
	</li>
	<li>The Fork Awesome documentation is licensed under the CC BY 3.0 License:
		<ul>
			<li>https://creativecommons.org/licenses/by/3.0/</li>
		</ul>
	</li>
</ul>

<p><a href="https://forkawesome.github.io/Fork-Awesome/">Fork Awesome</a> (A fork of Font Awesome, originally created by Dave Gandy)         </p>

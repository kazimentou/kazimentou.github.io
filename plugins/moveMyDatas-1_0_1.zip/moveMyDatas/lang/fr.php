<?php
$LANG = array(
	'ALTER'					=> 'Modifier',
	'CONFIRM_RENAME'		=> 'Voulez-vous renommer\nle dossier de données en cours',
	'DATA_FOLDER'			=> 'Dossier des données',
	'FOLDER'				=> 'Dossier',
	'FOLDER_EXISTS'			=> 'Le dossier %s existe déjà.',
	'HELP'					=> 'Liste de tous les&nbsp;dossiers contenant un&nbsp;sous-dossier avec un&nbsp;fichier <strong>parametres.xml</strong>',
	'INVALIDATE_NEW_NAME'	=> 'Le nom du nouveau dossier est incorrect',
	'INVALIDATE_OLD_NAME'	=> 'Le dossier %s \'existe pas',
	'MISSING_NAME'			=> 'Précisez le nom\ndu nouveau dossier',
	'NAME_IN_USE'			=> 'Ce dossier existe déjà',
	'NEW_FOLDER'			=> 'Nouveau dossier',
	'NEW_NAME'				=> 'Nouveau dossier',
	'NEW_NAME_PLACEHOLDER'	=> 'Pour ci-dessus ou un nouveau',
	'OLD_NAME'				=> 'Dossier actuel',
	'CURRENT_FOLDER'		=> 'Dossier de données actuel',
	'TITLE'					=> 'Renommez ou changez le dossier de vos données',
	'UNWRITABLE_FILE'		=> 'Impossible de modifier le fichier %s',
	'UNWRITABLE_FOLDER'		=> 'Aucun droit en écriture pour le dossier %s.',
);
?>
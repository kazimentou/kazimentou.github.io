<?php

$LANG = array(

# config.php
'L_JQUERY_THEME'	=> 'Thème pour jQuery',
'L_JQUERY_DOWNLOAD'	=> 'Téléchargement de la bibliothèque jQuery',
'L_JQUERY_GALLERY'	=> 'Voir la galerie de thèmes',
'L_JQUERY_NO'		=> 'Non',
'L_JQUERY_AUTO'		=> 'Auto',
'L_JQUERY_LOCAL'	=> 'Local'
);
?>

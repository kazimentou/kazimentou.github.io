<?php
$theme = (empty($_GET['theme'])) ? 'Smoothness' : $_GET['theme'];
$theme = strtolower(str_replace(' ', '-', $theme));
$download = (empty($_GET['download'])) ? 0 : $_GET['download'];
$jQuerySrc = ($download == 0) ? '//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js' : 'js/jquery-1.10.2.min.js';
$lang = (empty($_GET['lang'])) ? 'fr' : $_GET['lang'];
?>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>jQuery UI Datepicker</title>
	<style>
		body {background-color: WhiteSmoke;}
		p {text-align: justify;}
		h1, p.center {text-align: center;}
	</style>
	<link href="//code.jquery.com/ui/1.10.4/themes/<?php echo $theme; ?>/jquery-ui.css" rel="stylesheet" />
	<script src="<?php echo $jQuerySrc; ?>" type="text/javascript"></script>
	<script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
	<script src="js/jquery-ui-1.10.4.datepicker.min.js"></script>
	<script src="js/i18n/datepicker-<?php echo $lang; ?>.js" type="text/javascript"></script>
	<script type="text/javascript"> <!--
		$(function () {
			var datepicker1 = $('#day').datepicker({
				dateFormat: 'dd',
				altField: '#month',
				altFormat: 'mm',
				changeMonth: true,
				changeYear: true,
				onChangeMonthYear: function(year1, month1, widget1) {$('#year').val(year1);},
				showButtonPanel: true,
				beforeShow:
					function(input1, widget1) {
						return {'defaultDate': new Date($('#year').val(), $('#month').val()-1, $('#day').val())};
					}
			});
			if (datepicker1) {
				$('#month, #year').focus( function() { datepicker1.datepicker('show'); });
				}
			else
				console.log('datepicker1 not found')
			} ); // -->
	</script>
</head>
<body>
	<h1>Thema: <?php echo $theme; ?></h1>
	<p>
		Day <input type="text" id="day" maxlength="2" size="2" value="15" />&nbsp;
		Month <input type="text" id="month" maxlength="2" size="2" value="08" />&nbsp;
		Year <input type="text" id="year" maxlength="4" size="4" value="2013" />
	</p>
	<p>
		Localize the datepicker calendar language and format (English / Western formatting is the default).<br />
		The datepicker includes built-in support for languages that read right-to-left, such as Arabic and Hebrew.
	</p>
	<p class="center"><input type="button" value="Close" onclick="window.close();"></p>
</body>
</html>

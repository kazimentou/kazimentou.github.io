<?php

if (!defined('PLX_ROOT')) exit;

# Control du token du formulaire
plxToken::validateFormToken($_POST);

$params = array('theme'=>'string', 'download'=>'numeric');
$default_values = array('theme'=>$plxPlugin->default_theme_jquery, 'download'=>0);

if (!empty($_POST)) {
	foreach ($params as $field=>$type1) {
		if ($type1 == 'numeric')
			$value = intval($_POST[$field]);
		else
			$value = $_POST[$field] ? $_POST[$field] : $default_values[$field];
		$plxPlugin->setParam($field, $value, $type1);
		}
	$plxPlugin->saveParams();
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

$themes = array();
foreach ($plxPlugin->themes_jquery as $v)
	$themes[$v] = $v;
$downloads = array();
foreach (array('0'=>'AUTO', '1'=>'LOCAL', '2'=>'NO') as $k=>$v)
	$downloads[$k] = $plxPlugin->getlang('L_JQUERY_'.$v);
$items = array('theme'=>$themes, 'download'=>$downloads);
?>

<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
<p>
	<a href="https://raw.github.com/jquery/jquery-ui/master/ui/i18n/" target="_blank">Click here for more translation in Datepicker widget.</a><br />
	<a href="http://jqueryui.com/themeroller/" target="_blank"><?php echo $plxPlugin->lang('L_JQUERY_GALLERY'); ?></a>
</p>
<form id="form_<?php echo $plugin; ?>" method="post">
<?php
echo "\t".plxToken::getTokenPostMethod()."\n";
foreach($params as $field=>$type) {
	$value = $plxPlugin->getParam($field);
	if (empty($value))
		$value = $default_values[$field];
?>
	<p>
		<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_JQUERY_'.strtoupper($field)); ?></label>
<?php plxUtils::printSelect($field, $items[$field], $value);
		if ($field == 'theme') : ?>
		<input type="button" value="test" onclick="return demo_open('<?php $plxPlugin->print_demo_url(); ?>');" />
		<!-- supplies the language for the demo-window -->
		<input type="hidden" id="id_lang" name="lang" value="<?php echo $lang; ?>" />
<?php endif; ?>
	</p>
<?php
}
?>
	<p>
		<label>&nbsp;</label>
		<input type="submit" />
	</p>
</form>

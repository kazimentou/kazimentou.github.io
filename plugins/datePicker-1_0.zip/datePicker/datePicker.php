<?php

if (!defined('PLX_ROOT')) exit;

class datePicker extends plxPlugin {

	// for more translation for datepicker, look at : https://raw.github.com/jquery/jquery-ui/master/ui/i18n/

	public $themes_jquery = array(
		'UI lightness', 'UI darkness', 'Smoothness', 'Start', 'Redmond', 'Sunny', 'Overcast',
		'Le Frog', 'Flick', 'Pepper Grinder', 'Eggplant', 'Dark Hive', 'Cupertino',
		'South Street', 'Blitzer', 'Humanity', 'Hot Sneaks', 'Excite Bike', 'Vader', 'Dot Luv',
		'Mint Choc', 'Black Tie', 'Trontastic', 'Swanky Purse'
		);

	public $default_theme_jquery = 'Smoothness';

	public $gallery_jquery = 'http://jqueryui.com/themeroller/#themeGallery';

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
	}

	public function AdminTopEndHead($params=null) {
		global $plugin;

		$script = basename($_SERVER["SCRIPT_NAME"], '.php');
		switch ($script) {
			case 'article' :
				$theme = $this->getParam('theme');
				if (empty($theme))
					$theme = $this->default_theme_jquery;
					$theme = strtolower(str_replace(' ', '-', $theme));
					$lang = 'fr'; ?>
		<link href="//code.jquery.com/ui/1.10.4/themes/<?php echo $theme; ?>/jquery-ui.css" rel="stylesheet" />
<?php switch ($this->getParam('download')) {
	case 0 : // get jQuery from the Cloud if necessary ?>
	<script type="text/javascript">
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></scr'+'ipt>');
	</script>
<?php
		break;
	case 1 : // get jQuery from local file ?>
	<script src="<?php echo PLX_PLUGINS.__CLASS__; ?>/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<?php
		break;
}
?>
	<script src="<?php echo PLX_PLUGINS.__CLASS__; ?>/js/jquery-ui-1.10.4.datepicker.min.js"></script>
	<script src="<?php echo PLX_PLUGINS.__CLASS__.'/js/i18n/datepicker-'.$lang; ?>.js" type="text/javascript"></script>
	<script type="text/javascript"> <!--
		$(function () {
			var datepicker1 = $('#id_day').datepicker(
				{
					dateFormat: 'dd',
					altField: '#id_month',
					altFormat: 'mm',
					changeMonth: true,
					changeYear: true,
					onChangeMonthYear: function(year1, month1, widget1) { $('#id_year').val(year1); },
					showButtonPanel: true,
					beforeShow:
						function(input1, widget1) {
							return {'defaultDate': new Date($('#id_year').val(), $('#id_month').val()-1, $('#id_day').val())};
						}
				}
				);
			if (datepicker1) {
				$('#id_month, #id_year').focus( function() { datepicker1.datepicker('show'); });
			}
			else
				console.log('datepicker1 not found')
			}
		); // -->
	</script>
<?php
				break;
			case 'parametres_plugin' :
				if ($plugin == __CLASS__) { ?>
	<style>
		#form_<?php echo __CLASS__; ?> {width: 500px; margin-top: 5px; padding: 2px;	background-color: AliceBlue; border-radius: 10px; border: 1px solid LightSteelBlue;}
		#form_<?php echo __CLASS__; ?> label {display: inline-block; width: 250px; text-align: right; }
		#form_<?php echo __CLASS__; ?> p {margin: 5px;}
		#form_<?php echo __CLASS__; ?> input[type='button'],
		#form_<?php echo __CLASS__; ?> input[type='submit'] {padding: 2px 20px;}
	</style>
	<script type="text/javascript">
		function demo_open(url) {

			var elt = document.getElementById('id_theme');
			var theme = (elt) ? elt.value : '';
			theme = encodeURI(theme);
			elt = document.getElementById('id_download');
			var download = (elt) ? elt.value : '';
			var elt = document.getElementById('id_lang');
			var lang = (elt) ? elt.value : 'fr';
			url = url+'?theme='+theme+'&download='+download+'&lang='+lang;

			var width = 400, height = 430, left = (screen.width-width)/2, top = (screen.height-height)/2;
			var options =
				'height='+height+', width='+width+', top='+top+', left='+left+
				',menubar=no, location=no, titlebar=no, toolbar=no, resizable=no';

			var myWindow = window.open(url, '_blank', options);
			return false;
		}
	</script>
<?php }
				break;
		}
	}

	public function print_demo_url() {
		echo PLX_PLUGINS.__CLASS__.'/demo-theme.php';
	}
}
?>

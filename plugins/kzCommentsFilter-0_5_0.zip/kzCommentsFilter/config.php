<?php
if(!defined('PLX_ROOT')) { exit; }

# Control du token du formulaire
plxToken::validateFormToken($_POST);

if(!empty($_POST['filter-btn'])) {
	$plxPlugin->filterUnModeratedComments();
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

if(!empty($_POST['params'])) {
	$plxPlugin->setFilters($_POST['params']);
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

?>
<form id="form_<?php echo $plugin; ?>" method="post">
	<div class="scrollable-table">
		<table>
			<thead>
<?php $iMax = $plxPlugin->printTitleColumns(); ?>
			</thead>
			<tbody id="filters">
<?php $iMax = $plxPlugin->printFilters(); ?>
			</tbody>
		</table>
	</div>
	<div class="in-action-bar">
		<?php echo plxToken::getTokenPostMethod()."\n"; ?>
		<input type="submit" value="<?php $plxPlugin->lang('SAVE_BTN'); ?>" />
<?php
$comsCount = $plxPlugin->getUnmoderatedCommentsCount();
if(!empty($comsCount)) {
?>
		<input type="submit" name="filter-btn" value="<?php $plxPlugin->lang('FILTER_BTN'); ?>" title="<?php $plxPlugin->lang('TITLE_FILTER_BTN'); ?>" />
		<em><?php printf($plxPlugin->getLang('COMS_COUNT'), $comsCount); ?></em>
<?php
}
?>
		<input type="button" id="new-filter-btn" value="<?php $plxPlugin->lang('NEW_FILTER_BTN'); ?>" />
	</div>
</form>
<?php echo $plxPlugin->printHelp(); ?>
<?php $plxPlugin->print_script_JS(kzCommentsFilter::CONFIG_SELECTOR); ?>
<script type="text/javascript">
	(function() {
		'use strict';

		const filters = document.getElementById('filters');
		if(filters != null) {
			const btn = document.getElementById('new-filter-btn');
			if(btn != null) {
				btn.addEventListener('click', function(event) {
					const newRow = document.createElement('TR');
					newRow.innerHTML = filters.rows[0].innerHTML.replace(/(name="\w+)\[\d+\]/g, '$1[' + (filters.rows.length - 1) + ']').replace(/value="[^"]+"/g, 'value=""');
					filters.appendChild(newRow);
				});
			}
		}
	})();
</script>
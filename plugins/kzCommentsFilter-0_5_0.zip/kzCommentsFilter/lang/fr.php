<?php
$LANG = array(
	'IPADDR'				=> 'Adresse IP4',
	'IPADDREND'				=> 'Fin adresse',
	'IPMASK'				=> 'Masque',
	'DOMAINMAIL'			=> 'Serveur courriel',
	'SITE'					=> 'Site Internet',
	'FILTER_BTN'			=> 'Filtrer',
	'NEW_FILTER_BTN'		=> 'Ajouter un filtre',
	'TITLE_FILTER_BTN'		=> 'Filtrer les commentaires en cours de modération',
	'IPMASK_TITLE'			=> 'Pour les adresses IP, de 8 à 32',
	'FILTER_BTN_TITLE'		=> 'Appliquer les filtres aux commentaires en cours de modération',
	'SAVE_BTN'				=> 'Enregistrer',
	'INPUT_HELP'			=> 'Format demandé pour les saisies (expressions régulières) :',
	'COMS_COUNT'			=> '%d commentaires à modérer',
	'DELETED_COMMENTS'		=> '%d commentaires supprimés',
	'NO_COMMENT_TO_DROP'	=> 'Aucun commentaire à supprimer',
	'NO_RULE'				=> 'Il n\'existe aucun filtre',
	'BAN'					=> 'Bannir adresses IP',
	'COUNTRY'				=> 'Pays'
);
?>
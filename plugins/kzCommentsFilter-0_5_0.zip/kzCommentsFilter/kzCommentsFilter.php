<?php
if(!defined('PLX_ROOT')) { exit; }

/**
 * Filtre les commentaires des visiteurs du site selon différents critères
 * (Adresse IP4, mail, site, ...).
 * */
class kzCommentsFilter extends plxPlugin {

	const PROVIDER_URL = 'http://ip-api.com/batch';
	const COMMENTS_SELECTOR = '#comments-table:not(.flag) td.ip-address[data-ip]';
	const CONFIG_SELECTOR = '#form_kzCommentsFilter td[data-ip]';
	const MAX_IPS = 256;
	const SPRITES = true;
	const UNMODERATED_COMMENTS_MASK = '@^_\d{4}\..*\.xml$@';
	const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE;

	# PHP version < 7.0 ne permet pas de définir des tableaux comme constantes.
	private $params = array(
		'ipAddr'		=> array('maxsize'=>15, 'type' => 'text', 'pattern' => '[1-9]\d{0,2}(?:\.\d{1,3}){3}'),
		'ipAddrEnd'		=> array('maxsize'=>15, 'type' => 'text', 'pattern' => '[1-9]\d{0,2}(?:\.\d{1,3}){3}'),
		'ipMask'		=> array('type' => 'number', 'min' => 4, 'max' => 32),
		'domainMail'	=> array('maxsize'=>30,'type' => 'text', 'pattern' => '@?[\w-]+\.[a-z]{2,8}$'),
		'site'			=> array('maxsize'=>50, 'type' => 'text', 'pattern' => '^https?://[^\w/-]+\.[a-z]{2,8}')
	);

	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		parent::setConfigProfil(PROFIL_ADMIN);

		parent::addHook('AdminCommentsPrepend', 'AdminCommentsPrepend');
		parent::addHook('AdminCommentsTop', 'AdminCommentsTop');
		parent::addHook('plxMotorNewCommentaire', 'plxMotorNewCommentaire');
		parent::addHook('plxMotorPreChauffageEnd', 'plxMotorPreChauffageEnd');
		parent::addHook('AdminCommentsFoot', 'AdminCommentsFoot');
		if(!empty(self::SPRITES) and is_file(__DIR__.'/flags.css')) {
			parent::addHook('AdminTopEndHead', 'AdminTopEndHead');
		}

		$this->lang = $default_lang;
	}

	/**
	 * Crée un tableau de filtres depuis le fichier de paramètres du plugin.
	 * */
	public function getFilters($warning=true) {
		$content = PARENT::getParam('content');
		if(!empty($content)) {
			$result = json_decode($content, true);
			if(is_array($result)) {
				return $result;
			}
		}
		if($warning) {
			plxMsg::Error(self::getLang('NO_RULE'));
		}
		return false;
	}

	/**
	 * Enregistre Les filtres pour les commentaires.
	 * */
	public function saveFilters($datas) {
		if(!empty($datas)) {
			usort($datas, function($a, $b) {
				$aNum = ip2long($a['ipAddr']);
				$bNum = ip2long($b['ipAddr']);
				return ($aNum - $bNum);
			});
			parent::setParam('content', json_encode($datas, JSON_UNESCAPED_UNICODE + JSON_UNESCAPED_SLASHES + JSON_PRETTY_PRINT), 'cdata');
		} else {
			parent::delParam('content');
		}
		parent::saveParams();
	}

	/**
	 * Enregistre toutes les saisies du panneau de configuration dans le fichier
	 * de paramètres du plugin.
	 * */
	public function setFilters($content) {
		if(is_array($content)) {
			$datas = array();
			foreach($content as $row) {
				$record = array();
				foreach($row as $field=>$value) {
					if(!empty($value)) {
						if(!empty($this->params[$field]['pattern'])) {
							if(preg_match('#'.$this->params[$field]['pattern'].'#', $value)) {
								$record[$field] = $value;
							}
						} elseif(!empty($this->params[$field]['type']) and ($this->params[$field]['type'] == 'number')) {
							$n = intval($value);
							if($n > 0) {
								$record[$field] = $n;
							}
						} elseif($field === 'error') {

						}
					}
				}
				if(!empty($record)) {
					$datas[] = $record;
				}
			}
			self::saveFilters($datas);
		}
	}

	public function printTitleColumns() {
		echo <<< ROW_STARTS
				<tr>\n
ROW_STARTS;
		$cells = array();
		foreach($this->params as $fieldName=>$values) {
			if(!empty($values['pattern'])) {
				$title = ' title="'.sprintf(PARENT::getLang('INPUT_HELP'), $values['pattern']).'"';
			} else {
				$title = '';
			}
			$caption = parent::getLang(strtoupper($fieldName));
			echo <<< CELL
						<th{$title}>{$caption}</th>\n
CELL;
		}
		$titleCol = parent::getLang('COUNTRY');
		echo <<< ROW_ENDS
					<th>$titleCol</th>
				</tr>\n
ROW_ENDS;
	}

	/**
	 * affiche une rangée dans le tableau de configuration avec
	 * les champs de saisie input et ses attributs.
	 * */
	public function printInputsRow($rang) {
		foreach(array_keys($this->params) as $fieldName) {
			$extras = array(
				'name="params['.$rang.']['.$fieldName.']"'
			);
			foreach($this->params[$fieldName] as $key=>$value) {
				$extras[] = $key.'="'.$value.'"';
			}
			if($rang >= 0) {
				if (
					!empty($this->filters) and
					($rang < count($this->filters)) and
					!empty($this->filters[$rang][$fieldName])
				) {
					$extras[] = 'value="'.$this->filters[$rang][$fieldName].'"';
				}
			}
			$attrs = implode(' ', $extras);
			echo <<< CELL
						<td><input {$attrs} /></td>\n
CELL;
		}
		$data_ip = (!empty($this->filters[$rang]['ipAddr'])) ? ' data-ip="'.$this->filters[$rang]['ipAddr'].'"' : '';
		echo <<< CELL
						<td{$data_ip}>&nbsp;</td>\n
CELL;
	}

	/**
	 * Affiche toutes les rangées du tableau de configuration.
	 * */
	public function printFilters() {
		$this->filters = SELF::getFilters();
		if(!empty($this->filters)) {
			$iMax = count($this->filters);
			for($i=0; $i <= $iMax; $i++) {
?>
					<tr>
<?php self::printInputsRow($i); ?>
					</tr>
<?php		}
			return $iMax;
		} else {
?>
					<tr>
<?php self::printInputsRow(-1); ?>
					</tr>
<?php
			return 0;
		}
	}

	/**
	 * Affiche une aide pour la saisie des filtres.
	 * */
	public function printHelp() {
		$title = PARENT::getLang('INPUT_HELP');
		echo <<< ROW_STARTS
		<p class="infos">{$title}</p>
		<ul>\n
ROW_STARTS;
		foreach($this->params as $fieldName=>$values) {
			if(!empty($values['pattern'])) {
				$caption = PARENT::getLang(strtoupper($fieldName));
				echo <<< ITEM
				<li><span>{$caption}</span> : {$values['pattern']}</li>\n
ITEM;
			}
		}
		echo <<< ROW_ENDS
		</ul>\n
ROW_ENDS;
	}

	/**
	 * Vérifie si une adresse IP apartient à un sous-réseau.
	 * */
	private function __filterIp($ip, $subnet, $range) {
		# see also : https://github.com/cloudflare/CloudFlare-Tools/blob/master/cloudflare/ip_in_range.php
		# for testing: $ip = '192.168.1.125'; echo long2ip(ip2long($ip) >> 8);
		$ipNum = ip2long($ip);
		$subnetNum = ip2long($subnet);
		if(!empty($range)) {
			if(is_integer($range)) {
				if($range < 32) {
					$right = 32 - $range;
					$ipNum = $ipNum >> $right;
					$subnetNum = $subnetNum >> $right;
				}
			} else {
				return ($subnetNum <= $ipNum) and ($ipNum <= ip2long($range));
			}
		}
		return $ipNum == $subnetNum;
	}

	/**
	 * Vérifie qu'un commentaire est blacklisté.
	 * */
	private function __checkBadComment($ip, $mail=false, $site=false) {
		if(empty($this->filters)) {
			$this->filters = $this->getFilters(false);
		}

		$result = false;
		foreach($this->filters as $filter) {
			$range = (!empty($filter['ipMask'])) ? intval($filter['ipMask']) : ((!empty($filter['ipEnd'])) ? $filter['ipEnd'] : false);
			if(
				( # adresse IP4. Le commentaire contient toujours l'adresse IP4 de l'expéditeur.
					!empty($filter['ipAddr']) and
					SELF::__filterIp($ip, $filter['ipAddr'], $range)
				) or ( # mail
					!empty($mail) and
					!empty($filter['domainMail']) and
					preg_match('#'.$filter['domainMail'].'#', $mail)
				) or ( # site
					!empty($site) and
					!empty($filter['site']) and
					preg_match('#'.$filter['site'].'#', $site)
				)
			) {
				$result = true;
				break;
			}
		}
		return $result;
	}

	/**
	 * Supprime les commentaires à valider pour les visiteurs qui sont en liste noire (blacklist).
	 * */
	public function filterUnModeratedComments() {
		global $plxAdmin;

		$this->filters = false;
		if($plxAdmin->getCommentaires(self::UNMODERATED_COMMENTS_MASK, '')) {
			$counter = 0;
			while($plxAdmin->plxRecord_coms->loop()) {
				if($this->__checkBadComment(
					$plxAdmin->plxRecord_coms->f('ip'),
					!empty($plxAdmin->plxRecord_coms->f('mail')) ? $plxAdmin->plxRecord_coms->f('mail') : false,
					!empty($plxAdmin->plxRecord_coms->f('site')) ? $plxAdmin->plxRecord_coms->f('site') : false
				)) {
					$plxAdmin->delCommentaire('_'.$plxAdmin->plxRecord_coms->f('article').'.'.$plxAdmin->plxRecord_coms->f('numero'));
					$counter++;
				}
			}
			if(!empty($counter)) {
				plxMsg::Info(sprintf(PARENT::getLang('DELETED_COMMENTS'), $counter));
			}
		} else {
			plxMsg::Error(PARENT::getLang('NO_COMMENT_TO_DROP'));
		}
	}

	/**
	 * Retourne le nombre de commentaires à modérer.
	 * */
	public function getUnmoderatedCommentsCount() {
		global $plxAdmin;

		$coms = plxGlob::getInstance(PLX_ROOT.$plxAdmin->aConf['racine_commentaires']);
		$records = $coms->query(SELF::UNMODERATED_COMMENTS_MASK, '');
		return (!empty($records)) ? count($records) : false;
	}


	/**
	 * Vérifie si ce visiteur du site a la permission d'envoyer un commentaire.
	 *
	 * S'il est blacklisté, on renvoie un code d'erreur aléatoire, avec un message d'erreur fantaisite.
	 * */
	public function checkComment($ip, $mail, $site) {
		$this->filters = false;
		if($this->__checkBadComment($ip, $mail, $site)) {
			# Do you play with me, guy ?
			$error_codes = file(__DIR__.'/erreur_codes.txt', FILE_SKIP_EMPTY_LINES + FILE_IGNORE_NEW_LINES);
			@shuffle($error_codes);
			$err = $error_codes[array_rand($error_codes)];
			$scheme = (!empty($_SERVER['SERVER_PROTOCOL'])) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0';
			header('Last-Modified: '.gmdate('D, d M Y H:i:s', filemtime(PLX_ROOT.'config.php')));
			header('Expires: '.gmdate('D, d M Y H:i:s \G\M\T', time() + 604800)); # 7 days
			header('Cache-Control: private');
			header('Pragma: private');
			header("$scheme $err ".plxUtils::charAleatoire(96));
			exit;
		}
		return false;
	}

	/**
	 * Bannit les adresses IP des commentaires sélectionnés.
	 * */
	public function ban_IPs($idComs, $plxAdmin) {
		# Protection anti-hack
		$idComs = array_filter($idComs, function($idCom) {
			return preg_match('@^_?\d{4}\.\d{0,12}-\d{0,4}$@', $idCom);
		});

		if(!empty($idComs)) {
			$motif = (count($idComs) > 1) ?'(?:'.implode('|', $idComs).')' : $idComs[0];
			$plxAdmin->getCommentaires('@^_?'.$motif.'\.xml$@', '', 0, false,'all');
			if(!empty($plxAdmin->plxRecord_coms)) {
				$updated = false;
				$filters = self::getFilters();
				$ips = array_unique(array_map(
					function($filter) {
						return (!empty($filter['ipAddr'])) ? $filter['ipAddr'] : false;
					},
					$filters
				));

				while($plxAdmin->plxRecord_coms->loop()) {
					$ip = $plxAdmin->plxRecord_coms->f('ip');
					if(!empty($ip) and !in_array($ip, $ips)) {
						$filters[] = array('ipAddr' => $ip);
						$updated = true;
					}
				}

				if($updated) {
					self::saveFilters($filters);
				}
			}

			return true;
		} else {
			return false;
		}
	}

	/**
	 * Vérifie si une adresse IP est en liste noire (blacklist)
	 * */
	public function isIP_banned() {
		$ip = plxUtils::getIp();
		return (!empty($ip) and self::__checkBadComment($ip));
	}

	function print_script_JS($selectorCSS) {
		$datas = json_encode(
			array(
				'provider'	=> self::PROVIDER_URL,
				'maxIPs'	=> self::MAX_IPS,
				'keyStorage'=> __CLASS__,
				'sprites'	=> self::SPRITES,
				'lang'		=> $this->lang,
				'flagsPath'	=> (defined('PLX_FLAGS_32_PATH')) ? PLX_FLAGS_32_PATH : null
			),
			self::JSON_OPTIONS
		);
		$src = PLX_PLUGINS.__CLASS__.'/ip-api.js';
		echo <<< SCRIPT_JS
	<script type="text/javascript" src="$src" data='$datas' data-selector="$selectorCSS"></script>\n
SCRIPT_JS;
	}

	/* --------- Hooks ---------- */

	/**
	 * Ajoute une feuille de style pour afficher les drapeaux avec des sprites.
	 * */
	public function AdminTopEndHead() {
		$href = PLX_PLUGINS.__CLASS__.'/flags.css';
		echo <<< LINK
		<link rel="stylesheet" href="$href" />\n
LINK;
	}

	/**
	 * Ajoute dans le sélecteur la possibilité de bannir les adresses IP de certains commentaires
	 * */
	public function AdminCommentsTop() {

		$caption = parent::getLang('BAN');
		$new_option = <<< NEW_OPTION

	<option value=\"ban\">$caption</option>
NEW_OPTION;
		$code = <<< 'ADMIN_COMMENT_STOP'
<?php
	$selector = preg_replace('@(\s*<option[^>]*>-{3,}</option>\s*)@', "##NEW_OPTION##$1", $selector);
?>
ADMIN_COMMENT_STOP;
		echo str_replace('##NEW_OPTION##', $new_option, $code);
	}

	/**
	 * Bannit les adresses IP des commentaires sélectionnés.
	 * */
	public function AdminCommentsPrepend() {
		$code = <<< 'ADMIN_COMMENTS_PREPEND'
<?php
# Contrôle de l'accès à la page en fonction du profil de l'utilisateur connecté
$plxAdmin->checkProfil(PROFIL_ADMIN, PROFIL_MANAGER, PROFIL_MODERATOR);

if(
	!empty($_POST['selection']) AND
	($_POST['selection'] === 'ban') AND
	!empty($_POST['btn_ok']) AND
	!empty($_POST['idCom']) AND
	$plxAdmin->plxPlugins->aPlugins['__CLASS__']->ban_IPs($_POST['idCom'], $plxAdmin)
) {
	header('Location: comments.php'.(!empty($_GET['a'])?'?a='.$_GET['a']:''));
	exit;
}
?>
ADMIN_COMMENTS_PREPEND;
		echo str_replace('__CLASS__', __CLASS__, $code);
	}

	/**
	 * Valide un nouveau commentaire pour un visiteur qui n'est pas en liste noire.
	 * */
	public function plxMotorNewCommentaire() {
		$code = <<< 'PLXMOTOR_NEW_COMMENTAIRE'
<?php
return $this->plxPlugins->aPlugins['__CLASS__']->checkComment(
	plxUtils::getIp(),
	filter_var(trim($content['mail']), FILTER_VALIDATE_EMAIL),
	preg_match('#__PATTERN__#', trim($content['site'])) ? trim($content['site']) : false
);
?>
PLXMOTOR_NEW_COMMENTAIRE;
		$replaces = array(
			'__PATTERN__'	=> $this->params['site']['pattern'],
			'__CLASS__'		=> __CLASS__
		);
		echo str_replace(array_keys($replaces), array_values($replaces), $code);
	}

	/**
	 * N'affiche pas le formulaire des commentaires sur le site si l'adresse IP du visiteur est bannie.
	 * */
	public function plxMotorPreChauffageEnd() {
		$code = <<< 'plxMotor_PreChauffage_End'
<?php
if($this->plxPlugins->aPlugins['__CLASS__']->isIP_banned()) {
	$this->aConf['allow_com'] = false;
}
?>
plxMotor_PreChauffage_End;
		echo str_replace('__CLASS__', __CLASS__, $code);
	}

	public function AdminCommentsFoot() {
		self::print_script_JS(self::COMMENTS_SELECTOR);
	}

}
?>
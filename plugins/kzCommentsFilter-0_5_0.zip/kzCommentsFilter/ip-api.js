(function() {
	'use strict';

	const script = document.querySelector('script[src$="ip-api.js"][data][data-selector]');

	if(script == null) {
		console.log('No element with "script[src$="ip-api.js"][data][data-selector]" selector CSS');
		return;
	}

	const selectorCSS = script.getAttribute('data-selector');
	if(selectorCSS.trim().length == 0) {
		console.log('data-selector is empty');
		return;
	}

	const cells = Array.prototype.slice.call(document.body.querySelectorAll(selectorCSS));
	if(cells.length > 0) {
		const PARAMS = JSON.parse(script.getAttribute('data'));
		const content = sessionStorage.getItem(PARAMS.keyStorage);
		var datas = (content == null) ? { ipList: {}, timeStamp: 0} : JSON.parse(content);
		var ipListUpdated = false;

		function saveDatas() {
			if(!ipListUpdated) { return; }

			const maxIPs = PARAMS.maxIPs;
			if(Object.keys(datas.ipList).length > maxIPs) {
				var index = new Array();
				for(var ip in datas.ipList) {
					index.push([ip, datas.ipList[ip].timeStamp]);
				}
				// Tri selon la valeur de timeStamp
				index.sort(function (a,b) {
					return b[1] - a[1]
				});
				console.log('Trop d\'IPs : ' + index.length);
				console.log(index);
				for(var i=maxIPs, iMax=index.length; i<iMax; i++) {
					delete datas.ipList[index[i][0]];
				}
			}
			console.log(Object.keys(datas.ipList).length + ' IPs enregistrés')
			sessionStorage.setItem(PARAMS.keyStorage, JSON.stringify(datas));
		}

		function setFlags() {
			cells.forEach(function (cell) {
				const ip = cell.getAttribute('data-ip');
				if(ip in datas.ipList) {
					datas.ipList[ip].timeStamp = datas.timeStamp;
					const infos = datas.ipList[ip];

					// Adds a flag in the HTML page. And more...
					const flag = document.createElement('SPAN');
					flag.className = 'kz-flag ' + infos.countryCode;
					flag.title = infos.country;
					cell.appendChild(flag);

					if(infos.city.trim().length > 0) {
						const span = document.createElement('SPAN');
						span.innerHTML = infos.city + ', ' + infos.country;
						cell.appendChild(span);
					}
				}
			});
		}

		function extractIP(text) {
			const matches = text.match(/([1-9]\d{0,2}(?:\.[1-9]\d{0,2}){3})/);
			return (matches != null) ? matches[1] : null;
		}

		function requestForNewIpAddrs() {
			var newIpAddrList = new Array();
			cells.forEach(function (cell) {
				const ip = (cell.hasAttribute('data-ip')) ? cell.getAttribute('data-ip') : extractIP(cell.textContent);
				if(ip != null && !(ip in datas.ipList)) {
					newIpAddrList.push({
						query: ip,
						lang: PARAMS.lang
					});
				}
			});
			if(newIpAddrList.length > 0) {
				const postDatas = JSON.stringify(newIpAddrList);
				const XHR =  new XMLHttpRequest();
				XHR.onreadystatechange = function (event) {
				    if (this.readyState === XMLHttpRequest.DONE) {
				        if (this.status === 200) {
							const infosList = JSON.parse(this.responseText);
							infosList.forEach(function (infos) {
								if(infos.status == 'success') {
									const ip = infos.query;
									delete infos.query;
									infos.timeStamp = datas.timeStamp;
									datas.ipList[ip] = infos;
									ipListUpdated = true;
								}
							});
							setFlags();
							saveDatas();
				        } else {
				            console.log("Status de la réponse: %d (%s)", this.status, this.statusText);
				        }
				    }
				}

				XHR.open('POST', PARAMS.provider, true);
				XHR.setRequestHeader('Accept', 'application/json');
				XHR.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
				XHR.send(postDatas);
			} else {
				setFlags();
			}
		}

		requestForNewIpAddrs();
	} else {
		console.log('No element with "' + selectorCSS + '" CSS selector');
	}
})();
<?php
if (isset($plugin))
	// Pluxml version 5.4
	$plugin_name = $plugin;
else if (isset($help) and ($help == 'plugin') and isset($page))
	// Pluxml version 5.5
	$plugin_name = $page;
else
	$plugin_name = false;

$logos = '&nbsp;';
if ($plugin_name) {
$myPlugin = $plxAdmin->plxPlugins->aPlugins[$plugin_name];
	$plugin_root = $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].$plugin_name.'/';
	$logos = <<< LOGOS
		<a href="http://www.tinymce.com/" target="_blank"><img src="${plugin_root}tinymce.png" alt="logo de TinyMCE" width="153" height="79" /></a>

LOGOS;
	 ?>
<h3>By <?php echo $myPlugin->getInfo('author'); ?></h3>
<?php }?>
<div id="tinyMCE-help">
	<p>
		Ce plugin vous offre un éditeur évolué pour la rédaction de vos articles et de vos pages statiques.
	</p><p>
		TinyMCE fournit de multiples plugins et options pour son éditeur :
	</p><ul>
		<li><a href="https://www.tinymce.com/docs/plugins/" target="_blank">Liste de plugins internes</a></li>
		<li><a href="https://www.tinymce.com/docs/configure/" target="_blank">Options de configuration</a></li>
		<li><a href="https://www.tinymce.com/docs/get-started/basic-setup/#toolbarmenuconfiguration" target="_blank">Contrôles pour le menu et la barre d'outils</a></li>
	</ul><p>
		Un plugin externe ajoute la coloration syntaxique pour l'édition du code source. Il utilise la bibliothèque de l'éditeur <a href="http://codemirror.net/" target="_blank">Codemirror</a>.
	</p><p>
		Pour la gestion des fichiers dans TinyMCE, en particulier des images, une extension a spécialement été développée pour PluXml, de façon à utiliser son gestionnaire de médias.
	</p><p>
		Une extension de Tinymce permet d'insérer directement un lien pointant sur un article, une catégorie ou un ensemble de tags. Dans la fenêtre popup qui s'affiche, après avoir cliqué sur l'icône du lien dans la barre d'outils ou dans le menu contextuel, choisissez une option dans la liste déroulante "Link list".
	</p><p>
		Afin de bénéficier des dernières mises à jour, la bibliothèque minifiée de TinyMCE est téléchargée depuis le CDN (<i><a href="http://fr.wikipedia.org/wiki/Content_delivery_network" target="_blank">Content Delivery Network</a></i>). L'adresse du CDN utilisé est <a href="https://cdnjs.com/libraries/tinymce/">https://cdnjs.com/libraries/tinymce/</a>.
	</p><p>
		Si toutefois, vous souhaitez installer cette librairie sur votre serveur, récupérez l'archive zip "Download TinyMCE Community" à l'adresse <a href="https://www.tinymce.com/download/">https://www.tinymce.com/download/</a> et dépliez la dans le dossier du plugin <strong>tinyMCE</strong>.
	</p><p>
		Pour l'interface utilisateur, vous disposez d'autres traductions à <a href="http://www.tinymce.com/i18n/" target="_blank">http://www.tinymce.com/i18n/</a>. Une fois téléchargée, l'archive zip est à décompresser dans le répertoire "tinymce/js/tinymce/langs" situé dans le dossier du plugin. Par défaut, ce plugin contient toutes les langues référencées dans PluXml. Si vous souhaitez les réinstaller, lancer le script install_langs.sh contenu dans le dossier du plugin. Pour cela, votre serveur doit être installé sous <a href="https://fr.wikipedia.org/wiki/Linux">Linux</a>.
	</p><p>
		Vous pourrez personnaliser l'apparence de TinyMCE en créant votre propre "skin" <a href="http://skin.tinymce.com/"  target="_blank">ici</a>. Il faudra pour cela vous armer de patience. Cela fait, décompressez l'archive obtenu dans le dossier "tinyMCE/skins" du plugin et indiquez dans la variable du script tinyMCE.php le nom de votre skin. Par défaut, TinyMCE fournit le skin lightgray.
	</p><p>
<?php echo $logos; ?>
	</p>
</div>
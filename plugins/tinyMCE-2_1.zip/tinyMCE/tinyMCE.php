<?php

if (!defined('PLX_ROOT')) { exit; }

/**
 * Plugin Tinymce pour PluXml.
 *
 * Site de Tinymce: http://www.tinymce.com
 * La bibliothèque en ligne est disponible à : https://cdnjs.cloudflare.com/ajax/libs/tinymce/.
 * Elle est également disponible à : //cloud.tinymce.com/stable/tinymce.min.js?apikey='. Mais, il faut une "API KEY".
 * Pour intégrer la bibliothèque de Tinymce sur le serveur, voir https://www.tinymce.com/download/custom-builds/.
 *
 * Utilise le gestionnaire de médias de PluXml pour la sélection d'images dans Tinymce.
 * Dans le gestionnaire de médias, cliquer sur le lien de l'image ou son aperçu, pour insérer dans le document.
 * Les liens sont transformés en adressage absolu ( voir options : relative_urls, remove_script_host, document_base_url )
 *
 * Tinymce a un plugin codesample pour afficher le code source dans un article. Utilise la bibliothèque de http://prismjs.com
 *
 * Plugins externes pouvant être intégrés ultérieurement :
 *   - https://github.com/josh18/TinyMCE-FontAwesome-Plugin
 *   - ttps://github.com/RichGuk/syntaxhl
 *   - https://github.com/leevh/codemagic (plugin pour codemirror)
 * */
class tinyMCE extends plxPlugin {

	const TINYMCE_LIB = 'https://cdnjs.cloudflare.com/ajax/libs/tinymce/4.6.5/tinymce.min.js';

	const LOCAL_MINIFY_LIB = '/tinymce/js/tinymce/tinymce.min.js'; // doit débuté avec un slash
	const BUNDLE = '/tinymce/js/tinymce/tinymce.full.min.js';

	// code et advcode sont incompatibles. Voir Tinymce. advcode nécessite une offre payante
	// manque : 'colorpicker, bbcode'
	const MCE_PLUGINS =
		'wordcount fullscreen save visualchars charmap '.
		'advlist autolink link image imagetools media lists hr anchor '.
		'emoticons searchreplace preview visualblocks nonbreaking '.
		'table contextmenu directionality template paste textcolor autoresize '.
		'help autosave code codesample';
	const BASIC_PLUGINS = 'wordcount fullscreen save';
	const MCE_PLUGINS_SITE = 'wordcount charmap autolink lists hr emoticons table nonbreaking';

	public $weightProfils = array(PROFIL_ADMIN=>128, PROFIL_MANAGER=>64, PROFIL_MODERATOR=>32, PROFIL_EDITOR=>16, PROFIL_WRITER=>8);

	private $__scriptname = false;
	protected $__user = false;

	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$scriptname = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');

		if(
			isset($_SESSION['profil']) and
			!empty(intval($this->getParam($scriptname)) & $this->weightProfils[$_SESSION['profil']])
		) {
			$this->addHook('AdminFootEndBody', 'AdminFootEndBody');
			$this->__user = intval($_SESSION['profil']);
		}
		$this->__scriptname = $scriptname;

		$this->addHook('plxMotorConstruct', 'plxMotorConstruct');
		$this->addHook('AdminIndexFoot', 'AdminIndexFoot');
		$this->addHook('AdminMediasFoot', 'AdminMediasFoot');

		# Edition des commentaires côté site
		if(!empty($this->getParam('comment_site'))) {
			$this->addHook('ThemeEndBody', 'ThemeEndBody');
		}

	}

	public function onDelete() {
		# Pour anciennes version du plugin
		$filename = substr(__DIR__, 0, -strlen(__CLASS__)).'tinyMCE-pluxml.js';
		if (is_writable($filename)) {
			unlink($filename);
		}
	}

	public function get_context($plxMotor) {
		$this->plx_racine = $plxMotor->racine;
		$this->plx_plugin_root = $plxMotor->racine.$plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		$this->plx_aConf = $plxMotor->aConf;
		$this->plx_theme = $plxMotor->racine.$plxMotor->aConf['racine_themes'].$plxMotor->style;
	}

	public function initValues() {
		$formats = <<< EOT
{title: 'Image Left', selector: 'img', styles: {'float': 'left', 'margin': '0 10px 0 10px'}},
{title: 'Image Right', selector: 'img', styles: {'float': 'right', 'margin': '0 10px 0 10px'}},
{title: 'centrer', selector: 'p', classes: 'center'},
{title: 'Centrer blocs', selector: 'p, div', classes: 'center-blocks'},
{title: 'N° lignes', selector: 'pre', classes:'line-numbers'}
EOT;
		$initValues = array(
			'cdn'		=> '0', // plxPlugin->getParam('...') retourne une chaine de caractères
			'article'	=> 248, // 128+64+32+16+8
			'statique'	=> 0,
			'comment'	=> 248,
			'user'		=> 248,
			'codemirror'=> 128,
			// 'parametres_edittpl'=>128,
			'selector'	=> '#id_chapo, #id_content',
			'codemirror'=> 128,
			'css_theme'	=> 1,
			'styleformats'=> $formats,
			'plugins0'	=> $this::MCE_PLUGINS,
			'plugins1'	=> $this::BASIC_PLUGINS,
			'plugins2'	=> $this::BASIC_PLUGINS,
			'plugins3'	=> $this::BASIC_PLUGINS,
			'plugins4'	=> $this::BASIC_PLUGINS,
		);
		foreach($initValues as $field=>$value) {
			$this->setParam($field, $value, is_numeric($value) ? 'numeric' : 'string');
		}
	}

	public function get_skins() {
		$items = array(''=>'Par défaut');
		foreach(array('extras/skins/', 'tinymce/js/tinymce/skins/') as $folder) {
			if(is_dir(__DIR__.'/'.$folder)) {
				$files = glob(__DIR__.'/'.$folder.'*', GLOB_ONLYDIR);
				if (!empty($files)) {
					foreach ($files as $file1) {
						$value = substr(strrchr($file1, '/'), 1);
						$items[$folder.$value] = ucfirst($value);
					}
				}
				else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
					echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
					$dir = new DirectoryIterator(__DIR__.$folder.'.');
					foreach ($dir as $fileinfo) {
						if ($fileinfo->isDir() && !$fileinfo->isDot()) {
							$filename = $fileinfo->getFilename();
							$items[$folder.$filename] = ucfirst($filename);
						}
					}
					asort($items);
				}
				break;
			}
		}
		return $items;
	}

	private function __print_mce_link_list_option() {
		//link_list				: <?php $this->__build_link_list_option();
		// https://www.tinymce.com/docs/plugins/link/#link_list

		global $plxAdmin;

		$sub_links = array();

		$top_lines1 = array();

		if(!empty($plxAdmin->aCats)) {
			$lines = array();
			foreach($plxAdmin->aCats as $k=>$v) {
				$title = addslashes($v['name']);
				$value = $plxAdmin->urlRewrite('?categorie'.intval($k).'/'.$v['url']);
				$lines[] = <<< CATS
					{ title: '$title', value: '$value' }
CATS;
			}
			if(!empty($lines)) {
				$menu = implode(",\n", $lines);
				$title = addslashes(L_MENU_CATEGORIES);
				$top_lines1[] = <<< CATEGORIES
			{
				title	: '$title',
				menu	: [
$menu
				]
			}
CATEGORIES;
			}
		}

		if(! empty($plxAdmin->aTags)) {
			// voir plxShow::tagList()
			$today = date('YmdHi');
			$tagsList = array();
			foreach($plxAdmin->aTags as $idArt => $infosArt) {
				if(! empty($infosArt['active'] and ! empty(trim($infosArt['tags']))) and ($infosArt['date'] <= $today)) {
					$tagsArt = array_map('trim', explode(',', $infosArt['tags']));
					foreach($tagsArt as $tag) {
						if(array_key_exists($tag, $tagsList)) {
							$tagsList[$tag]++;
						} else {
							$tagsList[$tag] = 1;
						}
					}
				}
			}

			if(! empty($tagsList)) {
				uksort($tagsList, function($item1, $item2) {
					return strcasecmp($item1, $item2);
				});
				$lines = array();
				foreach($tagsList as $k=>$v) {
					$title = addslashes($k).' ('.$v.')';
					$value = $plxAdmin->urlRewrite('?tag/'.plxUtils::title2url($k));
					$lines[] = <<< TAGS
					{ title: '$title', value: '$value' }
TAGS;
				}
				if(!empty($lines)) {
					$title = addslashes(L_ARTICLE_TAGS_FIELD);
					$menu = implode(",\n", $lines);
					$top_lines1[] = <<< TAGS
			{
				title	: '$title',
				menu	: [
$menu
				]
			}
TAGS;
				}
			}
		}

		if(!empty($plxAdmin->aStats)) {
			$statsGroups = array();
			foreach($plxAdmin->aStats as $idStat=>$infosStat) {
				if(! empty($infosStat['active']) and ($infosStat['date_update'] <= $today)) {
					$group = strtolower(trim($infosStat['group']));
					if(empty($group)) {
						$group = 'zzzzzzzzzzz';
					}
					if(!array_key_exists($group, $statsGroups)) {
						$statsGroups[$group] = array();
					}
					$link = $plxAdmin->urlRewrite("?static$idStat/${infosStat['url']}");
					$statsGroups[$group][ucfirst($infosStat['name'])] = $link;
				}
			}
			ksort($statsGroups);

			$lines = array();
			foreach($statsGroups as $group=>$options) {
				ksort($options);
				$sub_lines = array();
				foreach($options as $title=>$value) {
					$title1 = addslashes($title);
					$sub_lines[] = <<< SUB_LINE
					{ title: '$title1', value: '$value' }
SUB_LINE;
				}
				if(!empty($sub_lines)) {
					$menu = implode(",\n", $sub_lines);
					if(count($statsGroups) == 1) {
						$lines[] = $menu;
					} else {
						$title = addslashes(($group != 'zzzzzzzzzzz') ? $group : ucfirst($this->getLang('OTHERS_PAGES')));
						$lines[] = <<< STATS_GROUP
				{
					title	: '$title',
					menu	: [
$menu
					]
				}
STATS_GROUP;
					}
				}
			}
			if(!empty($lines)) {
				$menu = implode(",\n", $lines);
				$title = addslashes(L_MENU_STATICS);
				$top_lines1[] = <<< STATICS
			{
				title	: '$title',
				menu	: [
$menu
				]
			}

STATICS;
			}

			if(!empty($top_lines1)) {
				$list_link = implode(",\n", $top_lines1);
				echo <<< LINK_LIST
		link_list				: [
$list_link
		],

LINK_LIST;
			}
		}
	}

	private function __print_mce_external_plugins_options() {
		global $plxAdmin;

		/*
		$codesample_content_css = $this->getParam('repo_prism');
		if(!empty($codesample_content_css)) {
			$result['codesample_content_css'] = $plxAdmin->racine.$codesample_content_css; // conversion en adresse absolue
		}
		* */
		$mask_user = $this->weightProfils[$this->__user];
		$lines = array();
		foreach(explode(' ', 'codemirror prismjs codemagic') as $plugin) {
			$filename = $plugin.'/tinymce/plugin.min.js';
			if(
				array_key_exists($plugin, $plxAdmin->plxPlugins->aPlugins) and
				!empty(intval($this->getParam($plugin)) & $mask_user) and
				file_exists(PLX_PLUGINS.$filename)
			) {
				// adresse absolue requise !
				$url = $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].$filename;
				$lines[] = <<< PLUGIN
				$plugin	: '$url'
PLUGIN;
			}
		}
		if(!empty($lines)) {
			$plugins = implode(",\n", $lines);
			echo <<< START_EXTERNAL_PLUGINS
		external_plugins	: {
$plugins
		},

START_EXTERNAL_PLUGINS;
		}
	}

	private function __print_mce_launch($site=false) {
		global $plxAdmin;

		// selectors CSS for blocks to apply TinyMCE
		$selector = trim($this->getParam('selector'));
		if(empty($selector)) $selector = 'textarea';

		// https://www.tinymce.com/docs/configure/content-formatting/#style_formats_merge

?>
	<script type="text/javascript">
	tinymce.init({
		selector			: '<?php echo $selector; ?>',
		plugins				: '<?php echo (!$site) ? $this->getParam('plugins'.$this->__user) : $this::MCE_PLUGINS_SITE; ?>',
		toolbar				:
			'save undo redo | bold italic styleselect ' +
			'alignleft aligncenter alignright alignjustify | ' +
			'bullist numlist outdent indent | ' +
			'link image media anchor emoticons | ' +
			'forecolor backcolor | ' +
			' charmap visualchars fullscreen code codesample',
		// menubar			: 'insert tools restoredraft', // 2017-08-01
		document_base_url	: '<?php echo $this->plx_racine; ?>',
<?php
		if(!$site) {
			// Pictures are not managing in the front end
			// used by imagetools plugin from Tinymce
			// https://www.tinymce.com/docs/advanced/php-upload-handler
			$images_upload_url = $this->plx_plugin_root.'postAcceptor.php';
			// used by postAcceptor.php
			$path1 = ($plxAdmin->aConf['userfolders'] and ($this->__user == PROFIL_WRITER)) ? $this->__user.'/' : '';
			$images_upload_base_path = $plxAdmin->aConf['medias'].$path1;
			$files_root = substr(dirname(__FILE__), 0, -strlen($plxAdmin->aConf['racine_plugins'].__CLASS__));
			$_SESSION['tinyMCE_medias'] = $files_root.$plxAdmin->aConf['medias'].$path1;
?>
		imagetools_toolbar	: 'rotateleft rotateright | flipv fliph | editimage imageoptions',
		image_advtab		: true,
		image_description	: true,
		image_title			: true,
		image_caption		: true,
		image_class_list	: [
			{
				title	: 'Aucune',
				value	: ''
			},
			{
				title	: 'Galerie n°1',
				value	: 'lightbox-1'
			},
			{
				title	: 'Galerie n°2',
				value	: 'lightbox-2'
			},
			{
				title	: 'Galerie n°3',
				value	: 'lightbox-3'
			}
		],
		images_upload_url		: '<?php echo $images_upload_url; ?>',
		images_upload_base_path	: '<?php echo $images_upload_base_path; ?>',
		images_reuse_filename	: true,
		file_browser_callback_types	: 'file image',
		media_alt_source		: false,
		paste_data_images		: true,
<?php
		}
?>
		paste_as_text			: true,
		entities				:
			'160,nbsp,38,amp,34,quot,162,cent,169,copy,174,reg,' +
			<?php /* http://www.tinymce.com/wiki.php/Configuration:entity_encoding */ ?>
			'8482,trade,8240,permil,60,lt,62,gt,8804,le,8805,ge,' +
			'176,deg,8722,minus',
		// video_template_callback	: myVideo_template_callback,
		save_onsavecallback		: saveDocument,
		nonbreaking_force_tab	: true,
<?php $this->__print_mce_link_list_option(); ?>
		// https://www.tinymce.com/docs/configure/content-formatting/#style_formats_merge
		style_formats_merge		: <?php echo (!empty($this->getParam('style_formats_merge'))) ? 'true' : 'false'; ?>,
<?php
		$skin = $this->getParam('skin');
		if (! empty($skin) and is_readable(__DIR__.'/'.$skin)) {
?>
		skin_url				: '<?php echo $this->plx_plugin_root.$skin; ?>',
<?php
		}

		// checkout for language
		$lang = $this->default_lang;
		if($lang != 'en') {
			$i18N = array('en'=>'en_GB', 'fr'=>'fr_FR', 'pt'=>'pt_PT');
			if (array_key_exists($lang, $i18N))
				$lang = $i18N[$lang];
?>
		language				: '<?php echo $lang; ?>',
<?php
			if(!empty($this->getParam('cdn'))) {
				$language_url =
					$this->plx_plugin_root.
					pathinfo($this::LOCAL_MINIFY_LIB, PATHINFO_DIRNAME).
					"/langs/$lang.js";
?>
		language_url			: '<?php echo $language_url; ?>',
<?php
			}
		}
		// https://www.tinymce.com/docs/configure/content-appearance/#content_css
		if (! empty($this->getParam('css_theme'))) {
			if(in_array($this->__scriptname, explode(' ', 'article statique'))) {
?>
		content_css				: [
			'<?php echo $this->plx_theme; ?>/css/plucss.css',
			'<?php echo $this->plx_theme; ?>/css/theme.css'
		],
<?php
			}
		}
		# styleformats param is stored in javascript context. Don't ##json_encode## again !
		$style_formats = trim($this->getParam('styleformats'));
		if(!empty($style_formats)) {
?>
		style_formats			: [
<?php echo $style_formats; ?>

		],
<?php
		}

		if(!$site) {
			$this->__print_mce_external_plugins_options();
		}
		// https://www.tinymce.com/docs/configure/content-appearance/#body_class
		// https://www.tinymce.com/docs/configure/content-appearance/#body_id: Pas utilisé par le thème par défaut
		$body_classes = array(
			'article'		=> 'container',
			'statique'		=> 'static-page',
			'comment'		=> 'comment',
			'new_comment'	=> 'body-article', // A vérifier
			'user'			=> 'admin-page' // A vérifier
		);
		if(array_key_exists($this->__scriptname, $body_classes)) {
			$body_class = $body_classes[$this->__scriptname];
?>
		body_class				: '<?php echo $body_class; ?>',
<?php
		}
?>
		file_picker_callback	: myFile_picker_callback
	});
	</script>
<?php
	}

// ------------- Hooks start here ----------------------------------
	public function plxMotorConstruct() {
		echo '<?php $this->plxPlugins->aPlugins["'.__CLASS__.'"]->get_context($this); ?>';
	}

	public function AdminFootEndBody($site=false) {
?>
		<!-- ========= plugin: <?php echo __CLASS__; ?> $this->__scriptname : <?php echo $this->__scriptname; ?> ========== -->
<?php
		if(
			!empty($this->getParam('cdn')) or
			!is_readable(__DIR__.$this::LOCAL_MINIFY_LIB)
		) {
			// loading library for TinyMCE via CDN
			$src = $this::TINYMCE_LIB;
		} else {
			// loading library for TinyMCE locally
			$src = $this->plx_plugin_root;
			$src .= (file_exists(__DIR__.$this::BUNDLE)) ? $this::BUNDLE : $this::LOCAL_MINIFY_LIB;
		}
?>
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__; ?>/tinyMCE.js"></script>
	<script type="text/javascript" src="<?php echo $src; ?>"></script>
<?php
		$this->__print_mce_launch($site); // Lance Tinymce avec ses options
	}

/* ---------------------- for using core/admin/medias.php as medias manager ----------------- */
	public function AdminMediasFoot($params=false) {
		global $plxAdmin;

		if (defined('PLX_VERSION')) {
			$versionPluxml = PLX_VERSION;
		} else {
			$versionPluxml = strval($plxAdmin->version);
		}
		$idTable = (version_compare($versionPluxml, '5.4', '<')) ? 'list-files' : 'medias-table'; ?>
		<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
		<script type="text/javascript">
			setMediasForTinyMCE('<?php echo $idTable; ?>', '<?php echo $versionPluxml; ?>', 'media');
		</script>
<?php
	}

/* --------------- for using core/admin/index.php as articles manager like medias manager ------- */
	public function AdminIndexFoot() {

		if (defined('PLX_VERSION')) {
			$versionPluxml = PLX_VERSION;
		} else {
			global $plxAdmin;
			$versionPluxml = strval($plxAdmin->version);
		}
		$idTable = (version_compare($versionPluxml, '5.4', '<')) ? 'table' : 'articles-table'; ?>
		<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
		<script type="text/javascript">
			setMediasForTinyMCE('<?php echo $idTable; ?>', '<?php echo $versionPluxml; ?>', 'file');
		</script>
<?php
	}

	public function ThemeEndBody() {
		// Tester si on est en mode article et si les commentaires sont autorisés pour cette article
		$this->AdminFootEndBody(true);
	}

}

?>
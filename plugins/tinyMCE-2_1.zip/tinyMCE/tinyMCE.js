/*
 * See documentation at following links :
 * http://www.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 * */
// updated on 2015-12-20

if (typeof String.prototype.capitalize !== 'function') {
	String.prototype.capitalize = function() {
		return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
	}
}

function setMediasForTinyMCE(idTable, versionPluxml, filetype) {
	// hide some nodes in medias.php if the HTML page is loaded in an iframe.

	var myFrame = window.frameElement;
	if (myFrame) {
		document.body.classList.add('myTinyMCE');
		var parentId = myFrame.parentNode.id;
		if (parentId && (parentId.indexOf('mce') == 0)) {
			var mediasList = document.getElementById(idTable);
			if (mediasList) {
				switch (filetype) {
					case 'media' :
						var labelCol = document.querySelector('#'+idTable+' th:nth-of-type(4)');
						if (labelCol)
							labelCol.innerHTML = 'Ext.';
						var folder = document.querySelector('#folder');
						if (folder) {
							folder.setAttribute('onchange', 'this.form.submit();');
						}
						var tbody = document.querySelector('#'+idTable+' tbody');
						if (tbody)
							tbody.addEventListener('click', function(event) {
								if (event.target.tagName == 'A') {
									var anchor1 = event.target;
									if (confirm('Ajouter dans l\'éditeur\n' + anchor1.href.split(/[\\/]/).pop()+'\n'+anchor1.href)) {
										var args = top.tinymce.activeEditor.windowManager.getParams();
										var href= anchor1.href, options, title = 'titre par défault';
										switch (args.mediaType) {
											case 'file' :
												var matches = /^.*\/([^\/]+)\.[a-z,0-9]+$/.exec(href);
												var text = (matches) ? matches[1].capitalize() : '';
												options = {title: 'Voir le média', text: text};
												break;
											case 'image' :
												var matches = /^.*\/([^\/\.]+)(?:\.tb)?\.(?:jpg|jpeg|png|gif)$/.exec(href);
												if (matches)
													title = matches[1].capitalize();
												options = {title: title, alt: 'Image'};
												break;
											default :
										}
										args.oninsert(href, options);
										// fermer la fenetre
										top.tinymce.activeEditor.windowManager.close();
									}
									event.preventDefault();
									// pour IE < 9
									event.returnValue = false;
								}
							});
						break;
					case 'file' :
						var idArt = document.querySelector('#form_articles th:nth-of-type(2)');
						if (idArt != null) {
							idArt.innerHTML = 'Id.';
						}
						var id_sel_cat = document.getElementById('id_sel_cat');
						if (id_sel_cat && (id_sel_cat.tagName == 'SELECT'))
							id_sel_cat.addEventListener('change', function (event) {
								var aForm = event.target.form;
								aForm.submit();
							});
						var okBtn = document.querySelector('#id_sel_cat + input');
						if (okBtn) {
							// <input type="submit" /> with name="submit" conflicts with TinyMCE. Just rename it !
							okBtn.name = 'btn1';
						}
						var element = document.querySelector('#form_articles div:first-of-type');
						if (element) {
							var mediasBtn = document.createElement('input');
							mediasBtn.setAttribute('type', 'button');
							mediasBtn.setAttribute('value', 'Medias');
							mediasBtn.setAttribute('onclick', 'document.location = \'medias.php\'');
							element.appendChild(mediasBtn);
						}
						var tbody = document.querySelector('#'+idTable+' tbody');
						if (tbody)
							tbody.addEventListener('click', function(event) {
								if (event.target.tagName == 'A') {
									var href = event.target.href;
									var res;
									var id = (res = /^.*?a=(\d{4})$/.exec(href)) ? res[1] : '';
									var text = event.target.textContent;
									if (confirm('article n° '+id+'\nTitre: '+text)) {
										var href = 'index.php?article'+id+'/'+text;
										var args = top.tinymce.activeEditor.windowManager.getParams();
										args.oninsert(href, {text: text, title: 'Voir l\'article'});
										// fermer la fenetre
										top.tinymce.activeEditor.windowManager.close();
									}
									event.preventDefault();
									// pour IE < 9
									event.returnValue = false;
								}
							});
						break;
				}
			}
			else
				console.log('Id ' + idTable + ' element not found');
		}
	}
}

// launch by file_picker_callback
var myFile_picker_callback = function (callback, value, meta) {

	if (meta.filetype == 'file')
		tinymce.activeEditor.windowManager.open(
			{
				title: "Insérer un lien pour un article publié",
				url: 'index.php?sel=published',
				width: 850,
				height: 800
			},
			{
				oninsert: function (url, options) { callback(url, options); },
				mediaType: meta.filetype
			}
		)
	else
		tinymce.activeEditor.windowManager.open(
			{
				title: "Insérer un média",
				url: 'medias.php',
				width: 800,
				height: 600
			},
			{
				oninsert: function (url, options) { callback(url, options); },
				mediaType: meta.filetype
			}
		)
}

/*
 * N'est plus nécessaire avec la dernière version de Tinymce au 2017-08-12
var myVideo_template_callback = function (data) {
	var urlPattern = {regex: /dailymotion\.com\/video\/([^_]+)/, type: 'iframe', w: 560, h: 315, url: '//www.dailymotion.com/embed/video/$1', allowFullscreen: true};
	var match;
	if ((match = urlPattern.regex.exec(data.source1))) {
		var url = urlPattern.url.replace('$1', match[1]);
		var allowFullscreen = urlPattern.allowFullscreen ? ' allowFullscreen="1"' : '';
		return '<iframe src="' + url + '" width="' + urlPattern.w + '" height="' + urlPattern.h + '"' + allowFullscreen + '></iframe>';
	} else
		return '<video width="' + data.width + '" height="' + data.height + '"' + (data.poster ? ' poster="' + data.poster + '"' : '') + ' controls="controls">\n' + '<source src="' + data.source1 + '"' + (data.source1mime ? ' type="' + data.source1mime + '"' : '') + ' />\n' + (data.source2 ? '<source src="' + data.source2 + '"' + (data.source2mime ? ' type="' + data.source2mime + '"' : '') + ' />\n' : '') + '</video>';
}
*/

window.addEventListener('load', function (event) {
	// Hack against Pluxml with its stupid z-index=9999
	var aStyle = document.createElement('style');
	aStyle.type = 'text/css';
	aStyle.innerHTML = '\
form:first-of-type > div:first-of-type { z-index: 99; } \
@media (max-width: 767px) {\
	.aside .responsive-menu { z-index: 99; }\
}';
	document.head.appendChild(aStyle);

	// restore fullscreen after saving
	setFullscreen();
});

function saveDocument() {
	var id1 = tinyMCE.activeEditor.id;
	sessionStorage.setItem('tinyMCE-fullscreen', tinyMCE.activeEditor.plugins.fullscreen.isFullscreen());
	sessionStorage.setItem('tinyMCE-editorId', id1);
	var textArea = document.getElementById(id1);
	if (textArea) {
		var form1 = textArea.form;
		var submitBtn = form1.querySelector('input[type="submit"][name="update"]');
		if (! submitBtn) {
			submitBtn = form1.querySelector('input[type="submit"]');
		}
		if (submitBtn) {
			submitBtn.click();
		}
	}
}

function setFullscreen() {
	if ((sessionStorage.getItem('tinyMCE-fullscreen') === true) && sessionStorage.getItem('tinyMCE-editorId')) {
		var id1 = sessionStorage.getItem('tinyMCE-editorId');
		tinyMCE.editors.every(function(editor) {
			if (id1 && (editor.id == id1)) {
				editor.focus();
				editor.execCommand('mceFullScreen', false);
				sessionStorage.setItem('tinyMCE-fullscreen', false);
				return false;
			} else {
				return true;
			}
		});
	}
}
#!/bin/sh

CURRENT_PWD=$(pwd)
cd $(dirname ${0})

PLUGIN_NAME=$(basename $PWD)
VERSION=$(\
	grep "<version>" infos.xml \
	| sed 's/^\s*<version>\([^<]*\)<\/version>.*$/\1/' \
)
echo "\n\033[33mPlugin ${PLUGIN_NAME} - version ${VERSION}\033[0m\n"

cd ..

ZIP_NAME="${CURRENT_PWD}/${PLUGIN_NAME}-$(echo ${VERSION} | sed 's/\./_/g').zip"

zip -r -o ${ZIP_NAME}  \
	${PLUGIN_NAME}/*.* \
	${PLUGIN_NAME}/css/* \
	${PLUGIN_NAME}/extras/* \
	${PLUGIN_NAME}/lang/* \
	${PLUGIN_NAME}/prism/* \
	${PLUGIN_NAME}/tinymce/src/skins/perso/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/skins/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/langs/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/*/img/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/*/css/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/*.min.js \
	${PLUGIN_NAME}/tinymce/js/tinymce/*.txt \
	${PLUGIN_NAME}/tinymce/js/tinymce/themes/*/*.min.js \
	${PLUGIN_NAME}/tinymce/src/skins/perso/src/*

echo "\nNom complet de l'archive du plugin:\n\033[32m${ZIP_NAME}\033[0m\n"

cd $OLDPWD

echo "Done !"
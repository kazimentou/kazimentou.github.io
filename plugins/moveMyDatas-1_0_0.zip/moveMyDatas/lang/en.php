<?php
$LANG = array(
	'ALTER'					=> 'Change',
	'CONFIRM_RENAME'		=> 'Would you change\nthe name of the current directory',
	'DATA_FOLDER'			=> 'Data directory',
	'FOLDER'				=> 'Folder',
	'FOLDER_EXISTS'			=> 'The %s folder already exists.',
	'HELP'					=> 'Lists every folder with a <strong>parametres.xml</strong> file inside',
	'MISSING_NAME'			=> 'Input a new name',
	'INVALIDATE_NEW_NAME'	=> 'Bad name for the new folder',
	'INVALIDATE_OLD_NAME'	=> 'The folder %s is unknown',
	'MISSING_NAME'			=> 'Give a name for the new folder',
	'NAME_IN_USE'			=> 'This folder already exists',
	'NEW_FOLDER'			=> 'New folder',
	'NEW_NAME'				=> 'New folder',
	'NEW_NAME_PLACEHOLDER'	=> 'For a new folder or the current folder',
	'OLD_NAME'				=> 'Current folder',
	'CURRENT_FOLDER'		=> 'Current folder of datas',
	'TITLE'					=> 'Change or rename the folder of datas',
	'UNWRITABLE_FILE'		=> 'No right for writing the %s file',
	'UNWRITABLE_FOLDER'		=> 'No right for adding any file int the % folder.',
);
?>

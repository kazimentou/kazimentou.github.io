<?php
if(!defined('PLX_ROOT')) { exit; }

# Control du token du formulaire
plxToken::validateFormToken($_POST);

if(is_writable($plxPlugin->config_filename)) {
	if(!empty($_POST)) {
		$plxPlugin->process(
			filter_input(INPUT_POST, 'old_name', FILTER_SANITIZE_STRING),
			filter_input(INPUT_POST, 'new_name', FILTER_SANITIZE_STRING)
		);
		header('Location: index.php');
		exit;
	}
} else {
	// Impossible de modifier le fichier config.php à la racine du site
	plxMsg::Error(sprintf($plxPlugin->getLang('UNWRITABLE_FILE'), $plxPlugin->config_filename));
}

?>
<form method="post" id="form_<?php echo $plugin; ?>">
	<h3><?php $plxPlugin->lang('DATA_FOLDER') ?></h3>
	<fieldset>
		<p>
			<label for="id_old_name"><?php $plxPlugin->lang('OLD_NAME') ?><sup>*</sup></label>
<?php $plxPlugin->printDatasFoldersSelect('old_name'); ?>
		</p><p>
			<label for="id_new_name"><?php $plxPlugin->lang('NEW_NAME') ?></label>
			<input type="text" id="id_new_name" name="new_name" maxlength="30" placeholder="<?php $plxPlugin->lang('NEW_NAME_PLACEHOLDER'); ?>"/>
		</p><p class="help">
			<sup>*</sup> <?php $plxPlugin->lang('HELP'); ?>
		</p><p class="in-action-bar">
			<?php echo plxToken::getTokenPostMethod(); ?>
			<input type="submit" value="<?php $plxPlugin->lang('ALTER'); ?>" />
		</p>
	</fieldset>
</form>
<div class="spinner">
<?php readfile(__DIR__.'/spinner.svg'); ?>
</div>
<script type="text/javascript">
	(function() {

		'use strict';

		document.forms[0].addEventListener('submit', function (event) {
			const aForm = event.target;
			var newName = aForm.elements.new_name.value.trim();
			var error = false;
			if (newName.length > 0) {
				newName = newName.replace(/\/?$/, '/');
				const options = aForm.elements.old_name.options;
				for (var i=options.length-1; i>=0; i--) {
					if (options[i].value == newName) {
						alert('<?php $plxPlugin->lang('NAME_IN_USE'); ?>');
						error = true;
						break;
					}
				}
				error = error || !(aForm.elements.old_name.value == '' || confirm('<?php $plxPlugin->lang('CONFIRM_RENAME'); ?>'));
			} else {
				const selectValue = aForm.elements.old_name.value.trim();
				if(selectValue.length == 0) {
					alert('<?php $plxPlugin->lang('MISSING_NAME'); ?>');
					error = true;
				} else if(selectValue == '<?php echo dirname(PLX_CONFIG_PATH).'/'; ?>') {
					alert('<?php $plxPlugin->lang('THIS_IS_THE_CURRENT_FOLDER'); ?>');
					error = true;
				}
			}
			if(error) {
				event.preventDefault();
			} else {
				document.querySelector('#form_<?php echo $plugin; ?> + div.spinner').classList.add('active');
			}
		});
	})();
</script>
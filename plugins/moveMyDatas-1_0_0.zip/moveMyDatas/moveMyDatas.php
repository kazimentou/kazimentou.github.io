<?php
if (!defined('PLX_ROOT')) { exit; }

/**
 * Le plugin moveMyDatas permet de basculer rapidement d'un dossier de données à un autre.
 *
 * Le plugin recherche à la racine du site tous les fichiers parametres.xml
 * pour pouvoir sélectionner un dossier de données dans une liste.
 * Il permet également de renommer un dossier de données existant en mettant à jour les liens
 * dans les articles, pages statiques et commentaires.
 * Il met également à jour le fichier parametres.xml pour les racines des dossiers articles, static, ....
 *
 * Il peut aussi créer un dossier de données.
 *
 * @author	J.P. Pourrez
 * @version	2017-12-14
 * */
class moveMyDatas extends plxPlugin {

	const PARAMS_FILE = 'parametres.xml';
	const PARTIAL_MASK = <<< 'PARTIAL'
\b(define\s*\(\s*(?:'PLX_CONFIG_PATH'|"PLX_CONFIG_PATH")\s*,\s*(?:'|")|const\s*PLX_CONFIG_PATH\s*=\s*(?:'|"))
PARTIAL;
	const CONFIG_MASK = '@'.moveMyDatas::PARTIAL_MASK.'[^'.DIRECTORY_SEPARATOR.']+'.DIRECTORY_SEPARATOR.'@';
	const STATIC_FIELDS = 'name title_htmltag meta_description '.
		'meta_keywords group url active menu template date_creation '.
		'date_update readable';
	const USER_FIELDS = 'login name infos password salt email lang';

	/**
	 * Constructeur de la class moveMyDatas.
	 *
	 * Régle affichage dans le menu latéral gauche.
	 * Récupère l'adresse compléte du fichier config.php.
	 * */
	public function __construct($default_lang='fr') {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->setAdminProfil(PROFIL_ADMIN);
		# Personnalisation du menu admin
		$label = $this->getlang('FOLDER').': '.dirname(PLX_CONFIG_PATH).'/';
		$title = $this->getlang('TITLE');
		$this->setAdminMenu($label, 0, $title);

		/*
		if (basename($_SERVER['SCRIPT_NAME'], '.php') == 'index') {
			$this->addHook('AdminPrepend', 'AdminPrepend');
		}
		 * */

		// $this->addHook('plxAdminConstruct', 'plxAdminConstruct');

		$this->config_filename = realpath(__DIR__.'/'.PLX_ROOT.'config.php');
	}

	/**
	 * Récupère la liste des dossiers contenant un fichier parametres.xml au niveau 2.
	 * */
	public function getDatasFolders() {

		return array_map(
			function($item) {
				return preg_replace('@^'.PLX_ROOT.'([^/]+/).*'.moveMyDatas::PARAMS_FILE.'$@', '$1', $item);
			},
			glob(PLX_ROOT.'*/*/'.moveMyDatas::PARAMS_FILE)
		);
	}

	/**
	 * Crée et remplit une balise <select> pour le panneau admin.php.
	 * */
	public function printDatasFoldersSelect($name) {
?>
		<select id="id_<?php echo $name ?>" name="<?php echo $name ?>">
			<option value=""><?php $this->lang('NEW_FOLDER'); ?></option>
<?php
		$currentFolder = preg_replace('@^([^/]+/).*$@', '$1', PLX_CONFIG_PATH);
		foreach($this->getDatasFolders() as $folder) {
			$selected = ($folder == $currentFolder) ? ' selected' : '';
			echo <<< OPTION
			<option value="$folder"$selected>$folder</option>

OPTION;
		}
?>
		</select>
<?php

	}

	/**
	 * Vérifie le droit en écriture du dossier.
	 * */
	private function writableFiles($folder) {
		global $plxAdmin;

		$folders = array(PLX_CONFIG_PATH);
		foreach(explode(' ', 'articles statiques commentaires') as $k) {
			$folders[] = $plxAdmin->aConf['racine_'.$k];
		}

		$result = true;
		foreach(glob(PLX_ROOT.'{'.explode(',', $folders).'}/*') as $filename) {
			if (!is_writable($filename)) {
				plxMsg::Error(sprintf($this->getLang('UNWRITABLE'), $filename));
				$result = false;
				break;
			}
		}
		return $result;
	}

	/**
	 * Met à jour tous les liens des attributs href et src dans un fichier.
	 * */
	private function __updateFile($params) {

		# enregistre la date du fichier
		$updateTime = filemtime($params['abspath']);
		$filename = $params['abspath'];

		$content = file_get_contents($filename);
		if(!empty($content)) {
			if (
				file_put_contents(
					$filename,
					preg_replace(
						'#(href="|src="|CDATA\[)'.$params['oldName'].'#',
						'$1'.$params['newName'],
						$content
					)
				)
			) {
				# restaure la date du fichier
				return touch($params['abspath'], $updateTime);
			} else {
				# echec
				return false;
			}
		} else {
			return true;
		}
	}

	/**
	 * Renomme le dossier de données en mettant à jour les liens pour les attributs href et src.
	 * */
	private function __renameDatasFolder($oldName, $newName) {
		global $plxAdmin;

		# So, we change the name of the data folder
		$params = array('oldName'=>$oldName, 'newName'=>$newName);

		# $plxAdmin->plxGlob_arts
		$dirname = PLX_ROOT.$plxAdmin->aConf['racine_articles'];
		foreach($plxAdmin->plxGlob_arts->aFiles as $filename) {
			$params['abspath'] = $dirname.$filename;
			if (!$this->__updateFile($params)) {
				plxMsg::Error('Echec sur articles');
				break;
			}
		}

		# $plxAdmin->plxGlob_coms
		$dirname = PLX_ROOT.$plxAdmin->aConf['racine_commentaires'];
		foreach($plxAdmin->plxGlob_coms->aFiles as $filename) {
			$params['abspath'] = $dirname.$filename;
			if (!$this->__updateFile($params)) {
				plxMsg::Error('Echec sur commentaires');
				break;
			}
		}

		# plxAdmin->aStats
		$isDirty = false;
		$genuineFields = explode(' ', moveMyDatas::STATIC_FIELDS);
		$dirname = PLX_ROOT.$plxAdmin->aConf['racine_statiques'];
		foreach($plxAdmin->aStats as $number=>$values) {
			$filename = $number.'.'.$values['url'].'.php';
			$params['abspath'] = $dirname.$filename;
			if (!$this->__updateFile($params)) {
				plxMsg::Error('Echec sur pages statiques');
				break;
			}
			foreach(array_keys($values) as $k) {
				if (!in_array($k, $genuineFields)) {
					$isDirty = true;
					$plxAdmin->aStats[$number][$k] = preg_replace('#^'.$oldName.'#', $newName, $values[$k]);
				}
			}
		}
		if ($isDirty) {
			$plxAdmin->editStatiques(array(), true);
		}

		# plxAdmin->aTags
		# $plxAdmin->editTags();

		# plxAdmin->aUsers
		# $plxAdmin->users($content);

		# modifier le fichier parametres.xml dans le dossier de données
		$content = array();
		$racines = array('racine_articles', 'racine_commentaires', 'racine_statiques', 'medias');
		foreach($racines as $k) {
			$content[$k] = preg_replace('#^'.$oldName.'#', $newName, $plxAdmin->aConf[$k]);
		}
		$plxAdmin->editConfiguration($plxAdmin->aConf, $content);

		#renommer le dossier de données
		rename(PLX_ROOT.$oldName, PLX_ROOT.$newName);

		return true;
	}

	/**
	 * Formate et écrit un fichier XML.
	 * */
	private function __writeXML($content, $filename) {
		$cname = 'constant';

		$xmlContent = <<< XML
<?xml version="1.0" encoding="{$cname('PLX_CHARSET')}"?>
<document>
$content
</document>
XML;
		plxUtils::write($xmlContent, $filename);
	}

	/**
	 * Post the first article and return the first category and tags.
	 * */
	private function __firstArticle($lang, $userId, $folderName) {
		$creation = date('YmdHi');
		$filename = __DIR__."/sample/$lang.tpl";
		if(is_file($filename)) {
			list($titleArt, $categoryArt, $tagsArt, $chapoArt, $contentArt) = explode('<<|>>', file_get_contents($filename));
			$src = __DIR__.'/sample/alice.jpg';
			$medias = $folderName.'medias/';
			$img = $medias.basename($src);
			$thumbArt = $medias.plxUtils::thumbName(basename($img));
			copy($src, PLX_ROOT.$img);
			plxUtils::makeThumb($src, PLX_ROOT.$medias.'.thumbs/'.basename($src), 48, 48);
			plxUtils::makeThumb($src, PLX_ROOT.$thumbArt, 100, 200);
		} else {
			$titleArt = plxUtils::strRevCheck(L_DEFAULT_ARTICLE_TITLE);
			$categoryArt = 'PluXml';
			$tagsArt = 'pluxml';
			list($chapoArt, $contentArt) = explode('-----', file_get_contents(PLX_CORE.'lib/html.article.txt'));
			$thumbArt = 'core/admin/theme/images/pluxml.png';
		}
		$article = <<< ARTICLE
	<title><![CDATA[$titleArt]]></title>
	<allow_com>1</allow_com>
	<template>article.php</template>
	<chapo><![CDATA[$chapoArt]]></chapo>
	<content><![CDATA[$contentArt]]></content>
	<tags><![CDATA[PluXml]]></tags>
	<meta_description></meta_description>
	<meta_keywords></meta_keywords>
	<title_htmltag></title_htmltag>
	<date_creation>$creation</date_creation>
	<date_update>$creation</date_update>
	<thumbnail><![CDATA[$thumbArt]]></thumbnail>
ARTICLE;
		$this->__writeXML($article, PLX_ROOT.$folderName."/articles/0001.001.{$userId}.${creation}.".L_DEFAULT_ARTICLE_URL.'.xml');
		return array($categoryArt, $tagsArt, $creation);
	}

	/**
	 * Crée un nouvel dossier pour les données avec ses fichiers de configuration.
	 * */
	private function __createDatasFolder($folderName) {
		global $plxAdmin, $lang;

		if (!is_dir(PLX_ROOT.$folderName)) {
			if (mkdir(PLX_ROOT.$folderName)) {
				loadLang(PLX_CORE.'lang/'.$lang.'/install.php');

				# create all folders
				$folders = explode(' ', 'articles commentaires statiques medias/.thumbs configuration/plugins');
				foreach($folders as $f) {
					mkdir(PLX_ROOT.$folderName.$f, 0755, true);
				}

				file_put_contents(PLX_ROOT.$folderName.'.htaccess', "Options -Indexes\n");

				$userId = $_SESSION['user']; // 001
				list($titleCat, $tags, $dateArt) = $this->__firstArticle($lang, $userId, $folderName);

				# configurations
				$pattern = '#\b'.dirname(PLX_CONFIG_PATH).'/#';
				$newConfigPath = preg_replace($pattern, $folderName, PLX_CONFIG_PATH);
				foreach(explode(' ', 'CATEGORIES STATICS TAGS PLUGINS USERS') as $k) {
					switch ($k) {
						case 'USERS':
							$user = $plxAdmin->aUsers[$userId];
							$lines = '';
							foreach(explode(' ', moveMyDatas::USER_FIELDS) as $field) {
								$v = $user[$field];
								$lines .= <<< USER_BODY
		<$field><![CDATA[$v]]></$field>
USER_BODY;
							}
							$content = <<< USER
	<user number="$userId" active="1" profil="0" delete="0">
$lines
	</user>
USER;
							break;
						case 'PLUGINS':
							$name = __CLASS__;
							$content = <<< PLUGINS
	<plugin name="$name"></plugin>
PLUGINS;
							break;
						case 'CATEGORIES':
							$content = <<< CATEGORIES
	<categorie number="001" active="1" homepage="1" tri="desc" bypage="5" menu="oui" url="literature" template="categorie.php">
		<name><![CDATA[$titleCat]]></name>
		<description><![CDATA[]]></description>
		<meta_description><![CDATA[]]></meta_description>
		<meta_keywords><![CDATA[]]></meta_keywords>
		<title_htmltag><![CDATA[]]></title_htmltag>
	</categorie>
CATEGORIES;
							break;
						case 'TAGS':
							$content = <<< TAGS
	<article number="0001" date="$dateArt" active="1"><![CDATA[$tags]]></article>
TAGS;
							break;
						default:
							$content = '';
					}
					$target = preg_replace($pattern, $folderName, path('XMLFILE_'.$k));
					$this->__writeXML($content, path('XMLFILE_'.$k, $target));
				}

				$newConfig = array(
					'title'					=> 'Lovely build by MoveMyDatas plugin',
					'meta_description'		=> '',
					'meta_keywords'			=> '',
					'medias'				=> $folderName.'medias/',
					'racine_articles'		=> $folderName.'articles/',
					'racine_commentaires'	=> $folderName.'commentaires/',
					'racine_statiques'		=> $folderName.'statiques/',
					'urlrewriting'			=> 0 /* Important pour forcer la ré-écriture de .htaccess */
				);
				if (is_dir(PLX_ROOT.$plxAdmin->aConf['racine_themes'].'defaut')) {
					$newConfig['style'] = 'defaut';
				}
				$foo = path('XMLFILE_PARAMETERS', preg_replace($pattern, $folderName, path('XMLFILE_PARAMETERS')));
				// $plxAdmin->aConf n'est pas mis à jour (passage de paramètre par valeur)
				$plxAdmin->editConfiguration($plxAdmin->aConf, $newConfig);

				return true;
			} else {
				plxMsg::Error(sprintf($this->getLang('UNWRITABLE_FOLDER'), $folderName));
			}
		} else {
			plxMsg::Error(sprintf($this->getLang('FOLDER_EXISTS'), $folderName));
		}
		return false;
	}

	/**
	 * Met à jour le fichier config.php en fonction du nom du dossier de données.
	 * */
	private function __configUpdate($folder) {
		// On vérifie qu'on ne modifie pas config.php pour utiliser le dossier de données actuel.
		if(!preg_match('@^'.$folder.'/@', PLX_CONFIG_PATH)) {
			$content = file_get_contents($this->config_filename);
			$newContent = preg_replace(moveMyDatas::CONFIG_MASK, '$1'.$folder, $content);
			plxUtils::debugJS('folder', $folder);
			plxUtils::debugJS('content', $content);
			plxUtils::debugJS('newContent', $newContent);
			$backup_filename = $this->config_filename.'.bak';

			try {
				copy($this->config_filename, $backup_filename);
				file_put_contents($this->config_filename, $newContent, LOCK_EX);

				// forces core/admin/medias.php to init the following variable
				unset($_SESSION['medias']);

				// clearstatcache(true);
				if (function_exists('opcache_invalidate')) {
					opcache_invalidate($this->config_filename);
				}
			} catch(Exception $err) {
				plxMsg::Error($err->getMessage());
			}
		} else {
			plxMsg::Error($this->getLang('THIS_IS_THE_CURRENT_FOLDER'));
		}
	}

	/**.
	 * Traite l'envoi du formulaire pour changer le dossier de données.
	 * */
	public function process($oldName, $newName) {
		global $plxAdmin;

		if(!is_writable($this->config_filename)) { return; }

		$pattern = '#^[\w-]+/?$#';
		$dataFolders = $this->getDatasFolders();
		// On vérifie que $newName est valide et qu'il n'existe pas déjà un dossier $newName
		if(
			empty($newName) || (
				preg_match('@^([\w-]+)/?$@', $newName, $matches) and
				!in_array($newName, $this->getDatasFolders())
			)
		) {
			// Normalisation de $newName. Doit finir par '/'.
			if(!empty($matches)) { $newName = $matches[1].'/'; }
			if(!empty($oldName)){
				// On valide $oldName
				if(in_array($oldName, $dataFolders)) {
					if(empty($newName)) {
						// Changement de dossier pour les données
						$this->__configUpdate($oldName);
					} elseif(preg_match($pattern, $newName)) {
						// Renommage du dossier pour les données
						if($this->__renameDatasFolder($oldName, $newName)) {
							$this->__configUpdate($newName);
						}
					}
				} else {
					// valeurs invalide pour $oldName
					plxMsg::Error(sprintf($this->getLang('INVALIDATE_OLD_NAME'), $oldName));
				}
			} else {
				// Nouveau dossier
				if($this->__createDatasFolder($newName)) {
					$this->__configUpdate($newName);
				}
			}
		} else {
			plxMsg::Error(sprintf($this->getLang('INVALIDATE_NEW_NAME'), $newName));
		}
	}

	/* ------------ Hooks non utilisés ------------ */
/*
	public function AdminPrepend() {

		# durée minimum pour que le cache de PHP se mette à jour - Pb avec include('config.php')
		const MMD_RELAX_TIME = 5;

	# hack against cache include file in PHP
		$referer = basename($_SERVER['HTTP_REFERER'], '.php');
		$p = strrpos($referer, '?p='.__CLASS__);
		if (true or ($p > 0)) {
			$content = file_get_contents(PLX_ROOT.'config.php');
			$str = preg_replace('#^.*\'PLX_CONFIG_PATH\'[^\']*\'([^\']*)\'.*$#s', '$1', $content);
			if ($str != PLX_CONFIG_PATH) {
				if (moveMyDatas::MMD_RELAX_TIME > 0) {
					header('Refresh: '.moveMyDatas::MMD_RELAX_TIME);
				}
				$this->config = $str;
			}
		}
	}

	public function plxAdminConstruct() {
		$code = <<< 'CODE'
<?php
	$plugin = $this->plxPlugins->aPlugins['##CLASS##'];
	$plugin->url = $this->racine.$this->aConfig['racine_plugins'].'##CLASS##/';
	$plugin->currentUser = $this->aUsers[$_SESSION['user']];
?>
CODE;
		$params = array(
			'##CLASS##'	=> __CLASS__
		);
		echo str_replace(array_keys($params), array_values($params), $code);
	}
 * */

}
?>
<?php
$LANG = array(
	/* config.php */
	'L_CSSCONTROL_ACTIVATE'=>'Forcer la mise à jour du cache CSS',
	'L_CSSCONTROL_PROFIL'=>'Limiter l\'utilisation au',
	'L_CSSCONTROL_SAVE'=>'Enregistrer',
	'L_CSSCONTROL_INFOS'=>'Lorsque la mise à jour est forcée, vous pouvez activer ou désactiver temporairement la mise à jour du cache en cliquant sur l\'entrée "Cache CSS" du menu.'
);
?>

<?php
if (!defined('PLX_ROOT')) {
	header('HTTP/1.0 404 What did you expect ?');
	exit;
}

/*
 * Plugin moveMyDatas for Pluxml cms by J.P. Pourrez
 * le plugin recherche à la racine du site tous les fichiers parametres.xml
 * pour offrir le choix d'un dossier d'un dossier de données
 * Il permet également de renommer un dossier de données existant en mettant à jour les liens
 * dans les articles, pages statiques et commentaires.
 * Il met également le fichier parametres.xml pour les racines des dossiers.
 * */

# durée minimum pour que le cache de PHP se mette à jour - Pb avec include('config.php')
define('MMD_RELAX_TIME', 5);
define('MDD_CONFIG_FILE', realpath(__DIR__.'/'.PLX_ROOT.'config.php'));
define('MDD_SAMPLES', true);

class moveMyDatas extends plxPlugin {

	public function __construct($default_lang='fr') {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		# $this->setConfigProfil(PROFIL_ADMIN);

		$this->setAdminProfil(PROFIL_ADMIN);
		# Personnalisation du menu admin
		$label = $this->getlang('FOLDER').': '.dirname(PLX_CONFIG_PATH).'/';
		$title = $this->getlang('TITLE');
		$this->setAdminMenu($label, 0, $title);

		if (basename($_SERVER['SCRIPT_NAME'], '.php') == 'index') {
			$this->addHook('AdminPrepend', 'AdminPrepend');
			$this->addHook('AdminIndexFoot', 'AdminIndexFoot');
		}

		$this->exportJSON = true;
		// $this->addHook('plxAdminEditArticle', 'xml2jsonArt');

	}

	public function pluginRoot() {
		global $plxAdmin;

		return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
	}

	public function AdminPrepend() {

		# hack against cache include file in PHP
		$referer = basename($_SERVER['HTTP_REFERER'], '.php');
		$p = strrpos($referer, '?p='.__CLASS__);
		if (true or ($p > 0)) {
			$content = file_get_contents(PLX_ROOT.'config.php');
			$str = preg_replace('#^.*\'PLX_CONFIG_PATH\'[^\']*\'([^\']*)\'.*$#s', '$1', $content);
			if ($str != PLX_CONFIG_PATH) {
				if (MMD_RELAX_TIME > 0) {
					header('Refresh: '.MMD_RELAX_TIME);
				}
				$this->config = $str;
			}
		}
	}

	public function AdminIndexFoot() {

		# hack against cache include file in PHP
		if (!empty($this->config)) {
			global $plxAdmin;

			$configDate = date('H:i:s', filemtime(PLX_ROOT.'config.php'));
			$now = date('H:i:s');
			$configPath = PLX_CONFIG_PATH;
			$imgPath =  $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/'; ?>
		<style type="text/css">
			.alert.red {display: none;}
		</style>
<?php
			echo <<< EOT
		<p id="mmd_loader"></p>
		<script type="text/javascript">
			console.log('------- here is moveMyDatas plugin ------------')
			console.log('last modification for config.php at {$configDate}');
			console.log('PLX_CONFIG_PATH equals {$this->config} in this file');
			console.log('PLX_CONFIG_PATH equals {$configPath} as constante in PHP');
			var elm = document.getElementById('mmd_loader');
			var offset = offset0 = -1056;
			var timer1 = setInterval(function() {
				elm.style.backgroundPosition = offset+'px 0';
				offset += 96;
				if (offset > 0) {
					offset = offset0;
				}
			}, 150);
		</script>
EOT;
		}
	}

	public function xml2jsonArt() {
		// enregistre l'article au format JSON
		global $plxAdmin;

		if (empty($this->exportJSON)) {
			return false;
		}
		$target = PLX_ROOT.$plxAdmin->aConf['racine_articles'];
		$code = <<< 'CODE'
<?php
$temp = $content;
$blacklist = array('publish', 'update', 'token', 'artId', 'date_update_old', 'date_publication_day', 'date_publication_day', 'date_publication_month', 'date_publication_year', 'date_publication_time',);
foreach(array_keys($temp) as $k) {
	if (in_array($k, $blacklist) or empty($temp[$k])) {
		unset($temp[$k]);
	}
}
# rationalisation des dates
$times = array('creation', 'update');
foreach($times as $l) {
	$hour = explode(':', $temp['date_'.$l.'_time']);
	$temp[$l] = $temp['date_'.$l.'_year'].$temp['date_'.$l.'_month'].$temp['date_'.$l.'_day'].$hour[0].$hour[1];
	foreach(array('day', 'month', 'year', 'time') as $k) {
			unset($temp['date_'.$l.'_'.$k]);
		}
}
	file_put_contents('#target#'.$temp['url'].'.json', json_encode($temp, JSON_UNESCAPED_UNICODE));
return false;
?>
CODE;
		echo str_replace('#target#', $target, $code);
	}

	private function expandDate(&$content) {
		$times = array('creation', 'update');
		foreach($times as $l) {
			if (preg_match('#^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})#', $content[$l], $matches)) {
				$content['date_'.$l.'_time'] = $matches[4].':'.$matches[5];
				foreach(array('day'=>3, 'month'=>2, 'year'=>1) as $k=>$i) {
					$content['date_'.$l.'_'.$k]	= $matches[$i];
				}
				unset($content[$m]);
			}
		}
		$content['date_update_old'] = $content['lastUpdated'];
		unset($content['lastUpdated']);
	}

	private function updateFile($params) {

		# enregistre la date du fichier
		$updateTime = filemtime($params['abspath']);

		$content = file_get_contents($params['abspath']);
		if (strlen($content) > 0) {
			if (!file_put_contents($params['abspath'], preg_replace('#(href="|src="|CDATA\[)'.$params['oldName'].'#', '$1'.$params['newName'], $content))) {
				return false;
			} else {
				# restaure la date du fichier
				return touch($params['abspath'], $updateTime);
			}
		} else {
			return true;
		}
	}

	private function configUpdate($newName) {
		$content = file_get_contents(MDD_CONFIG_FILE);
		$newContent = preg_replace('#^\s*(define\(\'PLX_CONFIG_PATH\',\s*\')[^/]+/#m', '$1'.$newName, $content);
		file_put_contents(MDD_CONFIG_FILE, $newContent, LOCK_EX);
		// clearstatcache(true);
		if (function_exists('opcache_invalidate')) {
			opcache_invalidate(realpath(MDD_CONFIG_FILE));
		}
	}

	private function writableFiles($folder) {
		global $plxAdmin;

		$result = true;
		$keys = explode(' ', 'articles statiques commentaires');
		$folders = array(PLX_CONFIG_PATH);
		foreach($keys as $k) {
			$folders[] = $plxAdmin->aConf['racine_'.$k];
		}
		$files = glob(PLX_ROOT.'{'.explode(',', $folders).'}/*');
		foreach($files as $f) {
			if (!is_writable($f)) {
				plxMsg::Error($f.' '.$this->getLang('UNWRITABLE'));
				$result = false;
				break;
			}
		}
		return $result;
	}

	public function renameFolder($oldName, $newName) {
		global $plxAdmin;

		$pattern = '#^[\w-]+/?$#';
		if (preg_match($pattern, $oldName)) {
			if (is_writable(MDD_CONFIG_FILE)) {
				$ok = true;
				if (!empty($newName)) {
					if (preg_match($pattern, $newName)) {
						# the name of the folder is altered

						$newName = trim($newName);
						if (substr($newName, -1) != '/') {
							$newName .= '/';
						}

						if (is_dir(PLX_ROOT.$newName)) {
							# a folder with this new name already exists
							plxMsg::Error(str_replace('##FOLDER##', $newName, $this->getLang('FOLDER_EXISTS')));
							$ok = false;
						} else if (($newName != $oldName) and $this->writableFiles($oldName)) {
							# So, we change the name of the data folder
							$params = array('oldName'=>$oldName, 'newName'=>$newName);

							# $plxAdmin->plxGlob_arts
							$dirname = PLX_ROOT.$plxAdmin->aConf['racine_articles'];
							foreach($plxAdmin->plxGlob_arts->aFiles as $filename) {
								$params['abspath'] = $dirname.$filename;
								if (!$this->updateFile($params)) {
									plxMsg::Error('Echec sur articles');
									break;
								}
							}

							# $plxAdmin->plxGlob_coms
							$dirname = PLX_ROOT.$plxAdmin->aConf['racine_commentaires'];
							foreach($plxAdmin->plxGlob_coms->aFiles as $filename) {
								$params['abspath'] = $dirname.$filename;
								if (!$this->updateFile($params)) {
									plxMsg::Error('Echec sur commentaires');
									break;
								}
							}

							# plxAdmin->aStats
							$isDirty = false;
							$genuineFields = explode(' ', 'name title_htmltag meta_description meta_keywords group url active menu template date_creation date_update readable');
							$dirname = PLX_ROOT.$plxAdmin->aConf['racine_statiques'];
							foreach($plxAdmin->aStats as $number=>$values) {
								$filename = $number.'.'.$values['url'].'.php';
								$params['abspath'] = $dirname.$filename;
								if (!$this->updateFile($params)) {
									plxMsg::Error('Echec sur pages statiques');
									break;
								}
								foreach(array_keys($values) as $k) {
									if (!in_array($k, $genuineFields)) {
										$isDirty = true;
										$plxAdmin->aStats[$number][$k] = preg_replace('#^'.$oldName.'#', $newName, $values[$k]);
									}
								}
							}
							if ($isDirty) {
								$plxAdmin->editStatiques(array(), true);
							}

							# plxAdmin->aTags
							# $plxAdmin->editTags();

							# plxAdmin->aUsers
							# $plxAdmin->users($content);

							# modifier le fichier parametres.xml dans le dossier de données
							$content = array();
							$racines = array('racine_articles', 'racine_commentaires', 'racine_statiques', 'medias');
							foreach($racines as $k) {
								$content[$k] = preg_replace('#^'.$oldName.'#', $newName, $plxAdmin->aConf[$k]);
							}
							$plxAdmin->editConfiguration($plxAdmin->aConf, $content);

							#renommer le dossier de données
							rename(PLX_ROOT.$oldName, PLX_ROOT.$newName);
						}
					} else {
						# bad name. Keep away !
						$ok = false;
					}
				}
				if ($ok) {
					# Actualiser le nom du dossier de données dans config.php
					$realName = dirname(PLX_CONFIG_PATH).'/';
					if (empty($newName)) {
						$newName = $oldName;
					}
					if ($realName != $newName) {
						$this->configUpdate($newName);
					}
					// forces core/admin/medias.php to init the following variable
					unset($_SESSION['medias']);
				}
			} else {
				plxMsg::Error(MDD_CONFIG_FILE.' '.$this->getLang('UNWRITABLE'));
			}
		}
	}

	public function createFolderData($folderName) {
		global $plxAdmin;

		$folderName = trim($folderName);
		if (empty($folderName)) {
			return;
		}
		if (substr($folderName, -1) != '/') {
			$folderName .= '/';
		}
		if (!is_dir(PLX_ROOT.$folderName)) {
			if (mkdir(PLX_ROOT.$folderName)) {
				$newConfig = array(
					'title' => 'Lovely build by MoveMyDatas plugin',
					'meta_description' => '',
					'meta_keywords' => ''
				);

				# create all folders
				$folders = explode(' ', 'articles commentaires statiques medias configuration');
				foreach($folders as $f) {
					$fd = $folderName.$f;
					mkdir(PLX_ROOT.$fd);
					switch ($f) {
						case 'medias':
							$newConfig['medias'] = $fd.'/';
							break;
						case 'configuration':
							mkdir(PLX_ROOT.$fd.'/plugins/');
							break;
						default:
							$newConfig['racine_'.$f] = $fd.'/';
					}
				}

				file_put_contents(PLX_ROOT.$folderName.'.htaccess', "Options -Indexes\n");

				# configurations
				$pattern = '#\b'.dirname(PLX_CONFIG_PATH).'/#';
				$newConfigPath = preg_replace($pattern, $folderName, PLX_CONFIG_PATH);
				foreach(explode(' ', 'CATEGORIES STATICS TAGS PLUGINS USERS') as $k) {
					switch ($k) {
						case 'USERS':
							$fields = explode(' ', 'login name infos password salt email lang');
							$id ='001';
							$content = <<< USER_START
	<user number="$id" active="1" profil="0" delete="0">

USER_START;
							$user = $plxAdmin->aUsers[$id];
							foreach($fields as $field) {
								$v = $user[$field];
								$content .= <<< USER_BODY
		<$field><![CDATA[$v]]></$field>

USER_BODY;
							}
							$content .= <<< USER_END
	</user>

USER_END;
							break;
						case 'PLUGINS':
							$name = __CLASS__;
							$content = <<< PLUGINS
	<plugin name="{$name}"></plugin>

PLUGINS;
							break;
						case 'CATEGORIES':
							if (MDD_SAMPLES) {
								$content = <<< CATEGORIES
	<categorie number="001" active="1" homepage="1" tri="desc" bypage="5" menu="oui" url="litterature" template="categorie.php"><name><![CDATA[Littérature]]></name><description><![CDATA[]]></description><meta_description><![CDATA[]]></meta_description><meta_keywords><![CDATA[]]></meta_keywords><title_htmltag><![CDATA[]]></title_htmltag></categorie>

CATEGORIES;
							} else {
								$content = '';
							}
							break;
						default:
							$content = '';
					}
					$charset = PLX_CHARSET;
					$xmlContent = <<< XML
<?xml version="1.0" encoding="{$charset}"?>
<document>
{$content}</document>
XML;
					$target = preg_replace($pattern, $folderName, path('XMLFILE_'.$k));
					plxUtils::write($xmlContent, path('XMLFILE_'.$k, $target));
				}
				if (is_dir(PLX_ROOT.$plxAdmin->aConf['racine_themes'].'defaut')) {
					$newConfig['style'] = 'defaut';
				}
				$foo = path('XMLFILE_PARAMETERS', preg_replace($pattern, $folderName, path('XMLFILE_PARAMETERS')));
				// $plxAdmin->aConf n'est pas mis à jour (passage de paramètre par valeur)
				$plxAdmin->editConfiguration($plxAdmin->aConf, $newConfig);
				$this->configUpdate($folderName);

				# populate the datas
				if (MDD_SAMPLES) {
					$this->exportJSON = false;
					$plxAdmin->aConf['racine_articles'] = $newConfig['racine_articles'];
					$n = 1;
					foreach(glob(dirname(__FILE__).'/samples/arts/*.json') as $filename) {
						$content = json_decode(file_get_contents($filename), true);
						$this->expandDate($content);
						$content['date_publication_year'] = date('Y') - 1;
						$content['date_publication_month'] = str_pad(rand(1, 12), 2, '0', STR_PAD_LEFT);
						$content['date_publication_day'] = str_pad(rand(1, 28), 2, '0', STR_PAD_LEFT);
						$content['date_publication_time'] = '08:00';
						$artId = str_pad($n, 4, '0', STR_PAD_LEFT);
						$plxAdmin->editArticle($content, $artId);
						$n++;
					}
					$this->exportJSON = true;
				}
			} else {
				plxMsg::Error(str_replace('##FOLDER##', $folderName, $this->getLang('UNWRITABLE_FOLDER')));
			}
		} else {
			plxMsg::Error(str_replace('##FOLDER##', $folderName, $this->getLang('FOLDER_EXISTS')));
		}
	}
}
?>
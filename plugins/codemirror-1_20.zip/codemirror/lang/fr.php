<?php

$LANG = array(
	/* config.php */
	'L_CODEMIRROR_THEME'=>'Théme pour l\'éditeur',
	'L_CODEMIRROR_LINENUMBERS'=>'Numéroter les lignes',
	'L_CODEMIRROR_ARTICLE'=>'Activer pour la rédaction des articles',
	'L_CODEMIRROR_STATIQUE'=>'Activer pour la rédaction des pages statiques',
	'L_CODEMIRROR_PARAMETRES_EDITTPL'=>'Activer pour l\'édition des modèles',
	'L_CODEMIRROR_PARAMETRES_PLUGINCSS'=>'Activer pour l\'édition des styles CSS',
	'L_CODEMIRROR_SHOW'=>'Coloration syntaxique dans les publications',
	'L_CODEMIRROR_MINIFY_JS'=>'Utiliser une bibliothèques minifiée',
	'L_CODEMIRROR_SHOW_ME'=>'Démonstration',
	'L_CODEMIRROR_DOWNLOAD'=>'Télécharger la bibliothèque minifiée',
	'L_CODEMIRROR_COMPLETION'=>'Tapez sur Ctrl-Espace pour compléter le code',
	'L_CODEMIRROR_FULLSCREEN'=>'Plein écran',
	'L_CODEMIRROR_COMMENT'=>'Le code à colorier doit être placé entre les balises &lt;pre&gt; et &lt;/pre&gt;. Par défault, le mime-type "text/html" est reconnu. Pour d\'autres langages, préciser le avec l\'attribut data-lang dans la balise &lt;pre&gt;. Par exemple, &lt;pre data-lang="text/css"&gt;...&lt;/pre&gt;.'
);

?>

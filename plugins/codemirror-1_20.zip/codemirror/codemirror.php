<?php
if (!defined('PLX_ROOT'))
	exit;

/*
 * Plugin pour CodeMirror
 * http://codemirror.net/
 * */

class codemirror extends plxPlugin {

	private $script_name;
	private $stylesheets = array('display/fullscreen', 'fold/foldgutter', 'hint/show-hint', 'dialog/dialog');
	private $modes = array('xml', 'javascript', 'css', 'htmlmixed', 'markdown', 'clike', 'php', 'python', 'shell');
	private $addons = array(
		false=>array(
			'edit/matchbrackets', 'edit/matchtags', 'edit/closebrackets', 'edit/closetag', 'display/fullscreen',
			'fold/foldcode', 'fold/foldgutter', 'fold/xml-fold', 'fold/comment-fold', 'fold/markdown-fold',
			'dialog/dialog', 'selection/active-line', 'search/searchcursor', 'search/search',
			'hint/show-hint', 'hint/css-hint', 'hint/html-hint', 'hint/javascript-hint', 'hint/xml-hint'
			),
		true=>array('runmode/runmode', 'runmode/colorize'));

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminSettingsEdittplTop', 'AdminSettingsEdittplTop');
		$this->addHook('AdminSettingsEdittplFoot', 'AdminArticleFoot');
		$this->addHook('AdminArticleFoot', 'AdminArticleFoot');
        $this->addHook('AdminStaticTop', 'AdminStaticTop');
		$this->addHook('AdminStaticFoot', 'AdminArticleFoot');
		$this->addHook('AdminPluginCss', 'AdminArticleFoot');
 		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
		}

	public function pluginRoot() {
		global $plxShow;
		
		if (isset($plxShow)) {
			return $plxShow->plxMotor->racine.$plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}
	
	private function themes() {
		$result = array();
		foreach (scandir(dirname(__FILE__).'/codemirror/theme') as $fn)
			if (substr($fn, -4) == '.css')
				array_push($result, substr($fn, 0, -4));
		return $result;
	}

	public function printMinifyJS_Code_urls() {
		define('URL_BASE', 'http://codemirror.net/');
		$value = URL_BASE.'lib/codemirror.js'; ?>
		<input type="hidden" name="code_url" value="<?php echo $value; ?>" />
<?php
		foreach ($this->modes as $mode) {
			$value = URL_BASE.'mode/'.$mode.'/'.$mode.'.js'; ?>
		<input type="hidden" name="code_url" value="<?php echo $value; ?>" />
<?php	}
		foreach ($this->addons as $k=>$v) {
			foreach ($v as $f=>$w) {
				$value = URL_BASE.'addon/'.$w.'.js'; ?>
		<input type="hidden" name="code_url" value="<?php echo $value; ?>" />
<?php		}
		}
	}

	public function printSelectThemes($onchange='', $name='theme') {

		$onChange1 = (!empty($onchange)) ? ' onchange="'.$onchange.'"' : '';
?>
			<select id="id_<?php echo $name; ?>" name="<?php echo $name; ?>"<?php echo($onChange1); ?>>
				<option value="">default</option>
<?php
	$theme = $this->getParam('theme');
	foreach($this->themes() as $t) {
		$selected = ($t == $theme) ? ' selected' : ''; ?>
				<option value="<?php echo $t; ?>"<?php echo $selected; ?>><?php echo ucfirst($t); ?></option>
<?php } ?>
			</select>
<?php
	}

	public function print_demo_url() {
		return $this->pluginRoot().'codemirror/demo/theme.html';
	}

	private function setContext($colorize=false) {
		$theme = $this->getParam('theme');
		$root = $this->pluginRoot();
        $addonsRoot = $root.'codemirror/addon/';
        $modesRoot = $root.'codemirror/mode/';
        $libsRoot = $root.'codemirror/lib/';

        // $minifyJS = (empty()) ? false : $this->getParam('minify_js');
		$minifyJS = $this->getParam('minify_js');
?>
	<link rel="stylesheet" href="<?php echo $libsRoot; ?>codemirror.css" />
<?php	if (!empty($theme)) {
			$href = $root.'codemirror/theme/'.$theme.'.css'; ?>
	<link rel="stylesheet" href="<?php echo $href; ?>" />
<?php }
        foreach ($this->stylesheets as $sheet) { ?>
	<link rel="stylesheet" href="<?php echo $addonsRoot.$sheet.'.css'; ?>" />
<?php	} ?>
	<link rel="stylesheet" href="<?php echo $root.__CLASS__; ?>.css" />
<?php
		if ($minifyJS) { ?>
	<script src="<?php echo $root; ?>/codemirror.min.js" type="text/javascript"></script>
<?php		}
		else { // load each js file one after one ?>
	<script src="<?php echo $libsRoot; ?>codemirror.js" type="text/javascript"></script>
<?php
			foreach ($this->modes as $m) { ?>
	<script src="<?php echo $modesRoot.$m.'/'.$m; ?>.js" type="text/javascript"></script>
<?php
			}
			foreach($this->addons[$colorize] as $a) { ?>
	<script src="<?php echo $addonsRoot.$a; ?>.js" type="text/javascript"></script>
<?php
			}
		}
	}

	public function AdminTopEndHead() {
		global $plugin;
		
		$root = $this->pluginRoot();
		switch ($this->script_name) {
			case 'parametres_plugin' :
				if ($plugin == __CLASS__) { ?>
	<link rel="stylesheet" href="<?php echo $root.__CLASS__; ?>.css" />
	<script src="<?php echo $root.__CLASS__; ?>.js" type="text/javascript"></script>
<?php			}
				break;
			case 'parametres_pluginhelp' :
			if ($plugin == __CLASS__) { ?>
	<link rel="stylesheet" href="<?php echo $root.__CLASS__; ?>.css" />
<?php		}
				break;
			case 'parametres_edittpl' :
			case 'article' :
			case 'statique' :
			case 'parametres_plugincss' :
				$param = $this->script_name;
				// $value = (!empty($this->getparam($param))) ? $this->getparam($param) : false;
				$value = $this->getparam($param);
				if ($value) {
					$this->setContext();
?>
	<script src="<?php echo $root.__CLASS__; ?>.js" type="text/javascript"></script>
<?php
					}
				break;
		}
	}

	public function AdminSettingsEdittplTop() {
?>
	<p style="text-align: right; margin: 5px 0;">
		<input type="button" id="fullscreen" value="<?php echo $this->lang('L_'.strtoupper(__CLASS__).'_FULLSCREEN'); ?>" title=" Dans l'éditeur, tapez F11 ou Esc. " />
		<i><?php echo $this->lang('L_'.strtoupper(__CLASS__).'_COMPLETION'); ?></i>
	</p>
<?php
	}

	public function AdminStaticTop() {
?>
	<p style="text-align: right; margin: 5px 0;">
		<input type="button" id="fullscreen" value="<?php echo $this->lang('L_'.strtoupper(__CLASS__).'_FULLSCREEN'); ?>" title=" Dans l'éditeur, tapez F11 ou Esc. " />
		<i><?php echo $this->lang('L_'.strtoupper(__CLASS__).'_COMPLETION'); ?></i>
	</p>
<?php
	}

	// we wish to use Codemirror for writing article, static page and template
	public function AdminArticleFoot() {
		$param = $this->script_name;
		// $value = (!empty($this->getparam($param))) ? $this->getparam($param) : false;
		$value = $this->getparam($param);
		if ($value) {
			$theme = $this->getParam('theme');
			$showLinesNumber = ($this->getParam('lineNumbers') == 1) ? 'true' : 'false';
			$mode = ($this->script_name == 'parametres_plugincss') ? 'css' : 'htmlmixed';
			echo <<< JAVASCRIPT
	<script type="text/javascript">
		<!--
		activeEditor('$theme', $showLinesNumber, '$mode');
		// -->
	</script>
JAVASCRIPT;
		}
	}
	
    // ----------------- for publication ------------------------
	public function ThemeEndHead() {
		$show = $this->getParam('show');
		if (isset($show) && $show) {
			$this->setContext(true);
		}
	}

	public function ThemeEndBody() {
		$show = $this->getParam('show');
		if (isset($show) && $show) {?>
	<script type="text/javascript">
		<!-- // default mode is not defined in standard
		CodeMirror.colorize(document.body.getElementsByTagName('pre'), 'text/html');
		// -->
	</script>
<?php
		}
	}

}
?>

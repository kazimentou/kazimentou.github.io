/*
 * See documentation at following links :
 * http://www.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 * */
// updated on 2015-12-20

if (typeof String.prototype.capitalize !== 'function') {
	String.prototype.capitalize = function() {
		return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
	}
}

function setMediasForTinyMCE(idTable, versionPluxml, filetype) {
	// hide some nodes in medias.php if the HTML page is loaded in an iframe.

	var myFrame = window.frameElement;
	if (myFrame) {
		var parentId = myFrame.parentNode.id;
		if (parentId && (parentId.indexOf('mce') == 0)) {
			var mediasList = document.getElementById(idTable);
			if (mediasList) {
				switch (filetype) {
					case 'media' :
						// for Pluxml version 5.4
						var rules = '\
aside, #nav_id + label, \
#id_folder + input[name="btn_delete"], \
#folder + input[type="submit"] { display: none; } \
.section { margin-bottom: 0.2; margin-top: 0.2rem; } \
th { text-align: center; }';
						var aStyle = document.createElement('style');
						aStyle.type = 'text/css';
						aStyle.innerHTML = rules;
						document.head.appendChild(aStyle);
						var labelCol = document.querySelector('#'+idTable+' th:nth-of-type(4)');
						if (labelCol)
							labelCol.innerHTML = 'Ext.';
						var folder = document.querySelector('#folder');
						if (folder) {
							folder.setAttribute('onchange', 'this.form.submit();');
						}
						var tbody = document.querySelector('#'+idTable+' tbody');
						if (tbody)
							tbody.addEventListener('click', function(event) {
								if (event.target.tagName == 'A') {
									var anchor1 = event.target;
									if (confirm('Ajouter dans l\'éditeur\n' + anchor1.href.split(/[\\/]/).pop()+'\n'+anchor1.href)) {
										var args = top.tinymce.activeEditor.windowManager.getParams();
										var href= anchor1.href, options, title = 'titre par défault';
										switch (args.mediaType) {
											case 'file' :
												var matches = /^.*\/([^\/]+)\.[a-z,0-9]+$/.exec(href);
												var text = (matches) ? matches[1].capitalize() : '';
												options = {title: 'Voir le média', text: text};
												break;
											case 'image' :
												var matches = /^.*\/([^\/\.]+)(?:\.tb)?\.(?:jpg|jpeg|png|gif)$/.exec(href);
												if (matches)
													title = matches[1].capitalize();
												options = {title: title, alt: 'Image'};
												break;
											default :
										}
										args.oninsert(href, options);
										// fermer la fenetre
										top.tinymce.activeEditor.windowManager.close();
									}
									event.preventDefault();
									// pour IE < 9
									event.returnValue = false;
								}
							});
						break;
					case 'file' :
						var rules = '#id_selection1, #id_selection1 + input, #id_sel_cat + input, ';
						['first-of-type', 'nth-of-type(2)', 'nth-last-of-type(3)', 'last-of-type'].forEach(function (col) {
							rules += '#'+idTable+' th:'+col+', ';
							rules += '#'+idTable+' td:'+col+', ';
						});
						// rules += '#form_articles h2, ';
						rules += 'aside { display: none; } ';
						rules += 'th { text-align: center; } ';
						rules += '.section { margin-bottom: 0; margin-top: 0.2rem; }'
						var aStyle = document.createElement('style');
						aStyle.type = 'text/css';
						aStyle.innerHTML = rules;
						document.head.appendChild(aStyle);
						var id_sel_cat = document.getElementById('id_sel_cat');
						if (id_sel_cat && (id_sel_cat.tagName == 'SELECT'))
							id_sel_cat.addEventListener('change', function (event) {
								var aForm = event.target.form;
								aForm.submit();
							});
						var okBtn = document.querySelector('#id_sel_cat + input');
						if (okBtn) {
							// <input type="submit" /> with name="submit" conflicts with TinyMCE. Just rename it !
							okBtn.name = 'btn1';
						}
						var element = document.querySelector('#form_articles div:first-of-type');
						if (element) {
							var mediasBtn = document.createElement('input');
							mediasBtn.setAttribute('type', 'button');
							mediasBtn.setAttribute('value', 'Medias');
							mediasBtn.setAttribute('onclick', 'document.location = \'medias.php\'');
							element.appendChild(mediasBtn);
						}
						var tbody = document.querySelector('#'+idTable+' tbody');
						if (tbody)
							tbody.addEventListener('click', function(event) {
								if (event.target.tagName == 'A') {
									var href = event.target.href;
									var res;
									var id = (res = /^.*?a=(\d{4})$/.exec(href)) ? res[1] : '';
									var text = event.target.text;
									if (confirm('article n° '+id+'\nurl: '+urlArts[id]+'\nTitre: '+text)) {
										var href = 'index.php?article'+id+'/'+urlArts[id];
										var args = top.tinymce.activeEditor.windowManager.getParams();
										args.oninsert(href, {text: text, title: 'Voir l\'article'});
										// fermer la fenetre
										top.tinymce.activeEditor.windowManager.close();
									}
									event.preventDefault();
									// pour IE < 9
									event.returnValue = false;
								}
							});
						break;
				}
			}
			else
				console.log('Id ' + idTable + ' element not found');
		}
	}
}

// launch by file_picker_callback
var myFile_picker_callback = function (callback, value, meta) {

	if (meta.filetype == 'file')
		tinymce.activeEditor.windowManager.open(
			{
				title: "Insérer un lien",
				url: 'index.php',
				width: 700,
				height: 800
			},
			{
				oninsert: function (url, options) { callback(url, options); },
				mediaType: meta.filetype
			}
		)
	else
		tinymce.activeEditor.windowManager.open(
			{
				title: "Médias",
				url: 'medias.php',
				width: 700,
				height: 600
			},
			{
				oninsert: function (url, options) { callback(url, options); },
				mediaType: meta.filetype
			}
		)
}

var myVideo_template_callback = function (data) {
	var urlPattern = {regex: /dailymotion\.com\/video\/([^_]+)/, type: 'iframe', w: 560, h: 315, url: '//www.dailymotion.com/embed/video/$1', allowFullscreen: true};
	var match;
	if ((match = urlPattern.regex.exec(data.source1))) {
		var url = urlPattern.url.replace('$1', match[1]);
		var allowFullscreen = urlPattern.allowFullscreen ? ' allowFullscreen="1"' : '';
		return '<iframe src="' + url + '" width="' + urlPattern.w + '" height="' + urlPattern.h + '"' + allowFullscreen + '></iframe>';
	} else
		return '<video width="' + data.width + '" height="' + data.height + '"' + (data.poster ? ' poster="' + data.poster + '"' : '') + ' controls="controls">\n' + '<source src="' + data.source1 + '"' + (data.source1mime ? ' type="' + data.source1mime + '"' : '') + ' />\n' + (data.source2 ? '<source src="' + data.source2 + '"' + (data.source2mime ? ' type="' + data.source2mime + '"' : '') + ' />\n' : '') + '</video>';
}

// Hack against Pluxml with its stupid z-index=9999
window.addEventListener('load', function (event) {
	var aStyle = document.createElement('style');
	aStyle.type = 'text/css';
	aStyle.innerHTML = '\
form:first-of-type > div:first-of-type { z-index: 99; } \
@media (max-width: 767px) {\
	.aside .responsive-menu { z-index: 99; }\
}';
	document.head.appendChild(aStyle);
});

<?php
if (!defined('PLX_ROOT')) exit;

# Control du token du formulaire
plxToken::validateFormToken($_POST);

$params = array(
	'skin'=>'string', 'cdn'=>'boolean', 'article'=>'numeric',
	'statique'=>'numeric', 'comment'=>'numeric', /* 'parametres_edittpl'=>'numeric', */
	'selector'=>'string',
	'codemirror'=>'numeric', 'styleformats'=>'cdata');

$checked_fields = array('article', 'statique', 'comment', /* 'parametres_edittpl', */ 'codemirror');

// from parametres_users.php
# Tableau des profils
$aProfils = array(
	PROFIL_ADMIN => L_PROFIL_ADMIN, // can moderate everything
	PROFIL_MANAGER => L_PROFIL_MANAGER, // can moderate static pages
	PROFIL_MODERATOR => L_PROFIL_MODERATOR, // can moderate comments
	PROFIL_EDITOR => L_PROFIL_EDITOR, // can moderate categories
	PROFIL_WRITER => L_PROFIL_WRITER // can moderate only articles
);

if (!empty($_POST)) {
	foreach ($params as $field=>$type) {
		if (isset($_POST[$field])) {
			switch ($type) {
				case 'boolean' :
					$value = 1;
					break;
				case 'numeric' :
					if (in_array($field, $checked_fields) and is_array($_POST[$field]))
						$value = array_sum($_POST[$field]);
					else
						$value = $_POST[$field];
					break;
				default :
					$value = $_POST[$field];
					break;
			}
		}
		else
			$value = ($type == 'numeric') ? 0 : '';
		$plxPlugin->setParam($field, $value, ($type == 'boolean') ? 'numeric' : $type);
	}
	$plxPlugin->saveParams();
	if ($result = $plxPlugin->create_JS_lib())
		plxMsg::Info(intval($result).' octets écrits dans le fichier '.dirname(__FILE__).'/'.TINY_PLUXML_JS_LIB);
	else
		plxMsg::Error('Pas de droit en écriture pour le dossier '.dirname(__FILE__).'/');
	header('Location: '.basename($_SERVER['REQUEST_URI']));
	exit;
}

$skins = $plxPlugin->get_skins();
?>
	<h2><?php echo(L_PLUGINS_CONFIG.': '.$plxPlugin->getInfo('title')); ?></h2>
	<p><i><?php echo $plxPlugin->getInfo('description'); ?></i></p>
	<form id="form_<?php echo $plugin; ?>" method="post">
		<div>
<?php
foreach ($params as $field=>$type) {

	$value = $plxPlugin->getParam($field);
	if (($value == '') and (array_key_exists($field, $plxPlugin->default_values)))
		$value = $plxPlugin->default_values[$field];
	else {
		if ($type == 'numeric')
			$value = intval($value);
		else
			$value = plxUtils::strCheck($value);
	}

	$classLarge = ($field == 'styleformats') ? ' class="large"' : '';
	// Adding titles of columns for users' profil
	if ($field == 'article') { ?>
		</div><div id="<?php echo $plugin; ?>_users_caption">
			<p>
				<label><?php $plxPlugin->lang('L_'.strtoupper($plugin).'_PROFIL_USERS'); ?></label>
<?php
		foreach ($aProfils as $profil=>$caption) { ?>
				<span title="<?php echo $caption; ?>"><?php echo mb_substr($caption, 0, 3, PLX_CHARSET); ?>.</span>
<?php
		} ?>
			</p>
<?php
	}
?>
			<p>
				<label for="id_<?php echo $field; ?>"<?php echo $classLarge; ?>><?php $plxPlugin->lang('L_'.strtoupper($plugin).'_'.strtoupper($field)); ?></label>
<?php
		switch ($type) {
			case 'numeric' :
				if (in_array($field, $checked_fields)) {
					$pass1 = true;
					foreach (array_keys($aProfils) as $profil) {
						$id = ($pass1) ? 'id="id_'.$field.'" ' : '';
						$checked = (($value & $plxPlugin->weightProfils[$profil]) > 0) ? ' checked' : '';
?>
				<input <?php echo $id; ?>type="checkbox" name="<?php echo $field.'[]'; ?>" value="<?php echo $plxPlugin->weightProfils[$profil]; ?>"<?php echo $checked; ?> />
<?php				$pass1 = false;
					}
				}
				break;
			case 'boolean' :
				$checked = ($value == '1') ? ' checked' : ''; ?>
				<input id="id_<?php echo $field; ?>" type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
				if (($field == 'cdn') and !is_readable($plxPlugin->local_tinymce_library))
					echo ' <i>'.$plxPlugin->getLang('L_LIBRARY_NOT_FOUND').'</i>';
				break;
			case 'cdata' : ?>
				</p>
				<?php plxUtils::printArea($field, $value, 30, 10); ?>
				<p>
<?php
				break;
			default :
				switch ($field) {
					case 'skin' : ?>
				<?php plxUtils::printSelect($field, $plxPlugin->get_skins(), $value);
						break;
					default : ?>
				<?php plxUtils::printInput($field, $value, 'text', '5-50', false);
						break;
				}
				break;
		}
	}
?>			</p>
		</div><div>
			<p>
				<label>&nbsp;</label>
				<?php echo plxToken::getTokenPostMethod()."\n"; ?>
				<input type="submit" value="<?php echo L_SAVE_FILE; ?>">
			</p>
		</div>
	</form>

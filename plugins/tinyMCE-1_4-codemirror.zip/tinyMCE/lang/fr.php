<?php

$LANG = array(
	/* config.php */
	'L_TINYMCE_THEME'=>'Théme pour l\'éditeur',
	'L_TINYMCE_SKIN'=>'Habillage (skin)',
	'L_TINYMCE_CDN'=>'Utiliser un réseau de serveurs (CDN)',
	'L_LIBRARY_NOT_FOUND'=>'Pas de librairie tinymce.min.js sur le serveur',
	'L_TINYMCE_PROFIL_USERS'=>'Profils utilisateurs (<i>selon leurs droits</i>)',
	'L_TINYMCE_ARTICLE'=>'Activer pour la rédaction des articles',
	'L_TINYMCE_STATIQUE'=>'Activer pour la rédaction des pages statiques',
	'L_TINYMCE_COMMENT'=>'Activer pour la modération des commentaires',
	'L_TINYMCE_PARAMETRES_EDITTPL'=>'Activer pour l\'édition des modèles',
	'L_TINYMCE_SELECTOR'	=> 'Sélecteur des champs à éditer (règles CSS)',
	'L_TINYMCE_CODEMIRROR'=>'Utiliser le plugin externe Codemirror<sup>*</sup>',
	'L_TINYMCE_STYLEFORMATS'=>"Règles CSS, à séparer avec des virgules. Ex: {title: 'titre1', selector: 'img', styles: {'margin': '5px', 'border':'2px'}}",
	'L_TINYMCE_CODEMIRROR_HELP'=>'La bibliothèque minifiée <strong>codemirror.min.js</strong> de Codemirror doit être située dans un des dossiers suivants :',
	'L_TINYMCE_CODEMIRROR_WARNING'=>'Le téléchargement prendra quelques dizaines de secondes.\nLe fichier sera à stocker sur le serveur dans le dossier:\n'
);

?>

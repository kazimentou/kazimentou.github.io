<?php
if (!defined('PLX_ROOT')) exit;

// https://dev.twitter.com/docs/api/1.1
// http://www.sitepoint.com/oauth-for-php-twitter-apps-part-1/
// http://blog.fpmurphy.com/2010/08/update-twitter-status-using-php-and-oauth.html

// Control du token du formulaire
plxToken::validateFormToken($_POST);

$params = array(
	'skin'=>'string', 'cdn'=>'boolean', 'article'=>'numeric',
	'statique'=>'numeric', 'comment'=>'numeric', 'categorie'=>'numeric', /* 'parametres_edittpl'=>'numeric', */
	'codemirror'=>'numeric', 'extended'=>'boolean', 'styleformats'=>'cdata');
define('INITIAL_VAL_ARTICLE', 128+64+32+16+8);
$default_values = array('article'=>INITIAL_VAL_ARTICLE, 'static'=>1, 'template'=>0, 'direct_page'=>0);
$checked_fields = array('article', 'statique', 'comment', 'categorie', /* 'parametres_edittpl', */ 'codemirror');

if (!empty($_POST)) {
	foreach ($params as $field=>$type) {
		if (isset($_POST[$field])) {
			switch ($type) {
				case 'boolean' :
					$value = 1;
					break;
				case 'numeric' :
					if (in_array($field, $checked_fields) and is_array($_POST[$field]))
						$value = array_sum($_POST[$field]);
					else
						$value = $_POST[$field];
					break;
				default :
					$value = $_POST[$field];
					break;
			}
		}
		else
			$value = ($type == 'numeric') ? 0 : '';
		$plxPlugin->setParam($field, $value, ($type == 'boolean') ? 'numeric' : $type);
	}
	if ($plxPlugin->use_extension()) {
		foreach (array_keys($plxPlugin->allPlugins) as $field) {
			if (!empty($_POST[$field]) and is_array($_POST[$field]))
				$value = array_sum($_POST[$field]);
			else
				$value = 0;
			$plxPlugin->setParam($field, $value, 'numeric');
		}
	}
	$plxPlugin->saveParams();
	header('Location: '.$_SERVER['REQUEST_URI']);
	exit;
}

$skins = $plxPlugin->get_skins();
$plxPlugin->init_aProfils();

if (!array_key_exists($plugin, $plxAdmin->plxPlugins->aPlugins) and isset($plxPlugin)) {
	// $plugin is disabled but we needs to call some Hook in /core/admin/top.php ('AdminTopEndHead', ...)
	$plxPlugins = $plxAdmin->plxPlugins;
	$plxPlugins->aPlugins[$plugin] = $plxPlugin;
	$plxPlugins->aHooks = array_merge_recursive($plxPlugins->aHooks, $plxPlugin->getHooks());
}

?>
	<h2><?php echo(L_PLUGINS_CONFIG.': '.$plxPlugin->getInfo('title')); ?></h2>
	<p><i><?php echo $plxPlugin->getInfo('description'); ?></i></p>
	<form id="form_<?php echo $plugin; ?>" method="post">
		<div>
<?php
foreach ($params as $field=>$type) {
	if (($field == 'styleformats') and $plxPlugin->use_extension()) continue;
	$value = $plxPlugin->getParam($field);
	if (($value == '') and (array_key_exists($field, $plxPlugin->default_values)))
		$value = $plxPlugin->default_values[$field];
	else {
		if ($type == 'numeric')
			$value = intval($value);
		else
			$value = plxUtils::strCheck($value);
	}

	$classLarge = ($field == 'styleformats') ? ' class="large"' : '';
	// Adding titles of columns for users' profil
	if ($field == 'article') { ?>
		</div><div id="<?php echo $plugin; ?>_users_caption" class="profils">
<?php $plxPlugin->printProfilNames();
	}
?>
			<p>
				<label for="id_<?php echo $field; ?>"<?php echo $classLarge; ?>><?php $plxPlugin->lang('L_'.strtoupper($plugin).'_'.strtoupper($field)); ?></label>
<?php
		switch ($type) {
			case 'numeric' :
				// multiple checkboxes for this parameter
				if (in_array($field, $checked_fields))
					$plxPlugin->printCheckboxes($field);
				break;
			case 'boolean' :
				$checked = ($value == '1') ? ' checked' : ''; ?>
				<input id="id_<?php echo $field; ?>" type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
				if (($field == 'cdn') and !is_readable($plxPlugin->local_tinymce_library))
					echo ' <i>'.$plxPlugin->getLang('L_TINYMCE_LIBRARY_NOT_FOUND').'</i>';
				break;
			case 'cdata' :
				if (($field != 'styleformats') or !$plxPlugin->use_extension()) { ?>
				</p>
				<?php plxUtils::printArea($field, $value, 30, 10); ?>
				<p>
<?php
				}
				break;
			default :
				switch ($field) {
					case 'skin' : ?>
				<?php plxUtils::printSelect($field, $plxPlugin->get_skins(), $value);
						break;
					default : ?>
				<?php plxUtils::printInput($field, $value, 'text', '5-10', false);
						break;
				}
				break;
		}
?>			</p>
<?php
}
?>
		</div>
<?php
if ($plxPlugin->use_extension())
	// we are using array_keys($examples) from examples.php to get list of plugins
	foreach (array('examples.php', 'lang/fr-comments.php', 'config-extended.php') as $fn) {
		$filename = PLX_PLUGINS.$plugin.'/'.$fn;
		if (is_readable($filename))
			include($filename);
		else { ?>
			<p><?php echo str_replace(array('#FILENAME#', '#PLUGIN#'), array($fn, $plugin), $plxPlugin->getLang('L_TINYMCE_FILE_NOT_FOUND')); ?></p>
<?php
		}
	}
?>
		<div>
			<p>
				<label>&nbsp;</label>
				<?php echo plxToken::getTokenPostMethod()."\n"; ?>
				<input type="submit">
			</p>
		</div>
	</form>

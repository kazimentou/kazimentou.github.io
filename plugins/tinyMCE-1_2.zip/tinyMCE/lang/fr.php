<?php

$LANG = array(
	/* config.php */
	'L_TINYMCE_THEME'=>'Théme pour l\'éditeur',
	'L_TINYMCE_SKIN'=>'Habillage (skin)',
	'L_TINYMCE_CDN'=>'Utiliser un réseau de serveurs (CDN)',
	'L_LIBRARY_NOT_FOUND'=>'Pas de librairie tinymce.min.js sur le serveur',
	'L_TINYMCE_PROFIL_USERS'=>'Profils utilisateurs',
	'L_TINYMCE_ARTICLE'=>'Activer pour la rédaction des articles',
	'L_TINYMCE_STATIQUE'=>'Activer pour la rédaction des pages statiques',
	'L_TINYMCE_COMMENT'=>'Activer pour la modération des commentaires',
	'L_TINYMCE_PARAMETRES_EDITTPL'=>'Activer pour l\'édition des modèles',
	'L_TINYMCE_CODEMIRROR'=>'Utiliser le plugin externe Codemirror',
	'L_TINYMCE_EXTENDED'=>'Utiliser la version étendue de ce plugin',
	'L_TINYMCE_STYLEFORMATS'=>"Règles CSS, à séparer avec des virgules. Ex: {title: 'titre1', selector: 'img', styles: {'margin': '5px', 'border':'2px'}}",
	'L_TINYMCE_FILE_NOT_FOUND'=>'Le fichier "<span>#FILENAME#</span>" est absent du dossier du plugin "<span>#PLUGIN#</span>".',
	'L_TINYMCE_PROFIL'=>'Profil',
	'L_TINYMCE_ALL_USERS'=>'Pour tous les profils',
	'L_TINYMCE_PLUGINS_USE'=>'Ces plugins ont des options - Sur un profil ou un plugin: clic inverse les cases cochées, ctrl-clic cochent toutes les cases.',
	'L_TINYMCE_PLUGINS_BASIC'=>'Coche tous les plugins de la biblio. basique',
	'L_TINYMCE_PLUGINS_SELECTION'=>'Coche une sélection de plugins (recommandée)',
	'L_TINYMCE_PLUGINS_ALL'=>'Coche tous les plugins',
	'L_TINYMCE_PLUGINS_RESET'=>'Tout décocher',
	'L_TINYMCE_PLUGINS_LIBRARY'=>'Plugins de la librairie Tinymce',
	'L_TINYMCE_OPTIONS'=>'Options de la librairie Tinymce'
);
?>

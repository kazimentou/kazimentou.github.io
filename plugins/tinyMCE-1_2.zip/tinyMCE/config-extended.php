<?php
if (!defined('PLX_ROOT')) exit;

if (isset($examples)) {
	ksort($examples);
	ksort($comments);
}

// plugins with options
$optionsPlugins = array(
	'advlist', 'link', 'image', 'importcss', 'fullpage',
	'tabfocus', 'table', 'pagebreak', 'visualblocks',
	'paste', 'template', 'autosave', 'autoresize',
	'save', 'noneditable', 'insertdatetime', 'spellchecker',
	'contextmenu', 'media'
);

?>
<!-- begin config-extended.php -->
		<div id="tinymcePlugins" class="profils">
			<h3><?php $plxPlugin->lang('L_TINYMCE_PLUGINS_LIBRARY'); ?></h3>
			<div>
<?php $plxPlugin->printProfilNames();

/* ****************************************** */
/* Grille de sélection des plugins de tinymce */
/* ****************************************** */
	$tiny_plugins = array_keys($plxPlugin->allPlugins);
	sort($tiny_plugins);
	$n = count($tiny_plugins); $sep = ceil($n / 3);
	foreach ($tiny_plugins as $tiny_plugin) {
		$value = $plxPlugin->getParam($tiny_plugin);
		$asterisk = (in_array($tiny_plugin, $optionsPlugins)) ? '<sup>*</sup>' : '<sup>&nbsp;</sup>';
		if (($n % $sep) == 0) { // multi-columns ! ?>
			</div><div>
<?php $plxPlugin->printProfilNames();
		} ?>
				<p>
					<label for="id_<?php echo $tiny_plugin; ?>"><?php echo $tiny_plugin.$asterisk; ?></label>
<?php $plxPlugin->printCheckboxes($tiny_plugin, "\t"); ?>
					<input type="button" value="?" />
				</p><p>
					<code><?php echo (array_key_exists($tiny_plugin, $examples)) ? $examples[$tiny_plugin] : 'No example'; ?></code>
					<span><?php echo (array_key_exists($tiny_plugin, $comments)) ? $comments[$tiny_plugin] : 'No comment'; ?></span>
				</p>
<?php
		if ($n >= 0)
			$n--;
	} ?>
			</div>
			<hr />
		</div>
		<p id="plugins-manual">
			<sup>*</sup><?php $plxPlugin->lang('L_TINYMCE_PLUGINS_USE'); ?>
		</p><p id="select-plugins">
			<input type="button" value="Basique" title="<?php $plxPlugin->lang('L_TINYMCE_PLUGINS_BASIC'); ?>" onclick="pluginsSelect(basicPlugins);"/>
			<input type="button" value="Sélection" title="<?php $plxPlugin->lang('L_TINYMCE_PLUGINS_SELECTION'); ?>" onclick="return pluginsSelect(selectionPlugins);" />
			<input type="button" value="Tous"  title="<?php $plxPlugin->lang('L_TINYMCE_PLUGINS_ALL'); ?>" onclick="return pluginsSelect('all');" />
			<input type="button" value="Reset" title="<?php $plxPlugin->lang('L_TINYMCE_PLUGINS_RESET'); ?>" onclick="return pluginsSelect('');" />
		</p>
		<div id="tinymceOptions">
			<h3><?php $plxPlugin->lang('L_TINYMCE_OPTIONS'); ?></h3>
			<div>
				<p>
					<label for="id_styleformats"><?php $plxPlugin->lang('L_TINYMCE_ALL_USERS'); ?></label>
					<input type="button" value="help" onclick="return optionsHelpRequest();" />
				</p>
				<?php
				$field = 'styleformats';
				$value = $plxPlugin->getParam($field);
				$value = plxUtils::strCheck($value);
				plxUtils::printArea($field, $value, 30, 5);

/* ******************************************** */
/* Grille des options de tinymce (saisie libre) */
/* ******************************************** */
	$n = 5;
	$abrev = array(PROFIL_ADMIN=>'adm', PROFIL_MANAGER=>'man', PROFIL_MODERATOR=>'mod', PROFIL_EDITOR=>'edi', PROFIL_WRITER=>'wri');
	foreach ($plxPlugin->aProfils as $user=>$caption) {
		$field = 'options_'.$abrev[$user];
		if (($n % 2) == 0) { ?>
			</div><div>
<?php } ?>
			<p>
				<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_TINYMCE_PROFIL'); ?>&nbsp;<?php echo $caption; ?></label>
			</p>
				<?php
		$value = $plxPlugin->getParam($field);
		$value = plxUtils::strCheck($value);
		plxUtils::printArea($field, $value, 30, 5);
		if ($n >= 0)
			$n--;
	}
?>
			</div>
			<hr />
		</div>
<!-- end config-extended.php -->

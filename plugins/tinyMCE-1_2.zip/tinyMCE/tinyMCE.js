/*
 * See documentation at following links :
 * http://www.tinymce.com/wiki.php/Configuration:file_browser_callback
 * http://www.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 * */

var COOKIE1 = 'PluXML-TinyMCE';

function setCookie(name, value, mins) {
	var exdate = new Date();
	if (! mins)
		mins = 10;
	exdate.setTime(exdate.getTime() + (mins * 60000)); // = 60*1000 millisecondes/min
	var expires = '; expires=' + exdate.toUTCString();
	document.cookie = name + "=" + escape(value) + expires;
}

function clearCookie(name) {
	setCookie(name, '', -1);
	console.log('Cookie is dropped');
	}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function cleanUp(e) {
	console.log('Bye-bye');
	clearCookie(COOKIE1);
	return 'Cookie is clear';
}

function updateLinksTable(aTable) {
	var rows = aTable.getElementsByTagName('tr');
	for (i=1; i<rows.length; i++) { // skip the first rows of <th>
		var anchors = rows[i].getElementsByTagName('a');
		for (j=1 ;j<anchors.length; j++) {
			if (anchors[j].hasAttribute('rel'))
				anchors[j].removeAttribute('rel');
			anchors[j].setAttribute('onclick', 'return tinyMCE_Set(this);');
		}
	}
}

function setMediasForTinyMCE() {
	// search for links in table tag to add  'return tinyMCE_Set(this);' as onclick property
	var listFiles = document.getElementById('list-files');
	if (listFiles) {
		updateLinksTable(listFiles);
		window.onunload = cleanUp;
	}
	else {
		console.log('Id list-files element not found');
		var files_manager = document.getElementById('files_manager');
		if (files_manager) {
			var tables = files_manager.getElementsByTagName('table');
			if (tables.length > 0) {
				var noSuccess = true;
				for (i = 0; i < tables.length; i++) {
					if (tables[i].className.match(/(?:^|\s)table(?!\S)/)) {
						console.log('We are found one or more table elements with class="table"');
						updateLinksTable(tables[i]);
						noSuccess = false;
						break;
					}
				}
				if (noSuccess)
					console.log('No table with class table.');
				else
					window.onunload = cleanUp;
			}
			else
				console.log('No table element in the id files_manager element');
		}
		else
			console.log('Id files_manager element not found');
	}
}

function tinyMCE_Set(anchor1) {
	// copy the url of the file in TinyMCE
	if (confirm('Ajouter dans l\'éditeur')) {
		var args = top.tinymce.activeEditor.windowManager.getParams();
		var field = args.win.document.getElementById(args.field_name);
		if (field)
			field.value = anchor1.href;
		else
			alert('Field '+args.field_name+' not found');
		// fermer la fenetre
		clearCookie(COOKIE1);
		top.tinymce.activeEditor.windowManager.close();
		}
	return false;
}

var myCallback = function (field_name1, url1, type1, win1) {
	// Launch the file/image browser
	//  type1 value in ('image', 'file', 'media')
	setCookie(COOKIE1, type1, 15);
	tinymce.activeEditor.windowManager.open({
		title: "Médias",
		url: 'medias.php',
		width: 700,
		height: 600},
		{win: win1, field_name: field_name1, type: type1, url: url1}
	);
}

// for config-extended.php
var basicPlugins =
	'anchor charmap code contextmenu fullscreen image insertdatetime link ' +
	'lists media paste preview searchreplace table wordcount';

function pluginsSelect(aSelection) {
	var div1 = document.getElementById('tinymcePlugins');
	if (div1) {
		var inputs = div1.getElementsByTagName('input');
		for (i=0; i<inputs.length; i++) {
			var el = inputs[i];
			if ((el.hasAttribute('type')) && (el.getAttribute('type') == 'checkbox')) {
				var name1 = el.name.substr(0, el.name.length-2);
				el.checked = ((aSelection == 'all') || ((aSelection.length > 0) && (aSelection.indexOf(name1) >= 0)));
			}
		}
	}
	else
		console.log('Element with id="tinymcePlugins" not found.');
	return false;
}

function displayOptionsHelp() {
	alert('displayOptionsHelp not implemented !');
	return false;
}

function setHelpShow() {

	var tinymcePlugins = document.getElementById('tinymcePlugins');
	if (tinymcePlugins) {

		var lastHelpShowElt = null;
		var helpShow =
			function(evenement) {
				var parent = evenement.target.parentNode;
				var myBrother = parent.nextSibling;
				// store the className of myBrother
				var className1 = myBrother.className;
				if (lastHelpShowElt) {
					lastHelpShowElt.className = '';
					lastHelpShowElt = null;
				}
				if (className1 == '') {
					lastHelpShowElt = myBrother;
					myBrother.className = 'helpShow';
				}
			}

		var inputs = tinymcePlugins.getElementsByTagName('input');
		console.log(inputs.length + ' inputs in element with id="tinymcePlugins"');

		for (i = 0; i < inputs.length; i++) {
			var el = inputs[i];
			if ((el.hasAttribute('type')) && (el.getAttribute('type') == 'button') && el.value == '?') {
				el.addEventListener('click', helpShow, false);
			}
		}

		var checkBox = function(el, ctrlClick) {
			if (el.hasAttribute('type') && (el.getAttribute('type') == 'checkbox')) {
				if (ctrlClick)
					el.checked = true;
				else
					el.checked = ! el.checked;
			}
		}

		var divs = tinymcePlugins.getElementsByTagName('div'),
			// alter the plugins when click event on the name of profile
			checkPlugins4User = function(event,indice) {
				var aDiv = event.target.parentNode.parentNode,
					paragrs = aDiv.getElementsByTagName('p');
				for (i=1; i< paragrs.length; i++) {
					var paragr = paragrs[i],
						inputs = paragr.getElementsByTagName('input');
					if (inputs.length > indice)
						checkBox(inputs[indice], event.ctrlKey);
				}
			}
			// alter the plugins when click event on the name of plugin
			checkPlugin = function(event) {
				var myParent = event.target.parentNode,
					inputs = myParent.getElementsByTagName('input');
				for (i=0; i<inputs.length; i++)
					checkBox(inputs[i], event.ctrlKey);
			}

		for (var i=0; i <divs.length; i++) {
			var	div1 = divs[i],
				paragrs = div1.getElementsByTagName('p');
			if (paragrs.length > 0) {
				// title of columns
				var spans = paragrs[0].getElementsByTagName('span');
				/*
				for (s=0; s < spans.length; s++) {
					spans[s].addEventListener('click', function(event)(i) {return checkPlugins4User(event, i);}(s), false);
				}
				* */
				var myEvent = 'click';
				spans[0].addEventListener(myEvent, function(event) {return checkPlugins4User(event, 0);}, false);
				spans[1].addEventListener(myEvent, function(event) {return checkPlugins4User(event, 1);}, false);
				spans[2].addEventListener(myEvent, function(event) {return checkPlugins4User(event, 2);}, false);
				spans[3].addEventListener(myEvent, function(event) {return checkPlugins4User(event, 3);}, false);
				spans[4].addEventListener(myEvent, function(event) {return checkPlugins4User(event, 4);}, false);
				for (var j=1; j<paragrs.length; j++) {
					var labels = paragrs[j].getElementsByTagName('label');
					if (labels.length > 0)
						labels[0].addEventListener('click', checkPlugin, false);
				}
			}
		}
	}
	else
		console.log('Element with "tinymcePlugins" id not found');
}

function optionsHelpRequest() {

	var width = 1015, height = 500, left = (screen.width-width)/2, top = (screen.height-height)/2;
	var options =
		'height='+height+', width='+width+', top='+top+', left='+left+
		',menubar=no, location=no, titlebar=no, toolbar=no, scrollbars=yes, resizable=yes';
	var url = 'http://www.tinymce.com/wiki.php/Configuration';

	var myWindow = window.open(url, '_blank', options);
	return false;
}

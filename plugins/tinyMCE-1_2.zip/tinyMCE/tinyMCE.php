<?php

if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour utiliser TinyMCE dans l'édition des articles et des pages statiques
 * Utilise le script core/admin/medias.php pour choisir les images et les documents de
 * la bibliothèque de médias
 *
 * Dans le tableau de la bibliothèque de médias, cliquez sur un des liens pour insérer
 * un document/image dans l'article ou la page statique
 *
 * On utilise un cookie créé avec le script plugins/tinymce/js/myCallback.js pour masquer
 * panneau de navigation dans la bibliothèque
 *
 * Tous les liens vers les documents/images insérés dans les articles et pages statiques
 * sont transformés en liens absolus par TinyMCE
 * ( voir options : relative_urls, remove_script_host et document_base_url )
 *
 * version TinyMCE 4.0.x
 * http://www.tinymce.com/
 * http://www.tinymce.com/wiki.php/TinyMCE pour la documentation
 * http://www.tinymce.com/wiki.php/Tutorial:Using_CDN
 *
 * */

// voir pour theme, skin, plugins externe, options,
/*

*/
class tinyMCE extends plxPlugin {

	private $browser_only = false;
	private $tinyMCE_base;
	public $default_values = array(
		'article'=>248, // 128+64+32+16+8
		'statique'=>192, // 128+64
		'comment'=>248, // 128+64+32+16+8
		// 'parametres_edittpl'=>128,
		'codemirror'=>0,
		'cdn'=>1
	);
	public $weightProfils = array(PROFIL_ADMIN=>128, PROFIL_MANAGER=>64, PROFIL_MODERATOR=>32, PROFIL_EDITOR=>16, PROFIL_WRITER=>8);
	public $local_tinymce_library = false;
	public $aProfils = false;
	public $basicPlugins = false;
	public $selectionPlugins = false;
	public $allPlugins = false;
	private $selectedPlugins = false;

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->tinyMCE_base = PLX_PLUGINS.__CLASS__.'/tinyMCE';
		$this->local_tinymce_library = PLX_PLUGINS.__CLASS__.'/tinyMCE/tinymce.min.js';

		if(defined('PLX_ADMIN')) {
			# déclaration pour ajouter l'éditeur
			$this->browser_only = false;

			// for config-extended.php
			$this->selectionPlugins = array(
				'advlist', 'anchor', 'autolink', 'autoresize', 'charmap', 'contextmenu', 'directionality',
				'emoticons', 'fullscreen', 'hr', 'image', 'link', 'lists', 'media', 'nonbreaking', 'paste', 'save',
				'searchreplace', 'table', 'template', 'textcolor', 'visualblocks', 'visualchars', 'wordcount'
			);
			// When not false, plugin has one or more buttons in the toolbar
			$this->allPlugins = array(
				'advlist'=>false,
				'anchor'=>array(8, true),
				'autolink'=>false,
				'autoresize'=>false,
				'autosave'=>false,
				'bbcode'=>false,
				'charmap'=>array(36, true),
				'code'=>array(28, true),
				// 'compat3x'=>false,
				'contextmenu'=>false,
				'directionality'=>array(22, 'ltr rtl'),
				'emoticons'=>array(32, true),
				// 'example'=>false,
				// 'example_dependency'=>false,
				'fullpage'=>false,
				'fullscreen'=>array(24, true),
				'hr'=>false,
				'image'=>array(9, true),
				'insertdatetime'=>array(10, true),
				// 'layer'=>false,
				'legacyoutput'=>false,
				'link'=>array(11, 'link unlink'),
				'lists'=>false,
				'importcss'=>false,
				'media'=>array(12, true),
				'nonbreaking'=>array(35, true),
				'noneditable'=>false,
				'pagebreak'=>array(34, true),
				'paste'=>array(16, true),
				'preview'=>array(19, true),
				'print'=>array(20, true),
				'save'=>array(21, true),
				'searchreplace'=>array(17, true),
				'spellchecker'=>array(18, true),
				'tabfocus'=>false,
				'table'=>array(27, true),
				'template'=>array(29, true),
				'textcolor'=>array(33,'forecolor backcolor'),
				'visualblocks'=>array(25, true),
				'visualchars'=>array(26, true),
				'wordcount'=>false
			);

			$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
			$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
			$this->addHook('AdminFootEndBody', 'AdminFootEndBody');
		}
	}

	// called by config.php
	public function init_aProfils() {
		// At building,
		// when plugin is inactive, L_PROFIL.. are know
		// when plugin is active, L_PROFIL.. are unknow
		// values from parametres_users.php
		$this->aProfils = array(
			PROFIL_ADMIN => L_PROFIL_ADMIN, // can moderate everything
			PROFIL_MANAGER => L_PROFIL_MANAGER, // can moderate static pages
			PROFIL_MODERATOR => L_PROFIL_MODERATOR, // can moderate comments
			PROFIL_EDITOR => L_PROFIL_EDITOR, // can moderate categories
			PROFIL_WRITER => L_PROFIL_WRITER // can moderate only articles
		);
	}

	public function use_extension() {
		return (intval($this->getParam('extended')) == 1);
	}

	public function paramChecked($paramName, $user_id=false) {
		if (empty($user_id))
			$user_id = $_SESSION['profil'];
		$value = $this->getParam($paramName);
		return (($value & $this->weightProfils[$user_id]) > 0) ? ' checked' : '';
	}

	public function get_skins() {
		$folder = PLX_PLUGINS.__CLASS__.'/'.__CLASS__.'/skins/';
		$items = array(''=>'Par défaut');
		$files = glob($folder.'*');
		if (!empty($files)) {
			foreach ($files as $file1) {
				if (is_dir($file1)) {
					$value = substr(strrchr($file1, '/'), 1);
					$items[$value] = ucfirst($value);
				}
			}
		}
		else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
			echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
			$dir = new DirectoryIterator($folder.'.');
			foreach ($dir as $fileinfo) {
				if ($fileinfo->isDir() && !$fileinfo->isDot()) {
					$filename = $fileinfo->getFilename();
					$items[$filename] = ucfirst($filename);
				}
			}
			asort($items);
		}
		return $items;
	}

	private function print_tinymce_library_setup() {
		if ((intval($this->getParam('cdn') == 1) or !is_readable($this->local_tinymce_library)))
			$tinyMCE_lib = '//tinymce.cachefly.net/4.0/tinymce.min.js'; // for CDN
		else
			$tinyMCE_lib = $this->local_tinymce_library;
?>
	<script type="text/javascript" src="<?php echo $tinyMCE_lib; ?>"></script>
<?php
	}

	private function parametres_pluginhelp_setup() {
		$idHelp = __CLASS__.'-help'; ?>
	<style type="text/css">
		#<?php echo $idHelp; ?> {width: 700px; padding: 10px; background-color: AliceBlue; border-radius: 10px; border: 1px solid LightSteelBlue; font-size: 12pt; margin-top: 0.5em;}
		#<?php echo $idHelp; ?> p, #html5uploader-help ul {margin: 10px 0;}
		#<?php echo $idHelp; ?> p {text-align: justify; text-indent: 1em;}
		#<?php echo $idHelp; ?> p:last-child {text-align: center; text-indent: 0;}
		#<?php echo $idHelp; ?> p:last-child img {margin: 2px 5%;}
		#<?php echo $idHelp; ?> ul {padding-left: 3em;}
		#<?php echo $idHelp; ?> li {list-style-type: decimal;}
		#<?php echo $idHelp; ?> i {padding: 0 5px;}
		#local-lib {color: Navy; font-weight: 600;}
	</style>
<?php
	}

	private function parametres_plugin_setup() { ?>
	<link rel="stylesheet" type="text/css" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.css" />
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
<?php
	}

	private function set_plugins_list() {
		if ($this->use_extension()) {
			$this->selectedPlugins = array();
			$tiny_plugins = array_keys($this->allPlugins);
			foreach ($tiny_plugins as $tiny_plugin)
				if ($this->paramChecked($tiny_plugin))
					array_push($this->selectedPlugins, $tiny_plugin);
		}
		else
			$this->selectedPlugins = $this->selectionPlugins;
	}

	private function set_toolbar($codemirror_ok) {
		// some basic buttons
		// codemirror needs the code button on toolbar
		$code = ($codemirror_ok) ? ' code' : ''; // if ($codemirror_ok) echo ' code'
		if ($this->use_extension()) {
			// some basic buttons
			// 'undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent';
			$toolbar = array();
			foreach ($this->selectedPlugins as $tiny_plugin) {
				if (($tiny_plugin == 'code') and $codemirror_ok) continue;
				$plugin1 = $this->allPlugins[$tiny_plugin];
				if (is_array($plugin1)) {
					$buttons = $plugin1[1];
					$toolbar[$plugin1[0]] = (is_string($buttons)) ? $buttons : $tiny_plugin;
				}
			}
			ksort($toolbar);
			$buttonsGroups = array();
			foreach( array_keys($toolbar) as $k) {
				$group = $k & 248; // 256 - 8
				if (!isset($buttonsGroups[$group]))
					$buttonsGroups[$group] = array($toolbar[$k]);
				else
					array_push($buttonsGroups[$group], $toolbar[$k]);
			}
			foreach ($buttonsGroups as $group=>$buttons) { // building panel of buttons
				$buttonsGroups[$group] = implode(' ', $buttons);
			}
			return 'undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | '.$code.' '.implode(' | ', $buttonsGroups);
		}
		else {
			return 'undo redo | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media anchor | forecolor backcolor emoticons |'.$code.' fullscreen';
		}
	}

	private function edition_setup($script_name) {

		$mask_user = $this->weightProfils[$_SESSION['profil']];

		if ($this->paramChecked($script_name)) {
			global $plxAdmin;

			$document_base_url = $plxAdmin->racine;
			$external_root = $document_base_url.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/tinyMCE/';
			$external_plugins_root = $external_root.'plugins/';
			$skin = $this->getParam('skin'); // look at tinyMCE/skins/ folder in the plugin
			if (!empty($skin) and ($skin != 'lightGray') and is_dir(PLX_PLUGINS.__CLASS__.'/tinyMCE/skins/'.$skin)) {
				$external_skin = $external_root.'skins/'.$skin;
				$option_skin = "skin: '$skin', skin_url: '$external_skin',";
			}
			else
				$option_skin = '';
			$i18N = array('en'=>'en_GB', 'fr'=>'fr_FR', 'pt'=>'pt_PT');
			$lang = $plxAdmin->aConf['default_lang'];
			if (array_key_exists($lang, $i18N))
				$lang = $i18N[$lang];
			$language_url = $this->tinyMCE_base.'/langs/'.$lang.'.js';
			// $codemirror_ok = ((intval($this->getParam('codemirror')) & $mask_user) > 0);
			$codemirror_ok = $this->paramChecked('codemirror');
			$this->set_plugins_list();
?>
	<script type="text/javascript">
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src='+'"//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></scr'+'ipt>');
	</script>
<?php $this->print_tinymce_library_setup(); ?>
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
	<script type="text/javascript">
		tinymce.init({
			selector:'textarea',
			plugins: '<?php echo implode(' ', $this->selectedPlugins); ?>',
			toolbar1: '<?php echo $this->set_toolbar($codemirror_ok); ?>',
			language: '<?php echo $lang; ?>',
			language_url:'<?php echo $language_url; ?>',
			<?php echo $option_skin; ?>
			image_advtab: true,
			file_browser_callback: myCallback,
			content_css: '<?php echo $external_root; ?>content.css',
<?php	if ($codemirror_ok) { ?>
			external_plugins: {
				'codemirror': '<?php echo $external_plugins_root; ?>codemirror/plugin.min.js'
				 },
			codemirror: {
			    indentOnInit: true, // Whether or not to indent code on init.
			    config: {           // CodeMirror config object
					mode: 'application/x-httpd-php',
					lineNumbers: true,
					indentUnit: 2,
					tabSize: 2
			    },
			    cssFiles: ['theme/elegant.css']
		    },
<?php	} ?>
			remove_script_host: true,
			document_base_url: '<?php echo $document_base_url; ?>',
			rel_list: [
				{title: 'Lightbox',  value: 'lightbox'},
				{title: 'Galerie 1', value: 'lightbox-1'},
				{title: 'Galerie 2', value: 'lightbox-2'},
				{title: 'Galerie 3', value: 'lightbox-3'},
				{title: 'Galerie 4', value: 'lightbox-4'}
			],
<?php
		$style_formats = $this->getParam('styleformats');
		if (!empty($style_formats)) { ?>
			style_formats: [
<?php echo $style_formats; ?>
			],
<?php	} ?>
			nonbreaking_force_tab: true
		});
	</script>
<?php
		}
	}

	private function medias_setup() {
		$this->browser_only = !empty($_COOKIE['PluXML-TinyMCE']); // $this->browser_only is used by AdminMediasFoot hook.
		if ($this->browser_only) {
			global $plxMedias;
			$img_exts = $plxMedias->img_exts;
			// $doc_exts = $plxMedias->doc_exts;
			// dans doc_exts, conserver les extensions des images pour utiliser Lightbox
			$doc_exts = '/\.(jpg|gif|png|jpeg|7z|csv|doc|docx|gz|gzip|ods|odt|odp|pdf|ppt|pptx|pxd|qt|ram|rar|rm|rmi|rmvb|rtf|sxc|sxw|tar|tgz|txt|xls|xlsx|zip)$/i';
			$media_exts = '/\.(pdf|aiff|asf|avi|fla|flv|mid|mov|mp3|mp4|mpc|mpeg|mpg|ogg|pxd|qt|ram|rm|rmi|rmvb|swf|sxc|sxw|wav|wma|wmv)$/i';
			// echo("<!--\n$img_exts\n$doc_exts\n-->\n");
			// stylesheet for hiding sidebar
?>
	<style>
		#sidebar {display: none;}
		#content {position: absolute; left: 0; margin: 5px; padding: 0}
		div#files_manager {min-width: 500px;}
		div.files > p {display:none;}
		div.browser input.delete {display: none;}
		div.files table td:first-child, div.files table th:first-child {display: none;}
	</style>
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js"></script>
	<script type="text/javascript">
		var filtres = {image: <?php echo $img_exts; ?>, file: <?php echo $doc_exts; ?>, media: <?php echo $media_exts; ?>};
    </script>
<?php
			}
	}

	public function AdminTopEndHead() {
		$script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		switch ($script_name) {
			case 'parametres_pluginhelp' :
				$this->parametres_pluginhelp_setup();
				break;
			case 'parametres_plugin' :
				$this->parametres_plugin_setup();
				break;
			case 'article' :
			case 'statique' :
			case 'comment':
			case 'categorie' :
			case 'parametres_edittpl' :
				$this->edition_setup($script_name);
				break;
			case 'medias' :
				$this->medias_setup();
				break;
		}
	}

	public function AdminMediasFoot($params='') {
		if ($this->browser_only) { ?>
		<script type="text/javascript">
			setMediasForTinyMCE();
		</script>
<?php
		}
	}

	// for config.php and config-extended.php
	public function printCheckboxes($paramName, $tab='') {
		// $pass1 = true;
		$pass1 = false;
		foreach (array_keys($this->aProfils) as $profil) {
			$checked = $this->paramChecked($paramName, $profil);
			$id = '';
			if ($pass1) {
				$id = ' id="id_'.$paramName.'"';
				$pass1 = false;
			}
			$attribs = 'name="'.$paramName.'[]" value="'.$this->weightProfils[$profil].'"'.$checked.$id;
			echo $tab."\t\t\t\t".'<input type="checkbox" '.$attribs.' />'."\n";
		}
	}

	public function printProfilNames() { ?>
			<p>
				<label><?php $this->lang('L_'.strtoupper(__CLASS__).'_PROFIL_USERS'); ?></label>
<?php
	foreach ($this->aProfils as $profil=>$caption) { ?>
				<span title="<?php echo $caption; ?>"><?php echo mb_substr($caption, 0, 3, PLX_CHARSET); ?>.</span>
<?php
	} ?>
			</p>
<?php
}

	// For config-extended.php we are waiting for loading page
	public function AdminFootEndBody($params) {
		global $plugin;

		if (isset($plugin) and $this->use_extension()) { ?>
	<script type="text/javascript">
		var selectionPlugins = '<?php echo implode(' ', $this->selectionPlugins); ?>';
		setHelpShow();
	</script>
<?php
		}
	}

}
?>

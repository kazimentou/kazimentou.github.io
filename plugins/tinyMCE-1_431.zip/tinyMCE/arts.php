<?php

define('PLX_ROOT', '../../');
include(PLX_ROOT.'config.php');
if (! defined('PLX_LIB'))
	define('PLX_LIB', PLX_ROOT.'core/lib/');
include(PLX_LIB.'config.php');
foreach(array('utils', 'record', 'glob', 'plugins', 'token', 'motor') as $lib)
	include(PLX_LIB.'class.plx.'.$lib.'.php');
	
$plxMotor = plxMotor::getInstance();
if (isset($_GET['art'])) {
	$plxMotor->motif = '/^'.$_GET['art'].'\..*\.xml$/';
	if ($plxMotor->getArticles('all')) {
		$infosArt = $plxMotor->plxRecord_arts->result[0];
		$result = array('id'=>$infosArt['numero'], 'title'=>$infosArt['title'], 'url'=>$infosArt['url'], 'chapo'=>$infosArt['chapo']);
		foreach(array_keys($infosArt) as $k)
			if (substr(strtolower($k), -8) == 'vignette') {
				$result['thumbnail'] = $infosArt[$k];
			}
		header('Content-Type: application/json');
		echo json_encode($result);
		exit;
	}
} else if (isset($_GET['cat'])) {
	$result = array();
	foreach($plxMotor->aCats as $k=>$infos) {
		if ($infos['articles'] > 0) {
			$title = $infos['name'];
			$value = 'index.php?categorie'.$k.'/'.$infos['url'];
			$result[] = array('title'=>$title, 'value'=>$value);
		}
	}
	header('Content-Type: application/json');
	echo json_encode($result);
	exit;
}
$limit = 50;
?>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Liste articles</title>
	<style>
		h1 + div {display: flex;}
		table {border: 1px solid; border-collapse: collapse; width: 100%;}
		thead {background-color: #D5E073;}
		th, td {margin: 0; padding: 2px 5px;}
		td:not(:first-of-type), th:not(:first-of-type) {border-left: 1px solid;}
		td:first-of-type {text-align: center;}
		tr:nth-child(even) {background-color: #E1E9E6;}
		tr:hover {background-color: yellow;}
		tbody a {margin:0 5px; padding: 0 2px;}
		tbody a:hover {background-color: green; color: #FFF;}
		td[colspan] {text-align: center;}
	</style>
</head>
<body>
	<h1>Liste de <?php echo count($plxMotor->plxGlob_arts->aFiles); ?> articles</h1>
	<div>
	<p>
		<label>Catégories</label>
		<select name="cat" id="cat" onchange="refresh();">
			<option value="">Toutes</option>
<?php
	foreach($plxMotor->aCats as $k=>$infos) {
		$label = $infos['name'];
		echo <<< OPTION
			<option value="$k">$label</option>

OPTION;
	}
?>
			<option value="000">Non classés</option>
		</select>
	</p>
	<p>
		<label>Auteurs</label>
		<select name="user" id="user" onchange="refresh();">
			<option value="">Toutes</option>
<?php
	foreach($plxMotor->aUsers as $k=>$infos) {
		$label = $infos['name'];
		echo <<< OPTION
			<option value="$k">$label</option>

OPTION;
	}
?>
		</select>
	</p>
	<p>
		<input type="checkbox" id="tri_alpha" value="1" checked /><label for="tri_alpha">Tri alpha. des titres</label>
	</p>
	</div>
	<table>
		<thead>
			<th data-sort="date">Date</th>
			<th data-sort="url">Url</th>
			<th data-sort="user">Auteur</th>
			<th>Catégories</th>
		</thead>
		<tbody id="tbody">
		</tbody>
	</table>
	<p>L'affichage est limité à <?php echo $limit; ?> articles.</p>
</body>
<script language="javascript" src="tinyMCE.js"></script>
<script>
	// from https://openclassrooms.com/courses/ajax-et-l-echange-de-donnees-en-javascript/l-objet-xmlhttprequest-1
	function getXMLHttpRequest() {
		var xhr = null;
		if (window.XMLHttpRequest || window.ActiveXObject) {
			if (window.ActiveXObject) {
				try {
					xhr = new ActiveXObject("Msxml2.XMLHTTP");
				} catch(e) {
					xhr = new ActiveXObject("Microsoft.XMLHTTP");
				}
			} else {
				xhr = new XMLHttpRequest();
			}
		} else {
			alert("Votre navigateur ne supporte pas l'objet XMLHTTPRequest...");
			return;
		}
		return xhr;
	}
	
	var aFiles = <?php echo json_encode($plxMotor->plxGlob_arts->aFiles); ?>;
	var activeArts = <?php echo json_encode(array_keys($plxMotor->activeArts)); ?>;
	var categories = <?php echo json_encode($plxMotor->aCats); ?>;
	var users = <?php echo json_encode($plxMotor->aUsers); ?>;
	var catSelect = document.getElementById('cat');
	var userSelect = document.getElementById('user');
	var tbody = document.getElementById('tbody');
	var motif, matches;
	function showArticle() {
		var user = users[matches[3]];
		var cats = '';
		var catIds = matches[2].split(',');
		catIds.forEach(
			function (value) {
				if ((value != '000') && (/^\d{3}$/.exec(value))) {
					var cat = categories[value];
					if (cat)
						cats += '<a href="#" data-cat="'+value+'">'+cat.name+'</a>';
				}
			}
		)
		var tr = document.createElement('tr');
		tr.innerHTML = '\
<td>'+matches[6]+'/'+matches[5]+'/'+matches[4]+'</td>\
<td><a href="#" data-art="'+matches[1]+'">'+matches[9]+'</a></td>\
<td><a href="#" data-user="'+matches[3]+'">'+user.name+'</a></td>\
<td>'+cats.trim()+'</td>';
		tbody.appendChild(tr);
	}
	
	function refresh() {
		tbody.innerHTML = '';
		var aSelect, value;
		aSelect = document.getElementById('cat');
		value = aSelect.value;
		var cat = (value.length > 0) ? value : '\\d{3}';
		aSelect = document.getElementById('user');
		value = aSelect.value;
		var auth = (value.length > 0) ? value : '\\d{3}';
		motif = new RegExp('^(\\d{4})\\.((?:home,|draft,|pin,|\\d{3},)*'+cat+'(?:,home|,draft|,\\d{3})*)\\.('+auth+')\\.(\\d{4})(\\d{2})(\\d{2})(\\d{2})(\\d{2})\\.([\\w-]+)\\.xml$');
		var limit = <?php echo $limit; ?>;
		var n = limit;
		for (i in aFiles) {
			if (matches = motif.exec(aFiles[i])) {
				showArticle();
				n--;
				if (n <=0)
					break;
			}
		}
		if (n == limit) {
			var tr = document.createElement('tr');
			tr.innerHTML = '<td colspan="4">Aucun article</td>';
			tbody.appendChild(tr);
		}
	}
	
	refresh();
	tbody.addEventListener('click', function (event) {
		var elt = event.target;
		if (elt.tagName == 'A') { // tagName renvoie le tag en majuscules
			if (elt.hasAttribute('data-art')) {
				var value = elt.getAttribute('data-art');
				var xhr = getXMLHttpRequest();
				xhr.callback = function (aData) {
					var result = JSON.parse(aData);
					var msg = 'Article';
					msg += '\nId: '+result.id;
					msg += '\nTitle: '+result.title;
					msg += '\nUrl: '+result.url;
					msg += '\nChapo : '+result.chapo;
					msg += '\nVignette: '+result.thumbnail;
					tinyMCE_SetArticle(result);
				}
				xhr.onreadystatechange = function() {
					if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
						this.callback(xhr.responseText);
					}
				};
				xhr.open('GET', 'arts.php?art='+value);
				xhr.send();
				return;
			} else if (elt.hasAttribute('data-user')) {
				var value = elt.getAttribute('data-user');
				var options = userSelect.options;
				for (i=0, iMax=options.length; i<iMax; i++) {
					if (options[i].value == value) {
						userSelect.selectedIndex = i;
						refresh();
						break;
					}
				}
			} else if (elt.hasAttribute('data-cat')) {
				var value = elt.getAttribute('data-cat');
				var options = catSelect.options;
				for (i=0, iMax=options.length; i<iMax; i++) {
					if (options[i].value == value) {
						catSelect.selectedIndex = i;
						refresh();
						break;
					}
				}
			}
		}
		event.preventDefault();
		// pour IE < 9
		event.returnValue = false;
	}, false);
</script>
</html>

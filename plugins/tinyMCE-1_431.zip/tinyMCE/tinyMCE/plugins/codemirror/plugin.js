/*jshint unused:false */
/*global tinymce:true */

tinymce.PluginManager.requireLangPack('codemirror');

tinymce.PluginManager.add('codemirror', function(editor, url) {

	function showSourceEditor() {

		// Insert caret marker
		editor.focus();
		editor.selection.collapse(true);
		editor.selection.setContent('<span class="CmCaReT" style="display:none">&#0;</span>');

		var isMac = /macintosh|mac os/i.test(navigator.userAgent);
		var helpMe =
			tinymce.translate('Shortcuts keyboard') + ':\n\n' +
			(isMac ? '&#8984;-F' : 'Ctrl-F') + '\t\t' + tinymce.translate('Start search') + '\n' +
			(isMac ? '&#8984;-G' : 'Ctrl-G') + '\t\t' + tinymce.translate('Find next') + '\n' +
			(isMac ? '&#8984;-Alt-F' : 'Shift-Ctrl-F') + '\t' + tinymce.translate('Find previous') + '\n' +
			(isMac ? '&#8984;-Alt-F' : 'Shift-Ctrl-F') + '\t' + tinymce.translate('Replace') + '\n' +
			(isMac ? 'Shift-&#8984;-Alt-F' : 'Shift-Ctrl-R') + '\t' + tinymce.translate('Replace all');

		// Open editor window
		var win = editor.windowManager.open({
			title: tinymce.translate('HTML source code'),
			// url: url + '/source.html',
			url: url + '/index.php',
			width: 900,
			height: 550,
			resizable : true,
			maximizable : true,
			buttons: [
				{ text: 'Help', onclick: function() { alert(helpMe); }},
				{ text: 'Cancel', onclick: 'close' },
				{ text: 'Save', subtype: 'primary', onclick: function(){
					var elt = document.querySelector('iframe[src$="/index.php"');
					elt.contentWindow.submit();
					win.close();
				}}
			]
		});
	};

	// Add a button to the button bar
	editor.addButton('code', {
		icon: 'code',
		tooltip: tinymce.translate('HTML source code'),
		onclick: showSourceEditor
	});

	// Add a menu item to the tools menu
	editor.addMenuItem('code', {
		icon: 'code',
		text: tinymce.translate('HTML source code'),
		context: 'tools',
		onclick: showSourceEditor
	});
});

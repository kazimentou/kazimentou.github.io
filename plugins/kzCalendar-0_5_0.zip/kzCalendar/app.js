// A faire prendre en charge  les événements répétitifs
(function() {
	'use strict';

	/**
	 * Get the ISO week date week number
	 * https://stackoverflow.com/questions/6117814/get-week-of-year-in-javascript-like-in-php
	 */
	Date.prototype.getWeek = function () {
	  // Create a copy of this date object
	  var target = new Date(this.valueOf());

	  // ISO week date weeks start on Monday, so correct the day number
	  var dayNr = (this.getDay() + 6) % 7;

	  // ISO 8601 states that week 1 is the week with the first Thursday of that year
	  // Set the target date to the Thursday in the target week
	  target.setDate(target.getDate() - dayNr + 3);

	  // Store the millisecond value of the target date
	  var firstThursday = target.valueOf();

	  // Set the target to the first Thursday of the year
	  // First, set the target to January 1st
	  target.setMonth(0, 1);

	  // Not a Thursday? Correct the date to the next Thursday
	  if (target.getDay() !== 4) {
	    target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
	  }

	  // The week number is the number of weeks between the first Thursday of the year
	  // and the Thursday in the target week (604800000 = 7 * 24 * 3600 * 1000)
	  return 1 + Math.ceil((firstThursday - target) / 604800000);
	}

	// https://stackoverflow.com/questions/14267781/sorting-html-table-with-javascript
	function sortTable(table_id, sortColumn){
	    var tableData = document.getElementById(table_id).getElementsByTagName('tbody').item(0);
	    var rowData = tableData.getElementsByTagName('tr');
	    for(var i = 0; i < rowData.length - 1; i++){
	        for(var j = 0; j < rowData.length - (i + 1); j++){
	            if(Number(rowData.item(j).getElementsByTagName('td').item(sortColumn).innerHTML.replace(/[^0-9\.]+/g, "")) < Number(rowData.item(j+1).getElementsByTagName('td').item(sortColumn).innerHTML.replace(/[^0-9\.]+/g, ""))){
	                tableData.insertBefore(rowData.item(j+1),rowData.item(j));
	            }
	        }
	    }
	}

	// gestion des onglets
	document.querySelectorAll('.kzCalendar-tabs').forEach(function(node) {
		node.addEventListener('click', function(event) {
			if(event.target.tagName == 'LABEL') {
				this.querySelectorAll('label.active').forEach(function(node1) {
					node1.classList.remove('active');
				});
			}
			event.target.classList.add('active');
		});
	});

	// Gestion des boutons pour les balises select
	function newValueForSelect(event) {
		if(
			event.target.hasAttribute('data-select') &&
			event.target.hasAttribute('data-msg')
		) {
			event.preventDefault();
			var newValue = prompt(event.target.getAttribute('data-msg'));
			if(newValue != null) {
				const el = document.createElement('OPTION');
				el.value = newValue;
				el.innerHTML = newValue;
				var select = document.getElementById('id_' + event.target.getAttribute('data-select'));
				select.appendChild(el);
				el.selected = true;
			}
		}

	}

	document.body.querySelectorAll('button[data-select]').forEach(function(item) {
		item.addEventListener('click', newValueForSelect);
	});

	// Gestionnaire de medias
	const mediasBtn = document.body.querySelector('button[data-medias-url]');
	const overlay = document.getElementById('kzCalendar-medias-overlay');
	function toggleOverlay(event) {
		event.preventDefault();
		overlay.classList.toggle('active');
		if(event.target.hasAttribute('data-medias-url')) {
			const iframe = document.body.querySelector('#kzCalendar-medias-overlay iframe');
			if(iframe != null) {
				iframe.src = event.target.getAttribute('data-medias-url');
			}
		}
	}
	if(mediasBtn != null && overlay != null) {
		mediasBtn.addEventListener('click', toggleOverlay);
		overlay.addEventListener('click', toggleOverlay);
	}

	/* --------------- Mise à jour ou affichage d'un évènement ---------------------- */
	function updateEvent(event) {
		const TARGET = event.target;
		if(
			TARGET.hasAttribute('data-event-id') ||
			(TARGET.tagName == 'TD' && TARGET.parentElement.hasAttribute('data-event-id'))
		) {
			event.preventDefault();
			const EVENT_ID = (TARGET.hasAttribute('data-event-id')) ? TARGET.getAttribute('data-event-id') : TARGET.parentElement.getAttribute('data-event-id');
			if(typeof this.datas.events != 'undefined') {
				// fill up each entry of the form
				const myEvent = this.datas.events[EVENT_ID];
				const theForm = document.getElementById('form_kzCalendar');
				if(theForm != null) {
					theForm.elements.ev_id.value = EVENT_ID;
					this.datas.fields.forEach(function(field) {
						if(field in theForm.elements) {
							theForm.elements[field].value = (field in myEvent) ? myEvent[field] : '';
						}
					});
					const LABEL = theForm.querySelector('p.event-id');
					if(LABEL != null) {
						LABEL.innerHTML = '#' + EVENT_ID;
					}
					// active l'onglet du formulaire
					const TAB = document.getElementById('theForm');
					if(TAB != null) {
						TAB.click();
					}
				} else {
					var overlay = document.getElementById('kzCalendar-infos');
					if(overlay == null) {
						overlay = document.createElement('DIV');
						overlay.id = 'kzCalendar-infos';
						overlay.className = 'kzCalendar';
						overlay.innerHTML = '<div></div>';
						document.body.appendChild(overlay);
						overlay.addEventListener('click', function(event) {
							this.classList.remove('active');
						});
					}
					const category = this.datas.category;
					const fields = '' +
						'title category content day_begin ' +
						'day_end hour_begin hour_end location ' +
						'period periodend ev_link';
					var innerHTML = '';
					fields.split(' ').forEach(function(field) {
						if(field in myEvent) {
							const caption = (typeof kzCalendarI18n.fieldNames !== 'undefined') ? kzCalendarI18n.fieldNames[field] : field;
							var content = myEvent[field];
							var classList = [field];
							if(field.match(/^(?:day_|hour_|category)/)) {
								classList.push('narrow');
							}
							var catClass = '';
							switch(field) {
								case 'content':
									content = myEvent.content.replace(/[\r\n]+/g, '<br />');
									break;
								case 'day_begin':
								case 'day_end':
									const parts = content.split('-');
									const dt = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
									content = dt.toLocaleDateString();
									break;
								case 'category' :
									if(myEvent.category in category) {
										catClass = ' class="' + category[myEvent.category].className + '"';
									}
									break;
								case 'ev_link' :
									content = '<a href="' + myEvent[field] + '" target="_blank" rel="noreferrer">' + myEvent[field] + '</a>';
									break;
							}
							innerHTML += '<p class="' + classList.join(' ') + '"><span>' + caption + ' : </span><span' + catClass + '>' + content + '</span></p>'
						}
					});

					const box = overlay.querySelector('div');
					box.innerHTML = innerHTML;
					overlay.classList.add('active');
				}
			}
		}
	}

	/* ----------------- Planning ---------------- */
	document.querySelectorAll('.kzCalendar[data-planning]').forEach(function(node) {
		var target = null;
		var format = null;
		if(!node.hasAttribute('data-format')) {
			const TABLE = document.createElement('TABLE');
			const THEAD = document.createElement('THEAD');
			var innerHTML = '' +
				'<tr>' +
					'<th>#category#</th>' +
					'<th>#title#</th>' +
					'<th>&nbsp;</th>' +
					'<th>#day_begin#</th>' +
					'<th>#hour_begin#</th>' +
					'<th>#day_end#</th>' +
					'<th>#hour_end#</th>' +
					'<th>#location#</th>' +
					'<th>#period#</th>' +
					'<th>#periodend#</th>' +
				'</tr>';
			// https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Objets_globaux/String/replace
			if(typeof kzCalendarI18n.fieldNames !== 'undefined') {
				innerHTML = innerHTML.replace(
					/#(\w+)#/g,
					function(match, p1, offset, str1) {
						return kzCalendarI18n.fieldNames[p1];
					}
				);
			THEAD.innerHTML = innerHTML;
			TABLE.appendChild(THEAD);
			target = document.createElement('TBODY');
			TABLE.appendChild(target);
			node.innerHTML = '';
			node.appendChild(TABLE);
			format = '' +
				'<tr data-event-id="#id#">' +
					'<td class="#className#">#category#</td>' +
					'<td>#title#</td>' +
					'<td>#ev_link#</td>' +
					'<td>#day_begin#</td>' +
					'<td>#hour_begin#</td>' +
					'<td>#day_end#</td>' +
					'<td>#hour_end#</td>' +
					'<td>#location#</td>' +
					'<td>#period#</td>' +
					'<td>#periodend#</td>' +
				'</tr>';
			}
		} else {
			format = node.getAttribute('data-format');
			target = node;
		}

		node.addEventListener('click', updateEvent);

		const XHR = new XMLHttpRequest();
		XHR.node = node;
		XHR.target = target;
		XHR.format = format;
		XHR.onreadystatechange = function(event) {
			if(this.readyState === XMLHttpRequest.DONE) {
				if(this.status === 200) {
					const datas = JSON.parse(this.responseText);
					this.node.datas = datas;
					this.node.sortedEvents = sortEvents(datas);
					var innerHTML = '';
					const format = this.format;
					// A faire tester si day_begin > today ou day_end > today
					this.node.sortedEvents.forEach(function(myEvent) {
						innerHTML += format.replace(
							/#(\w+)#/g,
							function(match, p1, offset, str1) {
								switch(p1) {
									case 'ev_link':
										return ('ev_link' in myEvent) ? '<a href="' + myEvent.ev_link + '" title="' + myEvent.ev_link + '" target="_blank" rel="noreferrer">🔗</a>' : '&nbsp;';
										break;
									case 'className' :
										return (myEvent.category in datas.category) ? datas.category[myEvent.category].className : '';
										break;

									case 'day_begin':
									case 'day_end':
										if(p1 in myEvent) {
											const parts = myEvent[p1].split('-');
											const dt = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
											return dt.toLocaleDateString();
										} else {
											return '&nbsp;';
										}
										break;

									default:
										return (p1 in myEvent) ? myEvent[p1] : '&nbsp;';
								}
							}
						);
					});
					this.target.innerHTML = innerHTML;
				} else {
					console.log("Status for the response: %d (%s)", this.status, this.statusText);
				}
			}
		};
		XHR.open('GET', node.getAttribute('data-planning'), true);
		XHR.send(null);
	});

	/* --------------- Calendar ---------------- */
	function sortEvents(datas) {
		var sortedEvents = null;
		const ONE_DAY = 24 * 60 * 60 * 1000;
		if('events' in datas) {
			var buf = [];
			for(var id in datas.events) {
				var event = datas.events[id];
				event.id = id;
				var bufBegin = event.day_begin.split('-'),
					dateBegin = new Date(bufBegin[0], bufBegin[1], bufBegin[2]);
				event.sortKey = Math.round(dateBegin.getTime() / ONE_DAY);
				var duration = 1;
				if('day_end' in event) {
					var
						bufEnd = event.day_end.split('-'),
						dateBegin = new Date(bufBegin[0], bufBegin[1], bufBegin[2]),
						dateEnd = new Date(bufEnd[0], bufEnd[1], bufEnd[2]);
					duration = (dateEnd.getTime() - dateBegin.getTime()) / ONE_DAY + 1;
				}
				event.duration = duration;
				buf.push(event);
			}
			sortedEvents = buf.sort(function(a, b) {
				// on same date, the longest event first !
				return (a.sortKey != b.sortKey) ? a.sortKey - b.sortKey : b.duration - a.duration;
			});
		}
		return sortedEvents;
	}

	function calendarDrawing(container) {
		const TBODY = container.querySelector('table tbody');
		const SELECT_MONTH = container.querySelector('div:first-of-type select');
		const SELECT_YEAR = container.querySelector('div:first-of-type input[type="number"]');
		const OFFSETS = [-5, -6, 0, -1, -2, -3, -4]; // sunday to saturday (0..6)
		if(SELECT_MONTH != null && SELECT_YEAR != null) {
			const MONTH = parseInt(SELECT_MONTH.value); // starts from 0 to 11 on select tag
			const YEAR =  parseInt(SELECT_YEAR.value);
			const MONTH_BEGIN = new Date(YEAR, MONTH, 1); // year, month starts from 0, day starts from 1
			// console.log('Month begins on ' + MONTH_BEGIN.toLocaleString());
			const MONTH_END = new Date(YEAR, MONTH + 1, 1, 0, 0, -1);
			// console.log('Month ends on ' + MONTH_END.toLocaleString());
			const DAY_OF_WEEK = MONTH_BEGIN.getDay(); // day of week - starts from 0 with sunday
			// console.log('Day of the week for the 1st day : ' + DAY_OF_WEEK);
			// Monday on the first column, not sunday
			const CALENDAR_BEGIN = new Date(YEAR, MONTH, OFFSETS[DAY_OF_WEEK]);
			// console.log('Calendar begins on ' + CALENDAR_BEGIN.toLocaleString());
			const PREV_MONTH_DAYS = (new Date(YEAR, MONTH, 0)).getDate(); // last day of the previous month = count of days for the previous month
			const MONTH_DAYS = MONTH_END.getDate(); // count of days for this month
			// console.log(MONTH_DAYS + ' days of this month');
			// console.log(PREV_MONTH_DAYS + ' days for the previous month');

			// building the virtual calendar
			var step = CALENDAR_BEGIN.getDate(); // local time
			var localMonth = MONTH;
			var outerMonth = true;
			var virtualCal = []; // virtual calendar table
			var days = {}; // indexes for each day in the virtual calendar table
			for(var d=0, dMax=6 * 7; d < dMax; d++) {
				const dayStr = [YEAR, ('0' + localMonth).substr(-2), ('0' + step).substr(-2)].join('-');
				virtualCal.push({
					step: step,
					dateStr: dayStr,
					events: [],
					outerMonth: outerMonth
				});
				days[dayStr] = d;
				if(
					( outerMonth && step < PREV_MONTH_DAYS ) ||
					( !outerMonth && step < MONTH_DAYS)
				) {
					step++;
				} else {
					step = 1;
					localMonth++;
					outerMonth = !outerMonth;
				}
			}

			// put each event in the virtualCal
			if(container.sortedEvents != null) {
				// sorting events by date
				const SPACER = 1;
				container.sortedEvents.forEach(function(event) {
					if(event.day_begin in days) {
						var x = days[event.day_begin];
						virtualCal[x].events.push(event);
						if(event.duration > 1) {
							var depth = virtualCal[x].events.length;
							for(y=x+1, yMax = x + event.duration; y < yMax; y++) {
								if(depth > virtualCal[y].events.length) {
									for(var d=0, dMax = depth - virtualCal[y].events.length; d < dMax; d++) {
										virtualCal[y].events.push(SPACER);
									}
								}
							}
						}
					}
				});

				// Drawing of the canvas
				TBODY.innerHTML = '';
				var week = CALENDAR_BEGIN.getWeek();
				for(var y=0, yMax=6; y<yMax; y++) { // 5 weeks/month maxi
					const row = document.createElement('TR');
					row.className = 'week';
					const cellWeek = document.createElement('TD');
					cellWeek.innerHTML = week;
					week++;
					row.appendChild(cellWeek);
					var rows = 1;
					// First, draws the day of month in the row and computes the max count of events for this week/row
					for(var x=y * 7, xMax = x + 7; x<xMax; x++) { // 7 days/week
						const cellDay = document.createElement('TD');
						cellDay.className = 'day';
						cellDay.innerHTML = virtualCal[x].step;
						if(virtualCal[x].outerMonth) {
							cellDay.classList.add('outer');
						}
						row.appendChild(cellDay);
						if(rows < virtualCal[x].events.length) {
							rows = virtualCal[x].events.length;
						}
						row.appendChild(cellDay);
					}
					cellWeek.rowSpan = rows + 1;
					TBODY.appendChild(row);

					// Then, scan each event row by row and day by day
					for(var r = 0; r < rows; r++) {
						const row = document.createElement('TR');
						var	x = y * 7,
							xMax = x + 7;
						while(x < xMax) {
							var	duration = 1;
							if(r <= virtualCal[x].events.length) {
								const cell = document.createElement('TD');
								if(r < virtualCal[x].events.length) {
									var event = virtualCal[x].events[r];
									if(event !== SPACER) {
										duration = event.duration;
										if(duration > 1) {
											cell.colSpan = event.duration;
										}
										const block = document.createElement('P');
										const myLink = ('ev_link' in event) ? '&nbsp;<a href="' + event.ev_link + '" title="' + event.ev_link + '" target="_blank" rel="noreferrer">🔗</a>' : '';
										block.innerHTML = event.title + myLink;
										block.setAttribute('data-event-id', event.id);
										if('content' in event) {
											block.title = event.content;
										}
										if(event.category in container.datas.category) {
											const CAT = container.datas.category[event.category];
											if('className' in CAT) {
												block.className = CAT.className;
											}
										}
										cell.appendChild(block);
									}
								} else if(r == virtualCal[x].events.length) {
									cell.innerHTML = '&nbsp;';
									const rowSpan = rows - r
									if(rowSpan > 1) {
										cell.rowSpan = rowSpan;
									}
								}

								if(virtualCal[x].outerMonth) {
									cell.className = 'outer';
								}
								row.appendChild(cell);
							}
							x += duration;
						}
						TBODY.appendChild(row);
					}
				}
			} /* if(container.sortedEvents != null) */

		}
	}

	document.querySelectorAll('.kzCalendar[data-calendar]').forEach(function(node) {
		const today = new Date();
		const todayMonth = today.getMonth();
		const todayYear = 1900 + today.getYear();
		const monthNames = (typeof kzCalendarI18n.monthNames == 'string') ? kzCalendarI18n.monthNames : 'january february march april may june july august september october november december';
		var options = [];
		var count = 0;
		monthNames.split(' ').forEach(function(caption) {
			var selected = (count === todayMonth) ? ' selected' : '';
			options.push('<option value="'+ count +'"' + selected + '>' + caption + '</option>');
			count++;
		});
		var innerHTML = '';
		innerHTML += '<button type="button" data-step="-1">&lt;</button>';
		innerHTML += '<select>' + options.join("\n") + '</select>';
		innerHTML += '<input type="number" value="' + todayYear + '" min="1000" max="9999" />';
		innerHTML += '<button type="button" data-step="1">&gt;</button>';
		const HEADER = document.createElement('div');
		HEADER.className = 'header';
		HEADER.innerHTML = innerHTML;
		node.innerHTML = '';
		node.appendChild(HEADER);

		const dayNames = (typeof kzCalendarI18n.dayNames == 'string') ? kzCalendarI18n.dayNames : 'monday tuesday wednesday thursday friday saturday sunday';
		var ths = ['<th>&nbsp;</th>'];
		dayNames.split(' ').forEach(function(caption) {
			ths.push('<th>' + caption + '</th>');
		});
		var innerHTML = '';
		innerHTML += '<table><thead><tr>' + ths.join("\n") + '</tr></thead><tbody></tbody></table>';
		const MAIN = document.createElement('DIV');
		MAIN.className = 'main';
		MAIN.innerHTML = innerHTML;
		node.appendChild(MAIN);

		node.repaint = function(event) {
			calendarDrawing(this);
		};

		HEADER.querySelectorAll('select, input[type="number"]').forEach(function(el) {
			el.node = node;
			el.addEventListener('change', function(event) {
				this.node.repaint();
			});
		});

		HEADER.node = node;
		HEADER.addEventListener('click', function(event) {
			if(event.target.hasAttribute('data-step')) {
				event.preventDefault();
				const step = event.target.getAttribute('data-step');
				const MONTH_SELECT = this.querySelector('select');
				const YEAR_INPUT = this.querySelector('input[type="number"]');
				var idx = MONTH_SELECT.selectedIndex + parseInt(event.target.getAttribute('data-step'));
				var year = parseInt(YEAR_INPUT.value);
				var newYear = year;
				if(idx < 0) {
					// previous year
					idx = 11;
					newYear--;
				} else if(idx > 11) {
					// next year
					idx = 0;
					newYear++;
				}
				if(newYear != year || ( newYear > 1000 && newYear < 9999)) {
					MONTH_SELECT.selectedIndex = idx;
					if(newYear != year) {
						YEAR_INPUT.value = newYear;
					}
					this.node.repaint();
				}
			}
		});

		node.addEventListener('click', updateEvent);

		const XHR = new XMLHttpRequest();
		XHR.node = node;
		XHR.onreadystatechange = function(event) {
			if(this.readyState === XMLHttpRequest.DONE) {
				if(this.status === 200) {
					// Update the datas and repaint the table
					node.datas = JSON.parse(this.responseText);

					const TFOOT = document.createElement('DIV');
					TFOOT.className = 'footer'
					node.appendChild(TFOOT);
					for(var cat in node.datas.category) {
						const LABEL = document.createElement('LABEL');
						LABEL.className = node.datas.category[cat].className
						LABEL.innerHTML = cat;
						TFOOT.appendChild(LABEL);
					};
					node.sortedEvents = sortEvents(node.datas);
					this.node.repaint();
				} else {
					console.log("Status for the response: %d (%s)", this.status, this.statusText);
				}
			}
		};
		XHR.open('GET', node.getAttribute('data-calendar'), true);
		XHR.send(null);
	});

	/* --------- config : sélection de couleurs pour les catégories ---------- */
	document.querySelectorAll('.kz-config tbody select[name$="[className]"]').forEach(function(node) {
		node.addEventListener('change', function(event) {
			const TARGET = event.target;
			event.preventDefault();
			const TR = TARGET.parentElement.parentElement;
			TR.querySelector('td').className = TARGET.value;
		});
	});

	/* ---------------- Confirmer la suppression ----------------------- */
	const BTN_DELETE = document.querySelector('#form_kzCalendar input[name="btn-event-delete"]');
	if(BTN_DELETE != null) {
		BTN_DELETE.addEventListener('click', function(event) {
			if(!confirm(this.value + "\n" + this.form.elements.title.value)) {
				event.preventDefault();
			}
		});
	}

	/* ---------------- Dupliquer un évènement ----------------------- */
	const BTN_DUPLICATE = document.getElementById('btn-event-duplicate');
	if(BTN_DUPLICATE != null) {
		BTN_DUPLICATE.addEventListener('click', function(event) {
			const theForm = BTN_DUPLICATE.form;
			'day_begin day_end hour_begin hour_end'.split(' ').forEach(function(field) {
				theForm.elements[field].value = '';
			});
			theForm.elements.ev_id.value = '';
			const LABEL = document.body.querySelector('#form_kzCalendar .event-id');
			if(LABEL != null) {
				LABEL.innerHTML = ''
			}
			theForm.elements.day_begin.focus();
		});
	}

	const BTN_RESET = document.body.querySelector('#form_kzCalendar input[type="reset"]');
	if(BTN_RESET != null) {
		BTN_RESET.addEventListener('click', function(event) {
			event.target.form.elements.ev_id.value = '';
			const LABEL = event.target.form.querySelector('#form_kzCalendar .event-id');
			if(LABEL != null) {
				LABEL.innerHTML = ''
			}
			event.target.form.elements.title.focus();
		});
	}

})();
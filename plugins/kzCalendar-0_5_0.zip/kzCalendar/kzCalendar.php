<?php

if(!defined('PLX_ROOT')) { exit; }

// https://www.w3schools.com/w3css/w3css_color_libraries.asp

// Ne pas utiliser PLX_PLUGINS. PluXml l'utilise à la fois pour les chemins des fichiers et les urls. Remplacé par kzCalendar::pluginRoot

class kzCalendar extends plxPlugin {

	const JSON_OPTIONS  = JSON_UNESCAPED_UNICODE + JSON_NUMERIC_CHECK + JSON_UNESCAPED_SLASHES;
	const JSON_PRETTY_OPTIONS = JSON_UNESCAPED_UNICODE + JSON_NUMERIC_CHECK + JSON_UNESCAPED_SLASHES + JSON_PRETTY_PRINT;
	const PERIODS = 'none hour day workingday week month daymonth';
	const DAYS_WEEK = 'fullweek working_days no_sundays weekend last_3days two_days';
	private $__datas = false; // stocke tous les évènements
	public $params = array( // liste des champs pour tous les évènements
		'category'		=> 'string',
		'title'			=> 'string',
		'content'	=> 'cdata',
		'day_begin'		=> 'date',
		'day_end'		=> 'date',
		'hour_begin'	=> 'time',
		'hour_end'		=> 'time',
		'location'		=> 'string',
		'period'		=> 'string',
		'periodend'		=> 'date',
		'ev_link'		=> 'string'
	);
	public $racine = false; // adresse absolue de la racine du site
	public $storage = false; // dossier de stockage des calendriers
	public $pluginRoot = false; // url du dossier du plugin

	public function __construct($default_lang) {

		parent::__construct($default_lang);

		$this->setConfigProfil(PROFIL_ADMIN);

		$this->setAdminProfil(PROFIL_ADMIN);
		$this->setAdminMenu($this->getLang('L_CALENDAR'), 4, 'Gestion évènementielle');

		if(defined('PLX_ADMIN')) {
			// Gestionnaire de médias
			$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
			// récupère l'adresse Url de la racine du site
			$this->addHook('AdminFootEndBody', 'AdminFootEndBody');
			$this->addHook('plxAdminConstruct', 'plxAdminConstruct');
		} else {
			$this->addHook('ThemeEndBody', 'AdminFootEndBody');
			$this->addHook('IndexEnd', 'IndexEnd');
		}
		$this->addHook('plxMotorConstructLoadPlugins', 'plxMotorConstructLoadPlugins');
	}

	/**
	 * Détermine le nom du fichier pour les paramètres du plugin.
	 * */
	private function __filename() {
		// return preg_replace('@\.xml$@i', '.json', $this->plug['parameters.xml']);
		return PLX_ROOT.$this->storage.__CLASS__.'.json';
	}

	public function datasUrl() {
		$time = date('md-Hi');
		return plxUtils::getRacine().$this->storage.__CLASS__.'.json?time='.$time;
	}

	public function loadCalendar() {
		$filename = $this->__filename();
		if(file_exists($filename)) {
			$this->__datas = json_decode(file_get_contents($filename), true);
		} else {
			$this->__datas = array(
				'autoindex'	=> 1,
				'category'	=> array(),
				'location'	=> array(),
				'events'	=> array(),
				'fields'	=> array_keys($this->params)
			);
		}
	}

	/**
	 * Sauvegarde la liste des évènements et différents paramètres.
	 * */
	public function saveCalendar() {
		// Update lists of categories and locations
		if(!empty($this->__datas['events'])) {
			foreach(explode(' ', 'category location') as $field) {
					$items = array();
					foreach($this->__datas['events'] as $id=>$infos) {
						if(array_key_exists($field, $infos)) {
							$value = $infos[$field];
							if(array_key_exists($value, $items)) {
								$items[$value]++;
							} else {
								$items[$value] = 1;
							}
						}
					}
				if($field == 'category') {
					if(!array_key_exists('category', $this->__datas)) {
						$this->__datas['category'] = array();
					}

					foreach($items as $key=>$count) {
						if(!array_key_exists($key, $this->__datas['category'])) {
							$this->__datas['category'][$key] = array('count' => $count);
						} else {
							$this->__datas['category'][$key]['count'] = $count;
						}
					}

					foreach($this->__datas['category'] as $category=>$infos) {
						if(!array_key_exists($category, $items)) {
							// Drop unused old category
							unset($this->__datas['category'][$category]);
						}
					}
				} else {
					$this->__datas[$field] = $items;
				}
				ksort($this->__datas[$field]);
			}

			/* ********************************************************** */
			/* Trier les évènements par date de début avant la sauvegarde */
			/* ********************************************************** */
			uasort(
				$this->__datas['events'],
				function($value1, $value2) {
					$result = 0;
					$fields = explode(' ', 'day_begin hour_begin day_end hour_end');
					// $fields = explode(' ', 'day_begin hour_begin');
					foreach($fields as $field) {
						if(!empty($value1[$field])) {
							$result = (!empty($value1[$field])) ? strnatcmp($value1[$field], $value2[$field]) : 1;
						} else {
							$result = -1;
						}
						if($result != 0) { break; }
					}
					return $result;
				}
			);

			$this->__datas['fields'] = array_keys($this->params);

			$filename = $this->__filename();
			if(!file_put_contents($filename, json_encode($this->__datas, $this::JSON_PRETTY_OPTIONS))) {
				plxMsg::Error($this->getLang('L_CALENDAR_ERR'));
			} else {
				plxMsg::Info(L_SAVE_SUCCESSFUL);
			}
		} else {
			plxMsg::Error($this->getLang('L_EMPTY_EVENTS_LIST'));
		}
	}

	/**
	 * Ajoute ou met à jour un évènement.
	 * */
	public function setEvent($data) {
		if(isset($_POST['btn-event-delete'])) {
			// Suppression d'un évènement
			$id = $_POST['ev_id'];
			if(
				!empty($id) and
				array_key_exists($id, $this->__datas['events']) and
				!empty($_POST['title']) and
				($this->__datas['events'][$id]['title'] == $_POST['title'])
			) {
				unset($this->__datas['events'][$id]);
			}
		} elseif(isset($_POST['btn-category'])) {
			// Configuration des catégories
			if(!empty($_POST['categories']) and is_array($_POST['categories'])) {
				foreach($_POST['categories'] as $fields) {
					$cat = $fields['name'];
					if(array_key_exists($cat, $this->__datas['category'])) {
						foreach(array('className', 'days') as $key) {
							if(!empty($fields[$key])) {
								$this->__datas['category'][$cat][$key] = $fields[$key];
							} elseif(array_key_exists($key, $this->__datas['category'][$cat])) {
								unset($this->__datas['category'][$cat]);
							}
						}
					}
				}
			}
		} else {
			// Ajout ou modification d'un évènement
			if(empty($_POST['ev_id'])) {
				$this->__datas['autoindex']++;
				$id = $this->__datas['autoindex'];
			} else {
				$id = $_POST['ev_id'];
			}
			$data = array();
			// contrôle des valeurs des champs
			foreach(array_keys($this->params) as $field) {
				if(!empty($_POST[$field])) {
					$value = trim($_POST[$field]);
					if(!empty($value)) {
						switch($field) {
							case 'category' :
							case 'title' :
							case 'location' :
							case 'ev_link' :
							case 'content' :
								// élimination des codes indésirables php et javascript
								$data[$field] = preg_replace('@(?:<\?\w*\s*|\?>|on\w="[^""]*"|</?script[^>]*>)@is', '', $value);
								break;
							case 'day_begin' :
							case 'day_end' :
							case 'periodend' :
								// date
								if(preg_match('@^\d{4}(?:-\d\d){2}$@', $value)) {
									$data[$field] = $value;
								}
								break;
							case 'hour_begin' :
							case 'hour_end' :
								if(preg_match('@^\d\d(?::|h)\d\d$@i', $value)) {
									$data[$field] = $value;
								}
								break;
							case 'period' :
								if(
									in_array($value, explode(' ', $this::PERIODS)) and
									(strtolower($value) != 'none')
								) {
									$data[$field] = $value;
								}
								break;
						}
					}
				}
			}
			$required = true;
			foreach(explode(' ', 'title day_begin') as $field) {
				if(!array_key_exists($field, $data)) {
					$required = false;
					break;
				}
			}
			if($required) {
				$this->__datas['events'][$id] = $data;
				$_SESSION['kzCalendar-category'] = (array_key_exists('category', $data)) ? $data['category'] : '';
			}
		}
	}

	public function no_event() {
		return empty($this->__datas['events']);
	}

	public function getCategories() {
		return $this->__datas['category'];
	}

	/**
	 * Affiche une balise <select> pour la saisie d'un évènement.
	 * @param $field champ de saisie pour l'évènement. Valeurs permises : category, location
	 * @param $value valeur actuelle de ce champ pour cet évènement
	 * */
	public function print_select($field, $value='') {
		if(in_array($field, explode(' ', 'category location'))) {
			$items = $this->__datas[$field];
			if(!empty($this->__datas['popularity'][$field])) {
				arsort($items);
			}
?>
			<select id="id_<?php echo $field; ?>" name="<?php echo $field; ?>">
				<option value="">---</option>
<?php
			foreach(array_keys($items) as $option) {
				$selected = ($value == $option) ? ' selected' : '';
?>
				<option value="<?php echo $option; ?>"<?php echo $selected; ?>><?php echo $option; ?></option>
<?php
			}
?>
			</select>
<?php
		} else {
?>
		<span>select tag not allowed here</span>
<?php
		}

	}

	/* ---------- onActivate ----------- */
	/**
	 * Gère les règles CSS communes aux backend et frontend.
	 * */
	public function OnActivate() {

		$common_filename = __DIR__."/css/common.css";
		foreach(explode(' ', 'admin site') as $side) {
			$filename = __DIR__."/css/$side.css";
			$filename1 = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.".$side.css";
			if(
				file_exists($filename) and
				file_exists($common_filename) and
				(
					!file_exists($filename1) or
					(filemtime($filename1) < filemtime($filename)) or
					(filemtime($filename1) < filemtime($common_filename))
				)
			) {
				$buf = file_get_contents($common_filename);
				$buf .= file_get_contents($filename);
				if(!empty($buf)) {
					$header = "/* Auto-generated by ".__CLASS__." on ".date('Y-m-d H:i')."*/\n\n";
					file_put_contents($filename1, $header.$buf);
				}
				if(empty($buf) and file_exists($filename1)) {
					unlink($filename1);
				}
			}
		}
	}

	/* ------------ Hooks --------------- */

	/**
	 * Adapte le gestionnaire de médias pour sélectionner le média de l'évènement.
	 * */
	public function AdminMediasFoot() {
?>
		<script type="text/javascript">
			(function() {
				if(
					frameElement != null &&
					frameElement.id == 'kzCalendar-medias'
				) {
					const tbody = document.body.querySelector('#medias-table tbody');
					if(tbody != null) {
						document.body.classList.add('iframe');
						tbody.addEventListener('click', function(event) {
							if(event.target.tagName == 'A') {
								event.preventDefault();
								console.log(event.target.href);
								const target = window.top.document.getElementById('id_ev_link');
								const overlay = window.top.document.getElementById('kzCalendar-medias-overlay');
								if(target != null && overlay != null) {
									overlay.classList.remove('active');
									const urlBaseLength = overlay.getAttribute('data-url-base').length;
									target.value = event.target.href.substr(urlBaseLength);
								}
							}
						});
					}
				}
			})();
		</script>
<?php
	}

	/**
	 * Récupère la racine du site, les urls des dossiers pour le stockage des calendriers et du plugin. Crée le dossier de sauvegarde des évènements et charge le calendrier.
	 * */
	public function plxMotorConstructLoadPlugins() {
		// set true condition only on developpement
		if(true) { $this->onActivate(); }

		$pluginName = __CLASS__;
		$pattern = $this->getLang('L_UNABLE_TO_CREATE FOLDER');
		echo <<< CODE
<?php
	\$dirname1 = \$this->aConf['medias'].'$pluginName';
	if(!is_dir(PLX_ROOT.\$dirname1) && @!mkdir(PLX_ROOT.\$dirname1)) {
		plxMsg::Error(sprintf('$pattern', \$dirname1));
	}

	\$this->plxPlugins->aPlugins['$pluginName']->racine = \$this->racine;
	\$this->plxPlugins->aPlugins['$pluginName']->storage = \$dirname1.'/';
	\$this->plxPlugins->aPlugins['$pluginName']->pluginRoot = \$this->racine.\$this->aConf['racine_plugins']."$pluginName/";
	return false;
?>
CODE;
	}

	/**
	 * Charge le calendrier pour le panneau d'administration.
	 * */
	public function plxAdminConstruct() {
		$pluginName = __CLASS__;
		echo <<< CODE
<?php
	\$this->plxPlugins->aPlugins['$pluginName']->loadCalendar();
	return false;
?>
CODE;
	}

	/**
	 * Fait la liaison avec Javascript. Fournit un dictionnaire pour la traduction et l'url du script à télécharger.
	 * */
	public function AdminFootEndBody() {
		$src = $this->pluginRoot.'app.js';
		$monthNames = implode(' ', array(
			L_JANUARY,
			L_FEBRUARY,
			L_MARCH,
			L_APRIL,
			L_MAY,
			L_JUNE,
			L_JULY,
			L_AUGUST,
			L_SEPTEMBER,
			L_OCTOBER,
			L_NOVEMBER,
			L_DECEMBER
		));
		$dayNames = implode(' ',array(
			L_MONDAY,
			L_TUESDAY,
			L_WEDNESDAY,
			L_THURSDAY,
			L_FRIDAY,
			L_SATURDAY,
			L_SUNDAY
		));
		$lines = array();
		foreach(array_keys($this->params) as $param) {
			$value = addslashes($this->getLang('L_'.strtoupper($param)));
			$lines[] = <<< LINE
				$param : '$value'
LINE;
		}
		$fieldNames = implode(",\n", $lines);
?>
	<script type="text/javascript">
		const kzCalendarI18n = {
<?php
		echo <<< EOT
			monthNames : '$monthNames',
			dayNames: '$dayNames',
			fieldNames: {
$fieldNames
			}

EOT;
?>
		};
	</script>
	<script type="text/javascript" src="<?php echo $src; ?>"></script>
<?php
	}

	/**
	 * Gére l'urlrewriting côté site pour les attributs data-calendar et data-planning.
	 * Utilise une function de callback pour preg_replace()
	 * */
	public function IndexEnd() {
		echo <<< 'CODE'
<?php
	if($plxMotor->aConf['urlrewriting']) {
		$output = preg_replace_callback(
			'@(<div\s.*data-(?:calendar|planning))="([^>"]+)"@',
			function($matches) use($plxMotor) {
				if(!preg_match('@^(?:\w+://|/)@', $matches[2])) {
					return $matches[1].'="'.$plxMotor->racine.$matches[2].'"';
				} else {
					return $matches[0];
				}
			},
			$output
		);
	}
?>
CODE;
	}
}
?>
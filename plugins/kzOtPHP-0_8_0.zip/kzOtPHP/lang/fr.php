<?php
$LANG = array(
	'OTP_ENABLE'		=> 'Activer la double authentification',
	'OTP_PIN'			=> 'Code PIN',
	'OTP_FAILURE'		=> 'Code PIN erronné',
	'OTP_SCAN'			=> 'Scannez le QR-code',
	'DIGEST'			=> 'Hashage',
	'DIGITS'			=> 'Nombre de chiffres',
	'QRCODE_PROVIDER'	=> 'Générateur local pour le QRcode',
	'COPIED'			=> 'Uri copié dans le presse-papier'
);
?>
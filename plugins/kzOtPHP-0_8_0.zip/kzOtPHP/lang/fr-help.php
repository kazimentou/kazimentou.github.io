<p>
	Ce plugin installe la double authentification pour accéder à la partie administrative de votre CMS.
</p>
<p>En plus du couple habituel "nom d'utilisateur/mot de passe", il vous sera demander un code PIN qui est une courte série de chiffres, 6 par défaut, générée par un logiciel d'authentification installé, en général, sur votre smartphone.</p>
<p>Pour cela, quelques logiciels sont suggérés sur le panneau de configuration du plugin. Un seul suffit mais il est possible d'en tester plusieurs à la fois.</p>
<p>Le logiciel d'authentification doit partager avec votre CMS une clé secrète constituée une longue série aléatoire de lettres et chiffres. Pour éviter une recopie fastidieuse, cette clé est affichée sous forme d'un QR-Code, à scanner avec votre logiciel d'authentification installé sur votre smartphone. Des étiquettes sont rajoutées pour faciliter le classement des clés de vos différents CMS ou sites WEB.</p>
<p>Le code PIN a une durée de validité limitée à 30 secondes par défaut et est fonction de la date. C'est ce qui fait en fait sa force.</p>
<p>Il est toutefois possible d'accorder une certaine tolérance à cette période compte-tenu des éventuelles lenteurs de la connexion ADSL, en modifiant la constante de class kzOTPHP::WINDOW. Elle est réglée à 2. La validité d'un code PIN est alors de plus ou moins 2 fois la période, soit une minute. Le code pin changeant à chaque période, il peut donc y avoir plusieurs codes PIN valables en même temps.</p>
<p>Activer la double authenfication dans la page de profil et scanner le QR-Code affiché après enregistrement.</p>
<p>Dès que vous aurez accès à la page d'authentification, il faudra saisir les habituels compte utilisateur et mot de passe, et de plus, le code PIN généré par le logiciel sur votre smartphone.</p>
<p>En principe, le logiciel affiche un compte à rebours pour la validité du code PIN. Il est conseillé de valider la page d'authentification du CMS un peu avant la moitié du décompte.</p>
<p>En cas d'échec à la connection, il faut utiliser un client FTP, comme Fillezilla, et supprimer la ligne relative à ce plugin dans le fichier data/configuration/plugins.xml.</p>
<p>Les clés secrètes sont stockées dans le fichier sous une forme cryptée qui dépend du serveur.</p>
<p><strong>Ne transférez jamais ce fichier de configuration d'un serveur à l'autre.</strong></p>
<p>Pour afficher le QR-Code, on peut utiliser le générateur interne ou celui proposé par Google. Dans ce dernier cas, votre clé secrète sera transférée à Google avec le protocole HTTPS et stockée dans le code source de la page HTML produite.</p>
<p>Dans la page de profil, la clé secrète et les étiquettes seront recopiées dans le presse-papier en cliqant sur la QR-Code avec la souris.</p>
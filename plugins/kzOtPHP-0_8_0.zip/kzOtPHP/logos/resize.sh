#!/bin/sh
mogrify -resize 100x -path 100 *.png

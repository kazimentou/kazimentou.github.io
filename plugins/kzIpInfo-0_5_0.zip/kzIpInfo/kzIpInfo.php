<?php
if(!defined('PLX_ROOT')) { exit; }

class kzIpInfo extends plxPlugin {

	public function __construct($default_lang) {
		parent::__construct($default_lang);

		if(!function_exists('geoip_country_code_by_name')) {
			parent::addHook('AdminCommentsFoot', 'AdminCommentsFoot');
		}
	}

	/* --------- Hooks ------------- */
	public function AdminCommentsFoot() {
?>
<script type="text/javascript">
	(function() {
		const cells = document.body.querySelectorAll('#comments-table:not(.flag) td.ip-address[data-ip]');

		if(cells.length > 0) {
			const XHR =  new XMLHttpRequest();
			var ipList = new Array();
			for(var i=0, iMax=cells.length; i<iMax; i++) {
				const cell = cells[i];
				const ip = cell.getAttribute('data-ip');

				if(typeof ipList[ip] === 'undefined') {
					XHR.open('GET', 'http://ipinfo.io/' + ip + '/geo', false); // Requête synchrone
					XHR.send(null);
					if(XHR.status === 200) {
						ipList[ip] = JSON.parse(XHR.responseText);
					} else {
						ipList[ip] = null;
					}
				}

				if(ipList[ip] != null) {
					const country = ipList[ip].country;
					const flag = document.createElement('IMG');
					flag.src = '<?php echo PLX_FLAGS_32_PATH; ?>' + country + '.png';
					flag.className = 'flag';
					flag.alt = country;
					flag.title = [country, ipList[ip].region].join(' : ');
					cell.appendChild(document.createElement('BR'));
					cell.appendChild(flag);
				}
			}
		}
	})();
</script>
<?php
	}

}
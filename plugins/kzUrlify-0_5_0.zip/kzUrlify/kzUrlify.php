<?php

if(! defined('PLX_ROOT')) { exit; }

include_once('urlify/URLify.php');

// zip -rXo kzUrlify.zip kzUrlify  -x '*/*/.*'

/**
 * Intégration de la librairie urlify dans PluXml.
 *
 * Fait la translittération des titres en caractères latins pour former des urls valides
 * alphabets pris en charge : cyrillique, bulgare, polonais, allemand, ....
 *
 * https://github.com/jbroadway/urlify
 * https://fr.wikipedia.org/wiki/Transcription_et_translitt%C3%A9ration
 * */
class kzUrlify extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# $this->setConfigProfil(PROFIL_ADMIN);

		# Accès au menu admin réservé au profil administrateur
		# $this->setAdminProfil(PROFIL_ADMIN);

		# Ajouts des hooks
		$this->addHook('plxAdminEditArticle', 'plxAdminEditArticle');
		$this->addHook('plxAdminEditStatiquesUpdate', 'plxAdminEditStatiquesUpdate');
	}

	public function plxAdminEditArticle() {
		echo <<< 'EOT'
<?php
	if(
		($content['url'] == plxUtils::title2url($content['title'])) or
		($content['url'] == L_DEFAULT_NEW_ARTICLE_URL)
	) {
		# On défait ce qu'a fait PluXml avec la fonction plxUtils::removeAccents()
		$content['url'] = URLify::filter($content['title'], 60, $this->aConf['default_lang']);
	} else {
		$content['url'] = URLify::filter($content['url'], 60, $this->aConf['default_lang']);
	}

	return false;
?>
EOT;
	}

	public function plxAdminEditStatiquesUpdate() {
		echo <<< 'EOT'
<?php
	if(empty(trim($url))) {
		$value = URLify::filter($stat_name, 60, $this->aConf['default_lang']);
		if(!empty($value)) {
			$this->aStats[$static_id]['url'] = $value;
		}
	}
	return false;
?>
EOT;
	}

}
?>
# plxFontAwesome
PluXml plugin: Ajouter Font-Awesome 5.0.0 à votre thème PluXml

![Font-Awesome](https://cloud.githubusercontent.com/assets/13441278/10660837/31652daa-78aa-11e5-8c78-e07ad0694b1a.png)

Permet d'ajouter sans effort Font-Awesome à PluXml sans effort, il suffit simplement d'activer le plugin. 
Inclut également une documentation complète avec la liste des icones et les exemples pour intégrer une icone.

Le plugin complet est disponible sur  mon [dépôt de plugins pour Pluxml](http://blog.niqnutn.com/plugins/repository/index.php) ou sur [Github](https://github.com/nIQnutn/plxFontAwesome)   
    

[Font Awesome](https://fontawesome.com/):  Font Awesome 5.0.0          
Font Awesome licensed under 
* Icons — CC BY 4.0 License
* Fonts — SIL OFL 1.1 License
* Code — MIT License

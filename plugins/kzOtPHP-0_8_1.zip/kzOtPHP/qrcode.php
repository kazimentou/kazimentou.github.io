<?php
# Anti-hacking
if(
	empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) or
	!preg_match_all('@(([a-z]{2}(?:-[A-Z]{2})?)(?:;q=(1|0.\d+))?)@', $_SERVER['HTTP_ACCEPT_LANGUAGE'], $matches, PREG_SET_ORDER )
) {
	http_response_code(404);
	die();
}

define('PLX_ROOT', preg_replace('@[^/]+/[^/]+$@', '', __DIR__));

const IMG_SIZE = 200;

session_start();

foreach($matches as $set1) {
	if(substr($set1[2], 0, 2) == $_SESSION['admin_lang']) {
		$accept_lang = true;
		break;
	}
}

# Anti-hacking
if(empty($accept_lang)) {
	http_response_code(404);
	die();
}

if(empty($_SESSION['user']) or empty($_SESSION['domain']) or strpos($_SESSION['domain'], PLX_ROOT) !== 0) {
	header('Content-Type: text/plain;charset=utf-8');
	# print_r($_SESSION);
	echo PLX_ROOT."\n";
	echo strpos($_SESSION['domain'], PLX_ROOT)."\n";
	print_r($_SESSION);
	echo "\nUnavailable Service\nSorry for this disagrement.\n";
	exit;
}

require PLX_ROOT.'config.php';
$pluginName = basename(__DIR__);
$filename = PLX_ROOT.PLX_CONFIG_PATH."plugins/$pluginName.xml";

if(!file_exists($filename)) {
	header('Content-Type: text/plain;charset=utf-8');
	echo "File $filename not found\n";
	exit;
}

define('PLX_PLUGINS', preg_replace('@[^/]+$@', '', __DIR__));
require PLX_ROOT.'core/lib/config.php'; # define some constants: DEFAULT_LANG, PLX_CHARSET
require PLX_ROOT.'core/lib/class.plx.plugins.php';
require "$pluginName.php";
require 'vendor/autoload.php';
$plugin = new kzOtPHP($_SESSION['admin_lang']);
$qrCodeUri = $plugin->getQrCodeUri();

$renderer = new \BaconQrCode\Renderer\Image\Png();
$renderer->setHeight(IMG_SIZE);
$renderer->setWidth(IMG_SIZE);
$writer = new \BaconQrCode\Writer($renderer);

header('Content-Type: image/png');
header('Expires: on, 01 Jan 1970 00:00:00 GMT');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
echo $writer->writeString($qrCodeUri);
?>
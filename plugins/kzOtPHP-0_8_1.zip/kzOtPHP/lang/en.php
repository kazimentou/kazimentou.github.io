<?php
$LANG = array(
	'OTP_ENABLE'		=> 'Enable double factor authentification',
	'OTP_PIN'			=> 'PIN Code',
	'OTP_FAILURE'		=> 'Wrong PIN  Code',
	'OTP_SCAN'			=> 'Scan the QR-code',
	'DIGEST'			=> 'Hashage',
	'DIGITS'			=> 'Count of digits',
	'QRCODE_PROVIDER'	=> 'Internal builder for QRcode',
	'COPIED'			=> 'URI copied into the clipboard'
);
?>
<?php

if (!defined('PLX_ROOT'))
	exit;

/*
 * Plugin pour utiliser TinyMCE dans l'édition des articles et des pages statiques
 * Utilise le script core/admin/medias.php pour choisir les images et les documents de
 * la bibliothèque de médias
 *
 * Dans le tableau de la bibliothèque de médias, cliquez sur un des liens pour insérer
 * un document/image dans l'article ou la page statique
 *
 * Tous les liens vers les documents/images insérés dans les articles et pages statiques
 * sont transformés en liens absolus par TinyMCE
 * ( voir options : relative_urls, remove_script_host et document_base_url )
 *
 * version TinyMCE 4
 * http://www.tinymce.com/
 *
 * */

// pour le codage des entités, voir http://www.tinymce.com/wiki.php/Configuration:entity_encoding

define('TINY_VERSION', '4');
define('TINY_PLUXML_JS_LIB', 'tinyMCE-pluxml.js');

/*
if (! defined('JQUERY_LIB'))
	define('JQUERY_LIB', 'jquery-1.11.3.min.js');
if (! defined('JQUERY_SRC')) {
	define('JQUERY_SRC', '//code.jquery.com/'.JQUERY_LIB);
}
*/

if (! defined('TINYMCE_LIB'))
	define('TINYMCE_LIB', '//cdn.tinymce.com/'.TINY_VERSION.'/tinymce.min.js');

class tinyMCE extends plxPlugin {

	public $default_values = array(
		'article'=>248, // 128+64+32+16+8
		'statique'=>192, // 128+64
		'comment'=>248, // 128+64+32+16+8
		'user'=>0,
		// 'parametres_edittpl'=>128,
		'selector'=>'textarea',
		'codemirror'=>0,
		'cdn'=>1
	);
	public $weightProfils = array(PROFIL_ADMIN=>128, PROFIL_MANAGER=>64, PROFIL_MODERATOR=>32, PROFIL_EDITOR=>16, PROFIL_WRITER=>8);

	public $localMinifyLib = 'tinymce/js/tinymce/tinymce.min.js';
	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->default_values['styleformats'] = <<<EOT
{title: 'Image Left', selector: 'img', styles: {'float': 'left', 'margin': '0 10px 0 10px'}},
{title: 'Image Right', selector: 'img', styles: {'float': 'right', 'margin': '0 10px 0 10px'}}
EOT;
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminMediasFoot', 'AdminMediasFoot');
		$this->addHook('AdminIndexFoot', 'AdminIndexFoot');
	}

	public function onDelete() {
		# A tester avec Pluxml > version 5.5-beta3
		$filename = $this->abs_config_filename();
		if (is_writable($filename)) {
			unlink($filename);
		}
	}

	private function pluginRoot() {
		global $plxAdmin;
		return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
	}

	public function get_skins() {
		$items = array(''=>'Par défaut');
		$folder = dirname(__FILE__).'/tinymce/skins/';
		if (!is_dir($folder)) {
			$folder = dirname(__FILE__).'/extras/skins/';
		}
		if (is_dir($folder)) {
			$files = glob($folder.'*');
			if (!empty($files)) {
				foreach ($files as $file1) {
					if (is_dir($file1)) {
						$value = substr(strrchr($file1, '/'), 1);
						$items[$value] = ucfirst($value);
					}
				}
			}
			else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
				echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
				$dir = new DirectoryIterator($folder.'.');
				foreach ($dir as $fileinfo) {
					if ($fileinfo->isDir() && !$fileinfo->isDot()) {
						$filename = $fileinfo->getFilename();
						$items[$filename] = ucfirst($filename);
					}
				}
				asort($items);
			}
		}
		return $items;
	}

	private function build_javascript_lib($all=false) {
		global $plxAdmin;

		if ($all) {
			$options = '/* ======== Built automatically by TinyMCE plugin on '.date('c')." ============ */\n\n";
			$options.= "/* begin of tinyMCE.js */\n\n";
			$options .= file_get_contents(dirname(__FILE__).'/tinyMCE.js')."\n\n";
			$options.= "/* end of tinyMCE.js */\n\n";
		} else
			$options = '';

		$document_base_url = $plxAdmin->racine;
		$options .= "/* \$plxAdmin->racine: $document_base_url */\n";
		$options .= "/* \$_SERVER['REQUEST_SCHEME']: {$_SERVER['REQUEST_SCHEME']} */\n";
		$options .= "/* \$_SERVER['HTTP_HOST']: {$_SERVER['HTTP_HOST']} */\n";
		if (! preg_match('#^https?://#', $document_base_url)) {
			// we add protocol and hostname
			if (isset($_SERVER['REQUEST_SCHEME']))
				$document_base_url = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$plxAdmin->racine;
			else
				$document_base_url = 'http://'.$_SERVER['HTTP_HOST'].$plxAdmin->racine;
		}

		$external_root = $this->pluginRoot().'extras/';

		$skin = $this->getParam('skin'); // look at tinyMCE/skins/ folder in the plugin
		if (!empty($skin) and ($skin != 'lightGray') and is_readable(dirname(__FILE__).'/extras/skins/'.$skin)) {
			$external_skin = $external_root.'skins/'.$skin;
			$option_skin = "skin: '$skin', skin_url: '$external_skin',";
		}
		else
			$option_skin = '';
		$i18N = array('en'=>'en_GB', 'fr'=>'fr_FR', 'pt'=>'pt_PT');
		$lang = $plxAdmin->aConf['default_lang'];
		if (array_key_exists($lang, $i18N))
			$lang = $i18N[$lang];
		$language_url = $external_root.'langs/'.$lang.'.js';

		// selectors CSS for blocks to apply TinyMCE
		$selector = $this->getParam('selector');
		if (strlen($selector) == 0)
			$selector = 'textarea';

		$pluginRoot1 = $this->pluginRoot();
		$options .= <<< OPTIONS_BEGIN
var basicPlugins = 'wordcount fullscreen visualchars charmap save ';
var extraPlugins = '\
advlist autolink link image imagetools media lists hr anchor emoticons \
searchreplace preview visualblocks nonbreaking \
save table contextmenu directionality template paste textcolor autoresize\
';

// for each profil:
var pluginsList = [
	basicPlugins+extraPlugins, // PROFIL_ADMIN
	basicPlugins+extraPlugins, // PROFIL_MANAGER
	basicPlugins+extraPlugins, // PROFIL_MODERATOR
	basicPlugins, // PROFIL_EDITOR
	basicPlugins // PROFIL_WRITER
];
var options = {
	selector: '{$selector}',
	toolbar:
		'save undo redo | bold italic | alignleft aligncenter alignright alignjustify | '+
		'bullist numlist outdent indent | link image media anchor emoticons | forecolor backcolor |'+
		' charmap visualchars preview fullscreen',
	imagetools_toolbar: 'rotateleft rotateright | flipv fliph | editimage imageoptions',
	language: '{$lang}',
	language_url: '{$language_url}',
	{$option_skin}
	image_advtab: true,
	image_description: true,
	image_title: true,
	image_caption: true,
	image_class_list: [
		{title: 'Aucune', value: ''},
		{title: 'Galerie n°1', value: 'lightbox-1'},
		{title: 'Galerie n°2', value: 'lightbox-2'},
		{title: 'Galerie n°3', value: 'lightbox-3'}
	],
	paste_data_images: true,
	entities : "160,nbsp,38,amp,34,quot,162,cent,169,copy,174,reg,8482,trade,8240,permil,60,lt,62,gt,8804,le,8805,ge,176,deg,8722,minus",
	file_browser_callback_types: 'file image',
	file_picker_callback: myFile_picker_callback,
	link_list: '{$pluginRoot1}arts.php?cat',
	images_upload_url: '{$pluginRoot1}postAcceptor.php',
	media_alt_source: false,
	video_template_callback: myVideo_template_callback,
	content_css: '{$external_root}content.css',
	save_onsavecallback: saveDocument,
	external_plugins: {},

OPTIONS_BEGIN;

		$style_formats = $this->getParam('styleformats');
		if (!empty($style_formats)) {
			$options .= <<< OPTIONS_FORMATS
		style_formats: [
{$style_formats}
		],

OPTIONS_FORMATS;
		}

		$options .= <<< OPTIONS_END
	document_base_url: '{$document_base_url}',
	nonbreaking_force_tab: true
};

OPTIONS_END;

	return $options;
	}

	public function abs_config_filename() {
		return substr(dirname(__FILE__), 0, -strlen(__CLASS__)).TINY_PLUXML_JS_LIB;
	}

	public function create_JS_lib() {
		return file_put_contents($this->abs_config_filename(), $this->build_javascript_lib(true));
	}
// ------------- Hooks start here ----------------------------------
	public function AdminTopEndHead($params=false) {
		global $plxAdmin;

		$script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		switch ($script_name) {
			case 'article' :
			case 'statique' :
			case 'comment':
			case 'user':
			// case 'parametres_edittpl' :
				$param = intval($this->getParam($script_name)); // getParam returns a string value
				$mask_user = $this->weightProfils[$_SESSION['profil']];
				if (($param & $mask_user) > 0) { // bits mask
					if (! defined('JQUERY_LOADED')) { ?>
	<!-- TinyMCE plugin -->
	<!-- script type="text/javascript">
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src='+'"<?php echo JQUERY_SRC; ?>"></scr'+'ipt>');
	</script -->
<?php					define('JQUERY_LOADED', true);
					}

		// loading library for TinyMCE via CDN or locally
		if ((intval($this->getParam('cdn')) > 0) or ! is_readable(dirname(__FILE__).'/'.$this->localMinifyLib))
			$tinyMCE_lib = TINYMCE_LIB; // for CDN
		else
			$tinyMCE_lib = $this->pluginRoot().$this->localMinifyLib;
?>
	<script type="text/javascript" src="<?php echo $tinyMCE_lib; ?>"></script>
<?php
		$ok = is_readable($this->abs_config_filename());
		if ($ok) { ?>
	<script type="text/javascript" src="<?php echo $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].TINY_PLUXML_JS_LIB; ?>"></script>
<?php	} else { ?>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script>
<?php	}

		// used by postAcceptor.php
		// $mediasRoot = $plxAdmin->racine.$plxAdmin->aConf['medias'];
		$files_root = substr(dirname(__FILE__), 0, -strlen($plxAdmin->aConf['racine_plugins'].__CLASS__));
		$mediasRoot = $files_root.$plxAdmin->aConf['medias'];
		$path1 = ($plxAdmin->aConf['userfolders'] AND $_SESSION['profil']==PROFIL_WRITER) ? $_SESSION['user'].'/' : '';
		$_SESSION['tinyMCE_medias'] = $mediasRoot.$path1;
		// used by imagetools plugin from Tinymce
		$images_upload_base_path = $plxAdmin->aConf['medias'].$path1;
?>
	<script type="text/javascript">
		<!--
		<?php
echo '// options are defined in '.TINY_PLUXML_JS_LIB."\n";
if (! $ok) echo $this->build_javascript_lib();
$mask_user = $this->weightProfils[$_SESSION['profil']];
$pluginRoot = $this->pluginRoot();
$load_codemirror = ((intval($this->getParam('codemirror')) & $mask_user) > 0);
if ($load_codemirror)
	echo <<< CODEMIRROR
		options.external_plugins['codemirror'] = '${pluginRoot}extras/plugins/codemirror/plugin.min.js';

CODEMIRROR;
?>
		options.plugins = pluginsList[<?php echo $_SESSION['profil']; ?>];
		options.images_upload_base_path = '<?php echo $images_upload_base_path; ?>';
		tinymce.init(options);
		// ->
	</script>
<?php			}
				break;
		}
	}

	// for using core/admin/medias.php as medias manager
	public function AdminMediasFoot($params=false) {
		global $plxAdmin;

		if (defined('PLX_VERSION')) {
			$versionPluxml = PLX_VERSION;
		} else {
			$versionPluxml = strval($plxAdmin->version);
		}
		$idTable = (version_compare($versionPluxml, '5.4', '<=')) ? 'list-files' : 'medias-table'; ?>
		<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script>
		<script type="text/javascript">
			setMediasForTinyMCE('<?php echo $idTable; ?>', '<?php echo $versionPluxml; ?>', 'media');
		</script>
<?php
	}

	// for using core/admin/index.php as articles manager like medias manager
	public function AdminIndexFoot() {
		global $plxAdmin;

		$buf = array();
		foreach ($plxAdmin->plxRecord_arts->result as $k=>$infos)
			$buf[$infos['numero']] = $infos['url'];
		if (defined('PLX_VERSION')) {
			$versionPluxml = PLX_VERSION;
		} else {
			$versionPluxml = strval($plxAdmin->version);
		}
		$idTable = (version_compare($versionPluxml, '5.4', '<=')) ? 'table' : 'articles-table'; ?>
		<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script>
		<script type="text/javascript">
			var urlArts = <?php echo json_encode($buf); ?>;
			setMediasForTinyMCE('<?php echo $idTable; ?>', '<?php echo $versionPluxml; ?>', 'file');
		</script>
<?php
	}
}

?>
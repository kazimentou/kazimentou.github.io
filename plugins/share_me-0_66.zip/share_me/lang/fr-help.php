<?php
if (! defined('PLX_ROOT')) exit;
?>
<div id="help_share_me">
<p>
	Ce plugin vous permet de rajouter une série de liens pour partager un article ou une page statique via les réseaux sociaux.
</p>
<p>
	Il n'utilise aucun script javascript proposé par les réseaux sociaux. En effet, il est fréquent que ceux-ci rajoutent un cookie à vos pages pour suivre le parcours de vos visiteurs.
</p><p>
	Il rajoute dans l'entête de vos pages les balises meta définies par le protocole <a href="http://opengraphprotocol.org/" target="_blank"> Opengraph</a>. Ces balises sont utilisées par les réseaux sociaux pour compléter l'information donnée par l'URL utilisée pour le partage sur sur les réseaux sociaux. S'il existe un lien vers une image dans le contenu de votre page, celui sera proposé en partage.
</p>
<p>
	Pour utiliser ce plugin, il suffit d'ajouter un appel pour le hook "share_me" sur les modèles de page article ou static de votre thème.
</p>
<pre><code>// par exemple pour article.php ou static.php:
&lt;?php eval($plxShow->callHook('share_me')); ?></code></pre>
<p>
	Il est également possible de passer en paramètre un lien vers un média en adresse relative à l'adresse du site.
</p>
<pre><code>// par exemple pour article.php ou static.php:
&lt;?php eval($plxShow->callHook(
    'share_me', 'data/medias/moi.jpg'
)); ?></code></pre>
<p>
	Il est proposé un partage vers les réseaux sociaux suivants :
</p>
	<ul>
<?php
		$networks = array(
			'twitter'	=>'http://twitter.com/',
			'facebook'	=>'https://www.facebook.com/',
			'google+'	=>'https://plus.google.com/',
			'linkedin'	=>'https://fr.linkedin.com/',
			'pinterest'	=>'https://fr.pinterest.com/',
			'diaspora'	=>'https://diasporafoundation.org/'
		);
		foreach ($networks as $title=>$ref) {
			echo <<< NETWORK
			<li><a href="$ref">$title</a></li>

NETWORK;
}
?>
	</ul>
	<p>
	Pour Twitter, on peut préciser le compte qui diffuse le tweet (via).
	</p>
	<p>
	On peut également partager par courriel.
	</p>
</p>
</div>

var cps_mediasManager =  {

	frameId: 'chamPlus-medias',

	open: function(aLabel, url) {
		var myFrame = document.getElementById(this.frameId);
		if (! myFrame) {
			myFrame = document.createElement('iframe');
			myFrame.setAttribute('id', this.frameId);
			myFrame.src = url;
			aLabel.form.appendChild(myFrame);
		}
		myFrame.style.display = 'block';
		this.target = aLabel.getAttribute('for');
		this.test = 'a';
		return false;
	},

	setValue: function (aValue) {
		var target = document.getElementById(this.target);
		if (target)
			target.value = aValue;
	},

	init: function (urlBase, btnLabel, confirmLabel) {
		var id = window.id;
		if (window.frameElement && (window.frameElement.id == this.frameId)) {
			this.cibleId = window.frameElement.getAttribute('data-target');
			this.urlBase = urlBase;

			// cachez ces éléments que je ne saurais voir !!
			var aLink = document.createElement('style');
			aLink.type = 'text/css';
			aLink.innerHTML = '\
body > main > aside, #folder + input { display: none; } \
';
			document.head.appendChild(aLink);

			// change folder as you clik on select
			var aSelect = document.querySelector('#folder');
			if (aSelect)
				aSelect.setAttribute('onchange', 'this.form.submit();');

			var tbody = document.querySelector('#medias-table tbody');
			tbody.addEventListener('click',	function(event) {
				var t = event.target;
				if (t.tagName == 'A' && ! t.querySelector('img')) {
					cps_mediasManager.putValue(t);
					// this.putValue(t); why not ???
					event.preventDefault();
				}
			});
			// ajouter un bouton pour fermer
			var btn = document.createElement('input');
			btn.type = 'button';
			btn.value = btnLabel;
			btn.setAttribute('onclick', "window.frameElement.style.display = 'none';");
			btn.id = 'chamPlus-medias-close';
			var pattern1 = '#form_medias div:first-of-type';
			var target = document.querySelector(pattern1);
			if (target)
				target.appendChild(btn);
			else
				console.log('No result for querySelector(\''+pattern1+'\')');
			this.confirmLabel = confirmLabel;
		}
	},

	putValue: function (anchor1) {
		// var value = anchor1.href.replace(/^\https?:\/\/[^\/]+/, ''); // suppression du hostname
		value = anchor1.href.substr(this.urlBase.length);
		if (confirm(this.confirmLabel+':\n'+value)) {
			window.parent.cps_mediasManager.setValue(value);
			window.frameElement.style.display = 'none';
		}
		return false;
	}
}

function cpsOpenMediasManager(event) {
	event.preventDefault();
	var aLabel = event.target.parentNode;
	if (aLabel) {
		cps_mediasManager.open(aLabel, mediasManagerPath);
	}
}

function cpsPreview(event) {
	event.preventDefault();
	var aLabel = event.target.parentNode;
	var input1 = document.getElementById(aLabel.getAttribute('for'));
	var src = pluxmlRoot+input1.value;
	// alert(src);
	var cpsPreviewMedia = document.getElementById('cpsPreviewMedia');
	if (cpsPreviewMedia == undefined) {
		cpsPreviewMedia = document.createElement('div');
		cpsPreviewMedia.id = 'cpsPreviewMedia';
		var innerHTML = '<img>';
		innerHTML += '<span class="close" onclick="this.parentNode.classList.remove(\'visible\');">&Cross;</span>'
		cpsPreviewMedia.innerHTML = innerHTML;
		document.body.appendChild(cpsPreviewMedia);
	}
	var img = document.querySelector('#cpsPreviewMedia img');
	img.src = src;
	cpsPreviewMedia.classList.add('visible');
}

document.addEventListener('DOMContentLoaded', function (event) {
	var aForm = document.getElementById('form_article');
	if (aForm) {
		var filesBtn = document.querySelectorAll('.sidebar span.cps-medias');
		for (i=filesBtn.length-1; i>=0; i--) {
			filesBtn[i].addEventListener('click', cpsOpenMediasManager);
		}
		var previewBtn = document.querySelectorAll('.sidebar span.cps-preview');
		for (i=previewBtn.length-1; i>=0; i--) {
			previewBtn[i].addEventListener('click', cpsPreview);
		}
	}

});
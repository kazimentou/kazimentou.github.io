/*
 * See documentation at following links :
 * http://www.tinymce.com/wiki.php/Tutorials:Creating_custom_dialogs
 * */
// updated on 2017-11-20

// launch by file_picker_callback
var myFile_picker_callback = function (callback, value, meta) {

	var params = {};

	switch(meta.filetype) {
		case 'file':
			params = {
				title: "Insérer un lien pour un article publié",
				url: 'index.php?sel=published',
				width: 850,
				height: 800
			};
			break;
		case 'codesample':
			params = {
				title: "Insérer un fichier source",
				url: 'medias.php',
				width: 850,
				height: 800
			};
			break;
		default:
			params = {
				title: "Insérer un média",
				url: 'medias.php',
				width: 800,
				height: 600
			};
	}

	tinymce.activeEditor.windowManager.open(
		params,
		{
			oninsert: function (url, options) { callback(url, options); },
			mediaType: meta.filetype
		}
	)
}

/*
 * N'est plus nécessaire avec la dernière version de Tinymce au 2017-08-12
var myVideo_template_callback = function (data) {
	var urlPattern = {regex: /dailymotion\.com\/video\/([^_]+)/, type: 'iframe', w: 560, h: 315, url: '//www.dailymotion.com/embed/video/$1', allowFullscreen: true};
	var match;
	if ((match = urlPattern.regex.exec(data.source1))) {
		var url = urlPattern.url.replace('$1', match[1]);
		var allowFullscreen = urlPattern.allowFullscreen ? ' allowFullscreen="1"' : '';
		return '<iframe src="' + url + '" width="' + urlPattern.w + '" height="' + urlPattern.h + '"' + allowFullscreen + '></iframe>';
	} else
		return '<video width="' + data.width + '" height="' + data.height + '"' + (data.poster ? ' poster="' + data.poster + '"' : '') + ' controls="controls">\n' + '<source src="' + data.source1 + '"' + (data.source1mime ? ' type="' + data.source1mime + '"' : '') + ' />\n' + (data.source2 ? '<source src="' + data.source2 + '"' + (data.source2mime ? ' type="' + data.source2mime + '"' : '') + ' />\n' : '') + '</video>';
}
*/

/*
textarea lié: tinyMCE.activeEditor.targetElm
container de l'éditeur: tinyMCE.activeEditor.container - classList contient mce-fullscreen en plein écran
basculer le mode plein écran: tinyMCE.activeEditor.execCommand('mceFullscreen')
*/

function saveDocument() {
	const activeEditor = tinyMCE.activeEditor;
	const form = tinyMCE.activeEditor.targetElm.form;
	if(form != null) {
		if(activeEditor.plugins.fullscreen.isFullscreen()) {
			sessionStorage.setItem('tinyMCE-fullscreen', 'true');
			sessionStorage.setItem('tinyMCE-editorId', activeEditor.id);
		} else {
			sessionStorage.removeItem('tinyMCE-editorId');
		}
		const submitBtn = form.querySelector('input[type="submit"]:not([name="preview"]):not([name="delete"])');
		if(submitBtn != null) {
			const spinner = document.getElementById('tinymce-spinner');
			if(spinner != null) {
				spinner.classList.add('active');
			}
			submitBtn.click();
		}
	}
}

function setFullscreen() {
	if(typeof tinyMCE != 'undefined') {
		const key1 = 'tinyMCE-editorId';
		const id1 = sessionStorage.getItem(key1);
		if(id1 != null) {
			const key2 = 'tinyMCE-fullscreen';
			if(sessionStorage.getItem(key2) === 'true') {
				tinyMCE.editors.every(function(editor) {
					if(editor.id == id1) {
						editor.focus();
						editor.execCommand('mceFullScreen', false);
						return false;
					} else {
						return true;
					}
				});
			}
			sessionStorage.removeItem(key2);
			sessionStorage.removeItem(key1);
		}
	}
}

window.addEventListener('load', function(event) {

	'use strict';

	document.body.classList.add('tinyMCE-plugin');

	if (typeof String.prototype.capitalize !== 'function') {
		String.prototype.capitalize = function() {
			return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
		}
	}

	function setMediasForTinyMCE(idTable, versionPluxml, filetype) {
		// hide some nodes in medias.php if the HTML page is loaded in an iframe.

		var myFrame = window.frameElement;
		if (myFrame) {
			document.body.classList.add('myTinyMCE');
			var parentId = myFrame.parentNode.id;
			if (parentId && (parentId.indexOf('mce') == 0)) {
				var mediasList = document.getElementById(idTable);
				if (mediasList) {
					switch (filetype) {
						case 'media' :
							var labelCol = document.querySelector('#'+idTable+' th:nth-of-type(4)');
							if (labelCol)
								labelCol.innerHTML = 'Ext.';
							var folder = document.querySelector('#folder');
							if (folder) {
								folder.setAttribute('onchange', 'this.form.submit();');
							}
							var tbody = document.querySelector('#'+idTable+' tbody');
							if (tbody)
								tbody.addEventListener('click', function(event) {
									if (event.target.tagName == 'A') {
										var anchor1 = event.target;
										var offset = top.tinyMCE.settings.document_base_url.length;
										var value = anchor1.href.substr(offset);
										if (confirm('Ajouter dans l\'éditeur\n' + value.split(/[\\/]/).pop()+'\n'+value)) {
											var args = top.tinymce.activeEditor.windowManager.getParams();
											var href= anchor1.href, options, title = 'titre par défault';
											switch (args.mediaType) {
												case 'file' :
													var matches = /^.*\/([^\/]+)\.[a-z,0-9]+$/.exec(href);
													var text = (matches) ? matches[1].capitalize() : '';
													options = {title: 'Voir le média', text: text};
													break;
												case 'image' :
													var matches = /^.*\/([^\/\.]+)(?:\.tb)?\.(?:jpg|jpeg|png|gif)$/.exec(href);
													if (matches)
														title = matches[1].capitalize();
													options = {title: title, alt: 'Image'};
													break;
												default :
											}
											args.oninsert(value, options);
											// fermer la fenetre
											top.tinymce.activeEditor.windowManager.close();
										}
										event.preventDefault();
										// pour IE < 9
										event.returnValue = false;
									}
								});
							break;
						case 'file' :
							var idArt = document.querySelector('#form_articles th:nth-of-type(2)');
							if (idArt != null) {
								idArt.innerHTML = 'Id.';
							}
							var id_sel_cat = document.getElementById('id_sel_cat');
							if (id_sel_cat && (id_sel_cat.tagName == 'SELECT'))
								id_sel_cat.addEventListener('change', function (event) {
									var aForm = event.target.form;
									aForm.submit();
								});
							var okBtn = document.querySelector('#id_sel_cat + input');
							if (okBtn) {
								// <input type="submit" /> with name="submit" conflicts with TinyMCE. Just rename it !
								okBtn.name = 'btn1';
							}
							var element = document.querySelector('#form_articles div:first-of-type');
							if (element) {
								var mediasBtn = document.createElement('input');
								mediasBtn.setAttribute('type', 'button');
								mediasBtn.setAttribute('value', 'Medias');
								mediasBtn.setAttribute('onclick', 'document.location = \'medias.php\'');
								element.appendChild(mediasBtn);
							}
							var tbody = document.querySelector('#'+idTable+' tbody');
							if (tbody)
								tbody.addEventListener('click', function(event) {
									if (event.target.tagName == 'A') {
										var href = event.target.href;
										var res;
										var id = (res = /^.*?a=(\d{4})$/.exec(href)) ? res[1] : '';
										var text = event.target.textContent;
										if (confirm('article n° '+id+'\nTitre: '+text)) {
											var href = 'index.php?article'+id+'/'+text;
											var args = top.tinymce.activeEditor.windowManager.getParams();
											args.oninsert(href, {text: text, title: 'Voir l\'article'});
											// fermer la fenetre
											top.tinymce.activeEditor.windowManager.close();
										}
										event.preventDefault();
										// pour IE < 9
										event.returnValue = false;
									}
								});
							break;
					}
				}
				else
					console.log('Id ' + idTable + ' element not found');
			}
		}
	}

	if(window.frameElement != null) {
		// On est dans un contexte de medias manager
		const script = document.body.querySelector('script[type="text/javascript"][data-medias-id-table][data-pluxml-version][data-medias-type]');
		if(script != null) {
			setMediasForTinyMCE(
				script.getAttribute('data-medias-id-table'),
				script.getAttribute('data-pluxml-version'),
				script.getAttribute('data-medias-type')
			);
		}
	} else {
		// restore fullscreen after saving
		setFullscreen();
	}

});
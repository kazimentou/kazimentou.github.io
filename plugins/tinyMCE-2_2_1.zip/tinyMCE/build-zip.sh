#!/bin/sh

CURRENT_PWD=$(pwd)
cd $(dirname ${0})

YELLOW="\033[33m"
GREEN="\033[32m"
NORMAL="\033[0m"
PLUGIN_NAME=$(basename $PWD)
VERSION=$(sed '/<version>/!d; s/^\s*<version>\([^<]*\)<\/version>.*$/\1/' infos.xml)
echo "\n${YELLOW}Plugin ${PLUGIN_NAME} - version ${VERSION}${NORMAL}\n"

cd ..

ZIP_NAME="${CURRENT_PWD}/${PLUGIN_NAME}-$(echo ${VERSION} | sed 's/\./_/g').zip"

zip -r -o ${ZIP_NAME}  \
	${PLUGIN_NAME}/*.* \
	${PLUGIN_NAME}/css/* \
	${PLUGIN_NAME}/extras/* \
	${PLUGIN_NAME}/lang/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/skins/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/langs/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/*/img/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/*/css/* \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/*/*.min.js \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/codesample/prism.js \
	${PLUGIN_NAME}/tinymce/js/tinymce/plugins/codesample/components/*.min.js \
	${PLUGIN_NAME}/tinymce/js/tinymce/*.min.js \
	${PLUGIN_NAME}/tinymce/js/tinymce/*.txt \
	${PLUGIN_NAME}/tinymce/js/tinymce/themes/*/*.min.js \

echo "\nNom complet de l'archive du plugin:\n${GREEN}${ZIP_NAME}${NORMAL}\n"

cd $OLDPWD

echo "Done !"
<?php
	/*******************************************************
	* Only these origins will be allowed to upload images *
	******************************************************/
	$accepted_origins = array("http://localhost", "http://192.168.1.1", "http://example.com");

	/*********************************************
	* Change this line to set the upload folder *
	*********************************************/
	session_start();

	if (!isset($_SESSION['tinyMCE_medias']) or ! isset($_SESSION['user'])) exit;

	$imageFolder = $_SESSION['tinyMCE_medias'];

	reset($_FILES);
	$temp = current($_FILES);
	/* $temp is an array with these keys:
		name: mceclip0.gif
		type: image/gif
		tmp_name: /tmp/phpjt7BYQ
		error: 0
		size: 91471
	 * */

	if (is_uploaded_file($temp['tmp_name'])) {
		if (isset($_SERVER['HTTP_ORIGIN'])) {
			// same-origin requests won't set an origin. If the origin is set, it must be valid.
			if (in_array($_SERVER['HTTP_ORIGIN'], $accepted_origins)) {
				header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
			} else {
				header("HTTP/1.0 403 Origin Denied");
				return;
			}
		}

		/*
		If your script needs to receive cookies, set images_upload_credentials : true in
		the configuration and enable the following two headers.
		*/
		// header('Access-Control-Allow-Credentials: true');
		// header('P3P: CP="There is no P3P policy."');

		// Sanitize input
		if (preg_match("/([^\w\s\d\-_~,;:\[\]\(\).])|([\.]{2,})/", $temp['name'])) {
			header("HTTP/1.0 500 Invalid file name.");
			return;
		}

		$exts = array(
			IMAGETYPE_GIF		=> '.gif',
			IMAGETYPE_JPEG		=> '.jpg',
			IMAGETYPE_PNG		=> '.png',
			IMAGETYPE_SWF		=> '.swf',
			IMAGETYPE_PSD		=> '.psd',
			IMAGETYPE_BMP		=> '.bmp',
			IMAGETYPE_TIFF_II	=> '.tiff',
			IMAGETYPE_TIFF_MM	=> '.tiff',
			IMAGETYPE_JPC		=> '.jpc',
			IMAGETYPE_JP2		=> '.jp2',
			IMAGETYPE_JPX		=> '.jpx',
			IMAGETYPE_JB2		=> '.jb2',
			IMAGETYPE_SWC		=> '.swc',
			IMAGETYPE_IFF		=> '.iff',
			IMAGETYPE_WBMP		=> '.wbmp',
			IMAGETYPE_XBM		=> '.xbm',
			IMAGETYPE_ICO		=> '.ico'
		);

		if(false) {
			// for debugging
			$hdle = fopen('../postAcceptor.txt', 'w');
			foreach($temp as $k=>$v)
				fwrite($hdle, "$k: $v\n");
			fclose($hdle);
		}

		$imageType = exif_imagetype($temp['tmp_name']);
		if(array_key_exists($imageType, $exts)) {
			$path1 = $_SESSION['user'].'/tinymce';
			if (is_dir($imageFolder.$path1) or mkdir($imageFolder.$path1, 0777, true)) {
				$today = date('Y-m-d_H-i-s');
				$ext = $exts[$imageType];
				$target = $path1.'/'.$today.$ext;
				move_uploaded_file($temp['tmp_name'], $imageFolder.$target);

				// ".thumbs/" is defined by PlxMedias::__construct() in Pluxml
				$thumbnail = $imageFolder.'.thumbs/'.$target;
				if (file_exists($thumbnail))
					unlink($thumbnail);

				// Respond to the successful upload with JSON.
				// Use a location key to specify the path to the saved image resource.
				// { location : '/your/uploaded/image/file'}
				echo json_encode(array('location' =>$target));
			} else {
				header("HTTP/1.0 500 No folder to store the picture.");
			}
		} else {
			header("HTTP/1.0 500 Unkown type of image");
		}
	} else {
		// Notify editor that the upload failed
		header("HTTP/1.0 500 Server Error");
	}
?>
<?php

if (!defined('PLX_ROOT')) exit;

class html5uploader extends plxPlugin {

	private $scriptname = '';

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->scriptname = basename(strtolower($_SERVER['SCRIPT_FILENAME']), '.php');

		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminFootEndBody', 'AdminFootEndBody');
	}

	public function AdminTopEndHead($params) {

		if ($this->scriptname == 'medias') {
			// We add 3 $_SESSIONS variables: uploader_root, uploader_writer & upload_lang
			global $plxAdmin;
			// We have $_SESSION['folder'] and we have to add this $_SESSION
			$_SESSION['uploader_root'] = PLX_ROOT;
			$_SESSION['uploader_writer'] = ($plxAdmin->aConf['userfolders'] AND $_SESSION['profil']==PROFIL_WRITER) ? 'writer' : '';
			$_SESSION['uploader_lang'] = $plxAdmin->aConf['default_lang']; ?>
	<style type="text/css">
		#uploaderInfo {position: absolute; top: 1em; width: 40%; min-width: 350px; right: 5%; padding: 0.4em; background-color: AliceBlue; color: Black; font-size: 12pt; text-align: center; border-radius: 10px; border: 1px solid LightSteelBlue;}
		#uploaderInfo p {margin: 0.4em 12.5%; padding: 0.2em 0; border-radius: 10px; border: 1px solid LightSteelBlue; background-color: #F9FCFF;}
		#progressBar {position: absolute; top: 60%; text-align: center; font-weight: bold; font-size: 24pt; letter-spacing: 0.2em; padding:0; margin: 0;}
	</style>
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__?>.js"></script>
<?php	}
		elseif ($this->scriptname == 'parametres_pluginhelp') { ?>
	<style type="text/css">
		#html5uploader-help {width: 600px; padding: 10px; background-color: AliceBlue; border-radius: 10px; border: 1px solid LightSteelBlue; font-size: 10pt; margin-top: 0.5em;}
		#html5uploader-help p, #html5uploader-help ul {margin: 10px 0;}
		#html5uploader-help p {text-align: justify; text-indent: 1em;}
		#html5uploader-help ol {padding-left: 3em;}
		#html5uploader-help li {list-style-type: decimal;}
		#html5uploader-help i {padding: 0 5px;}
	</style>
<?php	}
	}

	private function getNumber($aString) {
		$aString = trim($aString);
		$value = intval($aString);
		$unit = strtoupper(substr($aString, -1));
		switch ($unit) {
			case 'G' :
				$value *= 1024;
			case 'M' :
				$value *= 1024;
			case 'K' :
				$value *= 1024;
		}
		return $value;
	}

	public function AdminFootEndBody($params) {
		if ($this->scriptname == 'medias') {
			$max_file_uploads = ini_get('max_file_uploads');
			$upload_max_filesize = ini_get('upload_max_filesize');
			$post_max_size = ini_get('post_max_size');
			?>
		<div id="uploaderInfo" style="opacity: 0;">
			Html5uploader <?php $this->lang('L_DND_DROP_READY_TO_SERVE'); ?>
			<p>
				<?php $this->lang('L_DND_DROP_CONSTRAINTS_SERVER'); ?> : <br />
<?php if ($max_file_uploads > 0) { ?>
				<?php echo $max_file_uploads.' '; $this->lang('L_DND_DROP_MAX_FILE_UPLOADS');?><br />
<?php } ?>
				<?php $this->lang('L_DND_DROP_UPLOAD_MAX_FILESIZE'); ?> : <?php echo $this->getNumber($upload_max_filesize) / 1024; $this->lang('L_DND_DROP_KBYTES'); ?><br />
				<?php $this->lang('L_DND_DROP_POST_MAX_SIZE'); ?> : <?php echo $this->getNumber($post_max_size) / 1024; $this->lang('L_DND_DROP_KBYTES'); ?>
			</p>
			<?php $this->lang('L_DND_DROP_YOUR_FILES'); ?>
		</div>
		<p id="progressBar" style="display: none"></p>
		<script type="text/javascript">
			var
				dropZone = addDepositFiles('form_medias', 'files'),
				max_file_uploads = '<?php echo $max_file_uploads; ?>',
				upload_max_filesize = '<?php echo $this->getNumber($upload_max_filesize); ?>',
				post_max_size = '<?php echo $this->getNumber($post_max_size); ?>',
				// some messages for the WorldWide ...
				max_file_uploadsWarn = '<?php $this->lang('L_DND_DROP_MAX_FILE_UPLOADS_WARN'); ?>',
				upload_max_filesizeWarn = '<?php $this->lang('L_DND_DROP_UPLOAD_MAX_FILESIZE_WARN'); ?>',
				post_max_sizeWarn = '<?php $this->lang('L_DND_DROP_POST_MAX_SIZE_WARN'); ?>',
				Kbytes = '<?php $this->lang('L_DND_DROP_KBYTES'); ?>',
				post_is_doneMsg = '<?php $this->lang('L_DND_DROP_POST_IS_DONE_MSG'); ?>';
				;
			if (dropZone) {
				uploader(dropZone, '<?php echo PLX_PLUGINS.__CLASS__; ?>/uploader.php', 'form_uploader', 'uploaderInfo'); // register.php | uploader.php
				fadeInOut('uploaderInfo', 120000);
				var isJSON = <?php echo (function_exists('json_encode')) ? 'true' : 'false'; // requires php version >= 5.2 ?>;
			}
			else
				console.log('DropZone is missing.');
		</script>
<?php	}
	}
}
?>

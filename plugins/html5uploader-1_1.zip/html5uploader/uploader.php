<?php

if (empty($_POST)) exit;

session_start();

define('PLX_ROOT', $_SESSION['uploader_root']);
define('PLX_CORE', PLX_ROOT.'core/');
include(PLX_ROOT.'config.php'); // défini PLX_CONFIG_PATH
include(PLX_CORE.'lib/config.php'); //

include_once(PLX_CORE.'lib/class.plx.date.php');
include_once(PLX_CORE.'lib/class.plx.utils.php');
include_once(PLX_CORE.'lib/class.plx.msg.php'); // request by plxMedias for displaying error
include_once(PLX_CORE.'lib/class.plx.medias.php');

class plxMediasMulti extends plxMedias {

	// It's the same function as _getDirFiles but this last one is a private function. Shit !!
	protected function getDirFiles($dir) {

		# Initialisation
		$files = array();
		# Ouverture et lecture du dossier demandé
		if($handle = opendir($this->path.$dir)) {
			while(FALSE !== ($file = readdir($handle))) {
				$thumName = plxUtils::thumbName($file);
				if($file[0] != '.' AND !preg_match('/index.htm/i', $file) AND !preg_match('/^(.*\.)tb.([^.]+)$/D', $file)) {
					if(is_file($this->path.$dir.$file)) {
						$ext = strtolower(strrchr($this->path.$dir.$file,'.'));
						$_thumb1=file_exists($this->path.'.thumbs/'.$dir.$file);
						if(!$_thumb1 AND in_array($ext, array('.gif', '.jpg', '.png'))) {
							$_thumb1 = plxUtils::makeThumb($this->path.$dir.$file, $this->path.'.thumbs/'.$dir.$file, $this->thumbWidth, $this->thumbHeight, $this->thumbQuality);
						}
						$_thumb2=false;
						if(is_file($this->path.$dir.$thumName)) {
							$_thumb2 = array(
								'infos' => getimagesize($this->path.$dir.$thumName),
								'filesize'	=> filesize($this->path.$dir.$thumName)
							);
						}
						if ($_thumb1)
							$myThumb = $this->path.'.thumbs/'.$dir.$file;
						else {
							$path1 = PLX_CORE.'admin/theme/images/';
							$filename = $path1.strtolower(substr($ext,1)).'.png';
							$myThumb = (is_readable($filename)) ? $filename : $path1.'file.png';
						}
						$files[$file] = array(
							'.thumb'	=> $myThumb,
							'name' 		=> $file,
							'path' 		=> $this->path.$dir.$file,
							'date' 		=> filemtime($this->path.$dir.$file),
							'filesize' 	=> filesize($this->path.$dir.$file),
							'extension'	=> $ext,
							'infos' 	=> getimagesize($this->path.$dir.$file),
							'thumb' 	=> $_thumb2
						);
					}
				}
            }
			closedir($handle);
        }
		# On tri le contenu
		ksort($files);
		# On retourne le tableau
		return $files;
    }

	// It's the same function as _uploadFile but this last one is a private function. Shit !!
	protected function uploadFile($file, $resize, $thumb) {

		if($file['name'] == '')
			return L_PLXMEDIAS_WRONG_FILENAME;

		if($file['size'] > $this->maxUpload['value'])
			return L_PLXMEDIAS_WRONG_FILESIZE;

		if(!preg_match($this->img_exts, $file['name']) AND !preg_match($this->doc_exts, $file['name']))
			return L_PLXMEDIAS_WRONG_FILEFORMAT;

		# On teste l'existence du fichier et on formate le nom du fichier pour éviter les doublons
		$i = 1;
		$upFile = $this->path.$this->dir.plxUtils::title2filename($file['name']);
		$name = substr($upFile, 0, strrpos($upFile,'.'));
		$ext = strrchr($upFile, '.');
		while(file_exists($upFile)) {
			$upFile = $this->path.$this->dir.$name.'.'.$i++.$ext;
		}

		if(!move_uploaded_file($file['tmp_name'],$upFile)) { # Erreur de copie
			return L_PLXMEDIAS_UPLOAD_ERR;
		} else { # Ok
			if(preg_match($this->img_exts, $file['name'])) {
				plxUtils::makeThumb($upFile, $this->path.'.thumbs/'.$this->dir.basename($upFile), $this->thumbWidth, $this->thumbHeight, $this->thumbQuality);
				if($resize)
					plxUtils::makeThumb($upFile, $upFile, $resize['width'], $resize['height'], 80);
				if($thumb)
					plxUtils::makeThumb($upFile, plxUtils::thumbName($upFile), $thumb['width'], $thumb['height'], 80);
			}
		}
		return L_PLXMEDIAS_UPLOAD_SUCCESSFUL;
	}

	public function uploadFilesMulti() {
		$params = array();
		foreach (array('resize', 'thumb') as $k) {
			if (!empty($_POST[$k])) {
				if ($_POST[$k] == 'user')	{
					$width = $_POST[$k.'_w']; $height = $_POST[$k.'_h'];
				}
				else {
					list($width, $height) = explode('x', $_POST[$k]);
				}
				$params[$k] = array('width'=>$width, 'height'=>$height);
			}
			else
				$params[$k] = false;
		}
		$count1 = 0;
		foreach ($_FILES as $input) {
			for ($i=0; $i<count($input['name']); $i++) {
				$file1 = array();
				foreach (array('name', 'type', 'tmp_name', 'error', 'size') as $m)
					$file1[$m] = $input[$m][$i];
				if ($file1['error'] == 0) {
					$res = $this->uploadFile($file1, $params['resize'], $params['thumb']);
					if ($res ==  L_PLXMEDIAS_UPLOAD_SUCCESSFUL)
						$count1++;
					else {
						return plxMsg::Error($res.': '.$file['name'].' - '.$file['size']);
						break;
					}
				}
				else {
					return plxMsg::Error(L_PLXMEDIAS_UPLOADS_ERR.$file['name'].' - '.$file['size']);
					break;
				}
			}
		}
		// update $this->aFiles
		unset($this->aFiles);
		$this->aFiles = $this->getDirFiles($this->dir);
		return plxMsg::Info($count1.' '.L_PLXMEDIAS_UPLOADS_SUCCESSFUL);
	}
}

loadLang(PLX_CORE.'lang/'.$_SESSION['uploader_lang'].'/admin.php'); // maybe core.php
// plxToken::validateFormToken($_POST);

// part of medias.php
// Nouvel objet de type plxMedias
$medias_root = PLX_ROOT.$_SESSION['medias'];
if ($_SESSION['uploader_writer'] == 'writer')
	$medias_root .=  $_SESSION['user'].'/';
$folder = $_SESSION['folder'];
$plxMedias = new plxMediasMulti($medias_root, $folder);

if ($plxMedias->uploadFilesMulti($_FILES, $_POST)) {
	$body = '';
	if($plxMedias->aFiles) {
		$num = 0;
		foreach($plxMedias->aFiles as $v) { # Pour chaque fichier
			$ordre = ++$num;
			$body .= '<tr class="line-'.($num%2).'">';
			$body .= '<td><input type="checkbox" name="idFile[]" value="'.$v['name'].'" /></td>';
			$body .= '<td class="icon"><a onclick="this.target=\'_blank\';return true;" title="'.plxUtils::strCheck($v['name']).'" href="'.$v['path'].'"><img alt="" src="'.$v['.thumb'].'" class="thumb" /></a></td>';
			$body .= '<td>';
			$body .= '<a onclick="this.target=\'_blank\';return true;" title="'.plxUtils::strCheck($v['name']).'" href="'.$v['path'].'">'.plxUtils::strCheck($v['name']).'</a><br />';
			if($v['thumb']) {
				$body .= '<a onclick="this.target=\'_blank\';return true;" title="'.L_MEDIAS_THUMB.' : '.plxUtils::strCheck($v['name']).'" href="'.plxUtils::thumbName($v['path']).'">'.L_MEDIAS_THUMB.'</a> : '.$v['thumb']['infos'][0].' x '.$v['thumb']['infos'][1]. ' ('.plxUtils::formatFilesize($v['thumb']['filesize']).')';
			}
			$body .= '</td>';
			$body .= '<td>'.strtoupper($v['extension']).'</td>';
			$body .= '<td>'.plxUtils::formatFilesize($v['filesize']).'</td>';
			$dimensions = '&nbsp;';
			if(isset($v['infos']) AND isset($v['infos'][0]) AND isset($v['infos'][1])) {
				$dimensions = $v['infos'][0].' x '.$v['infos'][1];
			}
			$body .= '<td>'.$dimensions.'</td>';
			$body .= '<td>'.plxDate::formatDate(plxDate::timestamp2Date($v['date'])).'</td>';
			$body .= '</tr>';
		}
	}
	$response = array('msg'=>$_SESSION['info'], 'inner'=>$body);
	$_SESSION['info'] = '';
}
else
	$response = array('msg'=>$_SESSION['error']);

header("Content-type: text/plain");
if (function_exists('json_encode'))
	// json_encode requires PHP version >= 5.2
	echo json_encode($response);
else
	echo implode('aZErTy', $response);
?>

<div class="<?php echo $page; ?>-help">
<p>
Ce plugin permet de masquer l'url des fichiers proposés en téléchargement dans un article ou une page statique.
</p>
<p>
Il y a deux utilisations possibles :
</p>
<ul>
<li><p>On sélectionne dans le panneau de configuration, le dossier où sont stockés les fichiers à télécharger.</p>
<p>Dans l'édition de l'article ou de la page statique, on insère un lien vers le fichier à télécharger comme pour n'importe quel fichier.</p>
<p>A l'affichage sur le site, le plugin cryptera automatiquement l'url du fichier (<em>Valeur de l'attribut href dans la balise &lt;a&gt;</em>). Il n'est possible de ne choisir qu'un seul dossier.</p>
</li>
<li>
Si on veut proposer plusieurs fichiers à télécharger sous la forme d'un joli tableau, on peut insérer dans l'article ou la page statique le code suivant :
</li>
<pre><code>&lt;div class="ma-class" data-download="dossier-des-fichiers-a-telecharger"&gt;
   Emplacement du tableau
&lt;/div&gt;</code></pre>
<p>Avant affichage, le contenu de la balise &lt;div&gt; sera remplacé par un tableau listant le nom des fichiers à télécharger présents dans le dossier précisé par l'attribut <em>data-download</em> avec l'url crypté pour les télécharger. Les tailles et dates de modification sont également précisées.
</p>
<p>
	Le chemin du dossier doit être précisé par rapport au dossier de médias (<em>par défaut: /datas/medias/</em>).
</p>
<p>
En outre, si un fichier <em>.htaccess</em> est présent dans le dossier avec des directives <a href="https://httpd.apache.org/docs/2.4/mod/mod_autoindex.html#adddescription" target="_blank">AddDescription</a>, une description sera ajoutée à chaque fichier concerné.
</p>
</ul>
<p>
Le plugin enregistre  également le nombre total de clics pour chaque url de téléchargement avec un détail hebdomadaire sur une période de trois mois.
</p>
<p>
La popularité des fichiers peut être présentée sous la forme d'un graphique pour l'ensemble de tous les fichiers sur cette période.
</p>
</div>

<?php

if (!defined('PLX_ROOT'))
	exit;

/* ****************************
 * author Jean-Pierre Pourrez
 * date : 2014-02-13
 * testé avec PluXml 5.3
 * mise à jour : 2015-11-16
 * testé avec PluXml 5.4
 * date : 2017-02-05
 * mise à jour pour Pluxml 5.6
 * **************************** */

define('RESP_CAPTCHA_NAME', 'respCaptcha');

class captchaImage extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# Ajouts des hooks
		$this->addHook('plxShowCapchaQ', 'plxShowCapchaQ');
		$this->addHook('AdminAuthPrepend', 'AdminAuthPrepend');
		$this->addHook('AdminAuthTop', 'AdminAuthTop');
		$this->addHook('AdminAuth', 'AdminAuth');
		$this->addHook('AdminAuthEndHead', 'AdminAuthEndHead');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

	private function _PluginRoot() {
		global $plxAdmin, $plxMotor;

		if(isset($plxAdmin)) {
			return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
		} elseif (isset($plxMotor)) {
			return $plxMotor->racine.$plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			return false;
		}
	}

	private function _showCapcha() {

		# core/admin/auth.php ne gère pas les feuilles de style des plugins (PluXml version 5.6 et précèdentes)
		global $plxMotor;

		$backgrounds = glob(__DIR__.'/backgrounds/capcha*.png');
		$filename = $backgrounds[array_rand($backgrounds)];
		$imagesize = getimagesize($filename);
		// $widthAttribute = $imagesize[3];
		$caption = $this->getLang('L_CAPTCHA_MESSAGE');
		$capcha_src = $this->_pluginRoot().'capcha.php';
		$refresh_src = $this->_pluginRoot().'refresh.png';
		echo <<< EOT
		${caption}<br />
		<img id="capcha-img" src="${capcha_src}" alt="Captcha" ${imagesize[3]} />
		<button id="capcha-refresh" type="button" style="height: 50px; background-color: #ddd; padding: 0; margin: 0 0.5rem;"><img src="${refresh_src}" alt="refresh" style="margin: 9px;"/></button>
EOT;
	}

	private function _refreshButtonListener() { ?>
		<script type="text/javascript">
			(function() {
				var btn = document.getElementById('capcha-refresh');
				if(btn != null) {
					btn.addEventListener('click', function(event) {
						var capcha = document.getElementById('capcha-img');
						if(capcha != null) {
							var d = new Date();
							capcha.src = '<?php echo $this->_pluginRoot(); ?>capcha.php?now=' + (parseInt(d.getTime() / 1000) % 86400);
						}
					});
				} else {
					console.log('#capcha-refresh button is missing');
				}
			})();
		</script>
<?php
	}

	public function plxShowCapchaQ() {

		$this->_showCapcha();
		echo '<?php return true; ?>';
	}

	public function ThemeEndBody() {
		if (defined('PLX_VERSION')) {
			if (version_compare(PLX_VERSION, '5.4', '>=')) {
				$id = 'id_rep';
			}
		} else {
			$id = 'id_capcha_rep';
		}
?>
		<script type="text/javascript"> <!-- captchaImage -->
			<!--
			var repId = document.getElementById('<?php echo $id; ?>');
			if (repId) {
				repId.setAttribute('maxlength', '5');
				repId.removeAttribute('style');
			}
			else
				console.log('Input with id: <?php echo $id; ?> not found');
			// -->
		</script>
<?php
		$this->_refreshButtonListener();
	}

	public function AdminAuthPrepend() {

		if (isset($_SESSION['capcha']) and isset($_POST[RESP_CAPTCHA_NAME]))  {
			if ($_SESSION['capcha'] !== sha1(strtolower(filter_input(INPUT_POST, RESP_CAPTCHA_NAME, FILTER_SANITIZE_STRING)))) {
				global $plxAdmin;

				$login = filter_input(INPUT_POST, 'login', FILTER_SANITIZE_STRING);
				foreach ($plxAdmin->aUsers as $id=>$user) {
					if ($login == $user['login']) {
						$plxAdmin->aUsers[$id]['active'] = false;
						$this->msgCapcha = $this->aLang['L_CAPTCHA_ERROR'];
						break;
					}
				}
			}
		}
	}

	public function AdminAuthTop() {

		if (isset($this->msgCapcha)) {
			// On traite l'erreur sur le captcha
		echo '<?php $msg = "'.$this->msgCapcha.'"; ?>';
		}
	}

	public function AdminAuth() { ?>
		<div class="col sml-12 text-center">
			<?php $this->_showCapcha(); ?><br />
			<input id="id_rep" name="<?php echo RESP_CAPTCHA_NAME; ?>" type="text" maxlength="5" autocomplete="off" required="required" />
		</div>
<?php
		$this->_refreshButtonListener();
	}

	public function AdminAuthEndHead() {
		# core/admin/auth.php ne gère pas les feuilles de style des plugins
?>
	<style type="text/css">
		body { background-color: #000; }
		.auth { min-width: 30rem; background-color: #eee; }
		#id_rep {
			width: 7rem;
			text-align: center;
			vertical-align: top;
			margin-top: 12px;
			padding: 0.3rem 0;
		}
	</style>
<?php
	}

}
?>
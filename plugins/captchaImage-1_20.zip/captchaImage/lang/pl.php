<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=>	'Wprowadź kod obrazka',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);
?>

<?php

$LANG = array(

'L_CAPTCHA_MESSAGE'	=> 'Introduceti codul de pe imagine ',
'L_CAPTCHA_ERROR'	=> 'Wrong code picture',

);

?>

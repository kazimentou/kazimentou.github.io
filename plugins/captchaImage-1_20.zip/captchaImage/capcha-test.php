<?php

/**
 * capchaImage
 *
 * @package capchaImage
 * version	1.0
 * @author	Stéphane F
 **/

# tableau contenant les fontes disponibles
$fonts = glob(__DIR__.'/fonts/*.ttf');

# Création de l'image de fond du capcha
$backgrounds = glob(__DIR__.'/backgrounds/capcha*.png');
$filename = $backgrounds[array_rand($backgrounds)];
$imgW = 1300;
$imgH = (50+10) * count($fonts) + 10;
$image = imagecreatetruecolor($imgW, $imgH);

# tableau des couleurs pour les lettres. imagecolorallocate() retourne un identifiant de couleur.
$colors=array(
	imagecolorallocate($image, 131,154,255), # bleu ciel
	imagecolorallocate($image, 89,186,255), # bleu turquoise
	imagecolorallocate($image, 119,151,173), # bleu gris
	imagecolorallocate($image, 242,67,149), # rose foncé
	imagecolorallocate($image, 32,151,82) # vert sapin
);

$colorFont = imagecolorallocate($image, 255, 255, 255);

// $defaultFont = '/usr/share/fonts/truetype/freefont/FreeMono.ttf';
$defaultFont = $fonts[0];

define('FONT_SIZE', 28);

$allChars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZ:!#&%?=+';
for($fnt = 0; $fnt < count($fonts); $fnt++) {
	for ($i=0; $i<strlen($allChars); $i++) {
		$angle = mt_rand(-15, 15);
		$fontName = $fonts[$fnt];
		$theChar = $allChars[$i];
		$sizeBox = imagettfbbox(FONT_SIZE, $angle, $fontName, $theChar);
		$w = abs($sizeBox[4] - $sizeBox[0]); if ($w > 32) $w = 0;
		$h = abs($sizeBox[5] - $sizeBox[1]);
		imagettftext($image, FONT_SIZE, $angle,  mt_rand(-2, 32 - $w) + $i*30,  (50+10) * $fnt + mt_rand(30,47), $colors[array_rand($colors)], $fontName, $theChar);
	}
	imagettftext($image, 16, 0, 50, (50+10) * ($fnt+1), $colorFont, $defaultFont, basename($fonts[$fnt], '.ttf'));
}

# Envoi de l'image
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);
?>
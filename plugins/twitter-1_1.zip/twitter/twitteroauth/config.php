<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'OjzWjYDYSwc2s2WcnzZrzFW1U');
define('CONSUMER_SECRET', 'HT5s62PoY9rpln71PqMR4qRbHBAcHWHQjM0URgZenemOUGJDbQ');
define('OAUTH_CALLBACK', 'http://www.echecs-annonay.fr/plugins/twitter/twitteroauth/callback.php');
?>

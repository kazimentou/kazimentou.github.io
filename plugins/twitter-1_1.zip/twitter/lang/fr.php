<?php
$LANG = array(
	/* config.php */
	'L_TWITTER_CONSUMER_KEY'=>'Clé utilisateur Twitter',
	'L_TWITTER_CONSUMER_SECRET'=>'Code secret utilisateur',
	'L_TWITTER_ACCESS_TOKEN_KEY'=>'Jeton d\'accès',
	'L_TWITTER_ACCESS_TOKEN_SECRET'=>'Jeton d\'accès secret',
	'L_TWITTER_TAGS'=>'Hashtags pour les tweets',
	'L_TWITTER_AUTHOR'=>'Publier le nom de l\'auteur',
	'L_TWITTER_TWEET'=>'Envoyer un tweet',
	'L_TWITTER_CREDITS'=>'Crédits',
	'L_TWITTER_TIMELINE'=>'Timeline',
	'L_TWITTER_CONFIG'=>'Configuration',
	'L_TWITTER_HELLO_THE_WORLD'=>'Bonjour tout le monde'
);
?>

<?php

if (!defined('PLX_ROOT')) exit;

/**
 * Permet à un visiteur de tester les différents styles avec un fichier infos.xml
 * présents dans le dossier de thèmes.
 *
 * La boîte de seélection de thèmes s'affiche en base et à droite du site.
 * Il n'y a aucun hook à ajouter aux thèmes. Activez simplement ce plugin pour vos essais.
 *
 * @author	J.P. Pourrez aka Bazooka07
 * @date	2018-12-29
 * */
class kzSkinSelect extends plxPlugin {

	const TOKEN = __CLASS__ .'-Token';
	const TOKEN_NAME = 'kz-token';
	private $__currentTheme = false;
	public $allow_coms = false;

	public function __construct($default_lang) {

		parent::__construct($default_lang);

		if(!defined('PLX_ADMIN')) {
			$this->addHook('plxMotorDemarrageBegin', 'plxMotorDemarrageBegin');
			$this->addHook('plxMotorDemarrageEnd', 'plxMotorDemarrageEnd');
			$this->addHook('ThemeEndHead', 'ThemeEndHead');
			$this->addHook('ThemeEndBody', 'ThemeEndBody');
		}
	}

	/**
	 * Traitement du hook plxMotorDemarrageBegin.
	 * */
	public function getThemes($themesRoot, $currentTheme, $allow_comms) {
		$themes = array();
		// On collecte les thèmes disponibles sur le site
        $pattern = PLX_ROOT.$themesRoot.'*/infos.xml';
		foreach(glob($pattern) as $filename) {
			$infos = simplexml_load_file($filename);
			$root = preg_replace('@/infos.xml$@', '', $filename);
            $folder = basename($root);
			$caption = trim($infos->title->__toString());
			if(strtolower($caption) != strtolower($folder)) {
				$caption .= " ($folder)";
			}
            // Tague les thèmes sans aperçu
            $mark = ' *';
            foreach(array('jpg', 'jpeg', 'png', 'gif') as $ext) {
				if(file_exists($root."/preview.$ext")) {
					$mark = '';
					break;
				}
			}
            $themes[$folder] = $caption.$mark;
		}

		if(count($themes) > 1) {
			// Plusieurs thèmes sont disponibles
			asort($themes);
			$this->__themes = $themes;
			$this->__currentTheme = $currentTheme;

			$options = array(
				'options' => array('regexp' => '@^[\da-z]{40}@i')
			);
			if(!empty($_POST[__CLASS__])) {
				if(isset($_SESSION[self::TOKEN])) {
					// Hack contre PluXml en mode article
					$this->allow_coms = $allow_comms;

					if(
						empty($_POST[self::TOKEN_NAME]) or
						filter_input(INPUT_POST, self::TOKEN_NAME, FILTER_VALIDATE_REGEXP, $options) === false) {

					}
						$key = $_POST[self::TOKEN_NAME];
						if(intval($_SESSION[self::TOKEN][$key]) < time()) {
						unset($_SESSION[self::TOKEN]);
						die('Security error : invalid or expired token');
					}
					unset($_SESSION[self::TOKEN][$key]);
					// On change de thème
					$value = filter_input(INPUT_POST, __CLASS__, FILTER_SANITIZE_STRING);
					if(!empty($value) and array_key_exists($value, $themes)) {
						$this->__currentTheme = $value;
						$_SESSION[__CLASS__] = $value;
						return $value;
					}
				}
			} elseif(!empty($_SESSION[__CLASS__])) {
				// On récupère le précèdent choix du visiteur et on l'active s'il existe.
				$value = $_SESSION[__CLASS__];
				if(array_key_exists($value, $themes)) {
					$this->__currentTheme = $value;
					return $value;
				}
			}
		}

		return false;
	}

	/**
	 * Traitement du plxMotorDemarrageEnd.
	 * */
	public function getAllow_comms() {
		return $this->allow_coms;
	}

	/* ============== Hooks ========================= */

	/**
	 * Analyse de la situation.
	 * valide le choix d'un thème par le visiteur.
	 * En mode article, interdit les commentaires dans ce cas précis.
	 *
	 * Dans le cas contraire, reprend le choix précèdent du visiteur stocké dans une variable de session.
	 * */
	public function plxMotorDemarrageBegin() {
		$code = <<< 'CODE'
<?php
$value = $this->plxPlugins->aPlugins['#CLASS#']->getThemes(
	$this->aConf['racine_themes'],
	$this->style,
	$this->aConf['allow_com']
);
if(!empty($value)) {
	$this->style = $value;
}
if($this->mode == 'article' and !empty($_POST['#CLASS#'])) {
	$this->aConf['allow_com'] = false;
}
return false;
?>
CODE;
		echo str_replace('#CLASS#', __CLASS__, $code);
	}

	/**
	 * En mode article, restitue l'autorisation des commentaires.
	 * */
	public function plxMotorDemarrageEnd() {
		$code = <<< 'CODE'
<?php
if($this->mode == 'article' and !empty($_POST['#CLASS#'])) {
	$this->aConf['allow_com'] = $this->plxPlugins->aPlugins['#CLASS#']->getAllow_comms();
}
?>
CODE;
		echo str_replace('#CLASS#', __CLASS__, $code);
	}

	/**
	 *  Ajoute les règles CSS pour le formulaire de sélection d'un thème.
	 * */
	public function ThemeEndHead() {
?>
		<style type="text/css">
			#form_kzSkinSelect,
			#form_kzSkinSelect label,
			#form_kzSkinSelect select {
				display: initial;
				height: auto;
				margin: initial;
				padding: initial;
				box-sizing: border-box;
				background-color: initial;
				font-size: initial;
				box-shadow: none;
				vertical-align: initial;
				border: none;
				border-radius: 0;
			}
			#form_kzSkinSelect {
				display: block;
				position: fixed;
				bottom: 2.5rem;
				right: 0.5rem;
				padding: 0.3rem 0.5rem;
				background-color: #bfb658;
				color: #000;
				font-family: 'Noto Sans', Arial, Sans-Serif;
				font-size: 16pt;
				border-radius: 0.3rem;
				-webkit-appearance: initial;
				z-index: 9999;
			}
			#form_kzSkinSelect label,
			#form_kzSkinSelect select {
				width: auto;
				color: inherit;
				font-family: inherit;
				line-height: 1.15;
			}
			#form_kzSkinSelect label { margin-right: 0.4rem; font-style: italic; letter-spacing: 0.1rem; }
			#form_kzSkinSelect select {
				padding-right: 0.5rem;
				background-color: #fff; color: #17178c;
				-webkit-appearance: menulist;
				background-image: none;
			}
		</style>
<?php
	}

	/**
	 * Ajoute un formulaire en bas de page pour sélectionner un thème.
	 * */
	public function ThemeEndBody() {
		if($this->__currentTheme === false) { return; }

		$token = sha1(mt_rand(0, 1000000));
		$_SESSION[self::TOKEN][$token] = time() + 3600; // Date limite pour le token
        $id = 'id_'. __CLASS__;
?>
		<form id="form_<?php echo __CLASS__; ?>" method="post">
			<input name="<?= self::TOKEN_NAME; ?>" value="<?= $token; ?>" type="hidden" />
            <label for="<?= $id; ?>">Style</label>
<?php plxUtils::printSelect(__CLASS__, $this->__themes, $this->__currentTheme); ?>
		</form>
		<script type="text/javascript">
			(function(id) {
				const select = document.getElementById(id);
				if(select != null) {
					select.onchange = function(event) {
						event.preventDefault();
						if(select.value.trim() != '') {
							select.form.submit();
						}
					}
				}
			})('<?= $id; ?>');
		</script>
<?php
	}

}

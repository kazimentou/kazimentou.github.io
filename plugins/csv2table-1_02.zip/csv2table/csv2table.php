<?php

if ( !defined('PLX_ROOT')) exit;

# to see forbidden functions at Free.fr, look at:
# http://www.free.fr/assistance/947.html

class csv2table extends plxPlugin {
	/**
	 * Constructeur de la classe
	 *
	 * @param	default_lang	langue par défaut
	 * @return	stdio
	 * @author	Jean-Pierre P.
	 * @date	2014-02-17
	 **/

	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accèder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);
		$this->addHook('plxShowPluginsCss', 'plxShowPluginsCss');
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('plxShowStaticContent', 'plxShowStaticContent');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
	}

	private $format_cells = '';
	private $picturesFolder = '';

	public function plxShowPluginsCss($params) { ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.css" />
<?php // catch all css stylesheets in the folder of the plugin
		$styleSheets = glob(PLX_PLUGINS.__CLASS__.'/*.css');
		if (!empty($styleSheets)) {
			foreach ($styleSheets as $filename) {
				if (basename($filename) != __CLASS__.'.css') { ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo $filename; ?>" />
	<?php		}
			}
		}
		else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
			echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
			$dir = new DirectoryIterator(dirname(PLX_PLUGINS.__CLASS__.'/.'));
			foreach ($dir as $fileinfo) {
				$filename = $fileinfo->getFilename();
			    if ((substr($filename, -4) == '.css') && ($filename != __CLASS__.'.css') ) { ?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.$filename; ?>" />
<?php			}
			}
		}
	}

	public function ThemeEndHead($params) { ?>
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__; ?>/sorttable.js" ></script>
<?php	}

	private function printCell($value, $columnNumber) {
		global $plxShow;

		if (empty($value))
			return '&nbsp;';
		else {
			if ($columnNumber < count($this->format_cells)) { // format the content of cell before any picture
				$fmt = trim($this->format_cells[$columnNumber]);
				$s = ($fmt) ? str_replace('##', $value, $fmt) : $value;
			}
			else
				$s = $value;
			// if you want more controls in your HTML output, add here a switch control on $columnNumber to alter the $s value
			if (preg_match('!(\S*\.(jpg|png|gif))!i', $s, $result)) { // We have a picture
				if (preg_match('!^(http|ftp)s?//:!i', $s)) { // picture in the Cloud
					$src = $s;
					$sz = explode('x', $this->getParam('default_size_picture'));
					$size =  (count($sz) == 2) ? ' width="'.$sz[0].'" height="'.$sz[1].'"' : '';
					return '<img src="'.$src.'"'.$size.' alt="'.$s.'" />';
				}
				else { // local picture
					$src = $this->picturesFolder.$result[1];
					$infos = getimagesize($src);
					$size= (count($infos) >= 3) ? $infos[3] : '';
					$img = '<img src="'.$src.'" '.$size.' alt="'.$s.'" />';
					return str_replace($result[1], $img, $s);
				}
			}
			else
				return trim($s);
		}
	}

	// transform a csv file into a list with <ul> and <li> html tags
	private function csv_list($filename, $title='', $params, $id='', $class='list') {
		define('COLUMN_NUMBER', false); // switching to true gives more info in html output
		if ($fp = fopen($filename, 'r')) {
			$idAttrib = (empty($id)) ? '' : ' id="'.$id.'"';
			$result = "\n".'<div'.$idAttrib.' class="csv-'.$class.'">'."\n";
			if (!empty($title))
				$result .= "\t<h3>$title</h3>\n";
			list($match1, $row_start, $col_start, $col_groups, $format_cells, $pictures) = $params;
			$this->format_cells = explode('|', $format_cells);
			$this->picturesFolder = $pictures;
			$row_cc = 0;
			$result .= "\t<ol>\n";
			// voir csv_table
			// while ($row = fgetcsv($fp, 0, $this->getParam('delimiter'), $this->getParam('enclosure'), $this->getParam('escape'))) {
			while ($row = fgetcsv($fp, 0, $this->getParam('delimiter'), $this->getParam('enclosure'))) {
				if ($row_cc >= $row_start) {
					$result .= "\t\t<li>\n\t\t\t<ul>\n";
					$col = 0;
					$repeatCols = false;
					foreach ($row as $cell) {
						if (empty($cell))
							break;
						if ($col_start > 0) {
							$n = $col - $col_start + 1;
							if (($n >= 0) && (($n % $col_groups) == 0)) {
								if (! $repeatCols) {  // we start the first group of columns
									$info = (COLUMN_NUMBER) ? ' <!-- Col. groupées -->' : '';
									$result .= "\t\t\t</ul>\n\t\t\t<div>".$info."\n\t\t\t\t<ul>\n";
									$repeatCols = true;
								}
								else // we start a new group of columns
									$result .= "\t\t\t\t</ul><ul>\n";
							}
							if ($repeatCols)
								$result .= "\t";
							$formatX = ($n >=0 ) ? $col_start - 1 + ($n % $col_groups) : $col;
						}
						else
							$formatX = $col;
						if (COLUMN_NUMBER)
							$result .= "\t\t\t\t<li>".$this->printCell($cell, $formatX)."</li> <!-- Col. n°$formatX -->\n";
						else
							$result .= "\t\t\t\t<li>".$this->printCell($cell, $formatX)."</li>\n";
						$col++;
						}
					$result .= ($repeatCols) ? "\t\t\t\t</ul>\n" : "\t\t\t</ul>\n";
					if ($repeatCols)
						$result .= "\t\t\t</div>\n";
					$result .= "\t\t</li>\n";
				}
				$row_cc++;
			}
			$result .= "\t</ol>\n</div>\n";
			fclose($fp);
			return $result;
		}
		else
			return "<p>$filename unreachable</p>\n";
	}

	// transform a csv file into a HTML table
	private function csv_table($filename, $title='', $id='', $class='table') {
		if ($fp = fopen($filename, 'r')) {
			$idAttrib = (empty($id)) ? '' : ' id="'.$id.'"';
			$result = "\n".'<table'.$idAttrib.' rules="cols" class="sortable csv-'.$class.'">'."\n";
			if (!empty($title))
				$result .= "<caption>$title</caption>\n";
			$title_cols = true;
			$result .= "<thead>\n";
// fgetcsv accepte le paramètre escape à partir de la version 5.3 de php => Free.fr phpversion = 5.1
//			while ($row = fgetcsv($fp, 0, $this->getParam('delimiter'), $this->getParam('enclosure'), $this->getParam('escape'))) {
			while ($row = fgetcsv($fp, 0, $this->getParam('delimiter'), $this->getParam('enclosure'))) {
				if ($title_cols) {
					$result .= "\t<tr><th>".implode('</th><th>', $row)."</th></tr>\n";
					$result .= "</thead>\n<tbody>\n";
					$title_cols = false;
				}
				else
					$result .= "\t<tr><td>".implode('</td><td>', $row)."</td></tr>\n";
			}
			$result .= "</tbody>\n</table>\n";
			fclose($fp);
			return $result;
		}
		else
			return "<p>$filename unreachable</p>\n";
	}

	public function plxShowStaticContent($output) {
		// affiche le coeur de la page
		global $plxShow;

		$motor = $plxShow->plxMotor;
		$docsFolder = $motor->aConf['documents'];
		# we are building the pattern with .csv files for preg_match_all
		$local_files = $docsFolder.'[^"]*\.csv';
		$href_list = array($local_files);
		if ($this->getParam('google')) {
			$google = 'https?://docs\.google\.com/spreadsheet/pub\?[^"]*output=csv';
			array_push($href_list, $google);
		}
		if ($this->getParam('dropbox')) {
			$dropbox = 'https?://www.dropbox.com/[^"]*\.csv';
			array_push($href_list, $dropbox);
		}
		$other_site = $this->getParam('other_filter');
		if (! empty($other_site))
			array_push($href_list, $other_site);
		$modele = '!\s*<p[^>]*>\s*<a\s.*href="('.implode('|', $href_list).')"[^>]*>([^<]*)</a>\s*</p>\s*!';
		# we are parsing the content of the static page for matching the pattern
		$filename = PLX_ROOT.$motor->aConf['racine_statiques'].$motor->cible;
		$filename .= '.'.$motor->aStats[ $motor->cible ]['url'].'.php';
		$content = file_get_contents($filename);
		$matches = preg_match_all($modele, $content, $result);
		if ($matches > 0) { // we have to do
			$needle = array();
			$replace = array();
			for ($i=0; $i < $matches; $i++) {
				$href = $result[1][$i];
				$remote_url = preg_match('!^(ftp|https?)://!', $href);
				$curl_ok = true;
				if ($remote_url) {
					// download the csv file from the Cloud
					$filename = PLX_ROOT.$docsFolder.plxUtils::charAleatoire(20).'.csv';
					$href = html_entity_decode($href);
					# copy et file_get_contents nécessitent que la directive, dans php.ini, allow_url_fopen soit à On.
					# copy(html_entity_decode($href), $filename);
					# So, we are using Curl
					$fp = fopen($filename, 'w');
					$ch = curl_init($href);
					curl_setopt($ch, CURLOPT_FILE, $fp);
					curl_setopt($ch, CURLOPT_HEADER, false);
					curl_setopt($ch, CURLOPT_USERAGENT, 'Wget/1.14 (linux-gnu)');
					curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Time to get the remote file
					curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // needed for Dropbox
					curl_exec($ch);
					$info_curl = curl_getinfo($ch);
					curl_close($ch);
					fclose($fp);
					$curl_ok = ($info_curl['http_code'] == 200);
				}
				else
					$filename = preg_replace("!^$docsFolder!", PLX_ROOT.$docsFolder, $href);
				if ((filesize($filename) > 0) && (!$remote_url || ($curl_ok))) {
					$title = trim($result[2][$i]);
					if (preg_match('!<a\s.*id="([^"]*)"[^>]*>!i', $result[0][$i], $idResult))
						$id1 = $idResult[1];
					else
						$id1 = '';
					// tester si rel="list()'
					if (preg_match('!rel="list\((\d*),(\d*),(\d*),([^,]*),([^\)]*)\)"!i', $result[0][$i], $params))
						$innerHTML = $this->csv_list($filename, $title, $params, $id1);
					else
						$innerHTML = $this->csv_table($filename, $title, $id1);
					array_push($replace, $innerHTML);
					array_push($needle, $result[0][$i]);
				}
				else
					if (!$curl_ok && $this->getParam('debug')) {
						echo 'Curl returns '.$info_curl['http_code']." error.\n";
						$msg = $result[0][$i]."\n".'<pre class="curl_getinfo">'."results for curl_geninfo() :\n".print_r($info_curl, true)."</pre>\n";
						array_push($replace, $msg);
						array_push($needle, $result[0][$i]);
					}
				if ($remote_url)
					unlink($filename);
			}
			echo str_replace($needle, $replace, $content);
			echo '<?php $output = \'\'; ?>';
		}
	}

	public function AdminTopEndHead() {
		global $plugin;

		if (!empty($plugin) && $plugin == __CLASS__) {?>
		<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.css" />
		<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.js" ></script>
<?php	}
	}
}

?>

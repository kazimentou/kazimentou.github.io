<?php

# config for csv

# !!! take care : $plxMedias->contentFolder() builds a select control with id="folder" !!!
# At the root folder, value = "."

define('PHOTOS', 'folder');

$fields = array(
	'delimiter'=>'string', 'enclosure'=>'string',
	/* 'escape'=>'string', */ 'local'=>'numeric', 'google'=>'numeric',
	'dropbox'=>'numeric', 'other_filter'=>'string', 'debug'=>'numeric',
	PHOTOS=>'string', 'documents'=>'string', 'skip_lines'=>'numeric', 'repeat_col'=>'numeric', 'cols_group'=>'numeric', 'format_cell'=>'string', 'link'=>'string');
$default_values = array(
	'delimiter'=>',', 'enclosure'=>'"',
	'escape'=>'\\', 'local'=>1, 'edition_tableau'=>1);

if (!empty($_POST)) {
	foreach ($fields as $field=>$type) {
		if ($type == 'numeric') {
			$value = intval($_POST[$field]);
			if ($value == 0 && array_key_exists($field, $default_values))
				$value = intval($default_values[$field]);
		}
		else {
			$value = $_POST[$field];
			if (empty($value) && array_key_exists($field, $default_values))
				$value = $default_values[$field];
		}
		$plxPlugin->setParam($field, $value, $type);
		}
	$plxPlugin->saveParams();
}

$picturesFolder = $plxPlugin->getParam(PHOTOS);
$folder = PLX_ROOT.$plxAdmin->aConf['images'];
if (substr($folder, -1) != '/') $folder .= '/';
$picturesFolderSelect = new plxMedias($folder, $picturesFolder);

$documentsFolder = $plxPlugin->getParam('documents');
$folder = PLX_ROOT.$plxAdmin->aConf['documents'];
if (substr($folder, -1) != '/') $folder .= '/';
$documentsFolderSelect = new plxMedias($folder, $documentsFolder);

?>

		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<p>PHP version <?php echo phpversion();?></p>
		<form id="form_<?php echo $plxPlugin->getInfo('title'); ?>" method="post" onsubmit="return true;">
			<p>
<?php foreach ($fields as $field=>$type) {
		if ($field == PHOTOS) {
?>
				<label><?php echo $plxPlugin->lang('L_CSV_ADVANCED_EDITION'); ?></label>&nbsp;</p><p>
<?php
		}
		$value = ($field == 'link') ? '' : $plxPlugin->getParam($field);
		if (!empty($value))
			$value = plxUtils::strCheck($value);
		else
			$value = (array_key_exists($field, $default_values)) ? $default_values[$field] : '';
		$class = ($type == 'cdata') ? 'class="large"' : '' ?>
				<label <?php echo $class;?>><?php $plxPlugin->lang('L_CSV_'.strtoupper($field)); ?></label>
<?php
		echo "\t\t\t\t";
		switch ($type) {
			case 'cdata' :
				plxUtils::printArea(BODY, $value, 70, 12);
				break;
			case 'numeric' :
				switch ($field) {
					case 'skip_lines' :
					case 'repeat_col' :
					case 'cols_group' :
						plxUtils::printInput($field, $value, 'text', '2-2');
						break;
					default :
						$items = array('1'=>L_YES, '0'=>L_NO);
						plxUtils::printSelect($field, $items, $value);
						break;
				}
				break;
			default :
				switch ($field) {
					case PHOTOS :
						echo $picturesFolderSelect->contentFolder();
						echo '&nbsp;'; ?><input type="button" value="Calcul lien" onclick="computeLink(this.form, '<?php echo $plxAdmin->aConf['images']; ?>', '<?php echo $plxAdmin->aConf['documents']; ?>');" /><?php
						break;
					case 'documents' :
						$buf = $documentsFolderSelect->contentFolder();
						echo str_replace('folder', 'documents', $buf);
						break;
					default :
						plxUtils::printInput($field, $value, 'text', '50-80');
						break;
				}
				break;
		echo "\n";
		} ?>
			</p><p>
<?php } ?>
				<?php $plxPlugin->lang('L_CSV_WARNING'); ?>
			</p><p>
				<label>&nbsp;</label>
				<input type="submit" />
			</p>
		</form>

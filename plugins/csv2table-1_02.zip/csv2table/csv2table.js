function csv_onclick() {
	var element = document.getElementById('');
	alert('Ok');
	return true;
}

function computeLink(aForm, photosRoot, documentsRoot) {
	/*
	folder
	documents
	skip_lines
	repeat_col
	cols_group
	format_cell
	* */
	var photos = aForm['folder'].value;
	if (photos == '.') folder = '';
	var documents = aForm['documents'].value;
	if (documents == '.') documents = '';
	aForm['link'].value =
		'<p><a href="'+ documentsRoot + documents +'monfichier.cvs"'+
		' rel="list('+
		aForm['skip_lines'].value+','+
		aForm['repeat_col'].value+','+
		aForm['cols_group'].value+','+
		aForm['format_cell'].value+','+
		photosRoot + photos +')">'+
		'Title'+
		'</a></p>';
}

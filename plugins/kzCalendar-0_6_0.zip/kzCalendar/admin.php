<?php

if(!defined('PLX_ROOT')) { exit; }

/* ------------------------------------------ */
/*    Il y a 2 formulaires dans cette page    */
/* ------------------------------------------ */

# Control du token du formulaire
plxToken::validateFormToken($_POST);

if(!empty($_POST)) {
	$plxPlugin->setEvent($_POST);
	$plxPlugin->saveCalendar();
	header('Location: plugin.php?p='.$plugin);
	exit;
}

function printSelect($name, $value='', $opts) {
	global $plxPlugin;

	$options = array();
	if(empty($value)) {
		$value = 'none';
	}
	foreach(explode(' ', $opts) as $opt) {
		$caption = $plxPlugin->getLang('L_'.strtoupper($opt));
		$selected = ($value == $opt) ? ' selected' : '';
		$options[] = <<< OPTION
		<option value="$opt"$selected>$caption</option>
OPTION;
	}
	$lines = implode("\n", $options);
	echo <<< EOT
	<select name="$name" id="id_$name">
$lines
	</select>

EOT;
}

function printInput($name, $value, $type) {
	$listRequiredFields = explode(' ', 'title day_begin');
	$required = (in_array($name, $listRequiredFields)) ? ' required' : '';
	if($type == 'string') {
		$type = "text";
	}
	echo <<< EOT
<input type="$type" id="id_$name" name="$name" value="$value" $required />

EOT;
}

function printClassnameSelect($name, $value) {
	global $plxPlugin;

	$opt = $plxPlugin->getLang('L_NONE');
	echo <<< SELECT_BEGIN

	<select name="$name">
		<option value="">$opt</option>

SELECT_BEGIN;
	for($i=0,$iMax=20; $i<$iMax; $i++) {
		$opt = 'category-'.str_pad($i, 2, '0', STR_PAD_LEFT);
		$selected = ($value == $opt) ? ' selected' : '';
		echo <<< OPTION
		<option value="$opt" class="$opt"$selected>$opt</option>

OPTION;
	}
	echo <<< SELECT_END
	</select>

SELECT_END;
}

$versionPluXml = (version_compare(PLX_VERSION, '5.6') < 0) ? ' class="PluXml-'.str_replace('.', '', PLX_VERSION).'"' : '';
?>
	<div class="kzCalendar-tabs">
		<label class="active" for="tab0" id="theForm"><?php $plxPlugin->lang('L_EVENT'); ?></label>
<?php
if(!$plxPlugin->no_event()) {
?>
		<label for="tab1"><?php $plxPlugin->lang('L_CALENDAR'); ?></label>
		<label for="tab2"><?php $plxPlugin->lang('L_PLANNING'); ?></label>
		<label for="tab3"><?php $plxPlugin->lang('L_CATEGORY'); ?></label>
<?php
}
?>
	</div>
	<input type="radio" name="tabs" id="tab0"  checked />         <!----------- saisie d'un évènement  ------------- -->
	<div class="event">
		<form id="form_<?php echo $plugin; ?>" method="post"<?php echo $versionPluXml; ?>>
<?php
	foreach($plxPlugin->params as $field=>$type) {
		$value = (($field == 'category') and !empty($_SESSION['kzCalendar-category'])) ? $_SESSION['kzCalendar-category'] : '';
		$className = ($type == 'cdata') ? ' class="wide"' : '';
		if($field == 'ev_link') {
			$className = ' class="ev_link"';
		}
		if($field == 'day_begin') {
?>
			<div class="multi">
<?php
		}
		if(strpos($field, '_begin') !== false) {
?>
			<div>
<?php
		}
?>
			<div<?php echo $className ?>>
				<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.strtoupper($field)); ?></label>
<?php
						switch($type) {
							case 'cdata':
								plxUtils::printArea($field, $value);
								break;
							case 'date':
							case 'time':
							case 'color':
								printInput($field, $value, $type);
								break;
							default: /* type string */
								switch($field) {
									case 'category':
									case 'location':
										$plxPlugin->print_select($field, $value);
?>
				<button type="button" data-select="<?php echo $field; ?>" data-msg="<?php $plxPlugin->lang('L_NEW_'.strtoupper($field)); ?>"><?php $plxPlugin->lang('L_NEW'); ?></button>
<?php
										break;
									case 'period':
										printSelect($field, $value, $plxPlugin::PERIODS);
										break;
									default:
										printInput($field, $value, $type);
								}
						}
						if($field == 'ev_link') {
?>
				<button type="button" data-medias-url="<?php echo $plxPlugin->racine; ?>core/admin/medias.php"><?php $plxPlugin->lang('L_MEDIAS'); ?></button>
<?php
						}
?>
			</div>
<?php
		if(strpos($field, '_end') !== false) {
?>
			</div>
<?php
		}
		if($field == 'hour_end') {
?>
			</div>
<?php
		}
	}
?>
			<div class="in-action-bar">
				<?php echo plxToken::getTokenPostMethod(); ?>

				<input type="submit" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>" />
				<input type="reset" />
				<input type="hidden" name="ev_id" value="" />
				<input type="submit" name="btn-event-delete" value="<?php echo L_DELETE; ?>" class="red" />
				<input type="button" id="btn-event-duplicate" value="<?php $plxPlugin->lang('L_DUPLICATE'); ?>" />
			</div>
			<p class="event-id"></p>
		</form>
	</div>
<?php
if(!$plxPlugin->no_event()) {
?>
	<input type="radio" name="tabs" id="tab1" /> <!-- ------- Affichage du calendrier ------------ -->
	<div class="kzCalendar" data-calendar="<?php echo $plxPlugin->datasUrl(); ?>" >
	</div>
	<input type="radio" name="tabs" id="tab2" />         <!-- -------- Affichage du planning ------------- -->
	<div class="kzCalendar" data-planning="<?php echo $plxPlugin->datasUrl(); ?>">
	</div>
	<input type="radio" name="tabs" id="tab3" />         <!-- ----- Configuration des catégories --------- -->
	<div class="kzCalendar kz-config">
		<form method="post"<?php echo $versionPluXml; ?>>
		<!-- "<?php echo PLX_VERSION; ?>" -->
			<div class="in-action-bar">
					<?php echo plxToken::getTokenPostMethod(); ?>

					<input type="submit" name="btn-category" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>" />
			</div>
			<table>
				<thead>
					<tr>
						<th><?php $plxPlugin->lang('L_CATEGORY')?></th>
						<th><?php $plxPlugin->lang('L_CLASSNAME')?></th>
						<th><?php $plxPlugin->lang('L_DAYS')?></th>
					</tr>
				</thead>
				<tbody>
<?php
	$count = 0;
	foreach($plxPlugin->getCategories() as $category=>$infos) {
		$className = (!empty($infos['className'])) ? $infos['className'] : '';
		$days = (!empty($infos['days'])) ? $infos['days'] : '';
?>
					<tr>
						<td class="<?php echo $className; ?>">
							<span><?php echo $category; ?></span>
							<input type="hidden" name="categories[<?php echo $count; ?>][name]" value="<?php echo $category; ?>">
						</td>
						<td><?php printClassnameSelect('categories['.$count.'][className]', $className); ?></td>
						<td><?php printSelect('categories['.$count.'][days]', $days, $plxPlugin::DAYS_WEEK); ?></td>
					</tr>
<?php
	$count++;
	}
?>
				</tbody>
			</table>
		</form>
	</div>
<?php
}
?>
	<div id="kzCalendar-medias-overlay" data-url-base="<?php plxUtils::getRacine(); ?>">
		<div>
			<iframe id="kzCalendar-medias"><?php $plxPlugin->lang('L_NO_IFRAME')?></iframe>
		</div>
	</div>
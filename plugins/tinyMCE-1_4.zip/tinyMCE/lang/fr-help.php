<?php
$myPlugin = $plxAdmin->plxPlugins->aPlugins[$plugin];
define('MY_PLUGIN_ROOT', '../../'.$plxAdmin->aConf['racine_plugins'].$plugin);
?>
<h2><?php echo $myPlugin->getInfo('title'); ?></h2>
<h3>By <?php echo $myPlugin->getInfo('author'); ?></h3>
<div id="<?php echo get_class($myPlugin); ?>-help">
	<p>
		Ce plugin vous offre un éditeur évolué pour la rédaction de vos articles et de vos pages statiques.
	</p><p>
		TinyMCE fournit de multiples plugins et options pour son éditeur :
	</p><ul>
		<li><a href="http://www.tinymce.com/wiki.php/Plugins" target="_blank">Liste de plugins internes</a></li>
		<li><a href="http://www.tinymce.com/wiki.php/Configuration" target="_blank">Options de configuration</a></li>
		<li><a href="http://www.tinymce.com/wiki.php/Controls" target="_blank">Contrôles pour le menu et la barre d'outils</a></li>
	</ul><p>
		Le plugin externe à TinyMCE qui fournit la coloration syntaxique du code est une adaptation d'un plugin publié à cette adresse :
		<a href="http://www.avoid.org/codemirror-for-tinymce4/"  target="_blank">http://www.avoid.org/codemirror-for-tinymce4/</a>. Il utilise <a href="http://codemirror.net/" target="_blank">Codemirror</a>.
	</p><p>
		Pour la gestion des fichiers dans TinyMCE, en particulier des images, une extension a spécialement été développée pour PluXml, de façon à utiliser son gestionnaire de médias.
	</p><p>
		Afin de bénéficier des dernières mises à jour, la bibliothèque minifiée de TinyMCE est téléchargée depuis le "<a href="http://fr.wikipedia.org/wiki/Content_delivery_network" target="_blank">content delivery network</a>" (<i>CDN</i>) de <a href="http://www.tinymce.com/wiki.php/Tutorial:Using_CDN" target="_blank">CacheFly</a>.
	</p><p>
		Pour l'interface utilisateur, vous disposez d'autres traductions à <a href="http://www.tinymce.com/i18n/index.php" target="_blank">http://www.tinymce.com/i18n/index.php</a>. Une fois téléchargée, l'archive zip est à décompresser dans le répertoire "tinyMCE/langs" du plugin.
	</p><p>
		Vous pourrez personnaliser l'apparence de TinyMCE en créant votre propre "skin" <a href="http://skin.tinymce.com/"  target="_blank">ici</a>. Il faudra pour cela vous armer de patience. Cela fait, décompressez l'archive obtenu dans le dossier "tinyMCE/skins" du plugin et indiquez dans la variable du script tinyMCE.php le nom de votre skin. Par défaut, TinyMCE fournit le skin lightgray.
	</p><p>
		<img src="<?php echo MY_PLUGIN_ROOT;?>/tinymce.png" alt="logo de TinyMCE" width="153" height="79" /><img src="<?php echo MY_PLUGIN_ROOT;?>/cachefly.png" alt="Logo de CacheFly" width="200" height="93"/>
	</p>
</div>

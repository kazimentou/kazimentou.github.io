// some parts are from https://github.com/christiaan/tinymce-codemirror

var	codemirror, editor,
	indentOnInit = false,
	cm_config,
	chr = 0;  // Unused utf-8 character, placeholder for cursor

function findDepth(haystack, needle) {
	"use strict";

	var idx = haystack.indexOf(needle), depth = 0, x;
	for (x = idx; x >= 0; x--) {
		switch(haystack.charAt(x)) {
			case '<': depth--; break;
			case '>': depth++; break;
		}
	}
	return depth;
}

// This function is called by plugin.js, when user clicks 'Ok' button
function submit() {
	"use strict";

	var cc = '&#x0;',
		isDirty = codemirror.isDirty,
		doc = codemirror.doc;

	if (doc.somethingSelected()) {
		// Clear selection:
		doc.setCursor(doc.getCursor());
	}

	// Insert cursor placeholder (&#x0;)
	doc.replaceSelection(cc);

	var pos = codemirror.getCursor(),
		curLineHTML = doc.getLine(pos.line);

	if (findDepth(curLineHTML, cc) !== 0) {
		// Cursor is inside a <tag>, don't set cursor:
		curLineHTML = curLineHTML.replace(cc, '');
		doc.replaceRange(curLineHTML, CodeMirror.Pos(pos.line, 0), CodeMirror.Pos(pos.line));
	}

	// Submit HTML to TinyMCE:
	editor.setContent(codemirror.getValue().replace(cc, '<span id="CmCaReT"></span>'));
	editor.isNotDirty = !isDirty;
	if (isDirty) {
		editor.nodeChanged();
	}

	// Set cursor:
	var el = editor.dom.select('span#CmCaReT')[0];
	if (el) {
		editor.selection.scrollIntoView(el);
		editor.selection.setCursorLocation(el,0);
		editor.dom.remove(el);
	}
}

function start() {
	if (window.frameElement) {
		var tinymce = window.parent.tinymce;
		if (tinymce) {
			// Set CodeMirror cursor to same position as cursor was in TinyMCE:
			editor = tinymce.activeEditor;
			var html = editor.getContent();
			html = html.replace(/<span\s+class="CmCaReT"([^>]*)>([^<]*)<\/span>/gm, String.fromCharCode(chr));
			editor.dom.remove(editor.dom.select('.CmCaReT'));

			var html = editor.getContent();
			cm_config.value = html;
			if (CodeMirror) {

				CodeMirror.defineInitHook(function(inst) {
					// Move cursor to correct position:
					inst.focus();
					var cursor = inst.getSearchCursor(String.fromCharCode(chr), false);
					if (cursor.findNext()) {
						inst.setCursor(cursor.to());
						cursor.replace('');
					}

					// Indent all code, if so requested:
					if (indentOnInit) {
						var last = inst.lineCount();
						inst.operation(function() {
							for (var i = 0; i < last; ++i) {
								inst.indentLine(i);
							}
						});
					}
				});

				// Instantiante CodeMirror:
				codemirror = CodeMirror(document.body, cm_config);
				codemirror.isDirty = false;
				codemirror.on('change', function(inst) {
					inst.isDirty = true;
				});
			}
		} else
			alert('Please, use Tinymce editor');
	} else
		alert('You must open this page in an IFRAME window');
}

<?php

$LANG = array(

'L_MESSAGE'				=>	'D&iacute;gite o c&oacute;digo da imagem ',

);

?>
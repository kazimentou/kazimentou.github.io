<?php

$LANG = array(

'L_MESSAGE'				=>	'Introduceti codul de pe imagine ',

);

?>
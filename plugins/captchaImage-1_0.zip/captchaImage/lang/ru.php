<?php

$LANG = array(

'L_MESSAGE'				=>	'Введите код изображения',

);
?>
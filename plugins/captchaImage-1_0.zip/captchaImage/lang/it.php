<?php

$LANG = array(

'L_MESSAGE'				=>	'Inserisci il codice',

);
?>

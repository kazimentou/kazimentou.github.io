<?php

$LANG = array(

'L_MESSAGE'				=>	'Geef de code van de afbeelding',

);

?>

<?php

$LANG = array(

'L_MESSAGE'				=>	'Enter image code',

);
?>
<?php

$LANG = array(

'L_MESSAGE'				=>	'Wprowadź kod obrazka',

);
?>
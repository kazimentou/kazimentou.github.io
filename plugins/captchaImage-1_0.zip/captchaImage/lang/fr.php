<?php

$LANG = array(

'L_MESSAGE'				=>	'Entrez le code de l\'image',

);

?>
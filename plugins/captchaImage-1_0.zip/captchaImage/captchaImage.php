<?php

if (!defined('PLX_ROOT')) exit;

# author Jean-Pierre P.
# date : 2014-02-13

class captchaImage extends plxPlugin {

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# Ajouts des hooks
		$this->addHook('plxShowCapchaQ', 'plxShowCapchaQ');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

	public function plxShowCapchaQ() {

		$this->lang('L_MESSAGE');  // echo 'blabla'...;
		$pwd = PLX_PLUGINS.__CLASS__; // r�pertoire du plugin
		$imagesize = getimagesize($pwd.'/capcha.png');
		echo '<br /><img src="'.$pwd.'/capcha.php" alt="Capcha" id="capcha" '.$imagesize[3].'/><?php return true; ?>'."\n";
	}

	public function AdminTopEndHead() {
		global $plugin;

		if (!empty($plugin) && $plugin == __CLASS__) { ?>
		<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.css" />
<?php	}
	}

	// This is a hack for Pluxml 5.3. The response at captcha is limited at a word of one caractere
	public function ThemeEndBody() { ?>
		<script type="text/javascript"> <!--
			var repId = document.getElementById('id_rep');
			if (repId) { repId.setAttribute('maxlength', '5'); } else { console.log('Input with id: id_rep not found'); } // -->
		</script>
<?php
	}

}
?>

<?php

$root = 'http://www.test.net/test1/';
$src1 = '&lt;img style=&quot;float: left; margin: 0px 10px;&quot; src=&quot;http://www.test.net/test1/data/images/alumnat-1-800.tb.jpg&quot; alt=&quot;Alumnat - Davézieux&quot; width=&quot;200&quot; height=&quot;94&quot; /&gt;';
$src2 = '&lt;img style=&quot;float: left; margin: 0px 10px;&quot; src=&quot;http://www.test.net/test1/data/images/.thumbs/test2/cover.jpg&quot; alt=&quot;Image 2&quot; width=&quot;41&quot; height=&quot;60&quot; /&gt;';
$src = $src2."\n";
$pats = ['&lt;', '&gt;', '&quot;'];
$reps = ['<<<<', '>>>>', '""""'];
$srcPlus = str_replace($pats, $reps, $src);
echo $srcPlus."\n";

$pattern1 = '!<((img\s[^>]*src=")('.$root.'[^"]*\.)(tb\.)(jpg|png|gif)([^>]*))>!';
$pattern2 = '!<((img\s[^>]*src=")('.$root.'[^"]*)(/\.thumbs)(/\w[^"]*\.)(jpg|png|gif)([^>]*))>!';

$patterns = [$pattern1, $pattern2];
$replaces = ['<a href="\3\5">>>><<<<\1></a>', '<a href="\3\5\6">>>><<<<\1>>>><<<</a>'];

preg_match($pattern2, $srcPlus, $result);
print_r($result);

$tmp = preg_replace($patterns, $replaces, $srcPlus);
echo $tmp."\n";

echo str_replace($reps, $pats, $tmp);

?>

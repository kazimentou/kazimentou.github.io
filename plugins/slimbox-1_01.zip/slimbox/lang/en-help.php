<?php if(!defined('PLX_ROOT')) exit; ?>
<h2>Slimbox 2</h2>
<p>The ultimate lightweight Lightbox clone</p>
<p><a href="http://www.digitalia.be/software/slimbox2" target="_blank">Click here for discover his features</a></p>
<p>This is a part of the manual of SlimBox2 : </p>
<h3><a name="Activate"></a>Activate<a href="#Activate" class="section_anchor"></a></h3>
<p>Add the <tt>rel=&quot;lightbox&quot;</tt> attribute to the links pointing to your full-sized images. Use the optional title attribute if you want to show a caption: </p>
<pre>
&lt;a href=&quot;images/image-1.jpg&quot; rel=&quot;lightbox&quot; title=&quot;my caption&quot;&gt;image #1&lt;/a&gt;</pre><p>You can even use HTML in the caption if you want. You must replace the &lt; and &gt; characters with HTML entities and use single quotes instead of double quotes. </p>
<p>For sets of related images that you want to group and make navigable, add a group name to the <tt>rel</tt> attribute just after the &quot;lightbox&quot; word, for example: </p>
<pre>
&lt;a href=&quot;images/image-1.jpg&quot; rel=&quot;lightbox-cats&quot;&gt;image #1&lt;/a&gt;
&lt;a href=&quot;images/image-2.jpg&quot; rel=&quot;lightbox-cats&quot;&gt;image #2&lt;/a&gt;
&lt;a href=&quot;images/image-3.jpg&quot; rel=&quot;lightbox-cats&quot;&gt;image #3&lt;/a&gt;
</pre>
<p>I don&#x27;t recommend using square brackets &quot;[ ]&quot; around group names in the <tt>rel</tt> attribute like the original Lightbox script does because these characters are invalid for XHTML and XML attributes, meaning that your web page would not validate against the latest standards. </p>
<p>More information here : <a href="http://code.google.com/p/slimbox/wiki/jQueryManual" target="_blank">http://code.google.com/p/slimbox/wiki/jQueryManual</a></p>
<p>And power users can read the documentation for API here : <a href="http://code.google.com/p/slimbox/wiki/jQueryAPI" target="_blank">http://code.google.com/p/slimbox/wiki/jQueryAPI</a></p>

<?php
$LANG = array(
    'L_TITLE'=>'SlimBox',
    'L_DESCRIPTION'=>'Plugin pour SlimBox V2.05 avec JQuery' 
);
?>

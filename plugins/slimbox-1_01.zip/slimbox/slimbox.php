<?php

if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour SlimBox2
 * version SlimBox 2.05
 * http://www.digitalia.be/software/slimbox2 for home page
 * http://code.google.com/p/slimbox/wiki/jQueryManual for the Manuel
 * http://code.google.com/p/slimbox/wiki/jQueryAPI for API
 * More infos about CDN here : http://encosia.com/3-reasons-why-you-should-let-google-host-jquery-for-you/
 * */

if (! defined('JQUERY_LIB'))
	define('JQUERY_LIB', 'jquery-1.11.3.min.js');
if (! defined('JQUERY_SRC')) {
	// define('JQUERY_SRC', '//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js');
	define('JQUERY_SRC', '//code.jquery.com/'.JQUERY_LIB);
}

class slimbox extends plxPlugin {

	private $script_name;

	private $default_options = array(
		'loop'=>false,
		'overlayOpacity'=>0.8,
		'overlayFadeDuration'=>400,
		'resizeDuration'=>400,
		'initialWidth'=>250,
		'initialHeight'=>250,
		'imageFadeDuration'=>400,
		'captionAnimationDuration'=>400,
		'closeKeys'=>'27, 88, c',
		'previousKeys'=>'37, 80',
		'nextKeys'=>'39, 78'
	);

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('FeedEnd', 'FeedEnd');
		}

	public function get_styles() {
		$pattern = PLX_PLUGINS.__CLASS__.'/css/*.css';
		return glob($pattern);
	}

	private function pluginRoot() {
		global $plxShow;
		
		if (isset($plxShow)) {
			return $plxShow->plxMotor->racine.$plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}

	private function set_slimbox($lang='en') {
		// title for enlarged pictures with Slimbox
		// Many thanks to http://translate.google.fr/
		$translations = array(
			'de' => 'Bild {x} von {y}',
			'es' => 'Imagen {x} de {y}',
			'fr' => 'Image {x} sur {y}',
			'it' => 'Immagine {x} di {y}',
			'nl' => 'Afbeelding {x} van {y}',
			'pl' => 'Zdjęcie {x} z {y}',
			'pt' => 'Imagem {x} de {y}',
			'ro' => 'Imaginea {x} din {y}',
			'ru' => 'Изображение {x} из {y}'
			);
		if (! defined('JQUERY_LOADED')) { ?>
	<script type="text/javascript">
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src'+'="<?php echo JQUERY_SRC; ?>"><\/scr'+'ipt>');
	</script>
<?php
			define('JQUERY_LOADED', true);
		}
?>
	<link href="<?php echo $this->pluginRoot().'css/'.$this->getParam('css'); ?>.css" rel="stylesheet" type="text/css" media="screen" />
	<script type="text/javascript">
		<!-- // Slimbox
		var slimbox_options = {
			overlayOpacity: 0.6,
			<?php
if (array_key_exists($lang, $translations))
			echo 'counterText: "'.$translations[$lang].'",'."\n";
?>
			initialWidth: 250,
			initialHeight: 333,
			loop: true
		};
		// -->
	</script>
	<script type="text/javascript" src="<?php echo $this->pluginRoot(); ?>js/slimbox2.js"></script> 
<?php
	}

// ============== Hooks start here =======================
	public function AdminTopEndHead() {
		global $plxAdmin;

		switch ($this->script_name) {
			case 'parametres_pluginhelp' :
?>
	<style type="text/css">
		div.slimbox {max-width: 700px;}
		div.slimbox p {margin: 0.8em 5px; text-align: justify;}
		div.slimbox pre {background-color: White; margin: 5px 2em; padding: 0.5em 1em;}
		div.slimbox tt {background-color: White; padding: 0.2em 0.5em;}
		div.slimbox h3 {font-size: 1.2em;}
	</style>
	<script src="http://google-code-prettify.googlecode.com/svn/loader/run_prettify.js"></script>
<?php
				break;
			case 'medias' :
				$this->set_slimbox($plxAdmin->aConf['default_lang']); // add language
				break;
		}
	}

	public function ThemeEndHead() {
		global $plxShow;
		$this->set_slimbox($plxShow->plxMotor->aConf['default_lang']);
	}
	
	public function FeedEnd() {
		global $plxFeed;

        // protect some HTML entities between tags (required by XML files)
        $code = "\$pats = ['&lt;', '&gt;', '&quot;'];\n";
        $code .= "\$reps = ['<<<<', '>>>>', '\"\"\"\"'];\n";

        $root = $plxFeed->racine;
        $host = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'];
        if (substr($root, 0, strlen($host)) != $host)
			$root = $host.$root;
        $_pattern1 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*\.)(tb\.)(jpg|png|gif)([^>]*))>>>>!';
        $_pattern2 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*)(/\.thumbs)(/\w[^"]*\.)(jpg|png|gif)([^>]*))>>>>!';
        $_replace1 = '<<<<a href="\3\5">>>><<<<\1>>>><<<</a>>>>';
        $_replace2 = '<<<<a href="\3\5\6">>>><<<<\1>>>><<<</a>>>>';

        $code .= "\$patterns = [\n\t'$_pattern1',\n\t'$_pattern2'\n];\n";
        $code .= "\$replaces = ['$_replace1', '$_replace2'];\n";
        $code .= "\$tmp = str_replace(\$pats, \$reps, \$output);\n";
		$code .= "\$tmp = preg_replace(\$patterns, \$replaces, \$tmp);\n";
        // deprotect some HTML entities and output
        $code .= "\$output = str_replace(\$reps, \$pats, \$tmp);\n";
		
		echo "<?php $code ?>";

	}

}
?>

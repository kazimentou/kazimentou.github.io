<?php
if(!defined('PLX_ROOT')) exit;

if (isset($_POST['jquery']) && isset($_POST['css'])) {
    $plxPlugin->setParam('jquery', $_POST['jquery'], 'string');
    $plxPlugin->setParam('mode', $_POST['mode'], 'string');
    $plxPlugin->setParam('css', $_POST['css'], 'string');
    $plxPlugin->saveParams();
}
?>

<form method="post">
<table style="background-color: Wheat; padding: 0;">
<caption>
<h2><?php $plxPlugin->lang('L_TITLE') ?></h2>
<?php $plxPlugin->lang('L_DESCRIPTION') ?>
</caption>
<tr>
    <td style="text-align: right;">Url pour JQuery</td><td><input type="text" name="jquery" size="40" value="<?php echo plxUtils::strCheck($plxPlugin->getParam('jquery')); ?>" /></td>
</tr><tr>
    <td style="text-align: right;">Charger JQuery</td>
    <td>
        <select  name="mode">
<?php
$selection =  plxUtils::strCheck($plxPlugin->getParam('mode'));
foreach (array('no'=>'Non', 'yes'=>'Oui', 'auto'=>'Auto') as $k=>$v) {
    $selected = ($k == $selection) ? ' selected' : '';
    echo('<option value="'.$k.'"'.$selected.'>'.$v."</option>\n");
}
?>
        </select>
    </td>
</tr><tr>
    <td style="text-align: right;">Feuille de style</td>
    <td>
        <select name="css">
<?php
$selection = plxUtils::strCheck($plxPlugin->getParam('css'));
foreach ($plxPlugin->get_styles() as $v) {
	$fn = basename($v, '.css');
    $selected = ($fn == $selection) ? ' selected' : '';
    echo('<option value="'.$fn.'"'.$selected.'>'.$fn."</option>\n");
}
?>
        </select>
    </td>
</tr>
<tr><td colspan="2" style="text-align: center;"><input type="submit" name="submit" value="Enregistrer" /></td></tr>
</table>
</form>

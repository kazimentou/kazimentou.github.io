<?php

$LANG = array(
	/* config.php */
	'L_CODEMIRROR_THEME'=>'Théme pour l\'éditeur',
	'L_CODEMIRROR_LINENUMBERS'=>'Number lines',
	'L_CODEMIRROR_ARTICLE'=>'Enabled to writing articles',
	'L_CODEMIRROR_STATIQUE'=>'Enabled to writing static pages',
	'L_CODEMIRROR_PARAMETRES_EDITTPL'=>'Enabled to writing templates',
	'L_CODEMIRROR_SHOW'=>'Syntax highlighter for public pages',
	'L_CODEMIRROR_MINIFY_JS'=>'MinifyJS library',
	'L_CODEMIRROR_SHOW_ME'=>'Show me',
	'L_CODEMIRROR_DOWNLOAD'=>'Download the minifyJS library',
	'L_CODEMIRROR_COMPLETION'=>'Hit Ctrl-Espace for completion',
	'L_CODEMIRROR_FULLSCREEN'=>'Full screen',
	'L_CODEMIRROR_COMMENT'=>'The code to colorize has to put between &lt;pre&gt; and &lt;/pre&gt; tags. By default, "text/html" mime-type is used. For other languages, add the data-lang attribute inside &lt;pre&gt; tag. For example, &lt;pre data-lang="text/css"&gt;...&lt;/pre&gt;.'
);

?>

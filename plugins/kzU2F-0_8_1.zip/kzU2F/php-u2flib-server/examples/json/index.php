<?php

const DEBUG = true;
const TITLE_PAGE = 'Test of U2F with storage in JSON format in the temporary directory (/temp)';

require_once '../../src/u2flib_server/App.php';

class MyApp extends u2flib_server\App {

	protected function loadRegistrations() {
		parent::loadRegistrations();

		if(empty($_SESSION['u2f']['filename'])) {
			// session_unset();
			$_SESSION['u2f'] = null;
			$_SESSION['u2f']['filename'] = tempnam(sys_get_temp_dir(), 'u2f');
		}

		if(file_exists($_SESSION['u2f']['filename'])) {
			$content = trim(file_get_contents($_SESSION['u2f']['filename']));
			if(!empty($content)) {
				$this->registrations = get_object_vars(json_decode($content));
			}
		}

		if(empty($this->registrations)) {
			$this->registrations = array();
		}
	}

	protected function getRegistrations($userId) {
		return (array_key_exists($userId, $this->registrations)) ? $this->registrations[$userId] : false;
	}

	protected function updateCounter($userId, $keyHandle, $value) {
		foreach($this->registrations[$userId] as &$registration) {
			if($registration->keyHandle === $keyHandle) {
				$registration->counter = $value;
				$this->saveRegistrations();
				break;
			}
		}
	}

	protected function saveRegistration($userId, &$registration) {
		if(!array_key_exists($userId, $this->registrations)) {
			$this->registrations[$userId] = array($registration);
		} else {
			// checks if keyHandle already exists
			$this->registrations[$userId][] = $registration;
		}
		$this->saveRegistrations();
	}

	protected function saveRegistrations() {
		// parent::saveRegistrations();
		ksort($this->registrations);
		file_put_contents($_SESSION['u2f']['filename'], json_encode($this->registrations, JSON_PRETTY_PRINT + JSON_UNESCAPED_SLASHES));
	}

	function getUserIds() {
		return (!empty($this->registrations)) ? array_keys($this->registrations) : false;
	}

	function getNewUserId() {
		do {
			$newUserId = rand(1, 50);
		} while($this->userExists($newUserId));
		return $newUserId;
	}

	protected function userExists($userId) {
		return (!empty($this->registrations) and array_key_exists($userId, $this->registrations));
	}
}

$myApp = new MyApp('../assets/u2f-api.js', DEBUG);
$authUserId = $myApp->getUserId(); // for authentication
// $_SESSION['lastUserId'] = $myApp->lastUserId;

include '../common.inc';

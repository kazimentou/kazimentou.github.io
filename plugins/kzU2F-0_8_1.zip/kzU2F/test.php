<?php

if(empty($_SERVER['HTTPS']) or strtolower($_SERVER['HTTPS']) !== 'on') {
	header('Content-Type: text/plain');
	exit('Only HTTPS protocol is supported');
}

if(
	!function_exists('session_start') or
	!function_exists('json_decode')
) {
	header('Content-Type: text/plain');
	exit('Session and JSON supports are required');
}

const DEBUG = true;

session_start();

require_once 'php-u2flib-server/src/u2flib_server/U2F.php';

class MyApp {

	public $registrations = false;
	private $libraryURL = false;
	private $u2f;

	function __construct($url='') {
		$this->libraryURL = $url;
		$this->loadRegistrations();

		$appId = "https://{$_SERVER['HTTP_HOST']}";
		$this->u2f = new u2flib_server\U2F($appId);
	}

	protected function loadRegistrations() {
		if(empty($_SESSION['u2f']['filename'])) {
			// session_unset();
			$_SESSION['u2f'] = null;
			$_SESSION['u2f']['filename'] = tempnam(sys_get_temp_dir(), 'u2f');
		}

		if(file_exists($_SESSION['u2f']['filename'])) {
			$content = trim(file_get_contents($_SESSION['u2f']['filename']));
			if(!empty($content)) {
				$this->registrations = get_object_vars(json_decode($content));
			}
		}

		if(empty($this->registrations)) {
			$this->registrations = array();
		}
	}

	protected function saveRegistrations() {
		ksort($this->registrations);
		file_put_contents($_SESSION['u2f']['filename'], json_encode($this->registrations, JSON_PRETTY_PRINT + JSON_UNESCAPED_SLASHES));
	}

	private function sessionCleanup($fieldsListArr) {
		foreach($fieldsListArr as $field) {
			if(array_key_exists($field, $_SESSION['u2f'])) {
				unset($_SESSION['u2f'][$field]);
			}
		}
	}

	private function alertJS($message, $userId='') {
		if(DEBUG) {
			echo <<< EOT
				alert("Ok for $message\\nLook at response in the JS console\\nof the userId : $userId");\n
EOT;
		}
	}

	protected function printRegistrationRequestJS($callback) {
		self::sessionCleanup(array('userId', 'authChallenge'));
		list($regAppId, $regRequest, $regRegisteredKeys) = $this->u2f->getRegisterData(); // $signs is an empty array;
		$_SESSION['u2f']['regRequest'] = json_encode($regRequest);
		$regRequestJSON = json_encode(array($regRequest), JSON_UNESCAPED_SLASHES);
		$regRegisteredKeysJSON = json_encode($regRegisteredKeys, JSON_UNESCAPED_SLASHES);
		echo <<< REGISTER
				setTimeout(function () {
					u2f.register(
						'$regAppId',
						$regRequestJSON,
						$regRegisteredKeysJSON,
						$callback
					)
				}, 1000);\n
REGISTER;
	}

	protected function printAuthenticationRequestJS($callback) {
		self::sessionCleanup(array('newUserId', 'regRequest'));

		$registrationObj = $this->registrations[$_SESSION['u2f']['userId']]; // Object is required by $u2f->getAuthenticateData
		list($signAppId, $signChallenge, $signRegisteredKeys) = $this->u2f->getAuthenticateData($registrationObj); // returns an array of one object
		$_SESSION['u2f']['authChallenge'] = $signChallenge;
		$signRegisteredKeysJSON = json_encode($signRegisteredKeys, JSON_UNESCAPED_SLASHES);
		echo <<< AUTHENTIFICATION
			setTimeout(function () {
					u2f.sign(
						'$signAppId',
						'$signChallenge',
						$signRegisteredKeysJSON,
						$callback
					);
			}, 1000);\n
AUTHENTIFICATION;
	}

	function printScriptJS($formId, $fieldname, $registerButtonId=false) {
		$sessionKey = (empty($registerButtonId)) ? 'userId' : 'newUserId';
		$actionMsg = (empty($registerButtonId)) ? 'authentification' : 'registration';
?>
	<script type="text/javascript">
	(function () {
		'use strict';

		const errorMsgs = [
		    'Success',
		    'An error otherwise not enumerated',
		    'The request cannot be processed',
		    'Client configuration is not supported',
		    'The presented device is not eligible for this request.\nFor a registration request this may mean that the token is already registered,\nand for a sign request it may mean the token does not know the presented key handle.',
		    'Timeout reached before request could be satisfied'
		];

		const actionMsg = '<?php echo (empty($registerButtonId)) ? 'authentification' : 'registration'; ?>';

		function u2fCallback(response) {
			console.log('Response from the token :', response);
			if(typeof response.errorCode === 'undefined' || response.errorCode === 0) {
<?php self::alertJS($actionMsg, $_SESSION['u2f'][$sessionKey]); ?>
				const form1 = document.getElementById('<?= $formId ?>');
				form1.elements['<?= $fieldname ?>'].value = JSON.stringify(response);
				form1.submit();
			} else {
				alert('U2F error #' + response.errorCode + ' for <?= $actionMsg ?> :\n\n' + errorMsgs[response.errorCode]);
			}
		}

		function setup() {
<?php
if(!empty($registerButtonId)) { /* ------ Registration ------ */
?>
			document.getElementById('<?= $registerButtonId ?>').addEventListener('click', function (event) {
				event.preventDefault();
				console.log('Starts registration');
<?php $this->printRegistrationRequestJS('u2fCallback'); ?>
			});
<?php
} else { /* -------- Authentication ----------- */
?>
			console.log('Starts authentification');
<?php $this->printAuthenticationRequestJS('u2fCallback'); ?>
<?php
}
?>
		}

		if(typeof u2f === 'undefined') {
			const script1 = document.createElement('SCRIPT');
			script1.src = '<?= $this->libraryURL ?>';
			script1.onload = function(event) {
				console.log('API loaded');
				setup();
			};
			document.head.appendChild(script1);
		} else {
			setup();
		}
	})();
	</script>
<?php
	}

	function doRegistration() {
		try {
			$registration = $this->u2f->doRegister(
				json_decode($_SESSION['u2f']['regRequest']),
				json_decode($_POST['registrationResp'])
			);
			/*
			 * $registration is u2flib_server\Registration object
			 *   with publicKey, keyHandle, certificate properties
			 * */
			$lastUserId = $_SESSION['u2f']['newUserId'];

			if(!array_key_exists($lastUserId, $this->registrations)) {
				$this->registrations[$lastUserId] = array();
			}
			// Check if this registration already exists
			$this->registrations[$lastUserId][] = $registration;
			$this->saveRegistrations();
		} catch( Exception $e ) {
			header('Content-Type: text/plain');
			echo "\$_SESSION['u2f']['regRequest'] = ";
			print_r($_SESSION['u2f']['regRequest']);
			echo "\njson_decode(\$_POST['registrationResp']) = ";
			print_r(json_decode($_POST['registrationResp']));
			die("Error for registration :".$e->getMessage());
		} finally {
			unset($_SESSION['u2f']['newUserId']);
			unset($_SESSION['u2f']['regRequest']);
		}
	}

	function doAuthentication() {
		try {
			$newRegistration = $this->u2f->doAuthenticate(
				$_SESSION['u2f']['authChallenge'],
				$this->registrations[$_SESSION['u2f']['userId']],
				json_decode($_POST['authentificationResp'])
			);
			foreach($this->registrations[$_SESSION['u2f']['userId']] as &$registration) {
				if($registration->keyHandle === $newRegistration->keyHandle) {
					$registration->counter = $newRegistration->counter;
					$this->saveRegistrations();
					break;
				}
			}
			header('Content-Type: text/plain');
			$hr = str_repeat('=', 45);
			echo "\n$hr\n  Successful authentification for userId: {$_SESSION['u2f']['userId']}\n$hr\n\n";
			echo '$newRegistration = ';
			print_r($newRegistration);
			echo "\n";
		} catch  (Exception $e) {
			die("Error for authentication :\n".$e->getMessage());
		} finally {
			unset($_SESSION['u2f']['authChallenge']);
			unset($_SESSION['u2f']['userId']);
		}
	}

	function getNewUserId() {
		do {
			$newUserId = rand(1, 50);
		} while(array_key_exists($newUserId, $this->registrations));
		return $newUserId;
	}

}

$myApp = new MyApp('u2f-api.js');

$lastUserId = '';

if(DEBUG) {
	echo "<!--\nAt beginning of this script :\n\n\$_SESSION['u2f'] = ".print_r($_SESSION['u2f'], true)."\n".
		"\$_POST = ".print_r($_POST, true)."-->\n";
}

if(
	!empty($_SESSION['u2f']['newUserId']) and
	!empty($_SESSION['u2f']['regRequest']) and
	!empty($_POST['registrationResp'])
) { /* ------------- Do registration ---------------- */
	$myApp->doRegistration();
} elseif(
	!empty($_POST['userId']) and
	array_key_exists($_POST['userId'], $myApp->registrations)
) {
	if(!empty($_POST['newToken'])) { /*  --------- Add a new token ---------- */
		$_SESSION['u2f']['newUserId'] = $_POST['userId'];
		$newToken = true;
	} else { /* --------- Request for authentification -------------- */
		$authUserId = $_POST['userId'];
		$_SESSION['u2f']['userId'] = $authUserId;
	}
} elseif(
	!empty($_SESSION['u2f']['userId']) and
	!empty($_SESSION['u2f']['authChallenge']) and
	!empty($_POST['authentificationResp'])
) {	/* ---------- Check authentification ------------ */
	$myApp->doAuthentication();
	echo '$_SESSION[\'u2f\'] = ';
	print_r($_SESSION['u2f']);
	exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Test of U2F</title>
</head><body>
<?php
if(empty($authUserId)) { /* ---------- Prepare a new registration -------- */
	if(empty($_SESSION['u2f']['newUserId'])) {
		// new userId
		$_SESSION['u2f']['newUserId'] = $myApp->getNewUserId();
	}
?>
	<form id="reg-form" method="post">
		<input type="hidden" name="registrationResp" value="" />
		<?= (!empty($newToken)) ? 'New token for' : 'New'; ?> userId : <?php echo $_SESSION['u2f']['newUserId']; ?>
		<button id="regBtn">Registration</button>
	</form>
<?php
	if(empty($newToken) and !empty($myApp->registrations)) {
?>
	<form id="auth-form" method="post">
		<label for="id_user-id">UserId</label>
		<select id="id_user-id" name="userId" required>
			<option value="">-------</option>
<?php
	foreach(array_keys($myApp->registrations) as $userId) {
		$selected = ($userId == $lastUserId) ? ' selected' : '';
		echo <<< OPTION
			<option value="$userId"$selected>$userId</option>\n
OPTION;
		}
?>
		</select>
		<input type="submit" value="New token" name="newToken" />
		<input type="submit" value="Authentification" />
	</form>
<?php
	}
	$myApp->printScriptJS('reg-form', 'registrationResp', 'regBtn');
} else { /* ---------- Request only for authentification -------- */
?>
	<form id="auth-form" method="post">
		<input type="hidden" name="authentificationResp" />
		Request authentication for UserId : <?php echo $authUserId; ?>
	</form>
<?php
	$myApp->printScriptJS('auth-form', 'authentificationResp');
}

if(DEBUG) {
?>
	<div style="position: fixed; bottom: 0; left:0; width: 100vw; max-height: 75vh; overflow: auto;">
		<pre style="margin: 0; padding: 0.3rem 0.8rem; width: 300vw; background: #666; color: greenyellow;">
<?php
echo '$_SESSION[\'u2f\'] = '.print_r($_SESSION['u2f'], true).
	'$registrations = '.print_r($myApp->registrations, true);
?>
		</pre>
	</div>
<?php
}
?>
</body></html>

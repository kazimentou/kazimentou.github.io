<?php
$LANG = array(
	'U2F_ENABLE'		=> 'Authenticate by token',
	'REGISTER_TOKEN'	=> 'Submit',
	'CHECK_TOKEN'		=> 'Check%s',
	'ADD_TOKEN'			=> 'Add',
	'DEL_TOKEN'			=> 'Remove',
	'VALIDATE_TOKEN'	=> 'Enable the USB key\nbefore updating the profil',
	'ACTIONS'			=> 'Error on saving|Error on authenticating',
	'ERROR_MESSAGES'	=>
			'Success|'.
		    'An error otherwise not enumerated|'.
		    'The request can not proceed|'.
		    'Unknown configuration for this client|'.
		    'The presented device is not eligible for this request.\nFor a registration request this may mean that the token is already registered,\nand for a sign request it may mean the token does not know the presented key handle.|'.
		    'Timeout reached before the device answers',
	'CONNECT_TOKEN'		=> 'Plug the key in the USB socket<br />and hit the button on it.'
);
?>

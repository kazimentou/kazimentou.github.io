<?php
$LANG = array(
	'U2F_ENABLE'		=> 'S\'authentifier par token',
	'REGISTER_TOKEN'	=> 'Valider',
	'CHECK_TOKEN'		=> 'Vérifier%s',
	'ADD_TOKEN'			=> 'Ajouter',
	'DEL_TOKEN'			=> 'Supprimer',
	'VALIDATE_TOKEN'	=> 'Activer la clé USB\navant de modifier le profil',
	'ACTIONS'			=> 'Erreur à l\'enregistrement|Erreur à l\'authentification',
	'ERROR_MESSAGES'	=>
			'Succès|'.
		    'An error otherwise not enumerated|'.
		    'La demande ne peut pas être traitée|'.
		    'Configuration inconnue pour ce client|'.
		    'Impossible de répondre à la demande pour ce périphérique.\nCe périphérique est peut-être déjà enregistré,\nou ce périphérique n\'est pas référencé pour vous authentifier.|'.
		    'Le périphérique a mis trop de temps à répondre',
	'CONNECT_TOKEN'		=> 'Insérez votre clé de sécurité<br />dans un port USB et<br>appuyez sur son bouton'
);
?>

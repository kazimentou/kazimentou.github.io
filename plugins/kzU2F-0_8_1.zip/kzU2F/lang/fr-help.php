<style>
	ul.kzU2F-help { display: none; }
	@media (min-width: 48rem) {
		ul.kzU2F-help {
			display: flex;
			justify-content: flex-end;
			right: 1.5rem;
			position: fixed;
			top: 0;
			width: 500px;
			height: 120px;
			margin: 0;
			list-style-type: none;
			z-index: 9999;
		}
	}
</style>
<div>
	<p style="font-weight: bold; color: red;">L'authentification par le couple "nom d'utilisateur / mot de passe" est insuffisante pour garantir un accès sécurisé à un site Internet.</p>
	<p>De plus en plus de sites comme Google, Dropbox, Github, ... ajoutent une étape supplémentaire d'authentification par un autre moyen, soit purement logiciel avec un code PIN à durée de vie limitée, soit en utilisant une clé de cryptage générée par un support physique. On parle alors de double authentification.</p>
	<p>Le site Internet doit également utiliser le protocole <a href="https://fr.wikipedia.org/wiki/HyperText_Transfer_Protocol_Secure" target="_blank" rel="noreferrer  nofollow"><strong>HTTPS</strong></a>.</p>
</div>
<div>
	<p>
	Pour utiliser ce plugin, vous devez posséder une clé de sécurité conforme à la norme <a href="https://fidoalliance.org/about/what-is-fido/" target="_blank" rel="noreferrer  nofollow"><strong>FIDO</strong></a>, à insérer dans le port USB. Ce plugin a été testé avec 2 clés USB de marque <a href="http://www.key-id.com/key-id-fido-u2f-security-key-online-security/" target="_blank" rel="noreferrer  nofollow">Key-id</a> et <a href="https://hypersecu.com/products/hyperfido" target="_blank" rel="noreferrer  nofollow">Hypersecu</a>.
	</p>
	<p>
		Ces clés de sécurité sont encore assez mal distribuées. On les trouvera principalement chez <a href="https://www.amazon.fr/s/ref=nb_sb_noss?field-keywords=fido-u2f" target="_blank" rel="noreferrer  nofollow">Amazon</a> en recherchant le mot-clé "fido-u2f".
	</p>
</div>
<ul>
	<li>Une fois connecté, aller sur votre page profil en cliquant dans le menu administration</li>
	<li>Repérer s'authentifier par token et sélectionner "oui"</li>
	<li>Cliquer sur le bouton "Ajouter" et insérer votre clé de sécurité dans un port USB</li>
	<li>Appuyer sur le bouton de la clé lorsque la lumière clignote</li>
	<li>Valider en cliquant sur le bouton modifier votre profil</li>
	<li>Se déconnecter éventuellement</li>
</ul>
<ul>
	<li>Sur la page d'authentication, identifiez avec votre couple nom d'utilisateur / votre mot de passe</li>
	<li>En cas de succès, une invitation à connecter votre clé de sécurité sur le port USB s'affiche</li>
	<li>Appuyer ensuite sur le bouton qui clignote</li>
	<li>Retirez la clé, une fois connecté</li>
</ul>
<div>
	<p>
Depuis la version 57, Firefox intègre désormais la prise en charge du standard FIDO U2F. Cette option n'est pas active par défaut.
	</p>
	<ul>
		<li>Dans la barre d'adresse, taper <strong>about:config</strong></li>
		<li>Ayez confiance et ignorer le message d'avertissement</li>
		<li>Rechercher : <strong>u2f</strong></li>
		<li>Régler la valeur du champ <strong>security.webauth.u2f</strong> à : true</li>
	</ul>
	<p>
		A ce jour, Chrome nécessite un script externe Javascript publié par Google. Le plugin téléchargera le script en cas de besoin.
	</p>
</div>
<?php $imgRoot = PLX_PLUGINS."$page/"; ?>
<ul class="kzU2F-help">
	<li><a href="https://fidoalliance.org/about/what-is-fido/" target="_blank" rel="noreferrer  nofollow"><img src="<?= $imgRoot ?>img/fido-u2f-2.png" alt="fido-u2f" title="Fido Alliance" /></a></li>
	<li><a href="https://hypersecu.com/products/hyperfido" target="_blank" rel="noreferrer  nofollow"><img src="<?= $imgRoot ?>img/hypersecu.png" alt="Hypersecu" title="Clé Hypersecu" /></a></li>
	<li><a href="http://www.key-id.com/key-id-fido-u2f-security-key-online-security/" target="_blank" rel="noreferrer  nofollow"><img src="<?= $imgRoot ?>img/key-id.png" alt="Key-Id" title="Clé Key-Id" /></a></li>
</ul>

<?php
if(
	!defined('PLX_ROOT') or
	empty($_SERVER['HTTP_USER_AGENT']) or
	empty($_SERVER['HTTP_ACCEPT_LANGUAGE']) or
	empty($_SERVER['HTTP_ACCEPT'])
) { exit; }

/*
 * https://github.com/google/u2f-ref-code/blob/master/u2f-gae-demo/war/js/u2f-api.js
 * https://fidoalliance.org/specs/fido-u2f-v1.2-ps-20170411/fido-u2f-javascript-api-v1.2-ps-20170411.html#methods
 * https://fidoalliance.org/specs/fido-u2f-v1.0-nfc-bt-amendment-20150514/fido-u2f-javascript-api.html#high-level-javascript-api
 * https://fidoalliance.org/specifications/overview
 * https://github.com/Yubico/php-u2flib-server
 * */

/* ======= Chrome extension don't respect FIDO specification ============ */

/*
 * plxPlugins::saveConfig(..) ne gère pas la méthode plxPlugin::OnDelete().
 * Il ne prend en compte que les méthodes plxPlugin::OnActivate() et plxPlugin::OnDeActivate().
 * Par ailleurs, plxPlugins::loadPlugins() gère la méthode plxPlugin::onUpdate().
 * Et c'est tout. Donc pas de fichier de données pour le plugin, juste un fichier de config.
 * */

/* ======================================= IMPORTANT ============================================ *\
 * filter_input(INPUT_POST, 'field', FILTER_SANITIZE_STRING) escapes simple and double quotes.
 *
 * if $_POST['field'] in JSON format, use :
 * filter_input(INPUT_POST, 'field', FILTER_SANITIZE_STRING, array('flags'=>FILTER_FLAG_NO_ENCODE_QUOTES))
\* ============================================================================================== */

require_once 'php-u2flib-server/src/u2flib_server/U2F.php';

class kzU2F extends plxPlugin {

	const DEBUG = false;
	const JSLIB_PATH = '/php-u2flib-server/examples/assets/u2f-api.js'; // Required by Chrome navigator and others
	// for core/admin/profil.php
	const FIELDNAME = 'u2f-enabled';
	const REG_FIELDNAME = 'u2f-register';
	const SIGN_FIELDNAME = 'u2f-signin';
	const DEL_FIELDNAME = 'u2f-delete';
	// for core/admin/auth.php
	const AUTH_FIELDNAME = 'u2f-auth';
	// private $registrationsFilename;
	private $registrations = false;
	private $appId;
	private $userId;
	private $userTokensCount = 0;

	public function __construct($lang) {

		parent::__construct($lang);

		$https_enabled = (!empty($_SERVER['HTTPS']) and strtolower($_SERVER['HTTPS']) === 'on');
		if($https_enabled and defined('PLX_AUTHPAGE')) {
			$this->appId = self::getAppId();

			# Authentification
			parent::addHook('AdminAuthPrepend', 'AdminAuthPrepend');
			parent::addHook('AdminAuthEndHead', 'AdminAuthEndHead');
			parent::addHook('AdminAuth', 'AdminAuth');
			parent::addHook('AdminAuthEndBody', 'AdminAuthEndBody');
		} elseif(defined('PLX_ADMIN')) {

			if(!$https_enabled) {
				plxMsg::Error(parent::getLang('MISSING_HTTPS'));
			} elseif(!empty($_SESSION['user'])) {
				// See PlxPlugin::__construct
				// $this->registrationsFilename = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'. __CLASS__ .'.json';
				$this->appId = self::getAppId();
				$this->userId = $_SESSION['user'];

				# droits pour accéder à la page config.php du plugin
				parent::setConfigProfil(PROFIL_ADMIN);

				parent::addHook('AdminTopEndHead', 'AdminTopEndHead');

				# User interface
				parent::addHook('AdminProfilTop', 'AdminProfilTop');
				parent::addHook('AdminProfil', 'AdminProfil');
				parent::addHook('AdminProfilFoot', 'deviceDialog');
				parent::addHook('plxAdminEditProfil', 'plxAdminEditProfil');

				# Manage the users
				parent::addHook('plxAdminEditUsersUpdate', 'plxAdminEditUsersUpdate');

				# Manage the user
				parent::addHook('AdminUserTop', 'AdminUserTop');
				parent::addHook('AdminUser', 'AdminUser');
				parent::addHook('plxAdminEditUser', 'plxAdminEditUser');
			}
		}
	}

	private function getAppId() {
		// return trim(plxUtils::getRacine(), '/'); /* doesn't work with Chrome navigator
		return "https://{$_SERVER['HTTP_HOST']}";
		// return sha1(trim(plxUtils::getRacine(), '/'));
	}

	private function __registrationsLoad() {
		if(is_array($this->registrations)) { return; }
		/*
		if(file_exists($this->registrationsFilename)) {
			$content = trim(file_get_contents($this->registrationsFilename));
			if(!empty($content)) {
				$this->registrations = get_object_vars(json_decode($content));
			}
		}
		* */
		$this->registrations = array();
		$content = trim(self::getParam('registrations'));
		if(!empty($content)) {
			$datas = json_decode($content);
			if(is_object($datas)) {
				foreach(get_object_vars($datas) as $userId => $values) {
					$this->registrations[$userId] = get_object_vars($values);
					if($userId === $this->userId) {
						$this->userTokensCount = count($this->registrations[$userId]['tokens']);
					}
				}
			}
		}
	}

	private function __registrationsSave() {
		if(is_array($this->registrations)) {
			ksort($this->registrations);
			$content = json_encode(
				$this->registrations,
				JSON_PRETTY_PRINT + JSON_UNESCAPED_SLASHES
			);
			/*
			file_put_contents($this->registrationsFilename, $content);
			 * */
			// plxMsg::Infos('U2F ok');
			self::setParam('registrations', $content, 'cdata');
			self::saveParams();
		} else {
			plxMsg::Error(__CLASS__ .'::registrations is not an array');
		}
	}

	public function signIn($sign) {
		self::__registrationsLoad();
		return false;
	}

	public function doRegistration($enabled, $reqResponseJSON, $signResponseJSON, $del=false) {
		$this->__registrationsLoad();

		if(array_key_exists($this->userId, $this->registrations)) {
			$this->registrations[$this->userId]['enabled'] = (($this->userTokensCount > 0) and $enabled);
		}

		if($enabled and !empty($_SESSION['u2f-challenge'])) {
			if(!empty($reqResponseJSON)) {
				try {
					$u2f = new u2flib_server\U2F($this->appId);
					$request = new u2flib_server\RegisterRequest($_SESSION['u2f-challenge'], $this->appId);
					$reqResponseObj = json_decode($reqResponseJSON);
					$registration = $u2f->doRegister($request, $reqResponseObj);
					if(!array_key_exists($this->userId, $this->registrations)) {
						$this->registrations[$this->userId] = array(
							'enabled'	=> true,
							'tokens'		=> array()
						);
					}
					// Check if this registration already exists
					$this->registrations[$this->userId]['tokens'][] = $registration; // Object Registration with publicKey, keyHandle, certificate properties
					$this->registrations[$this->userId]['enabled'] = true;
				} catch( Exception $e ) {
					header('Content-Type: text/plain');

					if(self::DEBUG) {
						echo "\$request = ";
						print_r($request);
						echo "\n\$reqResponseObj = ";
						print_r($reqResponseObj);
					}

					$warning = 'error: '.$e->getMessage();
					plxMsg::Error($warning);
					die($warning);
				}
			}

			if(!empty($signResponseJSON) and $this->userTokensCount > 0) {
				$signResponse = json_decode($signResponseJSON);
				if($del) {
					$tokens = $this->registrations[$this->userId]['tokens'];
					for($i=0, $iMax = count($tokens); $i<$iMax; $i++) {
						if($tokens[$i]->keyHandle == $signResponse->keyHandle) {
							unset($this->registrations[$this->userId]['tokens'][$i]);
							break;
						}
					}
				} else {
					try {
						$u2f = new u2flib_server\U2F($this->appId);
						$registration = $u2f->doAuthenticate(
							$_SESSION['u2f-challenge'],
							$this->registrations[$this->userId]['tokens'],
							$signResponse
						);

						// Update the counter for this user and this token
						$tokens = $this->registrations[$this->userId]['tokens'];
						for($i=0, $iMax = count($tokens); $i<$iMax; $i++) {
							if($tokens[$i]->keyHandle == $registration->keyHandle) {
								$this->registrations[$this->userId]['tokens'][$i]->counter = $registration->counter;
								break;
							}
						}
					} catch( Exception $e ) {
						header('Content-Type: text/plain');

						if(self::DEBUG) {
							echo "\$request = ";
							print_r($request);
							echo "\n\$signResponse = ";
							print_r($signResponse);
						}

						$warning = 'error: '.$e->getMessage();
						plxMsg::Error($warning);
						die($warning);
					}
				}
			}

			unset($_SESSION['u2f-challenge']);
		}

		$this->__registrationsSave();
	}

	private function __printConsoleJS($message, $extra='') {
		if(!SELF::DEBUG) { return; }
		if(!empty($extra)) { $extra = ", $extra"; }
		echo <<< EOT
				console.log('$message'$extra);\n
EOT;
	}

	public function deleteUsers($usersArr) {
		$this->__registrationsLoad();
		$update = false;
		foreach($usersArr as $userId) {
			if($userId !== '001' and array_key_exists($userId, $this->registrations)) {
				unset($this->registrations[$userId]);
				$update = true;
			}
		}
		if($update) { $this->__registrationsSave(); }
	}

	public function userEnabled($userId) {
		$this->__registrationsLoad();
		if(
			array_key_exists($userId, $this->registrations) and
			!empty($this->registrations[$userId]['enabled'])
		) {
			$this->adminUser = true;
			return true;
		} else {
			return false;
		}
	}

	public function disableUser($userId) {
		$this->__registrationsLoad();
		if(
			array_key_exists($userId, $this->registrations) and
			!empty($this->registrations[$userId]['enabled'])
		) {
			$this->registrations[$userId]['enabled'] = false;
			$this->__registrationsSave();
		}
	}

	/* =========================== HOOKS ==================================== */

	/* ----------------------- Authentification ------------------------------ */

	public function AdminAuthPrepend() {
		$login = filter_input(INPUT_POST, 'login', FILTER_SANITIZE_STRING);
		$password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

		if(!empty($login) and !empty($password)) {
			global $plxAdmin;

			foreach($plxAdmin->aUsers as $id => $infos) {
				if(
					!empty($infos['active']) and
					empty($infos['delete']) and
					$login === $infos['login'] and
					sha1($infos['salt'].md5($password)) === $infos['password']
				) {
					$userId = $id;
					break;
				}
			}

			if(!empty($userId)) {
				// This login is found and the password matches
				$isJsonRequest = ($_SERVER['HTTP_ACCEPT'] === 'application/json');
				$token = filter_input(INPUT_POST, self::AUTH_FIELDNAME, FILTER_SANITIZE_STRING);
				$this->__registrationsLoad();
				if(
					!array_key_exists($userId, $this->registrations) or
					empty($this->registrations[$userId]['enabled'])
				) {
					// This user don't need a double authentication
					if($isJsonRequest) {
						// Answer to the XMLHttpRequest

						// plxToken::getTokenPostMethod() is a destructive control
						$newToken = sha1(mt_rand(0, 1000000));
						$_SESSION['formtoken'][$newToken] = time();

						header('Content-Type: application/json');
						echo json_encode(array(
							'pass' => true,
							'newToken'	=> $newToken
						));
						exit;
					}
				} else {
					if(
						empty($token) or
						empty($_SESSION[self::AUTH_FIELDNAME][$token]) or
						$_SESSION[self::AUTH_FIELDNAME][$token] < time()
					) {
						// Anti-hacking
						header('Content-Type: text/plain');
						if(self::DEBUG) {
							echo "\$token = $token\n";
							echo "\$_SESSION = ".print_r($_SESSION, true)."\n";
							echo time();
							$_SESSION[self::AUTH_FIELDNAME] = ''; // Drops an array
							unset($_SESSION[self::AUTH_FIELDNAME]);
							unset($_SESSION['u2f-challenge']);
							echo "\$_POST = \n";
							print_r($_POST);
						}
						die('Security error : invalid or expired token for u2f');
					}

					// This user needs double authentication
					$tokens = $this->registrations[$userId]['tokens'];
					$u2f = new u2flib_server\U2F($this->appId);
					if($isJsonRequest) {
						// Returns a challenge with registered keys
						list($appId, $challenge, $registeredKeys) = $u2f->getAuthenticateData($tokens);
						$_SESSION['u2f-challenge'] = $challenge;

						// plxToken::getTokenPostMethod() is a destructive control
						$newToken = sha1(mt_rand(0, 1000000));
						$_SESSION['formtoken'][$newToken] = time();

						header('Content-Type: application/json');
						header('Cache-Control: no-cache, must-revalidate');
						header('Expires: Sat, 14 Jul 2000 05:00:00 GMT');
						echo json_encode(array(
							'appId'		=> $appId,
							'challenge'	=> $challenge,
							'keys'		=> $registeredKeys,
							'newToken'	=> $newToken
						));
						exit;
					} else {
						unset($_SESSION[self::AUTH_FIELDNAME][$token]);
						// checks for double authentication
						$signResponseJSON = filter_input(
							INPUT_POST,
							self::SIGN_FIELDNAME,
							FILTER_SANITIZE_STRING,
							array('flags'=>FILTER_FLAG_NO_ENCODE_QUOTES)
						);
						try {
							$challenge = $_SESSION['u2f-challenge'];
							unset($_SESSION['u2f-challenge']);
							$registration = $u2f->doAuthenticate(
								$challenge,
								$tokens,
								json_decode($signResponseJSON)
							);

							// Success ! Go on.

							// Update the counter for this user and this token
							$updated = false;
							for($i=0, $iMax = count($tokens); $i<$iMax; $i++) {
								if($tokens[$i]->keyHandle == $registration->keyHandle) {
									$this->registrations[$userId]['tokens'][$i]->counter = $registration->counter;
									$updated = true;
									break;
								}
							}
							if($updated) { self::__registrationsSave(); }
						} catch( Exception $e ) {
							$msg = $e->getMessage();
							die("Security error for u2f :\n{$msg}\n");
						}
					}
				}
			}
		}
	}

	public function AdminAuthEndHead() {
		$url = PLX_PLUGINS. __CLASS__ . '/img/fido-u2f.png';
		echo <<< STYLE
		<style>
			@keyframes kzU2F-slide {
				0%   { background-position: 550px 0, 40px 60px, 130px 270px, 70px 100px; }
				100% { background-position: 0px 550px, 390px 410px, 380px 520px, 220px 250px; }
			}
			body.kzU2F {
				/* http://lea.verou.me/css3patterns/#starry-night */
				background-color: #222;
				background-image:
					radial-gradient(#eee, rgba(200,200,200,.2) 2px, transparent 40px),
					radial-gradient(#ddd, rgba(255,255,255,.15) 1px, transparent 30px),
					radial-gradient(#ccc, rgba(255,255,255,.1) 2px, transparent 40px),
					radial-gradient(rgba(255,255,255,.4), rgba(255,255,255,.1) 2px, transparent 30px);
				background-size: 550px 550px, 350px 350px, 250px 250px, 150px 150px;
				animation: kzU2F-slide 20s linear infinite normal;
			}
			body.kzU2F section div.auth {
				background: #eee;
			}
			/* Hack against PluXml */
			#auth div.logo { margin-top: 0; }
			#auth .container section { margin-top: 50vh; transform: translateY(-50%); }
			#form_user #id_u2f-enabled { margin: 0; }

			.kzU2F-overlay {
				display: none;
				position: fixed;
				top: 0;
				left: 0;
				height: 100vh;
				width: 100vw;
				background: #222c;
			}
			.kzU2F-overlay.active {
				display: block;
			}
			.kzU2F-overlay > div {
				max-width: 36rem;
				margin: 50vh auto 0;
				padding: 1rem 2rem;
				transform: translateY(-50%);
				text-align: center;
				background: #eee;
			}
			#form_auth fieldset > div:last-of-type > div { background: url('$url') 1.5rem center no-repeat; }
		</style>\n
STYLE;
	}

	/**
	 * Add some hidden controls in the authentication page (core/admin/auth.php.
	 * */
	public function AdminAuth() {
		$this->token = sha1(mt_rand(0, 1000000));
?>
							<div style="display: none;">
								<input type="hidden" name="<?php echo self::SIGN_FIELDNAME; ?>" />
								<input type="hidden" name="<?php echo self::AUTH_FIELDNAME; ?>" />
							</div>
<?php
	}

	/**
	 * Prepare the authentication page (core/admin/auth.php) for the double authentication.
	 * */
	public function AdminAuthEndBody() {
		$_SESSION[self::AUTH_FIELDNAME][$this->token] = time() + 600; // 10 minutes
		$src = PLX_PLUGINS. __CLASS__ . self::JSLIB_PATH;
		// https://developer.mozilla.org/fr/docs/Web/API/XMLHttpRequest/Utiliser_XMLHttpRequest#G%C3%A9rer_les_donn%C3%A9es_binaires
?>
	<div class="kzU2F-overlay">
		<div><?php self::lang('CONNECT_TOKEN'); ?></div>
	</div>
	<script type="text/javascript">
	(function() {
		'use strict';

		document.body.classList.add('<?php echo __CLASS__; ?>');

		const form1 = document.getElementById('form_auth');
		if(form1 != null) {

			const DO_REGISTRATION = 0;
			const DO_SIGNIN = 1;
			var formStatus = 0;
			var params = null;

			function u2fErrorMsg(errorCode, actionCode) {
				const actions = "<?php echo $this->getLang('ACTIONS'); ?>".split('|');
				const messages = "<?php echo $this->getLang('ERROR_MESSAGES'); ?>".split('|');
				alert(actions[actionCode] + ':\n\n' + messages[errorCode]);
			}

			function signinCallback(response) {
				if(typeof response.errorCode === 'undefined' || response.errorCode === 0) {
					form1.elements['<?php echo self::SIGN_FIELDNAME; ?>'].value = JSON.stringify(response);
					formStatus = 4; // Success for authentication
					form1.submit();
				} else {
					u2fErrorMsg(response.errorCode, DO_SIGNIN);
					document.querySelector('div.kzU2F-overlay').classList.remove('active');
				}
			}

			function downloadU2f() {
				const script1 = document.createElement('SCRIPT');
				script1.type = 'text/javascript';
				script1.src = '<?= $src ?>';
				script1.onload = signin;
				document.head.appendChild(script1);
			}

			function signin() {
				<?php if(self::DEBUG) echo "console.log('Response for XHR', params);\n"; ?>
				form1.elements.token.value = params.newToken;
				setTimeout(u2f.sign(
					params.appId,
					params.challenge,
					params.keys, <?php /* registered keys */ echo "\n"; ?>
					signinCallback
				), 1000);
			}

			form1.addEventListener('submit', function(event) {
				if(
					form1.elements.login.value.trim().length > 0 &&
					form1.elements.password.value.trim().length > 0 &&
					form1.elements.token.value.trim().length > 0
				) {
					if(formStatus === 0 && form1.elements['<?php echo self::SIGN_FIELDNAME; ?>'].value.trim().length < 20) {
						event.preventDefault();
						formStatus = 1; <?php /* Request for authentication */ echo "\n"; ?>
 						form1.elements['<?php echo self::AUTH_FIELDNAME; ?>'].value = '<?php echo $this->token; ?>';

						const XHR = new XMLHttpRequest();
						XHR.open('POST', form1.action, false); // synchrone
						XHR.setRequestHeader('Accept', 'application/json');
						XHR.send(new FormData(form1));

						if(XHR.status == 200) { <?php /* Do authentication */ ?>
							if(
								XHR.getResponseHeader('Content-Type') === 'application/json' &&
								XHR.responseURL === form1.action
							) {
								formStatus = 0;
								params = JSON.parse(XHR.responseText);
								if('appId' in params && 'challenge' in params && 'keys' in params) {
									document.querySelector('div.kzU2F-overlay').classList.add('active');
									if(typeof u2f === 'undefined') {
										downloadU2f();
									} else {
										signin();
									}
								} else if('pass' in params && params.pass) { <?php /* No authentication required */ echo "\n"; ?>
									formStatus = 2;
									form1.elements['<?php echo self::SIGN_FIELDNAME; ?>'].value = '';
									form1.elements['<?php echo self::AUTH_FIELDNAME; ?>'].value = '';
									form1.elements.token.value = params.newToken;
									form1.submit();
								}
							}
						} else {
							const msg = 'XHR status : ' + XHR.status;
							<?php echo (self::DEBUG) ? 'alert(msg)' : 'console.log(msg)'; ?>;
						}
					}
				} else {
					event.preventDefault();
					console.log('Some input fields are empty');
				}
			});
		}
	})();
	</script>
<?php
	}

	/* -------------------- Setup for the current user ---------------------- */

	/**
	 * Active the cache for HTML output.
	 * */
	public function AdminProfilTop() {
		echo '<?php ob_start(); ?>';
	}

	/**
	 * Add controls for the double authentification for the current user in the core/admin/profil.php script.
	 * */
	public function AdminProfil() {
		self::__registrationsLoad();
		// Building a dialog block
		ob_start();
		$fieldname = self::FIELDNAME;
		$REG_FIELDNAME1 = self::REG_FIELDNAME;
		$caption = $this->getLang('U2F_ENABLE');
		$captionBtn = $this->getLang('REGISTER_TOKEN');
		echo <<< DIALOG_BEGIN
		<div class="grid">
			<div class="col sml-12">
				<input type="hidden" name="$REG_FIELDNAME1" id="id_$REG_FIELDNAME1" />
				<label for="id_$fieldname">$caption&nbsp;:</label>
DIALOG_BEGIN;
		$value = (
			$this->userTokensCount > 0 and
			$this->registrations[$this->userId]['enabled']
		) ? '1' : '0';
		plxUtils::printSelect(
			$fieldname,
			array('1'=>L_YES,'0'=>L_NO),
			$value
		);
		if($this->userTokensCount > 0) {
			$checkCaption = sprintf($this->getLang('CHECK_TOKEN'), ($this->userTokensCount > 1) ? " ($this->userTokensCount)" : '');
			$addCaption = $this->getLang('ADD_TOKEN');
			$delCaption = $this->getLang('DEL_TOKEN');
			$signFieldname = self::SIGN_FIELDNAME;
			$delFieldname = self::DEL_FIELDNAME;
			$disabled = ($value != '1') ? ' disabled' : '';
			echo <<< I_HAVE_TOKENS
				<input type="button" value="$checkCaption" id="u2f-checkBtn"$disabled />
				<input type="button" value="$addCaption" id="u2f-addBtn"$disabled />
				<input type="button" value="$delCaption" id="u2f-delBtn" disabled />
				<input type="hidden" name="$signFieldname" id="id_$signFieldname" />
				<input type="hidden" name="$delFieldname" id="id_$delFieldname" />\n
I_HAVE_TOKENS;
		} else {
			echo <<< NO_TOKEN
				<input type="button" value="$captionBtn" id="u2f-addBtn" disabled />\n
NO_TOKEN;
		}
		echo <<< DIALOG_END
			</div>
		</div>\n
DIALOG_END;
		$dialog = ob_get_clean();

		$code = <<< 'CODE'
<?php
$dialog = <<< DIALOG
##DIALOG##
DIALOG;
echo preg_replace('@(\s*</fieldset>.*)@s', "$dialog$1", ob_get_clean());
?>
CODE;
		echo str_replace('##DIALOG##', $dialog, $code);
	}


	/**
	 * It's the interface with the token in the navigator.
	 *
	 * Mostly working in the navigator. Register a new token,  check a registered token or drop it.
	 * */
	public function deviceDialog() {
		if(!defined('PLX_AUTHPAGE') and !defined('PLX_ADMIN')) { return; }

		self::__registrationsLoad();
		$tokens = ($this->userTokensCount > 0) ? $this->registrations[$this->userId]['tokens'] : array();

		$u2f = new u2flib_server\U2F($this->appId);

		list($appId, $challenge, $registeredKeys) = $u2f->getAuthenticateData($tokens);
		$_SESSION['u2f-challenge'] = $challenge;

		$src = PLX_PLUGINS. __CLASS__ . self::JSLIB_PATH;
?>
	<script type="text/javascript"> /* AdminProfilFoot from <?php echo __CLASS__; ?> plugin */
	(function () {
		'use strict';

		const DO_REGISTRATION = 0;
		const DO_SIGNIN = 1;

		function u2fErrorMsg(errorCode, actionCode) {
			const actions = "<?php echo $this->getLang('ACTIONS'); ?>".split('|');
			const messages = "<?php echo $this->getLang('ERROR_MESSAGES'); ?>".split('|');
			alert(actions[actionCode] + ':\n\n' + messages[errorCode]);
		}

		function setup() {

			const appId = '<?php echo $appId; ?>';
			const registeredKeys = <?php echo json_encode($registeredKeys, JSON_PRETTY_PRINT + JSON_UNESCAPED_SLASHES); ?>;

<?php
		if(defined('PLX_ADMIN')) {
			// Registration
			$request = new u2flib_server\RegisterRequest($challenge, $appId);
?>
			const request = <?php echo json_encode($request, JSON_PRETTY_PRINT + JSON_UNESCAPED_SLASHES); ?>;

			function u2fRegCallback(response) {
<?php	self::__printConsoleJS('u2fRegCallback :', 'response'); ?>
				if(typeof response.errorCode === 'undefined' || response.errorCode === 0) {
					regResponseElt.value = JSON.stringify(response);
					addBtn.disabled = true;
				} else {
					u2fErrorMsg(response.errorCode, DO_REGISTRATION);
				}
			}

			const form1 = document.getElementById('form_profil');
			const regResponseElt = document.getElementById('id_<?php echo SELF::REG_FIELDNAME; ?>');
			const checkBtn = document.getElementById('u2f-checkBtn');
			const addBtn = document.getElementById('u2f-addBtn');
			const delBtn = document.getElementById('u2f-delBtn');

			addBtn.addEventListener('click', function (event) {
<?php	self::__printConsoleJS('Starts registration'); ?>
				event.preventDefault();
				setTimeout(function () {
					u2f.register(
						appId,
						[request],
						registeredKeys,
						u2fRegCallback
					);
				}, 1000);
			});
<?php
			if($this->userTokensCount > 0) {
				// Authentification
?>

			const signResponseElt = document.getElementById('id_<?php echo SELF::SIGN_FIELDNAME; ?>');
			function signCallback(response) {
<?php	self::__printConsoleJS('signCallback :', 'response'); ?>
				if(typeof response.errorCode === 'undefined' || response.errorCode === 0) {
					signResponseElt.value = JSON.stringify(response);
					if(delBtn != null) {
						delBtn.disabled = false;
						checkBtn.disabled = true;
					}
				} else {
					u2fErrorMsg(response.errorCode, DO_SIGNIN);
				}
			}

			if(checkBtn != null) {
				checkBtn.addEventListener('click', function (event) {
					event.preventDefault();
<?php	self::__printConsoleJS('Starts authentification'); ?>
					setTimeout(function () {
						u2f.sign(
							appId,
							'<?php echo $challenge; ?>',
							registeredKeys,
							signCallback
						);
					}, 1000);
				});
			}

			if(delBtn != null) {
				delBtn.addEventListener('click', function(event) {
					event.preventDefault();
					document.getElementById('id_<?php echo self::DEL_FIELDNAME; ?>').value = '1';
					event.target.disabled = true;
				});
			}
<?php
			} else { // no registered token
?>

			form1.addEventListener('submit', function (event) {
				if (ACTIVATION_SELECT.value == '1' && regResponseElt.value.trim().length == 0) {
					event.preventDefault();
					alert('<?php echo self::getLang('VALIDATE_TOKEN'); ?>');
				}
			});
<?php
			}
		}
?>

			const ACTIVATION_SELECT = document.getElementById('id_<?php echo SELF::FIELDNAME; ?>');
			ACTIVATION_SELECT.addEventListener('change', function (event) {
				addBtn.disabled = (event.target.value == '0');
				if(checkBtn != null) {
					checkBtn.disabled = (event.target.value == '0');
				}
			});
		}

		if (typeof u2f == 'undefined') {
			console.log('Downloading <?= $src ?>');
			const script1 = document.createElement('SCRIPT');
			script1.src = '<?= $src ?>';
			script1.onload = function(event) {
				console.log('API loaded');
				setup();
			};
			document.head.appendChild(script1);
		} else {
			setup();
		}
	})();
	</script>
<?php
	}

	const PLX_ADMIN_EDITPROFIL_CODE = <<< 'PLX_ADMIN_EDITPROFIL_CODE'
<?php
$u2f_enabled = ($content['##FIELDNAME##'] == '1');
$u2f_register = trim(filter_input(
	INPUT_POST,
	'##REG_FIELDNAME##',
	FILTER_SANITIZE_STRING,
	array('flags'=>FILTER_FLAG_NO_ENCODE_QUOTES)
));
$u2f_signin = trim(filter_input(
	INPUT_POST,
	'##SIGN_FIELDNAME##',
	FILTER_SANITIZE_STRING,
	array('flags'=>FILTER_FLAG_NO_ENCODE_QUOTES)
));
$u2f_delete = filter_input(
	INPUT_POST,
	'##DEL_FIELDNAME##',
	FILTER_VALIDATE_BOOLEAN
);
$this->plxPlugins->aPlugins['##CLASS##']->doRegistration($u2f_enabled, $u2f_register, $u2f_signin, $u2f_delete);
return false;
?>
PLX_ADMIN_EDITPROFIL_CODE;

	/**
	 * Proceed the responses made by the token.
	 * */
	public function plxAdminEditProfil() {
		$replaces = array(
			'##FIELDNAME##'		=> self::FIELDNAME,
			'##REG_FIELDNAME##'	=> self::REG_FIELDNAME,
			'##SIGN_FIELDNAME##'	=> self::SIGN_FIELDNAME,
			'##DEL_FIELDNAME##'	=> self::DEL_FIELDNAME,
			'##CLASS##'			=> __class__
		);
		echo str_replace(array_keys($replaces), array_values($replaces), self::PLX_ADMIN_EDITPROFIL_CODE);
	}

	const PLX_ADMIN_EDITUSERS_UPDATE_CODE = <<< 'PLX_ADMIN_EDITUSERS_UPDATE_CODE'
<?php
if(
	!empty($content['idUser']) and
	$content['idUser'] === '001' and
	empty($content['update']) and
	!empty($content['selection']) and
	$content['selection'] == 'delete' and
	!empty($content['idUser'])
) {
	$this->plxPlugins->aPlugins['##CLASS##']->deleteUsers($content['idUser']);
}
?>
PLX_ADMIN_EDITUSERS_UPDATE_CODE;

	/**
	 * Drop all the tokens when a user is deleting.
	 * */
	public function plxAdminEditUsersUpdate() {
		echo str_replace('##CLASS##', __CLASS__, self::PLX_ADMIN_EDITUSERS_UPDATE_CODE);
	}

	/**
	 * Add a background-image. the path for the image depends of the location of the plugin.
	 * */
	public function AdminTopEndHead() {
		$url = PLX_PLUGINS. __CLASS__ . '/img/fido-u2f.png';
		echo <<< STYLE
		<style>
			#form_profil label[for="id_u2f-enabled"],
			#form_user label[for="id_u2f-enabled"] { padding-left: 70px; background: url('$url') left top no-repeat; }
		</style>\n
STYLE;
	}

	const ADMIN_USER_TOP_CODE = <<< 'ADMIN_USER_TOP_CODE'
<?php
if($plxAdmin->plxPlugins->aPlugins['##CLASS##']->userEnabled($id)) {
	ob_start();
}
?>
ADMIN_USER_TOP_CODE;

	/**
	 * Starts the bufferisation for output.
	 * */
	public function AdminUserTop() {
		echo str_replace('##CLASS##', __CLASS__, self::ADMIN_USER_TOP_CODE);
	}

	/**
	 * Add a control for disabling U2F for a user.
	 * */
	public function AdminUser() {
		if(!empty($this->adminUser)) {
			ob_start();
?>
		<div class="grid">
			<div class="col sml-12 med-5 label-centered">
				<label for="id_<?php echo self::FIELDNAME; ?>"><?php self::lang('U2F_ENABLE'); ?>&nbsp;:</label>
			</div>
			<div class="col sml-12 med-7">
<?php
		plxUtils::printSelect(
			self::FIELDNAME,
			array('1'=>L_YES,'0'=>L_NO),
			'1'
		);
?>
			</div>
		</div>
<?php
			$dialog = ob_get_clean();
			$code = <<< 'CODE'
<?php
$dialog = <<< DIALOG
##DIALOG##
DIALOG;
echo preg_replace('@(\s*</fieldset>.*)@s', "$dialog$1", ob_get_clean());
?>
CODE;
			echo str_replace('##DIALOG##', $dialog, $code);
		}
	}

	const PLXADMIN_EDIT_USER_CODE = <<< 'PLXADMIN_EDIT_USER_CODE'
<?php
if($content['##FIELDNAME##'] === '0') {
	$this->plxPlugins->aPlugins['##CLASS##']->disableUser($content['id']);
}
?>
PLXADMIN_EDIT_USER_CODE;

	/**
	 * Disable U2F for the user.
	 * */
	public function plxAdminEditUser() {
		$replaces = array(
			'##FIELDNAME##'	=> self::FIELDNAME,
			'##CLASS##'		=> __CLASS__
		);
		echo str_replace(array_keys($replaces), array_values($replaces), self::PLXADMIN_EDIT_USER_CODE);
	}

}
?>

<?php
require_once('./vendor/autoload.php');

const IP_LIST = <<< IP_LIST
37.115.205.45
146.185.223.154
146.185.223.166
146.185.223.177
146.185.223.147
146.185.223.132
185.38.250.76
146.185.223.163
146.185.223.123
8.8.8.8 Who is ?
146.185.223.132
198.11.132.250
41.202.129.195
5.194.254.153
103.26.42.16
158.69.197.22 The White House
202.36.253.12
200.68.105.160
177.223.193.203
37.115.205.45
185.38.250.76
185.194.141.58
82.112.93.25 Reykjavík City Museum
217.70.184.38
213.186.33.4
185.98.131.142
IP_LIST;

const DATABASE_PATH ='vendor/ip2location/ip2location-php/databases/';
const DATABASE_PREFIX = 'IP2LOCATION-';

$databases = array_map(
	function($item) {
		return str_replace(DATABASE_PATH.DATABASE_PREFIX, '', $item);
	},
	glob(DATABASE_PATH.DATABASE_PREFIX.'*.{bin,BIN}', GLOB_BRACE)
);
sort($databases, SORT_NATURAL);

$dbName = (!empty($_GET['db']) and in_array($_GET['db'], $databases)) ? $_GET['db'] : $databases[count($databases) - 1];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Ip2Location test</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<style type="text/css">
		form + div { overflow-x: auto; }
		table { border-collapse: collapse; margin-top: 0.3rem; }
		tr:not(:first-of-type):nth-of-type(even) { background-color: #f8f8f8; }
		tr:not(:first-of-type):hover { background-color: #444; color: #fff; }
		th { color: firebrick; }
		td { padding: 0.15rem 0.3rem; white-space: nowrap; margin: 0; }
		th:not(:first-of-type), td:not(:first-of-type) { border-left: 1px solid #555; }
		td:first-of-type,
		table.DB11 td:nth-of-type(8) { text-align: right; }
		td:nth-of-type(2),
		table.DB1 td:nth-of-type(5),
		table.DB3 td:nth-of-type(5),
		table.DB5 td:nth-of-type(7),
		table.DB11 td:nth-of-type(7) { text-align: center; }
		p:last-of-type strong a { color: firebrick; padding: 0 0.5rem; font-family: sans-serif; }
		p:last-of-type strong a:hover { background-color: green; color: #fff; text-decoration: none; }
	</style>
</head>
<body>
	<form method="get">
		<label>Database</label>
		<select name="db">
<?php
	foreach($databases as $db) {
		$sizeNum = filesize(DATABASE_PATH.DATABASE_PREFIX.$db);
		$sizeNum /= 1024 * 1024;
		echo "<!-- $sizeNum -->\n";
		$caption = ucfirst(substr($db, 0, -4)).sprintf(' (%0.1f Mo)', $sizeNum);
		$selected = ($db == $dbName) ? ' selected' : '';
		echo <<< OPTION
			<option value="$db"$selected>$caption</option>\n
OPTION;
	}
?>
		</select>
		<input type="submit" />
	</form>
	<div>
<?php
if(preg_match_all('@([1-9]\d{0,2}(?:\.[1-9]\d{0,2}){3})@', IP_LIST, $matches) !== false) {
	$filename = DATABASE_PATH.DATABASE_PREFIX.$dbName;
	$fields = array( # LITE-DB1.BIN
		\IP2Location\Database::IP_NUMBER,
		\IP2Location\Database::IP_VERSION,
		\IP2Location\Database::IP_ADDRESS,
		\IP2Location\Database::COUNTRY
	);
	switch($dbName) {
		case 'LITE-DB11.BIN' :
			$fields[] = \IP2Location\Database::TIME_ZONE;
			$fields[] = \IP2Location\Database::ZIP_CODE;
		case 'LITE-DB5.BIN' :
			$fields[] = \IP2Location\Database::COORDINATES;
		case 'LITE-DB3.BIN' :
			$fields[] = \IP2Location\Database::CITY_NAME;
			$fields[] = \IP2Location\Database::REGION_NAME;
	}
	$db = new \IP2Location\Database($filename, \IP2Location\Database::FILE_IO, $fields);

?>
		<table class="<?php echo preg_replace('@^.*(DB\d+).*$@', '$1', $dbName); ?>"><tr>
<?php
	$titleCols = true;
	foreach($matches[1] as $ipAddr) {
		$records = $db->lookup($ipAddr);
		if($titleCols) {
			foreach($records as $field=>$value) {
				echo <<< CELL
			<th>$field</th>\n
CELL;
			}
			$titleCols = false;
		}
		echo <<< SEP
		</tr><tr>\n
SEP;
		foreach($records as $field=>$value) {
			echo <<< CELL
			<td>$value</td>\n
CELL;
		}
	}
?>
		</tr></table>
<?php
}
?>
	</div>
	<p><a href="https://lite.ip2location.com/" rel="noreferrer nofollows" target="_blank"><img src="ip2location_logo.png" alt="https://lite.ip2location.com/"></a></p>
	<p>If you like this page, don't miss <strong><a href="https://kazimentou.fr/pluxml-plugins2/" target="_blank">this famous repository</a></strong> to find the finest addons for <a href="http://pluxml.org" target="_blank">PluXml</a></p>
</body>
</html>
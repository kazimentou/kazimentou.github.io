<?php
if(!defined('PLX_ROOT')) { exit('What did you expect ?'); }

require 'vendor/autoload.php';

/*
 * Base de données libre:
 * https://www.ip2location.com/developers/php
 * https://www.ip2location.com/tutorials
 * */
class kzIp2location extends plxPlugin {

	const COMMENTS_SELECTOR = '#comments-table:not(.flag) td.ip-address[data-ip]';

	const DATABASE = 'DB5';
	const DATABASE_FILENAME = '/vendor/ip2location/ip2location-php/databases/IP2LOCATION-LITE-'.self::DATABASE.'.BIN';

	# const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE + JSON_PRETTY_PRINT;
	const JSON_OPTIONS = JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE;

	public function __construct($default_lang) {
		parent::__construct($default_lang);

		if(!function_exists('geoip_country_code_by_name')) {
			parent::addHook('AdminCommentsFoot', 'AdminCommentsFoot');
		}
	}

	private function print_license() {
		$title = 'This site or product includes\nIP2Location LITE data available\nfrom https://lite.ip2location.com';
		$src = PLX_PLUGINS.__CLASS__.'/icon.jpg';
		echo <<< EOT
		const container = document.querySelector('#form_comments div.action-bar');
		if(container != null) {
			const div = document.createElement('DIV');
			div.className = 'ip2location-logo';
			div.innerHTML = '<a href="https://lite.ip2location.com/" rel="noreferrer" target="_blank"><img src="{$src}" alt="Ip2location" title="{$title}" /></a>';
			container.appendChild(div);
		}
EOT;
	}

	public function add_IP($ip) {
		if(empty($this->IP_list)) {
			$this->IP_list = array(
				$ip	=> false
			);
		} elseif(!array_key_exists($ip, $this->IP_list)) {
			$this->IP_list[$ip] = false;
		}
	}

	/**
	 * Extrait les infos de géo-localisation de la base de données pour
	 * les adresses IP collectées dans les commentaires.
	 * */
	private function __getGeoIP() {
		$fields = array(
			\IP2Location\Database::COUNTRY,
			\IP2Location\Database::IP_ADDRESS
		);
		switch(SELF::DATABASE) {
			case 'DB11':
				$fields = array_merge($fields, array(
					\IP2Location\Database::ZIP_CODE,
					\IP2Location\Database::TIME_ZONE,
					\IP2Location\Database::COORDINATES,
					\IP2Location\Database::REGION_NAME,
					\IP2Location\Database::CITY_NAME
				));
				break;
			case 'DB5':
				$fields = array_merge($fields, array(
					\IP2Location\Database::COORDINATES,
					\IP2Location\Database::REGION_NAME,
					\IP2Location\Database::CITY_NAME
				));
				break;
			case 'DB3':
				$fields = array_merge($fields, array(
					\IP2Location\Database::REGION_NAME,
					\IP2Location\Database::CITY_NAME
				));
		}
		$db = new \IP2Location\Database(
			__DIR__.self::DATABASE_FILENAME,
			\IP2Location\Database::FILE_IO,
			$fields
		);
		foreach(array_keys($this->IP_list) as $ip) {
			$this->IP_list[$ip] = $db->lookup($ip);
		}
	}

	public function set_flags($cssSelector) {
		if(empty($this->IP_list)) { return; }

		self::__getGeoIP();
?>
<script type="text/javascript">
	(function() {
		const cells = document.body.querySelectorAll('<?php echo $cssSelector; ?>');

		if(cells.length > 0) {
			const ipList = JSON.parse('<?php echo json_encode($this->IP_list, SELF::JSON_OPTIONS); ?>');

			function printFlags() {
				if(ipList != null) {
					for(var i=0, iMax=cells.length; i<iMax; i++) {
						const cell = cells[i];
						const ip = cell.getAttribute('data-ip');

						if(typeof ipList[ip] != 'undefined') {
							// Interface avec les enregistrements de IP2location
							const iso_code = ipList[ip].countryCode;
							const caption = (typeof ipList[ip].cityName !== 'undefined') ? [ipList[ip].cityName, ipList[ip].countryName].join('<br />') : ipList[ip].countryName;

							const flag = document.createElement('IMG');
							flag.src = '<?php echo PLX_FLAGS_32_PATH; ?>' + iso_code + '.png';
							flag.className = 'flag';
							flag.alt = iso_code;
							flag.title = caption;
							cell.appendChild(document.createElement('BR'));
							cell.appendChild(flag);
							const span = document.createElement('SPAN');
							span.innerHTML = caption;
							cell.appendChild(document.createElement('BR'));
							cell.appendChild(span);
						}
					}
				}
			}

			printFlags();
<?php self::print_license(); ?>
		}
	})();
</script>
<?php
	}

	/* --------- Hooks ------------- */
	public function AdminCommentsFoot() {
		$code = <<< 'CODE'
<?php
foreach($plxAdmin->plxRecord_coms->result as $com) {
	$plxAdmin->plxPlugins->aPlugins['##CLASS##']->add_IP($com['ip']);
}
$plxAdmin->plxPlugins->aPlugins['##CLASS##']->set_flags('##CSS_SELECTOR##');
?>

CODE;
		$replaces = array(
			'##CLASS##'	=> __CLASS__,
			'##CSS_SELECTOR##'	=> self::COMMENTS_SELECTOR
		);
		echo str_replace(array_keys($replaces), array_values($replaces), $code);
	}

}
?>
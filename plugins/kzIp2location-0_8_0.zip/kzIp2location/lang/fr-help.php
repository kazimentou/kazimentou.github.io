<?php
?>
<p><a href="https://www.ip2location.com/developers/php" rel="noreferrer,nofollow" target="_blank">Voir documentation pour développeurs</a></p>

<h3>Comparaison des différentes bases de géolocalisation indexées avec une adresse IP</h3>
<div class="scrollable-table">
<table class="ip2location-databases">
	<thead>
	<tr>
		<td>&nbsp;</td>
		<td>pays</td>
		<td>Région/Ville</td>
		<td>latitude/longitude</td>
		<td>Code postal</td>
		<td>F.A.I.</td>
		<td>domaine</td>
		<td>Fuseau horaire</td>
		<td>net-speed</td>
		<td>Id. zone</td>
		<td>Météo</td>
		<td>Opérateur tél. mobile</td>
		<td>Altitude</td>
		<td>usage-type</td>
		<td>&nbsp;</td>
	</tr>
	</thead>
	<tbody>
<?php
	$features = array(
		array('1',	'✔✘✘✘✘✘✘✘✘✘✘✘✘', 'country'),
		array('2',	'✔✘✘✘✔✘✘✘✘✘✘✘✘', 'country-isp'),
		array('3',	'✔✔✘✘✘✘✘✘✘✘✘✘✘', 'country-region-city'),
		array('4',	'✔✔✘✘✔✘✘✘✘✘✘✘✘', 'country-region-city-isp'),
		array('5',	'✔✔✔✘✘✘✘✘✘✘✘✘✘', 'country-region-city-latitude-longitude'),
		array('6',	'✔✔✔✘✔✘✘✘✘✘✘✘✘', 'country-region-city-latitude-longitude-isp'),
		array('7',	'✔✔✘✘✔✔✘✘✘✘✘✘✘', 'country-region-city-isp-domain'),
		array('8',	'✔✔✔✘✔✔✘✘✘✘✘✘✘', 'country-region-city-latitude-longitude-isp-domain'),
		array('9',	'✔✔✔✔✘✘✘✘✘✘✘✘✘', 'country-region-city-latitude-longitude-zipcode'),
		array('10',	'✔✔✔✔✔✔✘✘✘✘✘✘✘', 'country-region-city-latitude-longitude-zipcode-isp-domain'),
		array('11',	'✔✔✔✔✘✘✔✘✘✘✘✘✘', 'country-region-city-latitude-longitude-zipcode-timezone'),
		array('12',	'✔✔✔✔✔✔✔✘✘✘✘✘✘', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain'),
		array('13',	'✔✔✔✘✘✘✔✔✘✘✘✘✘', 'country-region-city-latitude-longitude-timezone-netspeed'),
		array('14',	'✔✔✔✔✔✔✔✔✘✘✘✘✘', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain-netspeed'),
		array('15',	'✔✔✔✔✘✘✔✘✔✘✘✘✘', 'country-region-city-latitude-longitude-zipcode-timezone-areacode'),
		array('16',	'✔✔✔✔✔✔✔✔✔✘✘✘✘', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain-netspeed-areacode'),
		array('17',	'✔✔✔✘✘✘✔✔✘✔✘✘✘', 'country-region-city-latitude-longitude-timezone-netspeed-weather'),
		array('18',	'✔✔✔✔✔✔✔✔✔✔✘✘✘', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain-netspeed-areacode-weather'),
		array('19',	'✔✔✔✘✔✔✘✘✘✘✔✘✘', 'country-region-city-latitude-longitude-isp-domain-mobile'),
		array('20',	'✔✔✔✔✔✔✔✔✔✔✔✘✘', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain-netspeed-areacode-weather-mobile'),
		array('21',	'✔✔✔✔✘✘✔✘✔✘✘✔✘', 'country-region-city-latitude-longitude-zipcode-timezone-areacode-elevation'),
		array('22',	'✔✔✔✔✔✔✔✔✔✔✔✔✘', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain-netspeed-areacode-weather-mobile-elevation'),
		array('23',	'✔✔✔✘✔✔✘✘✘✘✔✘✔', 'country-region-city-latitude-longitude-isp-domain-mobile-usagetype'),
		array('24',	'✔✔✔✔✔✔✔✔✔✔✔✔✔', 'country-region-city-latitude-longitude-zipcode-timezone-isp-domain-netspeed-areacode-weather-mobile-elevation-usagetype'),
	);
	foreach($features as $row) {
		list($n, $checkboxes, $caption) = $row;
		$lastCell = str_replace('-', ', ', $caption);
		echo <<< ROW_START
		<tr>
			<td><a href="https:/www.ip2location.com/databases/db{$n}-ip-{$caption}" rel="noreferrer,nofollow" target="_blank">DB{$n}</a></td>\n
ROW_START;
		foreach(preg_split("//u", $checkboxes, -1, PREG_SPLIT_NO_EMPTY) as $cell) {
			$class = ($cell == '✔') ? ' class="check"' : '';
			echo <<< CELL
			<td{$class}>{$cell}</td>
CELL;
		}
		echo <<< ROW_END
			<td>{$lastCell}</td>
		</tr>
ROW_END;
	}
?>
	</tbody>
	</table>
</div>
	<h3>Base de données libres (<em>nécessite une inscription gratuite</em>)</h3>
	<ul class="kz-ip2location">
<?php
		$databases = array(
			'1'		=> 'pays',
			'3'		=> 'pays, région et ville',
			'5'		=> 'pays, région et ville, latitude et longitude',
			'9'		=> 'pays, région et ville, latitude et longitude, code postal',
			'11'	=> 'pays, région et ville, latitude et longitude, code postal, fuseau horaire'
		);
		$docs =array(
			'1'		=> 'country',
			'3'		=> 'country-region-city',
			'5'		=> 'country-region-city-latitude-longitude',
			'9'		=> 'country-region-city-latitude-longitude-zipcode',
			'11'	=> 'country-region-city-latitude-longitude-zipcode-timezone'
		);
		$url = 'https://lite.ip2location.com';
		foreach($databases as $n=>$caption) {
			echo <<< LI
		<li>
			<a href="{$url}/database/ip-{$docs[$n]}" rel="noreferrer,nofollow" target="_blank">DB{$n}</a>
			<a href="{$url}/download?db=db{$n}&type=csv" rel="noreferrer,nofollow" target="_blank">(CSV format)</a>
			<a href="{$url}/download?db=db{$n}&type=bin" rel="noreferrer,nofollow" target="_blank">(BIN format)</a>
			<em>( {$caption} )</em>
		</li>\n
LI;
		}
?>
	</ul>
	<div>
		Télécharger l'archive de la base de données en cliquant sur un des liens ci-dessus au format binaire.
		Déplier l'archive dans le dossier "vendor/ip2location/ip2location.php/databases/".
		Ajuster la constante de class kzIp2location::DATABASE (DB5 par défaut).
	</div>
	<div class="in-action-bar ip2location-logo">
		<a href="https://lite.ip2location.com/" rel="noreferrer,nofollow" target="_blank">
			<img src="<?php echo PLX_PLUGINS.$page; ?>/icon.jpg" title="ip2location" />
		</a>
	</div>
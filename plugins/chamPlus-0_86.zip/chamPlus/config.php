<?php 

if(!defined('PLX_ROOT')) exit;

if(!empty($_POST)) {
	# Control du token du formulaire
	plxToken::validateFormToken($_POST);
	
	$keys = array_filter(
		array_keys($_POST),
		function($k) { return (strpos($k, 'name') === 0); }
	);

	if (count($keys) > 0) {
		foreach ($keys as $key) {
			$n = substr($key, strlen('name'));
			$name = trim($_POST['name'.$n]);
			if (strlen($name) > 0) {
				foreach ($plxPlugin->paramsNames as $paramName) {
					$idx = $paramName.$n;
					if ($paramName == 'textarea') {
						$value = intval($_POST[$idx]);
						$plxPlugin->setParam($idx, $value, 'numeric');
					}
					if ($plxPlugin->isBoolean($paramName)) {
						$value = (isset($_POST[$idx])) ? 1 : 0;
						$plxPlugin->setParam($idx, $value, 'numeric');
					}
					else {
						$value = (isset($_POST[$idx])) ? plxUtils::strCheck($_POST[$idx]) : '';
						if ($paramName == 'name')
							$value = preg_replace('#[\s-]+#', '#_#', $value);
						$plxPlugin->setParam($idx, $value, 'string');
					}
				}
			} else {
				foreach ($plxPlugin->paramsNames as $name)
					$plxPlugin->delParam($name.$n);
			}
		}
		foreach ($plxPlugin->options as $k) {
			$value = (isset($_POST[$k])) ? 1 : 0;
			$plxPlugin->setParam($k, $value, 'numeric');
		}
		$plxPlugin->saveParams();
	}
}

// remake of plxUtils::printInput
function strInput($name, $value, $placeHolder='', $type="text") {
	$end = '';
	switch ($type) {
		case 'text':
			if (strlen($placeHolder) > 0)
				$end = ' placeholder="'.$placeHolder.'"';
			break;
		case 'checkbox':
			if (strlen($placeHolder) > 0)
				$end = ' title="'.$placeHolder.'"';
			else
				$end = '';
			if (! empty($value) or intval($value) > 0)
				$end .= ' checked';
			break;			
	}
	return <<< RETURN
<input name="$name" value="$value" type="$type"$end />
RETURN;
}

function selectInput($name, $value) {
	global $plxPlugin;

	$result = <<< EOT
<select id="id_$name" name="$name">

EOT;
	foreach ($plxPlugin->fieldTypes as $val1=>$title) {
		$selected = ($value == $val1) ? ' selected' : '';
		$result .= <<< EOL
	<option value="$val1"$selected>$title</option>
EOL;
	}
	$result .= <<< EOT
</select>

EOT;
	return $result;
}

?>
<script type="text/javascript">
<!--
function addField(query) {
	var lastRow = document.querySelector(query);
	if (lastRow) {
		var newRow = document.createElement('tr');
		newRow.innerHTML = lastRow.innerHTML; 
		var parent = lastRow.parentNode;
		parent.appendChild(newRow);
		var inputs = newRow.querySelectorAll('td input, td select');
		for (i=0; i<inputs.length; i++) {
			var node = inputs.item(i);
			if (node.checked)
				node.checked = false;
			else if (node.value)
				node.value = '';
			var name = node.getAttribute('name');
			name = name.replace(/(\d+)$/,
				function(str, p1) {
					return (parseInt(p1) + 1);
				}
			);
			node.setAttribute('name', name);
		}
		return true;
	} else {
		console.log('unable to find "' + query + '" element');
		return false;
	}
}

function valid(idForm) {
	var emptyName = false;
	var badName = false;
	// check for not empty input in the first column, except for the last row
	var elements = document.querySelectorAll(idForm + ' tbody tr:not(:last-of-type) td:first-of-type input');
	for (i=0; i<elements.length; i++) {
		var node = elements.item(i);
		var value = node.value;
		if (value.trim() == '') {
			emptyName = true;
		} else if (! /^[a-z][a-z\d]{1,32}$/.test(value)) {
			// check if the value of name is right
			alert('<?php $plxPlugin->lang('L_CHAMPLUS_BADNAME'); ?>');
			badName = true;
			break;			
		}
	}
	return result = ! badName && (! emptyName || confirm('<?php $plxPlugin->lang('L_CHAMPLUS_CONFIRM_CANCEL'); ?>'));
}

function help_me(value) {
	var chk = document.getElementById('<?php echo $plugin; ?>_nav');
	if (chk)
		chk.checked = value;
	else
		console.log('Element with id champlus_nav not found.');
}
// -->
</script>
	<h2><?php echo $plxPlugin->getInfo('title'); ?></h2>
	<p><?php echo $plxPlugin->getInfo('description'); ?></p>
	<form id="form_<?php echo $plugin; ?>" method="post" onsubmit="return valid('<?php echo "#form_$plugin"; ?>');">
		<?php echo plxToken::getTokenPostMethod() ?>
		<fieldset>
		<table>
			<thead>
				<tr>
<?php	foreach ($plxPlugin->paramsNames as $name) { ?>
				<th><?php $plxPlugin->lang(strtoupper('L_CHAMPLUS_TITLE_'.$name)); ?></th>
<?php	} ?>
				</tr>
			</thead>
			<tbody>
<?php
	$iMax = 0;
	foreach ($plxPlugin->indices() as $i) { ?>
				<tr>
<?php
		foreach ($plxPlugin->paramsNames as $name) {
			$value = $plxPlugin->getParam($name.$i);
			$inputValue = plxUtils::strCheck($value);
			if ($name == 'textarea') { ?>
				<td><?php echo selectInput($name.$i, $value); ?></td>
<?php				
			} else if ($plxPlugin->isBoolean($name)) { ?>
					<td><?php echo strInput($name.$i, $inputValue, $plxPlugin->getLang(strtoupper('L_CHAMPLUS_'.$name)), 'checkbox'); ?></td>
<?php		}
			else { ?>
					<td><?php echo strInput($name.$i, $inputValue, $plxPlugin->getLang(strtoupper('L_CHAMPLUS_'.$name))); ?></td>
<?php		}
		} ?>
				</tr>
<?php
	if ($iMax < $i)
		$iMax = $i;
	} ?>
				<tr>
<?php	
		// nouveau champ
		$i = $iMax + 1;
		foreach ($plxPlugin->paramsNames as $name) {
			$value = '';
			if ($name == 'textarea') { ?>
				<td><?php echo selectInput($name.$i, $value); ?></td>
<?php				
			} else if ($plxPlugin->isBoolean($name)) { ?>
					<td><?php echo strInput($name.$i, 0, $plxPlugin->getLang(strtoupper('L_CHAMPLUS_NEW_'.$name)), 'checkbox'); ?></td>
<?php		}
			else {
				$inputValue = plxUtils::strCheck($value); ?>
					<td><?php echo strInput($name.$i, '', $plxPlugin->getLang(strtoupper('L_CHAMPLUS_NEW_'.$name))); ?></td>
<?php		}
		} ?>
				</tr>
			</tbody>
		</table>
		<div>
<?php
		foreach($plxPlugin->options as $k) {
			$checked = ($plxPlugin->getParam($k) > 0) ? ' checked' : ''; ?>
			<p>
				<input type="checkbox" value="1" name="<?php echo $k; ?>" id="id_<?php echo $k; ?>"<?php echo $checked; ?> />
				<label for="id_<?php echo $k; ?>"><?php $plxPlugin->lang(strtoupper('L_CHAMPLUS_'.$k)); ?></label>
			</p>
<?php	} ?>
		</div>
		</fieldset>
		<p>
			<input type="button" value="<?php $plxPlugin->lang('L_CHAMPLUS_HELP_LABEL') ?>" onclick="help_me(true);" />
			<input type="button" value="<?php $plxPlugin->lang('L_CHAMPLUS_ADD') ?>" onclick="addField('#form_<?php echo $plugin; ?> tbody tr:last-of-type');" />
			<input type="submit" value="<?php $plxPlugin->lang('L_CHAMPLUS_SAVE') ?>" /></p>
	</form>
	<p><?php $plxPlugin->lang('L_CHAMPLUS_WARNING'); ?></p>
	<input type="checkbox" id="<?php echo $plugin; ?>_nav" style="display: none;" />
	<div>
		<?php $plxPlugin->lang('L_CHAMPLUS_HELP'); ?>
	</div>

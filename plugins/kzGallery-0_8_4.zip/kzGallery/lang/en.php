<?php
$LANG = array(
	'ARTICLE_GALLERY_FOLDER'	=> 'Folder of pictures for the gallery',
	'LIGHTBOX2_CONFIG'			=> 'Using Lightbox2',
	'LINK_CONFIG'				=> 'Link to the pictures in real size',
	'TITLE_CONFIG'				=> 'Adding the title',
	'THUMBNAIL_CONFIG'			=> 'Required thumbnails',
	'ART_HINT'					=> 'Otherwise, insert : &#34;&lt;div data-gallery="mon-voyage/photos/"&gt;souvenirs&lt;/div&gt;&#34; inside the HTML code',
	'PASTE'						=> 'Paste',
	'COPY'						=> 'Copy',
	'GALLERY_NAME'				=> '#FOLDER# gallery',
	'COPY_BTN_TITLE'			=> 'Copy the HTML snippet for the gallery of pictures'
);
?>

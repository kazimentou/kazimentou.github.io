<?php
if (!defined('PLX_ROOT')) exit;

if (!empty($_POST)) {
	foreach ($plxPlugin->fields as $field=>$type) {
		switch ($type) {
			case 'numeric' :
				$value = intval($_POST[$field]);
				if ($value == 0 && array_key_exists($field, $plxPlugin->default_values))
					$value = intval($plxPlugin->default_values[$field]);
				break;
			case 'boolean' :
				$value = (!empty($_POST[$field])) ? 1 : 0;
				break;
			default :
				$value = $_POST[$field];
				if (empty($value) && array_key_exists($field, $plxPlugin->default_values))
					$value = $plxPlugin->default_values[$field];
				break;
		}
		$plxPlugin->setParam($field, $value, ($type == 'boolean') ? 'numeric' : $type);
	}
	$plxPlugin->saveParams();
}

$folder = PLX_PLUGINS.$plugin.'/styles/';

$items = array();
$files = glob($folder.'*');
if (!empty($files)) {
	foreach ($files as $file1) {
		if (is_dir($file1)) {
			$value = substr(strrchr($file1, '/'), 1);
			$items[$value] = ucfirst($value);
		}
	}
}
else { // Glob() ne marche pas chez certains hébergeurs comme Free.fr
	echo "<!--  Glob doesn't work! DirectoryIterator is using -->\n";
	$dir = new DirectoryIterator($folder.'.');
	foreach ($dir as $fileinfo) {
		if ($fileinfo->isDir() && !$fileinfo->isDot()) {
			$filename = $fileinfo->getFilename();
			$items[$filename] = ucfirst($filename);
		}
	}
	asort($items);
}
$transitions = array('elastic'=>'Elastic', 'fade'=>'Fade', 'none'=>'None');
$flickr_sizes = array(
	's'=>'75x75',	// small square 75x75
	'q'=>'150x150',	// large square 150x150
	't'=>'100',		// thumbnail, 100 on longest side
	'm'=>'240',		// small, 240 on longest side
	'n'=>'320',		// small, 320 on longest side
	'-'=>'500',		// medium, 500 on longest side
	'z'=>'640',		// medium 640, 640 on longest side
	'c'=>'800',		// medium 800, 800 on longest side†
	'b'=>'1024',	// large, 1024 on longest side*
	'h'=>'1600',	// large 1600, 1600 on longest side†
	'k'=>'2048',	// large 2048, 2048 on longest side†
	'o'=>'original'	// original image, either a jpg, gif or png, depending on source format
);
?>
		<script type="text/javascript">
			function demoStyles() {
				return styleClick('id_style', '<?php echo $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].$plugin; ?>/styles/');
			}
		</script>
		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<form id="form_<?php echo $plxPlugin->getInfo('title'); ?>" method="post" onsubmit="return colorBoxOnSubmit(this);">
			<div>
			<div>
<?php
define('TAB1', "\t\t\t\t");
define('MASK1', strtoupper($plugin));

$n1 = 28;
$n2 = 12;
foreach ($plxPlugin->fields as $field=>$type) {
	if ($n1 >= 0) $n1--;
	if ($n1 == $n2) { ?>
			</div><div>
<?php
	}
	$value = $plxPlugin->getParam($field);
	if (!empty($value))
		$value = plxUtils::strCheck($value);
	else
		$value = (array_key_exists($field, $plxPlugin->default_values)) ? $plxPlugin->default_values[$field] : '';
	if ($field == 'responsive_design')
		$asterisk = ' <sup>**</sup>';
	else
		$asterisk = (in_array($field, array(
			'width', 'height', 'innerWidth', 'innerHeight',
			'initialWidth', 'initialHeight', 'maxWidth', 'maxHeight',
			'top', 'bottom', 'left', 'right'
			))) ? ' <sup>*</sup>' : '';
?>
				<p>
					<label for="id_<?php echo $field; ?>" title="<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.MASK1.'_'.strtoupper($field)); echo $asterisk; ?></label>
<?php
		switch ($type) {
			case 'boolean' :
				$checked = ($value) ? ' checked' : '';
?>
					<input type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php
				break;
			case 'numeric' :
				echo TAB1;
				plxUtils::printInput($field, $value, 'text', '3-4', false, "num");
				if (in_array($field, array('speed', 'fadeOut', 'slideshowSpeed')))
					echo 'ms';
				break;
			default :
				switch ($field) {
					case 'style' :
						plxUtils::printSelect($field, $items, $value);
						break;
					case 'transition' :
						plxUtils::printSelect($field, $transitions, $value);
						break;
					case 'flickr_size' :
					case 'flickr_thumbnail' :
						plxUtils::printSelect($field, $flickr_sizes, $value);
						break;
					case 'flickr_user_id' :
						plxUtils::printInput($field, $value, 'text', '13-12');
						break;
					default :
						echo TAB1;
						$class1 = (empty($asterisk)) ? '' : 'px';
						plxUtils::printInput($field, $value, 'text', '5-10', false, $class1);
						break;
				}
				break;
		}
?>
				</p>
<?php
}
?>
			</div>
			</div>
			<div>
				<p>
					<sup>*</sup><?php $plxPlugin->lang('L_COLORBOX_ASTERISK1'); ?><br />
					<sup>**</sup><?php $plxPlugin->lang('L_COLORBOX_ASTERISK2'); ?><br />
					<a href="http://www.jacklmoore.com/colorbox/" target="_blank">Click here for more information.</a>
				</p><p>
					<input class="defaultValues" type="button" value="<?php echo $plxPlugin->lang('L_COLORBOX_DEFAULT_VALUES'); ?>" onclick="setDefaultsValues(this.form, defaultValues);" />
					<input type="reset" />
					<input type="submit" />
				</p>
			</div>
		</form>

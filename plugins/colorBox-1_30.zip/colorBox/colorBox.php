<?php

if (!defined('PLX_ROOT')) exit;

/*
 * Plugin pour Colorbox
 * http://www.jacklmoore.com/colorbox/
 *
 * */

if (! defined('JQUERY_LIB'))
	define('JQUERY_LIB', 'jquery-1.11.3.min.js');
if (! defined('JQUERY_SRC')) {
	define('JQUERY_SRC', '//code.jquery.com/'.JQUERY_LIB);
}

class colorBox extends plxPlugin {

	public $fields = array(
		'style'=>'string', 'transition'=>'string', 'responsive_design'=>'boolean', 'speed'=>'numeric', 'scalePhotos'=>'boolean', 'scrolling'=>'boolean',
		'opacity'=>'numeric', 'preloading'=>'boolean', 'loop'=>'boolean', 'fadeOut'=>'numeric', 'closeButton'=>'boolean',
		// Dimensions
		'width'=>'string', 'height'=>'string', 'innerWidth'=>'string', 'innerHeight'=>'string',
		'initialWidth'=>'string', 'initialHeight'=>'string', 'maxWidth'=>'string', 'maxHeight'=>'string',
		// Slideshow
		'slideshow'=>'boolean', 'slideshowSpeed'=>'numeric', 'slideshowAuto'=>'boolean',
		// Positioning
		'fixed'=>'boolean', 'top'=>'string', 'bottom'=>'string', 'left'=>'string', 'right'=>'string', 'reposition'=>'boolean',
		// Flickr
		'flickr_size'=>'string', 'flickr_thumbnail'=>'string'
		);

	public $default_values = array( // divide opacity by 1000 before sending to colorbox
		'responsive_design'=>1, 'transition'=>'elastic', 'speed'=>350, 'scalePhotos'=>1, 'scrolling'=>1,
		'opacity'=>900, 'preloading'=>1, 'loop'=>1, 'fadeOut'=>300, 'closeButton'=>1,
		'initialWidth'=>'300', 'initialHeight'=>'100',
		'slideshow'=>0, 'slideshowSpeed'=>2500, 'slideshowAuto'=>0,
		'flickr_size'=>'h', 'flickr_thumbnail'=>'t'
	);

	public  function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
		$this->addHook('flickrGalerie', 'flickrGalerie');
		$this->addHook('FeedEnd', 'FeedEnd');
	}

	private function pluginRoot() {
		global $plxShow;

		if (isset($plxShow)) {
			// adresse relative
			return $plxShow->plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			// adresse absolue
			global $plxAdmin;
			if (isset($plxAdmin)) {
				return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
			} else {
				return false;
			}
		}
	}

	private function setup($lang='en') {

		// We compile all options for colorBox
		$options = '';
		foreach ($this->fields as $field=>$type) {
			$value = $this->getParam($field); // getParam renvoie une chaine pour une valeur numérique !!!
			$typeNum = false;
			if (in_array($type, array('boolean', 'numeric'))) {
				$value = intval($value);
				$typeNum = true;
			}
			switch ($field) {
				case 'responsive_design' :
					break;
				case  'style' :
					if (empty($value)) $value = 'style1'; ?>
	<link href="<?php echo $this->pluginRoot().'styles/'.$value; ?>/colorbox.css" rel="stylesheet" type="text/css" media="screen" />
<?php
					break;
				case 'maxWidth' :
				case 'maxHeight' :
					if ($this->getParam('responsive_design') > 0)
						$value = '100%';
					if (! empty($value)) // by default $value is false
						$options .= "$field: '$value',\n";
					break;
				case 'opacity' :
					if ($value != $this->default_values['opacity'])
						$options .= 'opacity: '.round($value / 1000, 3).",\n";
					break;
				default :
					if (!empty($value) and
						(!array_key_exists($field, $this->default_values) || ($value != $this->default_values[$field])))
						$options .= $field.': '.(($typeNum) ? $value : "'$value'").",\n";
			}
		}
		// More infos about CDN here : http://encosia.com/3-reasons-why-you-should-let-google-host-jquery-for-you/
		// src'+'=" is a hack for abusing PluXml in plxUtils::rel2abs function
	if (! defined('JQUERY_LOADED')) {
?>
	<script type="text/javascript"> <!-- colorBox -->
		if (typeof jQuery === 'undefined')
			document.write('<scr'+'ipt type="text/javascript" src'+'="<?php echo JQUERY_SRC; ?>"></scr'+'ipt>');
	</script>
<?php
		define('JQUERY_LOADED', true);
	}
?>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>/jquery.colorbox-min.js"></script>
	<script type="text/javascript">
		<!--
<?php
echo file_get_contents(dirname(__FILE__).'/'.__CLASS__.'/i18n/jquery.colorbox-'.$lang.'.js');
?>
		jQuery.extend(jQuery.colorbox.settings, {
photo: true,
rel: 'lightbox',
<?php echo $options; ?>});

		$(document).ready(function() {
			// par défaut
			$("a[rel^='lightbox']").colorbox();

			var options = {};
			// medias de Pluxml dans article
			options.title = function() { var t = $(this).attr('title'); return (t) ? t : $(this).attr('alt'); };
			options.rel = 'lightbox-art*';
			options.href = function() { return $(this).attr('src').replace(/\.tb(\.\w+)$/i,'$1'); };
			$("article img[src$='\\.tb\\.jpg'], article img[src$='\\.tb\\.png'], article img[src$='\\.tb\\.gif'], article img[src$='\\.tb\\.jpeg']").colorbox(options);

			// themes/defaut/sidebar.php
			options.rel = 'lightbox-aside';
			options.href = function() { return $(this).attr('src').replace(/\.tb(\.\w+)$/i,'$1'); };
			$("aside img[src$='\\.tb\\.jpg'], aside img[src$='\\.tb\\.png'], aside img[src$='\\.tb\\.gif'], aside img[src$='\\.tb\\.jpeg']").colorbox(options);

			// pour core/admin/medias.php
			options.rel = 'lightbox-medias';
			options.href = function() { return $(this).attr('src').replace(/\/\.thumbs\//i, '/'); };
			$("img[src*='/\\.thumbs/']").colorbox(options);

			// Flickr
			// https://www.flickr.com/services/api/misc.urls.html
			options.rel = 'lightbox-flickr*';
			options.href = function() { return $(this).attr('src').replace(/\w(\.(?:jpg|jpeg|png|gif))$/i,'b$1'); };
			$("article img[src*='staticflickr']").colorbox(options);

			var resizeTimer;
			window.addEventListener(
				'orientationchange',
				function (event) {
					if (resizeTimer) clearTimeout(resizeTimer);
					resizeTimer = setTimeout(function() { $.colorbox.resize(); }, 300);
				});

		});
		// -->
	</script>
<?php	}

	public function AdminTopEndHead($params) {
		global $plxAdmin, $plugin;

		switch ($this->script_name) {
			case 'parametres_pluginhelp' :
				break;
			case 'medias' :
				$this->setup($plxAdmin->aConf['default_lang']); // add language
				break;
			case 'parametres_plugin' :
			if ($plugin == __CLASS__) {?>
	<script type="text/javascript">
		<!--
		var defaultValues = {
			<?php
		$buf = array();
		foreach ($this->default_values as $k=>$v) {
			if (array_key_exists($k, $this->fields)) {
				$type = $this->fields[$k];
				if ($type == 'boolean')
					$value = ($v > 0) ? 'true' : 'false';
				else
					$value = ($type == 'numeric') ? $v : "'$v'";
			}
			else
				$value = "'$v'";
			array_push($buf, $k.': '.$value);
		}
		echo implode(", \n\t\t\t", $buf)."\n";
?>
		}
		// -->
	</script>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>.js"></script>
<?php }
				break;
		}
	}

	public function ThemeEndHead($params) {
		global $plxShow;

		$this->setup($plxShow->plxMotor->aConf['default_lang']);?>
	<script type="text/javascript" src="<?php echo $this->pluginRoot().__CLASS__; ?>-flickr.js"></script>
<?php
	}

	public function ThemeEndBody($params) {
		global $plxShow, $output;

		// crée une galerie pour les images stockées par Pluxml
		if (preg_match('#(<(?:div|p)\s+[^>]*id="pl_gallery"[^>]*>)[^<]*</div>#', $output, $matches)) {
			if (preg_match('#data-src="([^"]+)"#', $matches[1], $match_src)) {
				$folder = $match_src[1];
				if (substr($folder, -1) != '/')
					$folder .= '/';
				$root = substr(dirname(__FILE__), 0, -strlen($plxShow->plxMotor->aConf['racine_plugins'].__CLASS__));
				$filesList = glob($root.$plxShow->plxMotor->aConf['medias'].$folder.'*.tb.{jpg,jpeg,png,gif}', GLOB_BRACE);
				$innerHTML = "\n";
				foreach ($filesList as $filename) {
					$src = substr($filename, strlen($_SERVER['DOCUMENT_ROOT']));
					$sizes = getimagesize($filename);
					$title = ucfirst(substr(pathinfo($filename, PATHINFO_FILENAME), 0, -3));
					$innerHTML .= <<< INNER_HTML
						<div><img src="$src" alt="image" {$sizes[3]} title="$title" /><p>$title</p></div>

INNER_HTML;
				}
				$output = str_replace($matches[0], $matches[1].$innerHTML.'</div>', $output);
			}
		}
		// Crée une galerie pour les images hébergées par Flickr
		 ?>
	<script type="text/javascript">
		var optionsFlickr = {imageSize: '<?php echo $this->getParam('flickr_size'); ?>', thumbnailSize: '<?php echo $this->getParam('flickr_thumbnail'); ?>'};
		flickGallery();
	</script>
<?php
	}

	public function FeedEnd() {
		global $plxFeed;

        // protect some HTML entities between tags (required by XML files)
        $code = "\$pats = ['&lt;', '&gt;', '&quot;'];\n";
        $code .= "\$reps = ['<<<<', '>>>>', '\"\"\"\"'];\n";

        $root = $plxFeed->racine;
        $host = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'];
        if (substr($root, 0, strlen($host)) != $host)
			$root = $host.$root;
        $_pattern1 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*\.)(tb\.)(jpg|png|gif)([^>]*))>>>>!';
        $_pattern2 = '!<<<<((img\s[^>]*src="""")('.$root.'[^"]*)(/\.thumbs)(/\w[^"]*\.)(jpg|png|gif)([^>]*))>>>>!';
        $_replace1 = '<<<<a href="\3\5">>>><<<<\1>>>><<<</a>>>>';
        $_replace2 = '<<<<a href="\3\5\6">>>><<<<\1>>>><<<</a>>>>';

        $code .= "\$patterns = [\n\t'$_pattern1',\n\t'$_pattern2'\n];\n";
        $code .= "\$replaces = ['$_replace1', '$_replace2'];\n";
        $code .= "\$tmp = str_replace(\$pats, \$reps, \$output);\n";
		$code .= "\$tmp = preg_replace(\$patterns, \$replaces, \$tmp);\n";
        // deprotect some HTML entities and output
        $code .= "\$output = str_replace(\$reps, \$pats, \$tmp);\n";

		echo "<?php $code ?>";
	}

}

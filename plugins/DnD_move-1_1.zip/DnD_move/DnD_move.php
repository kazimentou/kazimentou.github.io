<?php

if (!defined('PLX_ROOT')) exit;

/**
 * Ordonner les catégories, plugins, et pages statiques en glissant chaque rangée des tableaux à l'aide de la souris.
 * Pour PluXml version 5.5 - Fonctionnement non garanti pour PluXml 5.6
 * @author J.P. Pourrez alias bazooka07
 * @version 2017-06-18
 * */
class DnD_move extends plxPlugin {

	private $scriptJS = 'drag-and-drop.js';

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->setConfigProfil(PROFIL_ADMIN);

		# Accès au menu admin réservé au profil administrateur
		$this->setAdminProfil(PROFIL_ADMIN);

		# Ajouts des hooks
		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
		$this->addHook('AdminCategoriesFoot', 'AdminCategoriesFoot');
		$this->addHook('AdminSettingsPluginsFoot', 'AdminSettingsPluginsFoot');
		$this->addHook('AdminStaticsFoot', 'AdminStaticsFoot');
	}

	private function __printCleanUp() {
		$test = (defined('PLX_VERSION') and version_compare(PLX_VERSION, '5.6') == 0);
		echo ($test) ? 'true' : 'false';
	}

	public function AdminTopEndHead() {
		if(!is_readable(PLX_CORE.'lib/'.$this->scriptJS)) {
?>
	<script type="text/javascript" src="<?php echo PLX_PLUGINS.__CLASS__.'/'.$this->scriptJS; ?>"></script>
<?php
		}
	}

	public function AdminCategoriesFoot() {
?>
	<script type="text/javascript">
		dragAndDrop(
			'#categories-table tbody tr:not(.new)',
			'#categories-table tbody tr:not(.new) input[name$="_ordre"]',
			<?php $this->__printCleanUp(); ?>
		);
		document.getElementById('categories-table').classList.add('dnd-move');
	</script>
<?php
	}

	public function AdminSettingsPluginsFoot() {
		global $sel;

		if($sel == 1) {
?>
	<script type="text/javascript">
		dragAndDrop(
			'#plugins-table tbody tr',
			'#plugins-table tbody tr input[name^="plugOrdre"]'
		);
		document.getElementById('plugins-table').classList.add('dnd-move');
	</script>
<?php
		}
	}

	public function AdminStaticsFoot() {
?>
	<script type="text/javascript">
		dragAndDrop(
			'#statics-table tbody tr:not(:last-of-type)',
			'#statics-table tbody tr:not(:last-of-type) input[name$="_ordre"]',
			<?php $this->__printCleanUp(); ?>
		);
		document.getElementById('statics-table').classList.add('dnd-move');
	</script>
<?php
	}

}
?>
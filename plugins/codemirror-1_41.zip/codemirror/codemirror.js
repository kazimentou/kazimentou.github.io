/* **************** Pour l'administration du site ************************ */
window.addEventListener('keydown', function(event) {
    if (!event.altKey && !event.ctrlKey && !event.shiftKey && event.code == 'F1') {
        event.preventDefault();
        var elm = document.getElementById('cm-shortcuts_nav');
        if (elm) {
            elm.checked = !elm.checked;            
        }
    }
});

CodeMirror.commands.save = function(cm) {
	cm.save();
	var textArea = cm.getTextArea();
	var form1 = textArea.form;
	var submitBtn = form1.querySelector('input[type="submit"][name="update"]');
	if (! submitBtn) {
		submitBtn = form1.querySelector('input[type="submit"]');
	}
	if (submitBtn) {
		submitBtn.click();
	}
};

function demo_open(url) {

	var width = 800;
	var height = 500;
	var left = (screen.width-width)/2;
	var top = (screen.height-height)/2;
	var options =
		'height='+height+', width='+width+', top='+top+', left='+left+
		',menubar=no, location=no, titlebar=no, toolbar=no, resizable=no';

	var myWindow = window.open(url, '_blank', options);
	myWindow.unload = close;
	return false;
}

function activeEditor(aTheme, showLineNumbers, mode, i18n) {
	var options = {
		matchBrackets: true,
		mode: mode,
		indentUnit: 4,
		indentWithTabs: true,
		matchBrackets: true,
		autoCloseBrackets: true,
		autoCloseTags: true,
		lineWrapping: true,
		styleActiveLine: true,
		scrollbarStyle: null,
		extraKeys: {
			'F11': function(cm) {
				cm.setOption('fullScreen', !cm.getOption('fullScreen'));
                                var scrollbarStyle = (cm.getOption('fullScreen')) ? 'native' : null;
                                cm.setOption('scrollbarStyle', scrollbarStyle);
			},
			'Esc': function(cm) {
				if (cm.getOption('fullScreen')) cm.setOption('fullScreen', false);
			}
		},
		foldGutter: true,
	    gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
		enterMode: 'keep',
		tabMode: 'shift'}
	if (showLineNumbers)
		options['lineNumbers'] = true;
	if (aTheme.length > 0)
		options['theme'] = aTheme;

	var myTextareas = document.querySelectorAll('#id_content, #id_chapo, #id_frontend, #id_backend');
	var editors = {};
	for (i=0, iMax = myTextareas.length; i < iMax; i++) {
		var elmt = myTextareas[i];
		if (elmt.tagName == 'TEXTAREA') {
			var label = document.querySelector("label[for='"+elmt.id+"']")
			if (label) {
                                var follower = label.nextSibling;
                                var nav = document.getElementById('cm-shortcuts_nav');
                                if (nav) {
                                    var label1 = document.createElement('label');
                                    label1.setAttribute('for', 'cm-shortcuts_nav');
                                    label1.className = 'cm_fullscreen_msg';
                                    label1.innerHTML = i18n.help;
                                    label.parentNode.insertBefore(label1, follower);
                                    editors[i] = CodeMirror.fromTextArea(elmt, options);
                                }
			}
		}
	}
        var actionBar = document.querySelector('.section .action-bar');
        if (actionBar) {
            actionBar.style.zIndex = 20;
        }
}

/* ************** pour la partie publique site ******************************* */

function colorize(theme) {
	var collection = document.body.getElementsByTagName('textarea');
	for (var i = 0; i < collection.length; ++i) {
		var node = collection[i];
		var mode = node.getAttribute("data-lang");
		if (!mode) continue;
		var options = {
			matchBrackets: true,
			mode: mode,
			indentUnit: 4,
			indentWithTabs: true,
			matchBrackets: true,
			styleActiveLine: true,
			foldGutter: true,
		    gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
		    readOnly: true,
		    lineNumbers: true
		}
		if (theme && (theme.length > 0))
			options['theme'] = theme;
		var target = CodeMirror.fromTextArea(node, options);
	}
}
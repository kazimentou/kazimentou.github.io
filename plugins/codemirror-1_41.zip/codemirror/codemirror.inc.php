<?php
function codemirror_libs() {
	return array(
		'modes' => array('htmlmixed', 'xml', 'javascript', 'css', 'clike', 'php', 'markdown', 'python', 'shell'),
		'addons' => array(
			false=>array(
				'edit/matchbrackets', 'edit/matchtags', 'edit/closebrackets', 'edit/closetag', 'display/fullscreen',
				'fold/foldcode', 'fold/foldgutter', 'fold/xml-fold', 'fold/comment-fold', 'fold/markdown-fold',
				'dialog/dialog', 'selection/active-line', 'search/searchcursor', 'search/search',
				'hint/show-hint', 'hint/css-hint', 'hint/html-hint', 'hint/javascript-hint', 'hint/xml-hint'
				),
			true=>array(
				'edit/matchbrackets', 'edit/matchtags',
				'fold/foldcode', 'fold/foldgutter', 'fold/xml-fold', 'fold/comment-fold', 'fold/markdown-fold',
				'dialog/dialog', 'selection/active-line', 'search/searchcursor', 'search/search',
				'hint/show-hint', 'hint/css-hint', 'hint/html-hint', 'hint/javascript-hint', 'hint/xml-hint'
			)
		)
	);
}

define('URL_BASE', 'http://codemirror.net/');
# define('URL_BASE', 'https://raw.githubusercontent.com/codemirror/CodeMirror/5.12.0/');

function cm_mode_path($a) {
	return URL_BASE.'mode/'.$a.'/'.$a.'.js';
}

function cm_addon_path($a) {
	return URL_BASE.'addon/'.$a.'.js';
}

function cm_getFileslist() {
	$codemirror_libs = codemirror_libs();
	$temp1 = array(URL_BASE.'lib/codemirror.js');
	$modes = array_map('cm_mode_path', $codemirror_libs['modes']);
	$temp2 = $codemirror_libs['addons'][false] + $codemirror_libs['addons'][true];
	$addons = array_map('cm_addon_path', $temp2);
	$libs = array_merge($temp1, $modes, $addons);
	return $libs;
}

function print_cm_form_download($id=false) { ?>
	<form <?php echo ((!empty($id)) ? 'id="'.$id.'"' : ''); ?> method="post" action="http://marijnhaverbeke.nl/uglifyjs">
		<div>
			<input name="download" value="codemirror.min.js" />
<?php
	$fileslist = cm_getFileslist();
	foreach($fileslist as $lib) {
		echo <<< LINE
			<input name="code_url" value="{$lib}" />

LINE;
	} ?>
		</div>
		<p><input type="submit" /></p>
	</form>
<?php
}
?>
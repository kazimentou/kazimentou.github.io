<?php
if (!defined('PLX_ROOT'))
	exit;

/*
 * Plugin pour CodeMirror
 * http://codemirror.net/
 * */

define('CODEMIRROR_LIB', 'codemirror-5.12');
define('CODEMIRROR_LIB_MIN', 'codemirror.min.js');

class codemirror extends plxPlugin {

	private $script_name;
	private $modes;
	private $addons;

	public $params = array(
		'theme'=>'string', 'lineNumbers'=>'boolean', 'article'=>'boolean',
		'statique'=>'boolean', 'comment'=>'boolean', 'categorie'=>'boolean',
		'parametres_edittpl'=>'boolean', 'parametres_plugincss'=>'boolean',
		'show'=>'boolean', 'minify_js'=>'boolean'
	);
	public $params_default = array(
		'lineNumbers'=>1,
		'parametres_edittpl'=>1,
		'parametres_plugincss'=>1,
		'minify_js'=>1
	);

	public function __construct($default_lang) {
		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

        include(str_replace('.php', '.inc.php', __FILE__));
        $codemirror_libs = codemirror_libs();

        $this->modes = $codemirror_libs['modes'];
		$this->addons = $codemirror_libs['addons'];
		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->script_name = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');

		# hack against PHP 5.4
		$p = strpos($this->script_name, 'comment');

		if (in_array($this->script_name, array_keys($this->params)) or ($p === 0) or ($this->script_name == 'parametres_plugin')) {
			$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
			$this->addHook('AdminArticleFoot', 'AdminFoot');
			$this->addHook('AdminStaticFoot', 'AdminFoot');
			$this->addHook('AdminCommentFoot', 'AdminFoot');
			$this->addHook('AdminCommentNewFoot', 'AdminFoot');
			$this->addHook('AdminCategoryFoot', 'AdminFoot');
			$this->addHook('AdminSettingsEdittplFoot', 'AdminFoot');
			$this->addHook('AdminPluginCss', 'AdminFoot');
	 		$this->addHook('ThemeEndHead', 'ThemeEndHead');
			$this->addHook('ThemeEndBody', 'ThemeEndBody');
		}
	}

	public function onActivate() {
		foreach($this->params as $field=>$type) {
			if (array_key_exists($field, $this->params_default) and (($field != 'minify_js') or $this->minifyJS())) {
				$this->setParam($field, $this->params_default[$field], ($type != 'boolean') ? $type : 'numeric');
			}
		}
		$this->saveParams();
		$this->buildStyleSheets();
	}
	public function pluginRoot() {
		global $plxAdmin;

		if (isset($plxAdmin)) {
			return $plxAdmin->racine.$plxAdmin->aConf['racine_plugins'].__CLASS__.'/';
		} else {
			global $plxMotor;
			return $plxMotor->racine.$plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		}
	}

	# hack against PHP 5.4
	private function isComment($scriptname) {
		$p = strpos($scriptname, 'comment');
		$param = $this->getparam('comment');
		return (($p === 0) and !empty($param));
	}

	private function get_mode() {
		$scriptname = $this->script_name;
		$value = $this->getparam($scriptname);
		# if (($scriptname == 'parametres_plugin') or ((strpos($scriptname, 'comment') === 0) and !empty($this->getparam('comment'))) or !empty($value)) {
		if (($scriptname == 'parametres_plugin') or $this->isComment($scriptname) or !empty($value)) {
			switch ($scriptname) {
				case 'parametres_plugin' :
					$mode = (isset($_GET['p']) and ($_GET['p'] == __CLASS__));
					break;
				case 'parametres_plugincss' :
					$mode = 'css';
					break;
				case 'parametres_edittpl' :
					global $tpl;
					$mode = (pathinfo($tpl, PATHINFO_EXTENSION) == 'css') ? 'css' : 'htmlmixed';
					break;
				default:
					$mode = 'htmlmixed';
			}
		} else {
			$mode = false;
		}
		return $mode;
	}

	public function minifyJS() {
		return is_readable(dirname(__FILE__).'/'.CODEMIRROR_LIB_MIN);
	}

	public function buildStyleSheets() {
		global $plxAdmin;

		$addons = array(
			false =>  array('fold/foldgutter', 'hint/show-hint'), // site
			true => array('display/fullscreen', 'fold/foldgutter', 'hint/show-hint', 'dialog/dialog') // admin
		);
		$root = dirname(__FILE__).'/';
		foreach (array('admin', 'site') as $mode) {
			$buf = '/* Do not change - Build by codemirror.php on '.date('Y-m-d - H:i' ).' */'."\n\n";
			// theme par defaut. Obligatoire!
			if ($content = file_get_contents($root.CODEMIRROR_LIB.'/lib/codemirror.css')) {
				$buf .= "/* theme par defaut */\n";
				$buf .= $content;
			}
			// styles pour les addons de Codemirror
			$buf .= "/* Addons pour Codemirror */\n";
			foreach($addons[$mode == 'admin'] as $style) {
				if ($content = file_get_contents($root.CODEMIRROR_LIB.'/addon/'.$style.'.css')) {
					$buf .= '/* addon: '.$style." */\n";
					$buf .= $content;
				}
			}
			// theme personnalisé
			$theme = $this->getParam('theme');
			if (! empty($theme) and ($content = file_get_contents($root.CODEMIRROR_LIB.'/theme/'.$theme.'.css'))) {
				$buf .= '/* theme: '.$theme." */\n";
				$buf .= $content;
			}
			//
			if ($content = file_get_contents($root.$mode.'.css')) {
				$buf .= "/* personnalisation du plugin */\n";
				$buf .= $content;
			}
			// on sauvegarde
			// $filename = $root.'css/'.$mode.'.css';
			$filename = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.'.$mode.'.css';
			if (plxUtils::write(trim($buf), $filename) and $plxAdmin->plxPlugins->cssCache($mode)) {
				plxMsg::Info(L_SAVE_FILE_SUCCESSFULLY);
			} else {
				plxMsg::Info(L_SAVE_FILE_ERROR);
			}
		}
	}

	private function themes() {
		$result = array();
		foreach (scandir(dirname(__FILE__).'/'.CODEMIRROR_LIB.'/theme') as $fn)
			if (substr($fn, -4) == '.css')
				array_push($result, substr($fn, 0, -4));
		return $result;
	}

	public function printSelectThemes($onchange='', $name='theme') {

		$onChange1 = (!empty($onchange)) ? ' onchange="'.$onchange.'"' : '';
?>
			<select id="id_<?php echo $name; ?>" name="<?php echo $name; ?>"<?php echo($onChange1); ?>>
				<option value="">default</option>
<?php
	$theme = $this->getParam('theme');
	foreach($this->themes() as $t) {
		$selected = ($t == $theme) ? ' selected' : ''; ?>
				<option value="<?php echo $t; ?>"<?php echo $selected; ?>><?php echo ucfirst($t); ?></option>
<?php } ?>
			</select>
<?php
	}

	public function print_demo_url() {
		return $this->pluginRoot().CODEMIRROR_LIB.'/demo/theme.html';
	}

	private function setContext($colorize=false) {
		$theme = $this->getParam('theme');
		$root = $this->pluginRoot();
		$addonsRoot = $root.CODEMIRROR_LIB.'/addon/';
		$modesRoot = $root.CODEMIRROR_LIB.'/mode/';
		$libsRoot = $root.CODEMIRROR_LIB.'/lib/';

	        $minifyJS = $this->getParam('minify_js');
		if ($minifyJS) {  ?>
	<script src="<?php echo $root.CODEMIRROR_LIB_MIN; ?>" type="text/javascript"></script>
<?php	}  else { // load each js file one after one ?>
	<script src="<?php echo $libsRoot; ?>codemirror.js" type="text/javascript"></script>
	<!-- Modes for Codemirror -->
<?php
			foreach ($this->modes as $m) { ?>
	<script src="<?php echo $modesRoot.$m.'/'.$m; ?>.js" type="text/javascript"></script>
<?php
			} ?>
	<!-- Addons for CodeMirror -->
<?php
			foreach($this->addons[$colorize] as $a) { ?>
	<script src="<?php echo $addonsRoot.$a; ?>.js" type="text/javascript"></script>
<?php
			} ?>
	<!-- End for CodeMirror -->
<?php	}
	}

	public function AdminTopEndHead() {
		if ($mode = $this->get_mode()) {
			$root = $this->pluginRoot();
			if ($mode !== false) {
				$this->setContext();
			}
?>
	<script src="<?php echo $root.__CLASS__; ?>.js" type="text/javascript"></script> <!-- codemirror -->
<?php	}
	}

	private function printShortkeys() { ?>
			<input type="checkbox" id="cm-shortcuts_nav" style="display: none;" />
			<div id="cm-shortcuts">
				<p><label for="cm-shortcuts_nav"><?php $this->lang('L_'.strtoupper(__CLASS__).'_CLOSE'); ?></label></p>
				<h3><?php $this->lang('L_'.strtoupper(__CLASS__).'_SHORTCUTS'); ?></h3>
				<ul>
<?php
			$shortkeys = array(
				'helpScreen'=>'F1',
				'fullScreen'=>'F11',
				'save'=>'Ctrl-S (PC), Cmd-S (Mac)',
				'find'=>'Ctrl-F (PC), Cmd-F (Mac)',
				'findNext'=>'Ctrl-G (PC), Cmd-G (Mac)',
				'findPrev'=>'Shift-Ctrl-G (PC), Shift-Cmd-G (Mac)',
				'replace'=>'Shift-Ctrl-F (PC), Cmd-Alt-F (Mac)',
				'replaceAll'=>'Shift-Ctrl-R (PC), Shift-Cmd-Alt-F (Mac)',
				'selectAll'=>'Ctrl-A (PC), Cmd-A (Mac)',
				'singleSelection'=>'Esc',
				'killLine'=>'Ctrl-K (Mac)',
				'deleteLine'=>'Ctrl-D (PC), Cmd-D (Mac)',
				'delLineLeft'=>'Delete',
				'delWrappedLine'=>'LeftCmd-Backspace (Mac)',
				'delWrappedLine'=>'RightCmd-Delete (Mac)',
				'undo'=>'Ctrl-Z (PC), Cmd-Z (Mac)',
				'redo'=>'Ctrl-Y (PC), Shift-Cmd-Z (Mac), Cmd-Y (Mac)',
				'undoSelection'=>'Ctrl-U (PC), Cmd-U (Mac)',
				'redoSelection'=>'Alt-U (PC), Shift-Cmd-U (Mac)',
				'goDocStart'=>'Ctrl-Home (PC), Cmd-Up (Mac), Cmd-Home (Mac)',
				'goDocEnd'=>'Ctrl-End (PC), Cmd-End (Mac), Cmd-Down (Mac)',
				'goLineStart'=>'Alt-Left (PC), Ctrl-A (Mac)',
				'goLineStartSmart'=>'Home',
				'goLineEnd'=>'Alt-Right (PC), Ctrl-E (Mac)',
				'goLineRight'=>'Cmd-Right (Mac)',
				'goLineLeft'=>'Cmd-Left (Mac)',
				'goLine'=>'LeftSmart',
				'goLineUp'=>'Up, Ctrl-P (Mac)',
				'goLineDown'=>'Down, Ctrl-N (Mac)',
				'goPageUp'=>'PageUp, Shift-Ctrl-V (Mac)',
				'goPageDown'=>'PageDown, Ctrl-V (Mac)',
				'goCharLeft'=>'Left, Ctrl-B (Mac)',
				'goCharRight'=>'Right, Ctrl-F (Mac)',
				'goColumn'=>'Left',
				'goColumn'=>'Right',
				'goWordLeft'=>'Alt-B (Mac)',
				'goWordRight'=>'Alt-F (Mac)',
				'goGroupLeft'=>'Ctrl-Left (PC), Alt-Left (Mac)',
				'goGroupRight'=>'Ctrl-Right (PC), Alt-Right (Mac)',
				'delCharBefore'=>'Shift-Backspace, Ctrl-H (Mac)',
				'delCharAfter'=>'Delete, Ctrl-D (Mac)',
				'delWordBefore'=>'Alt-Backspace (Mac)',
				'delWordAfter'=>'Alt-D (Mac)',
				'delGroupBefore'=>'Ctrl-Backspace (PC), Alt-Backspace (Mac)',
				'delGroupAfter'=>'Ctrl-Delete (PC), Ctrl-Alt-Backspace (Mac), Alt-Delete (Mac)',
				'indentAuto'=>'Shift-Tab',
				'indentMore'=>'Ctrl-] (PC), Cmd-] (Mac)',
				'indentLess'=>'Ctrl-[ (PC), Cmd-[ (Mac)',
				'insert'=>'Tab',
				'insertSoft'=>'Tab',
				'defaultTab'=>'Tab',
				'transposeChars'=>'Ctrl-T (Mac)',
				'newlineAndIndent'=>'Enter',
				'toggleOverwrite'=>'Insert'
			);
			$prefix = 'L_'.strtoupper(__CLASS__).'_';
			foreach ($shortkeys as $cmd=>$keys) {
				$sum = $this->getLang($prefix.$cmd);
				echo <<< SHORTKEYS
					<li>
						<p><strong>$cmd</strong><span>$keys</span></p>
						<p>$sum</p>
					</li>
SHORTKEYS;
			} ?>
				</ul>
			</div>
<?php
	}

	// we wish to use Codemirror for writing article, static page, comment, and template
	public function AdminFoot() {
		if ($mode = $this->get_mode()) {
			$this->printShortkeys();
			$theme = $this->getParam('theme');
			$showLinesNumber = ($this->getParam('lineNumbers') == 1) ? 'true' : 'false';
			$help = L_PLUGINS_HELP.' Codemirror';
			echo <<< JAVASCRIPT
	<script type="text/javascript">
		<!--
		activeEditor(
			'{$theme}', {$showLinesNumber}, '{$mode}',
			{
				help: "($help)"
			}
		);
		// -->
	</script>
JAVASCRIPT;
		}
	}

    // ----------------- for publication ------------------------
	public function ThemeEndHead() {
		$show = $this->getParam('show');
		if (isset($show) && $show) {
			$this->setContext(true);
			$root = $this->pluginRoot(); ?>
	<script src="<?php echo $root.__CLASS__; ?>.js" type="text/javascript"></script>
<?php
		}
	}

	public function ThemeEndBody() {
		$show = $this->getParam('show');
		if (isset($show) && $show) {
			$theme = $this->getParam('theme'); ?>
	<script type="text/javascript">
		colorize();
	</script>
<?php
		}
	}

}
?>
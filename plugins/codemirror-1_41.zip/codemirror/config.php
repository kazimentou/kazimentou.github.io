<?php
if (!defined('PLX_ROOT')) exit;

# Control du token du formulaire
plxToken::validateFormToken($_POST);

if (!empty($_POST)) {
	foreach ($plxPlugin->params as $field=>$type) {
		switch ($type) {
			case 'boolean' :
				$value = (isset($_POST[$field])) ? 1 : 0;
				$plxPlugin->setParam($field, $value, 'numeric');
				break;
			default :
				$value = (isset($_POST[$field])) ? $_POST[$field] : '';
				$plxPlugin->setParam($field, $value, $type);
				break;
		}
	}
	$plxPlugin->saveParams();
	$plxPlugin->buildStyleSheets(true);
}
?>
	<h2><?php echo(L_PLUGINS_CONFIG.': '.$plxPlugin->getInfo('title')); ?></h2>
	<p id="<?php echo $plugin; ?>-top"><i><?php echo $plxPlugin->getInfo('description'); ?></i></p>
	<form id="form_<?php echo $plugin; ?>" method="post">
		<?php echo plxToken::getTokenPostMethod(); ?>
<?php
foreach ($plxPlugin->params as $field=>$type) {
	$value = $plxPlugin->getParam($field);
	if (!empty($value))
		$value = plxUtils::strCheck($value);
	else
		$value = (array_key_exists($field, $plxPlugin->default_values)) ? $plxPlugin->default_values[$field] : '';
	switch ($field) {
		case 'show':
			$asterisk = '<sup>*</sup>';
			break;
		case 'minify_js':
			$asterisk = '<sup>**</sup>';
			break;
		default: $asterisk = '';
	}
?>
		<p<?php echo ($field == 'theme') ? ' id="cm-demo-theme-container"' : ''; ?>>
<?php	if ($field != 'theme') { ?>
			<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.strtoupper($plugin).'_'.strtoupper($field)); echo $asterisk; ?></label>
<?php	}
		switch ($type) {
			case 'boolean' :
				$checked = ($value) ? ' checked' : '';
?>
			<input id="id_<?php echo $field; ?>" type="checkbox" name="<?php echo $field; ?>" value="1"<?php echo $checked; ?> />
<?php			if ($field == 'minify_js') {
					$minify_status = ($plxPlugin->minifyJS()) ? 'READY' : 'MISSING' ?>
			<input type="button" value="<?php $plxPlugin->lang(strtoupper('L_'.$plugin.'_DOWNLOAD')); ?>" onclick="download_mini_code();" />
			<span><?php echo $plxPlugin->lang('L_'.strtoupper($plugin).'_'.$minify_status); ?></span>
			(<i id="minifyVersion"></i>)
<?php				}
				break;
			default :
				switch ($field) {
					case 'theme' : ?>
			<span><?php $plxPlugin->lang('L_'.strtoupper($plugin).'_'.strtoupper($field)); ?></span>
			<input type="checkbox" id="nav-demo" style="display: none;" />
			(<label for="nav-demo">Aperçu</label>)
<?php $plxPlugin->printSelectThemes('themeChange(this.value); return true;', 'theme'); ?>
			<!-- input type="button" value="<?php $plxPlugin->lang('L_'.strtoupper($plugin).'_SHOW_ME'); ?>" onclick="return demo_open('<?php echo $plxPlugin->print_demo_url(); ?>');" -->
			<iframe id="cm-demo-theme" height="250" width="530" frameborder="0" allowfullscreen="false"></iframe>
<?php
						break;
					default : ?>
		<?php plxUtils::printInput($field, $value, 'text', '5-10', false, $class1);
						break;
				}
				break;
		}
?>		</p>
<?php
}
?>
		<p>
			<label>&nbsp;</label>
			<input type="submit" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>">
		</p>
		<div>
			<p>
				<sup>*</sup><?php echo $plxPlugin->lang('L_'.strtoupper($plugin).'_INFO'); ?>
			</p><p>
				<sup>**</sup><?php echo $plxPlugin->lang('L_'.strtoupper($plugin).'_MINIFY_TARGET').':<br />'.dirname(__FILE__); ?>
			</p>
		</div>
	</form>
	<div id="cm-config-bottom">
		<input type="radio" name="codemirror_more" id="codemirror_infos_nav" />
		<h3><label for="codemirror_infos_nav">Click for miscellanous informations</label></h3>
		<ul>
			<li><a href="<?php echo $plxPlugin->pluginRoot().CODEMIRROR_LIB.'/doc/manual.html';?>" target="_blank">Read the manual here</a></li>
			<li><a href="<?php echo $plxPlugin->pluginRoot().CODEMIRROR_LIB.'/doc/compress.html';?>" target="_blank">Compress modes and addons here</a></li>
            <li><a href="<?php echo $plxPlugin->pluginRoot().CODEMIRROR_LIB.'/mode/'; ?>" target="_blank">Modes</a></li>
		</ul>
		<input type="radio" name="codemirror_more" id="codemirror_demos_nav" />
		<h3><label for="codemirror_demos_nav">Click for examples from Codemirror</label></h3>
		<ul>
<?php
$root = dirname(__FILE__).'/';
$demos = glob($root.CODEMIRROR_LIB.'/demo/*.html');
foreach ($demos as $d) {
	$caption = ucfirst(basename($d, '.html'));
	$href = $plxPlugin->pluginRoot().substr($d, strlen($root)); ?>
			<li><a href="<?php echo $href; ?>" target="_blank"><?php echo $caption; ?></a></li>
<?php
}
?>
		</ul>
	</div>
<!-- for downloading codemirror.min.js -->
<?php
// include(dirname(__FILE__).'/codemirror.inc.php');
print_cm_form_download('form_'.$plugin.'_download');
?>
	<script language="javascript">
		<!--
		function download_mini_code() {
			var aForm = document.getElementById('form_<?php echo $plugin; ?>_download');
			if (aForm)
				aForm.submit();
			else
				console.log('Element with id: form_<?php echo $plugin; ?>_download not found.');
		}
		// -->
	</script>
<!-- Démo pour themes -->
<?php

$hrefBase = $plxPlugin->pluginRoot().CODEMIRROR_LIB.'/';
$theme = $plxPlugin->getParam('theme');
$href = ($theme != '') ? 'theme/'.$theme.'.css' : '';
$optionTheme = ($theme != '') ? "theme: '$theme'," : '';
$iframeContent = <<< CONTENT
/*
<!doctype html>
<html>
<head>
<title>CodeMirror: Theme Demo</title>
	<meta charset="utf-8"/>
	<base href="$hrefBase" />
	<link rel="stylesheet" href="doc/docs.css">
	<link rel="stylesheet" href="lib/codemirror.css">
	<link id="cm-theme" rel="stylesheet" href="$href">
	<script src="lib/codemirror.js"></script>
	<script src="mode/javascript/javascript.js"></script>
	<script src="addon/selection/active-line.js"></script>
	<script src="addon/edit/matchbrackets.js"></script>
	<style type="text/css">
	      .CodeMirror {border: 1px solid #222; font: monospace 12pt; height:auto;}
	      body { height: 220px; padding: 0; margin: 0 8px 0 0; font-size: 10pt; }
	      textarea {width: 100%; height: 100%; margin:0; resize: none; }
	</style>
</head>
<body>
	<textarea id="code" name="code">
function findSequence(goal) {
  function find(start, history) {
    if (start == goal)
      return history;
    else if (start > goal)
      return null;
    else
      return find(start + 5, "(" + history + " + 5)") ||
             find(start * 3, "(" + history + " * 3)");
  }
  return find(1, "1");
}</textarea>
<script type="text/javascript">
	var theme = '$theme';
	var editor = CodeMirror.fromTextArea(document.getElementById("code"), {
		lineNumbers: true,
		$optionTheme
		styleActiveLine: true,
		matchBrackets: true,
		lineWrapping: true
	});

  function setTheme(value) {
		var link1 = document.getElementById('cm-theme');
		if (link1) {
			if (value == '') {
				value = 'default';
			}
			if (value != 'default') {
				link1.href = 'theme/'+value+'.css';
			}
			editor.setOption('theme', value);
		}
	}
</script>
</body>
</html>
*/
CONTENT;
?>
<script type="text/javascript">
	<!--
	function heredoc (f) { return f.toString().match(/\/\*\s*([\s\S]*?)\s*\*\//m)[1]; };

	var ifr = null;

	function setDemo() {
		ifr = document.getElementById('cm-demo-theme');
		if (ifr) {
			var doc = ifr.contentWindow.document;
			doc.open();
			doc.write(heredoc(function() {
<?php echo $iframeContent; ?>
			}));
			doc.close();
		}
	}

	setDemo();

	function themeChange(value) {
		ifr.contentWindow.setTheme(value);
	}

	var elm = document.getElementById('minifyVersion');
	if (elm) {
		elm.innerHTML = 'version '+CodeMirror.version;
	}
	// -->
</script>
<!--  end of config.php for codemirror plugin -->
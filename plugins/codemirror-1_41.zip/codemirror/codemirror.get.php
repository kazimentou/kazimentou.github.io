<?php
// https://developers.google.com/closure/compiler/docs/gettingstarted_api
// https://developers.google.com/closure/compiler/docs/api-tutorial1
// https://developers.google.com/closure/compiler/docs/api-ref
// http://codemirror.net/1/compress.html

include(dirname(__FILE__).'/codemirror.inc.php');

define('URL_BASE', 'http://codemirror.net/');
# define('URL_BASE', 'https://raw.githubusercontent.com/codemirror/CodeMirror/5.12.0/');
define('UGLIFY_JS_URL', 'http://marijnhaverbeke.nl/uglifyjs'); // if CLOSURE is false
define('CLOSURE_URL', 'http://closure-compiler.appspot.com/compile'); // if CLOSURE is true
define('CLOSURE', false); // change for the factory
define('USER_AGENT', 'Lynx/2.8.4rel.1 libwww-FM/2.14');
define('DEBUG', true);

$factory = array(false=>UGLIFY_JS_URL, true=>CLOSURE_URL);

function mode_path($a) {
	return urlencode(URL_BASE.'mode/'.$a.'/'.$a.'.js');
}

function addon_path($a) {
	return urlencode(URL_BASE.'addon/'.$a.'.js');
}

$temp1 = array(urlencode(URL_BASE.'lib/codemirror.js'));
$modes = array_map('mode_path', $codemirror_libs['modes']);
$temp2 = $codemirror_libs['addons'][false] + $codemirror_libs['addons'][true];
$addons = array_map('addon_path', $temp2);
$libs = array_merge($temp1, $modes, $addons);
// sort($libs); !! ne pas trier !!

$filename = 'codemirror.min.js';

if (CLOSURE) {
	$params = array(
		'compilation_level'.'='.'SIMPLE_OPTIMIZATIONS', // WHITESPACE_ONLY, SIMPLE_OPTIMIZATIONS, and ADVANCED_OPTIMIZATIONS
		'output_info'.'='.'compiled_code', // compiled_code, warnings, errors, and statistics
		'language'.'='.'ECMASCRIPT5', // ECMASCRIPT3, ECMASCRIPT5 or even ECMASCRIPT6
		'output_info'.'='.'warnings',
		'output_info'.'='.'errors',
		'output_info'.'='.'statistics',
		'warning_level'.'='.'default',
		'output_file_name'.'='.$filename,
		'output_format'.'='.'json' // text, json, or xml
	);
} else {
	$params = array('download'.'='.$filename);
}

foreach($libs as $lib)
	$params[] = 'code_url='.$lib;

// echo implode("\n&", $params)."\n"; exit;

$request = implode('&', $params);

$curl_options = array(
	CURLOPT_HTTPHEADER		=> array('Content-Type: application/x-www-form-urlencoded'),
	CURLOPT_USERAGENT		=> USER_AGENT,
	CURLOPT_FOLLOWLOCATION	=> true,
	CURLOPT_RETURNTRANSFER	=> true,
	CURLOPT_COOKIESESSION	=> true,
	CURLOPT_TIMEOUT			=> 30, // secondes
	// CURLOPT_HEADER			=> false,
	CURLOPT_POST			=> true,
	CURLOPT_POSTFIELDS		=> $request
);
$res = curl_init($factory[CLOSURE]);
curl_setopt_array($res, $curl_options);
echo "Starting for download from ".$factory[CLOSURE]." ...\n";
$resp = curl_exec($res);
curl_close($res);
if ($resp) {
	if (CLOSURE) {
		// file_put_contents(basename($filename).'.json', $resp);
		$buf = json_decode($resp, true);
		$result = file_put_contents($filename, $buf['compiledCode'], LOCK_EX);
	} else {
		$result = file_put_contents($filename, $resp, LOCK_EX);
	}
	echo "Terminé\n";
}
else {
	echo 'Echec';
	echo 'Erreur n°'.curl_errno($res);
	echo curl_error($res);
}
?>
<?php

if (!defined('PLX_ROOT')) exit;

# http://telechargements.pluxml.org/docs/PluXml_-_Plugins_Guide_du_developpeur.pdf
# http://prismjs.com/

class prismJS extends plxPlugin {

	const PLUGINS_CSS  = '/prism/css/plugins/plugins.css';

	public $plx_plugin_root = PLX_PLUGINS.__CLASS__.'/';

	public function __construct($default_lang) {

		# Appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		$this->setConfigProfil(PROFIL_ADMIN);

		# Ajouts des hooks
		$scriptname = basename(strtolower($_SERVER['SCRIPT_NAME']),'.php');

		$this->addHook('plxMotorConstruct', 'plxMotorConstruct');

		if((
			($scriptname == 'parametres_plugin') and
			!empty($_REQUEST['p']) and
			($_REQUEST['p'] == __CLASS__)
		) or (
			($scriptname == 'parametres_help') and
			!empty($_REQUEST['page']) and
			($_REQUEST['page'] == __CLASS__)
		)) {
			if($scriptname == 'parametres_help') {
				$this->addHook('AdminFootEndBody', 'ThemeEndBody');

			}
		}

		/* Ne pas utiliser le hook ThemeEndHead !
		 * A l'enregistrement de la config du plugin, la feuille de style du thème est fusionnée avec celles des autres plugins
		 * */
		$this->addHook('ThemeEndBody', 'ThemeEndBody');
	}

/* ------------ Methods for this plugin ------------- */
	public function build_themes() {
		global $plxAdmin;

		$theme = $this->getParam('theme');
		if(!empty($theme)) {
			$theme = '-'.$theme; // le thème par defaut prism-default.css a été renonmmé prism.css depuis la dernière version de Prism
		}

		$today = date('c');
		$header = "/* Build by PrismJS::build_themes() on $today. Do not change manually. */\n\n";
		$contents = array(
			'admin'	=> $header,
			'site'	=> $header
		);

		foreach(array_keys($contents) as $f) {
			$contents[$f] .= file_get_contents(__DIR__.'/css/'.$f.'.css')."\n";
		}

		$contents['site'] .= file_get_contents(__DIR__."/prism/css/prism$theme.css")."\n";

		foreach(array_keys($contents) as $f) {
			$contents[$f] .= file_get_contents(__DIR__.$this::PLUGINS_CSS);
		}
		$buf = <<< CSS_BONUS
pre[class*="language"] div.toolbar {
	opacity : 0.3;
}
pre[class*="language"] div.toolbar .toolbar-item {
	margin-right : 1rem;
}

CSS_BONUS;
		foreach(array_keys($contents) as $f) {
			$contents[$f] .= $buf;
			$filename = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.'.$f.'.css';
			if(!plxUtils::write($contents[$f], $filename) or !$plxAdmin->plxPlugins->cssCache($f)) {
				plxMsg::Error(L_SAVE_FILE_ERROR);
			}
		}
	}

	public function get_context($plxMotor) {
		$this->plx_racine = $plxMotor->racine;
		$this->plx_plugin_root = $plxMotor->racine.$plxMotor->aConf['racine_plugins'].__CLASS__.'/';
		$this->plx_aConf = $plxMotor->aConf;
		$this->plx_theme = $plxMotor->racine.$plxMotor->aConf['racine_themes'].$plxMotor->style;
	}

	public function getStylesheetsList() {
		return (!empty($this->plx_racine)) ? false : array(
			'css/admin.css',
			'prism/css/plugins/plugins.css'
		);
	}

	private function __checkCacheCss() {
		$filename0 = __DIR__.$this::PLUGINS_CSS;
		$filename1 = preg_replace('@'.__CLASS__.'$@', '', __DIR__).'admin.css'; // cache pour tous les plugins
		$filename2 = PLX_ROOT.PLX_CONFIG_PATH.'plugins/'.__CLASS__.'.admin.css'; // cache pour ce plugin
		$dateRef0 = filectime($filename0);
		$dateRef1 = filectime($filename1);
		$dateRef2 = filectime($filename2);
		if(
			($dateRef1 < $dateRef0) or
			($dateRef1 < $dateRef0) or
			($dateRef1 < $dateRef2)
		) {
			plxMsg::Error($this->getLang('OBSOLETE_CSS'));
		}

	}
/* ============= Hooks start here ========================== */

	public function plxMotorConstruct() {
		echo '<?php $this->plxPlugins->aPlugins["'.__CLASS__.'"]->get_context($this); ?>';
	}

	public function ThemeEndBody() {

		$path = 'plugins/'.__CLASS__.'/prism/components/';
		echo <<< THEME_END_BODY
	<script type="text/javascript" src="{$this->plx_plugin_root}clipboard.min.js"></script>
	<script type="text/javascript" src="{$this->plx_plugin_root}prism.js" data-autoloader-path="$path"></script>

THEME_END_BODY;
		if(defined('PLX_ADMIN')) {
		/* Uniquement appelé si :
		 *   basename(strtolower($_SERVER['SCRIPT_NAME']),'.php') == 'parametres_help') et
		 *   $_REQUEST['page'] == __CLASS__
		 * L'ordre de chargement des feuilles de style est important !
		 * */
		$theme = $this->getParam('theme');
		$href = $this->plx_plugin_root.'prism/css/';
		$href .= 'prism'.((!empty($theme)) ? '-'.$theme : '');
		$this->__checkCacheCss();
?>
	<script type="text/javascript">
		const styleSheet = document.createElement('LINK');
		styleSheet.rel = 'stylesheet';
		styleSheet.href = '<?php echo $href; ?>.css';
		const adminCss = document.head.querySelector('link[href$="/plugins/admin.css"]');
		if(adminCss != null) {
			document.head.insertBefore(styleSheet, adminCss);
		} else {
			document.head.appendChild(styleSheet);
		}

		const help = document.querySelector('div.in-action-bar p.prismjs-warning');
		if(help != null) {
			help.style.display = 'none';
		}

	</script>
<?php
		}
	}

}

?>
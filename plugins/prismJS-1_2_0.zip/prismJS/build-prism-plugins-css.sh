#!/bin/sh

SOURCE="prism.js"
TARGET="prism/css/plugins/plugins.css"

GREEN_COLOR="\033[32m"
RED_COLOR="\033[31m"
YELLOW_COLOR="\033[33m"
NORMAL_COLOR="\033[0m"

if [ -f $SOURCE ]; then
	rm -f $TARGET

	echo "\nParsing ${SOURCE} script :\n"
	plugins=$(head -n 1 $SOURCE | sed -r 's/^.*plugins=(\S+).*$/\1/; s/\+/ /g')

	mkdir -p $(dirname ${TARGET})
	echo "/* Built by build-prism-plugins-css.sh - Any change can be lost. */" > $TARGET
	for plugin in ${plugins}; do
		src="prism/plugins/${plugin}/prism-${plugin}.css"
		if [ -f "$src" ]; then
			echo $plugin
			echo "\n\n/* ----- ${plugin} plugin ------- */" >> ${TARGET}
			cat ${src} >> ${TARGET}
		else
			echo "${YELLOW_COLOR}No stylesheet for ${plugin} plugin${NORMAL_COLOR}"
		fi
	done
	echo "\n${GREEN_COLOR}The ${TARGET} file was built.${NORMAL_COLOR}\nDone.\n"
else
	echo "\n${RED_COLOR}${SOURCE} file not found.\033[0m\n"
fi
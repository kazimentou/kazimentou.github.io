<?php

if (!defined('PLX_ROOT')) exit;

$LANG = array(
	'L_THEME'	=> 'Thème',
	'L_LINK'	=> 'Lien',
	'L_DEFAULT'	=> 'Par défaut',
	'L_DISABLED_PLUGIN'	=> 'Plugin inactif',
	'L_OBSOLETE_CSS'	=> 'Caches CSS obsolètes.\nEnregistrer la configuration et\ndé|ré-activer le plugin.'
);
?>
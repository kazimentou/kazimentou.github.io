<?php

if (!defined('PLX_ROOT')) exit;

$fields = array(
	'theme'	=> 'string'
);

$themes = array();
foreach(glob(__DIR__.'/prism/css/prism*.css') as $item) {
	$key = preg_replace('@^.*/prism-?([^/]*)\.css$@', '$1', $item);
	$themes[$key] = (!empty($key)) ? ucfirst($key) : $plxPlugin->getLang('L_DEFAULT');
}

if (!empty($_POST)) {
	plxToken::validateFormToken();

	foreach ($fields as $field=>$type) {
		$value = filter_input(INPUT_POST, $field, FILTER_SANITIZE_STRING);
		if(array_key_exists($value, $themes)) {
			$plxPlugin->setParam($field, $value, $type);
		} else {
			$plxPlugin->delParam($field);
		}
	}
	$plxPlugin->saveParams();

	$plxPlugin->build_themes();

	header('Location: parametres_plugin.php?p='.urlencode($plugin));
	exit;
}

$default_values = array();

ksort($themes); // null key first !
$selects = array(
	'theme' => $themes
);

/* ------------ HTML page starts here -------------- */
?>

		<form id="form_<?php echo $plugin; ?>" method="post">
<?php	foreach ($fields as $field=>$type) {
			$value = $plxPlugin->getParam($field);
			if (!empty($value))
				$value = plxUtils::strCheck($value);
			else
				$value = (array_key_exists($field, $default_values)) ? $default_values[$field] : '';
?>
			<p>
				<label for="id_<?php echo $field; ?>"><?php $plxPlugin->lang('L_'.strtoupper($field)); ?></label>
<?php
			switch($type) {
				case 'string':
					if(array_key_exists($field, $selects)) {
						plxUtils::printSelect($field, $selects[$field], $value);
					} else {
						plxUtils::printInput($field, $value);
					}
					if($field == 'theme') {
?>
						<span id="copy-clipboard" class="prismJS" data-clipboard-text title="Copy URL"><img src="<?php echo $plxPlugin->plx_plugin_root; ?>clipboard.png" alt="Copier" /></span>
<?php
					}
					break;
			}
?>
			</p>
<?php
		}
?>
			<div class="in-action-bar">
				<?php echo plxToken::getTokenPostMethod(); ?>
				<input type="submit" value="<?php echo L_COMMENT_SAVE_BUTTON; ?>" />
<?php
	$files = glob(__DIR__.'/prism/download.html');
	if(!empty($files)) {
		$query =
			'themes=prism-okaidia&'.
			'languages=markup+css+clike+javascript+php+php-extras&'.
			'plugins=line-numbers+autolinker+file-highlight+toolbar+jsonp-highlight+previewer-base+previewer-color+autoloader+normalize-whitespace+data-uri-highlight+show-language+copy-to-clipboard';
		$href= $plxPlugin->plx_plugin_root.substr($files[0], strlen(__DIR__.'/')).'?'.$query;
		echo <<< DOWNLOAD
				<a class="button" href="$href" target="_blank" rel="noreferrer">Download</a>

DOWNLOAD;
	}
	if(empty($plxPlugin->plx_racine)) {
?>
				<p class="primjs-warning" style="position: absolute; top: 0; left: 41.6667%; width: 30rem; color: red;"><strong><?php $plxPlugin->lang('L_DISABLED_PLUGIN'); ?></strong></p>
<?php
	}
?>
				<img class="icon" src="<?php echo $plxPlugin->plx_plugin_root; ?>icon.png" />
			</div>
		</form>
		<div class="myprism-grid">
			<div>
				<p>Ex: &lt;pre class="line-numbers" data-src="&lt;?php echo PLX_PLUGINS.$plugin.'/demo-config.php'; ?>" data-line="15">&lt;/pre></p>
				<div>
					<pre class="line-numbers" data-line="15" data-src="<?php echo PLX_PLUGINS.$plugin.'/demo-config.php'; ?>"></pre>
				</div>
			</div>
			<div>
				<p>Ex: &lt;pre class="language-js" data-jsonp="https://api.github.com/repos/pluxml/PluXml/contents/core/lib/multifiles.js">&lt;/pre></p>
				<div>
					<pre class="language-js" data-jsonp="https://api.github.com/repos/pluxml/PluXml/contents/core/lib/multifiles.js"></pre>
				</div>
			</div>
		</div>
<?php $plxPlugin->ThemeEndBody(); ?>
		<script type="text/javascript">
			(function() {

				'use strict';
<?php
	$stylesheets = $plxPlugin->getStylesheetsList();
	if(!empty($stylesheets)) {
?>

				/* ----- plugin disable -------- */
				[
'<?php echo implode("',\n'", $stylesheets); ?>'
				].forEach(function(stylesheet) {
					const node = document.createElement('LINK');
					node.rel = 'stylesheet';
					node.type = 'text/css';
					node.href = '<?php echo PLX_PLUGINS.$plugin; ?>/' + stylesheet;
					document.head.appendChild(node);
				});

<?php
	}
?>
				const href_template = '<?php echo $plxPlugin->plx_plugin_root; ?>prism/css/prism####.css';
				var themeSelect = document.getElementById('id_theme');
				if(themeSelect != null) {
					function loadStyleSheet(event) {
						var	theme = themeSelect.value,
							styleSheet = document.head.querySelector('link[rel="alternative stylesheet"][title="' + theme + '"]'),
							href = href_template.replace(/####\.css$/, ((theme == '') ? '' : '-') + theme + '.css');
						if(styleSheet == null) {
							styleSheet = document.createElement('LINK');
							styleSheet.title = theme;
							styleSheet.rel = 'alternative stylesheet';
							styleSheet.href = href;
							const adminCss = document.head.querySelector('link[href$="/plugins/admin.css"]');
							if(adminCss != null) {
								document.head.insertBefore(styleSheet, adminCss);
							} else {
								document.head.appendChild(styleSheet);
							}
						}
						const alternatives = document.head.querySelectorAll('link[rel="alternative stylesheet"]');
						for(var i=0, iMax=alternatives.length; i<iMax; i++) {
							var elmt = alternatives[i];
							elmt.disabled = (elmt.title != theme);
						}

						var caption = document.getElementById('theme-link');
						if(caption != null) {
							caption.innerHTML = href;
						}

						var copyClipboard = document.querySelector('#copy-clipboard[data-clipboard-text]');
						if(copyClipboard != null) {
							copyClipboard.setAttribute('data-clipboard-text', href);
						}
					}

					const btn = document.getElementById('copy-clipboard');
					if(btn != null) {
						const clipboard = new Clipboard('#copy-clipboard');
						clipboard.on('success', function(e) {
							btn.classList.add('copied');
							const timer1 = setTimeout(
								function() {
									btn.classList.remove('copied');
									clearTimeout(timer1);
								},
								1500
							);
						})
					}

					themeSelect.addEventListener('change', loadStyleSheet);
					loadStyleSheet();

				} else {
					console.log('unknown #id_theme element');
				}

			})();

		</script>
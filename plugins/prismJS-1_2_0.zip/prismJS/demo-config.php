<?php

// if (!defined('PLX_ROOT')) exit;

const TIMESTAMP_FORMAT = 'D, d M Y H:i:s';

session_start();

if(empty($_GET)) {
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename='.basename(__FILE__));
	header('Content-Length: '.filesize(__FILE__));
	header('Last-Modified: '.gmdate(TIMESTAMP_FORMAT, filemtime(__FILE__)).' GMT');
	header('Expires: '.gmdate(TIMESTAMP_FORMAT, time() + 7200));
	readfile(__FILE__);
	exit;
}

?>
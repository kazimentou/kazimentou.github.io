<?php

$LANG = array(

# config.php
'L_JQUERY_THEME'	=> 'Thème'
);
?>

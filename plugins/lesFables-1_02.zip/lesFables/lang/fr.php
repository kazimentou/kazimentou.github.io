<?php
$LANG = array(
'L_LESFABLES_NB_PAGES' => 'Nombre total de pages à générer',
'L_LESFABLES_CATEGORY' => 'Gérer les catégories',
'L_LESFABLES_TAGS'=>'Gérer les mot-clés',
'L_LESFABLES_NO_TAGS'=>'Pas de mot-clés pour ces mots',
'L_LESFABLES_TEMPLATE'=>'Modèle pour publier les articles',
'L_LESFABLES_ARCHIVE'=>'Archive des articles',
'L_LESFABLES_AUTHOR'=>'Rédigé par',
'L_LESFABLES_INFO'=>'Les mot-clés sont issues du titre des articles. Les mots à ne pas utiliser doivent être séparés par une virgule.',
'L_LESFABLES_ALL_PUBLISHED'=>'Tous les articles de l\' archive sont publiés',
'L_ZIP_ARCHIVE_MISSING'=>'La classe ZipArchive pour le langage PHP n\'est pas accessible.<br />Requiert PHP 5.2 au minimum'
);
?>

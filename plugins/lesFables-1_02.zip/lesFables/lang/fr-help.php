<?php
$myPlugin = $plxAdmin->plxPlugins->aPlugins[$plugin];
?>
<h2><?php echo $myPlugin->getInfo('title'); ?></h2>
<h3>By <?php echo $myPlugin->getInfo('author'); ?></h3>
<div id="<?php echo get_class($myPlugin); ?>-help">
	<p>
		Ce plugin permet de publier en une ou plusieur fois des articles pour tester un site.
	</p><p>
		Tous les articles sont contenues dans une archive au format zip. Chaque article est un fichier avec l'extension .inc dans l'archive.
		Chaque fichier contient les codes html prêts à inclure entre les balises &lt;body&gt; d'une page HTML
	</p><p>
		De plus, l'archive contient un fichier index.csv avec 3 champs par ligne, séparés par une tabulation "\t". Les champs contiennent respectivement : le nom de la catégorie de l'article, le titre de l'article, et le nom du ficher de l'article sans l'extension .inc.
	</p><p>
		L'archive zip doit être stockée dans le dossier du plugin. On peut avoir plusieurs archives.
	</p><p>
		Attention: Ce plugin utilise la classe PHP <b>ZipArchive</b>. PHP doit être au moins en version 5.2
	</p>
</div>

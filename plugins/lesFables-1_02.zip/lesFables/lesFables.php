<?php

if (!defined('PLX_ROOT')) exit;

class lesFables extends plxPlugin {

	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->addHook('AdminTopEndHead', 'AdminTopEndHead');
	}

	public function AdminTopEndHead() {
		global $plugin;

		if (!empty($plugin) && $plugin == __CLASS__) {?>
	<link rel="stylesheet" type="text/css" media="screen" href="<?php echo PLX_PLUGINS.__CLASS__.'/'.__CLASS__; ?>.css" />
<?php	}
	}
}
?>

<?php
$LANG = array(
	'OTP_ENABLE'		=> 'Activer la double authentification',
	'OTP_PIN'			=> 'Code PIN',
	'OTP_FAILURE'		=> 'Code PIN erronné',
	'OTP_SCAN'			=> 'Scannez le QR-code',
	'DIGEST'			=> 'Hashage',
	'DIGITS'			=> 'Nombre de chiffres',
	'QRCODE_PROVIDER'	=> 'Générateur local pour le QRcode',
	'COPIED'			=> 'Uri copié dans le presse-papier',
	'MISSING_ICONV_LIBRARY' => 'La bibliothéque Iconv pour PHP n\est pas installée',
	'MISSING_CTYPE_LIBRARY'	=> 'La bibliothéque Ctype pour PHP n\est pas installée',
	'ADMIN_LANG_FAILS'	=> 'Le code de la langue d\'administration du site est %s. Mais votre navigateur n\'accepte pas cette langue'
);
?>
<?php
if(!defined('PLX_ADMIN')) { exit; }

# Control du token du formulaire
plxToken::validateFormToken();

$digestsList = explode(' ', kzOtPHP::DIGESTS);
if(!empty($_POST)) {
	$digest = filter_input(INPUT_POST, 'digest', FILTER_SANITIZE_STRING);
	if(empty($_POST['digest']) or !in_array($digest, $digestsList)) {
		$digest = kzOtPHP::DEFAULT_DIGEST;
	}
	$plxPlugin->setParam('digest', $digest, 'string');

	$digits = intval(filter_input(INPUT_POST, 'digits', FILTER_SANITIZE_NUMBER_INT));
	if($digits < 3 or $digits > 10) {
		$digits = 6;
	}
	$plxPlugin->setParam('digits', $digits, 'numeric');

	$qrcode_provider = intval(filter_input(INPUT_POST, 'qrcode_provider', FILTER_SANITIZE_NUMBER_INT));
	if(!empty($qrcode_provider)) {
		$plxPlugin->setParam('qrcode_provider', 1, 'numeric');
	} else {
		$plxPlugin->delParam('qrcode_provider');
	}

	$plxPlugin->saveParams();
	header('Location: parametres_plugin.php?p='.$plugin);
	exit;
}

$digits = intval($plxPlugin->getParam('digits'));
if($digits < 3 or $digits > 10) {
	$digits = 6;
}
$digest = $plxPlugin->getParam('digest');
if(!in_array($digest, $digestsList)) { $digest = kzOtPHP::DEFAULT_DIGEST; }
$qrcode_provider = intval($plxPlugin->getParam('qrcode_provider'));
?>
<form method="post" class="inline-form" id="form_<?php echo $plugin; ?>">
	<div>
		<label for="id_digest"><?php $plxPlugin->lang('DIGEST'); ?></label>
		<select name="digest" id="id_digest">
<?php
foreach($digestsList as $value) {
	$selected = ($value == $digest) ? ' selected' : '';
	echo <<< OPTION
			<option value="$value"$selected>$value</option>\n
OPTION;
}
?>
		</select>
	</div>
	<div>
		<label for="id_digits"><?php $plxPlugin->lang('DIGITS'); ?></label>
		<input type="number" name="digits" id="id_digits" value="<?php echo $digits; ?>" min="3" max="10" />
	</div>
	<div>
		<label for ="id_qrcode_provider"><?php $plxPlugin->lang('QRCODE_PROVIDER'); ?></label>
<?php plxUtils::printSelect('qrcode_provider', array(1=>L_YES, 0=>L_NO), $qrcode_provider); ?>
	</div>
	<div class="in-action-bar">
		<?php echo plxToken::getTokenPostMethod(); ?>
		<input type="submit" value="<?php echo L_ARTICLE_UPDATE_BUTTON; ?>"/>
	</div>
</form>
<div>
<?php
$imgRoot = PLX_PLUGINS."$plugin/logos/100/";
foreach(array(
	kzOtPHP::PLAYSTORE_URL	=> kzOtPHP::ANDROID,
	kzOtPHP::F_DROID_URL	=> kzOtPHP::F_DROID
) as $url => $apkList) {
	if(preg_match_all('@(\w+)\s*=\s*([\w.]+)@', $apkList, $matches, PREG_SET_ORDER)) {
		echo <<< START
	<ul>\n
START;
		foreach($matches as $provider) {
			$img = strtolower($provider[1]);
			$src = "$imgRoot$img.png";
			$caption = str_replace('_', ' ', $provider[1]);
			echo <<< PROVIDER
		<li><figure>
			<a href="{$url}{$provider[2]}" rel="noreferrer nofollow" target="_blank"><img src="$src" alt="{$provider[1]}" /></a>
			<figcaption>{$caption}</figcaption>
		</figure></li>\n
PROVIDER;
		}
		echo <<< END
	</ul>\n
END;
	}
}
?>
</div>
<div class="kzOtPHP repos">
	<a href="https://staging.f-droid.org/search?q=totp" target="_blank" rel="nofollow noreferrer">
		<img src="<?php echo PLX_PLUGINS.$plugin; ?>/logos/fdroid.svg" alt="F-Droid" title="F-Droid" />
	</a>
	<a href="https://play.google.com/store/search?q=totp" target="_blank" rel="nofollow noreferrer">
		<img src="<?php echo PLX_PLUGINS.$plugin; ?>/logos/playstore.svg" alt="PlayStore" title="Android" />
	</a>
</div>
<?php
if(!defined('PLX_ROOT')) { exit; }

require 'vendor/autoload.php';
use OTPHP\TOTP;

/**
 * A Two Factor Authentication, also known as 2FA plugin for PluXml, according to RFC 4226 (HOTP Algorithm) and RFC 6238 (TOTP Algorithm).
 * Based on https://github.com/Spomky-Labs/otphp library.
 *
 * TOTP::__construct($label = null, $secret = null, $period = 30, $digest = 'sha1', $digits = 6)
 * https://github.com/Spomky-Labs/otphp/blob/v8.3/doc/Use.md
 * @author J.P. Pourrez
 * */
class kzOtPHP extends plxPlugin {

	const FIELDNAME = 'otphp_enable';
	const AUTH_FIELDNAME = 'kz-otp';
	const DIGESTS = 'md5 sha1 sha256 sha512';
	const DEFAULT_DIGEST = 'sha1';
	const DEFAULT_PERIOD = 30;
	const WINDOW = 2;

	const IMG_SIZE = 200; # for QR-code png file

	const PLAYSTORE_URL = 'https://play.google.com/store/apps/details?id=';
	const ANDROID = <<< ANDROID
LastPass=com.lastpass.authenticator
Sophos=com.sophos.sophtoken
Vip_Access=com.verisign.mvip.main
Authy=com.authy.authy
ANDROID;
	const F_DROID_URL = 'https://f-droid.org/packages/';
	const F_DROID = <<< F_DROID
OTP_Authenticator=net.bierbaumer.otp_authenticator
OneTimePass=com.github.onetimepass
AndOTP=org.shadowice.flocke.andotp
FreeOTP=org.fedorahosted.freeotp
F_DROID;

	const QR_CODE_PROVIDERS = <<< QR_CODE_PROVIDERS
Google=https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl={PROVISIONING_URI}
QRserver=http://api.qrserver.com/v1/create-qr-code/?size=200x200&ecc=M&qzone=0&margin=0&data={PROVISIONING_URI}
QR_CODE_PROVIDERS;

	# Use openssl_get_cipher_methods() PHP method to check if ENC_METHOS is available
	const ENCRYPT_METHOD = 'AES-128-CTR';

	private $label = null;

	public function __construct($default_lang) {

		parent::__construct($default_lang);

		if(defined('PLX_AUTHPAGE')) {
			# Authentification
			parent::addHook('AdminAuthPrepend', 'AdminAuthPrepend');
			parent::addHook('AdminAuth', 'AdminAuth');
			parent::addHook('AdminAuthTop', 'AdminAuthTop');
			parent::addHook('AdminAuthEndHead', 'AdminAuthEndHead');
		} elseif(defined('PLX_ADMIN')) {
			# droits pour accéder à la page config.php du plugin
			parent::setConfigProfil(PROFIL_ADMIN);

			# User interface
			parent::addHook('AdminProfilTop', 'AdminProfilTop');
			parent::addHook('AdminProfil', 'AdminProfil');
			parent::addHook('AdminProfilFoot', 'AdminProfilFoot');

			# Manage the user
			parent::addHook('plxAdminEditProfil', 'plxAdminEditProfil');
		}
	}

	/**
	 * Clean up config file from old version.
	 * */
	function onActivate() {
		if(!empty(parent::getParam('context'))) {
			$this->delParam('context');
			$this->saveParams();
		}
	}

	private function __encrypt_key() {
		return openssl_digest(
			gethostname() . "|" . ip2long($_SERVER['SERVER_ADDR']),
			'SHA256',
			true
		);
	}

	/**
	 * the allsecrets param is a serialized array within the secret key for evey user,
	 * indexed by each user ID (3 digits as a string).
	 * */
	private function __getAllSecrets() {
		# http://www.the-art-of-web.com/php/two-way-encryption/
		$param = $this->getParam('allsecrets');
		if(!empty($param)) {
			# $this->allSecrets = unserialize($param);
			$enc_iv = hex2bin($this->getParam('iv'));
			$this->allSecrets = unserialize(openssl_decrypt(
				$param,
				self::ENCRYPT_METHOD,
				self::__encrypt_key(),
				0,
				$enc_iv
			));
			unset($enc_iv);
		} else {
			$this->allSecrets = array();
		}
	}

	private function __saveAllSecrets() {
		if(!empty($this->allSecrets)) {
			# $this->setParam('allsecrets', serialize($this->allSecrets), 'cdata');
			$enc_iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(self::ENCRYPT_METHOD));
			$this->setParam('iv', bin2hex($enc_iv), 'cdata');
			$this->setParam(
				'allsecrets',
				openssl_encrypt(
					serialize($this->allSecrets),
					self::ENCRYPT_METHOD,
					self::__encrypt_key(),
					0,
					$enc_iv
				),
				'cdata'
			);
			unset($enc_iv);
		} else {
			$this->delParam('iv');
			$this->delParam('allsecrets');
			$this->delParam('context');
		}
		$this->saveParams();
	}

	private function __createTOTP($secret=null) {
		$digest = $this->getParam('digest');
		if(empty($digest) or !in_array($digest, explode(' ', self::DIGESTS))) {
			$digest = self::DEFAULT_DIGEST;
		}
		$digits = intval($this->getParam('digits'));
		if($digits < 3 or $digits > 10) { $digits = 6; }
		// $this->__getAllSecrets();
		return new TOTP(
		    $this->label,
		    $secret, # $this->allSecrets[$userId]
		    self::DEFAULT_PERIOD, #period
		    $digest, # sha1, sha256, md5, ...
		    $digits # number of digits
		);
	}

	/**
	 * This is the core of double HOTP and TOTP.
	 * */
	public function check(&$plxAdmin, $counter) {
		# No hook in PluXml after authentification is up !!!
		# So, we do the same job but in a better way.
		if(empty($_POST['login']) or empty($_POST['password'])) {
			return;
		}

		$params = filter_input_array(INPUT_POST, array(
			'login'			=> FILTER_SANITIZE_STRING,
			'password'		=> FILTER_SANITIZE_STRING,
			self::AUTH_FIELDNAME	=> array(
				'filter' => FILTER_VALIDATE_REGEXP,
				'options'=> array('regexp'=> '@^\d{3,10}$@')
			)
		));

		if(
			!empty($params['login']) and
			!empty($params['password'])
		) {
			$this->__getAllSecrets();
			$pass_md5 = md5($params['password']);
			foreach($plxAdmin->aUsers as $userId => $user) {
				if(
					!empty($user['active']) and !$user['delete'] and
					$_POST['login'] === $user['login'] and
					sha1($user['salt'].$pass_md5) === $user['password']
				) {
					# This user is found.
					if(array_key_exists($userId, $this->allSecrets)) {
						# This user is using the double authentification.
						$this->success = false;
						if(!empty($params[self::AUTH_FIELDNAME])) {
							$totp = $this->__createTOTP($this->allSecrets[$userId]);
							$this->success = $totp->verify($params[self::AUTH_FIELDNAME], null, self::WINDOW);
						}
						if(!$this->success) {
							# Authentification fails ! So desactivate the user.
							$plxAdmin->aUsers[$userId]['active'] = false;
						}
					}
					break;
				}
			}
		}
	}

	/**
	 * Callback for AdminProfilTop() hook.
	 * */
	public function setSecret(&$plxAdmin) {
		$this->__getAllSecrets();
		$userId = $_SESSION['user'];
		if(!empty($this->allSecrets) and array_key_exists($userId, $this->allSecrets)) {
			$login = $plxAdmin->aUsers[$userId]['login'];
			$this->secret = $this->allSecrets[$userId];
			$this->label = "{$login}@{$_SERVER['HTTP_HOST']}";
			$this->issuer = $plxAdmin->aConf['title'];
		}
	}

	/**
	 * Callback for plxAdminEditProfil() hook.
	 *
	 * Creates a secret for the current user.
	 * Also stores title of the page and login for using with internal QR-Code builder.
	 * */
	public function createSecret(&$plxAdmin) {
		$this->__getAllSecrets();
		$userId = $_SESSION['user'];
		if(!array_key_exists($userId, $this->allSecrets)) {
			$totp = $this->__createTOTP();
			$this->allSecrets[$userId] = $totp->getSecret();
			$this->__saveAllSecrets();
		}
	}

	/**
	 * 2nd Callback for plxAdminEditProfil() hook.
	 * */
	public function delSecret() {
		$this->__getAllSecrets();
		$userId = $_SESSION['user'];
		if(!empty($this->allSecrets) and array_key_exists($userId, $this->allSecrets)) {
			unset($this->allSecrets[$userId]);
			$this->__saveAllSecrets();
		}
	}

	/**
	 * Builds QR-code and returns as a string.
	 * */
	private function __getQRcode_img($provisioningUri) {
		$renderer = new \BaconQrCode\Renderer\Image\Png();
		$renderer->setHeight(SELF::IMG_SIZE);
		$renderer->setWidth(SELF::IMG_SIZE);
		$writer = new \BaconQrCode\Writer($renderer);
		return $writer->writeString($provisioningUri);
	}

/* ====================== Hooks ============================ */

	const ADMIN_AUTH_PREPEND_CODE = <<< 'ADMIN_AUTH_PREPEND_CODE'
<?php
if(
	empty($_SESSION['maxtry']['counter']) or
	empty($_SESSION['maxtry']['timer']) or
	intval($_SESSION['maxtry']['counter']) < $maxlogin['counter'] or
	time() <= $_SESSION['maxtry']['timer'] + $maxlogin['timer']
) {
	$plxAdmin->plxPlugins->aPlugins['##CLASS##']->check($plxAdmin, $maxlogin['counter']);
}
?>
ADMIN_AUTH_PREPEND_CODE;

	/**
	 * Use $this->check() for checking the code PIN.
	 * Desactivate the user if double-authentification fails when login and password match.
	 * */
	public function AdminAuthPrepend() {
		echo str_replace('##CLASS##', __CLASS__, self::ADMIN_AUTH_PREPEND_CODE);
	}

	/**
	 * Insère une entrée dans le formulaire pour saisir le code Pin.
	 * */
	public function AdminAuth() {
		$name = self::AUTH_FIELDNAME;
		$caption = parent::getLang('OTP_PIN');
		echo <<< DIV
		<div class="grid">
			<div class="col sml-12">
				<input id="id_{$name}" type="text" name="{$name}" value="" class="full-width text-center" maxlength="10" pattern="^\d{3,10}$" placeholder="$caption" inputmode="numeric" autocomplete="off" />
			</div>
		</div>
DIV;
	}

	const ADMIN_AUTH_TOP_CODE = <<< 'ADMIN_AUTH_TOP_CODE'
<?php
if(empty($msg) or $msg == L_ERR_WRONG_PASSWORD) {
	$msg = '##MSG##'; $error = 'error';
}
?>
ADMIN_AUTH_TOP_CODE;

	/**
	 * Update $msg if no success.
	 * */
	public function AdminAuthTop() {
		if(isset($this->success) and $this->success === false) {
			echo str_replace('##MSG##', self::getLang('OTP_FAILURE'), self::ADMIN_AUTH_TOP_CODE);
		}
	}

	public function AdminAuthEndHead() {
		$url = PLX_PLUGINS.__CLASS__.'/darkness-100.png';
		echo <<< BACKGROUND_IMAGE
		<style type="text/css">
			body { background-image: url('$url'); }
			section > div.auth { background-color: #f0f0f0; }
		</style>
BACKGROUND_IMAGE;

	}
	/* -------------------- Setup for the current user ---------------------- */

	const ADMIN_PROFIL_TOP = <<< 'ADMIN_PROFIL_TOP'
<?php
$plxAdmin->plxPlugins->aPlugins['##CLASS##']->setSecret($plxAdmin);
ob_start();
?>
ADMIN_PROFIL_TOP;

	/**
	 * Get the secret, Active the cache for output.
	 *
	 * Calls $this->setScecret(...)
	 * */
	public function AdminProfilTop() {
		echo str_replace('##CLASS##', __CLASS__, self::ADMIN_PROFIL_TOP);
	}

	const ADMIN_PROFIL_CODE = <<< 'ADMIN_PROFIL_CODE'
<?php
$replace = <<< 'REPLACE'

		<div class="grid">
			<div class="col sml-12">
				<label for="id_otphp_enable">##CAPTION##&nbsp;:</label>
##SELECT##
			</div>
		</div>
REPLACE;
$output = ob_get_clean();
echo preg_replace('@(\s*</fieldset>.*)@s', "{$replace}$1", $output);
?>
ADMIN_PROFIL_CODE;

	/**
	 * Add the select tag for the double authentification for the current user.
	 * */
	public function AdminProfil() {
		ob_start();
		plxUtils::printSelect(
			self::FIELDNAME,
			array('1'=>L_YES,'0'=>L_NO),
			!empty($this->secret) ? '1' : '0'
		);
		$select = trim(ob_get_clean());

		$replaces = array(
			'##CAPTION##'	=> $this->getLang('OTP_ENABLE'),
			'##SELECT##'	=> $select
		);
		echo str_replace(array_keys($replaces), array_values($replaces), self::ADMIN_PROFIL_CODE);
	}

	/**
	 * Checks if the internal QR-code builder can be using.
	 * */
	private function enabled_internal_provider() {
		if(!empty($this->getParam('qrcode_provider'))) {
			# With Alpinelinux, php-iconv and ctype aren't installed by default.
			if(!function_exists('iconv')) {
				plxMsg::Error($this->getLang('MISSING_ICONV_LIBRARY'));
				return false;
			}
			if(!function_exists('ctype_digit')) {
				plxMsg::Error($this->getLang('MISSING_CTYPE_LIBRARY'));
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * Display the secret with a QR-Code.
	 * */
	public function AdminProfilFoot() {
		if(!empty($this->secret)) {
			$totp = $this->__createTOTP($this->secret);
			$totp->setIssuer($this->issuer);
			$provisioningUri = $totp->getProvisioningUri();
			if(self::enabled_internal_provider()) {
				$imgData = self::__getQRcode_img($provisioningUri);
				$src = 'data:image/png;base64,' . base64_encode($imgData);
			} else {
				$src = $totp->getQrCodeUri(); # may be other than Google
			}
?>
	<figure class="<?php echo __CLASS__; ?> qrcode">
		<p><?php echo implode(' - ', array($this->getParam('digest'), $this->getParam('digits').' digits')); ?></p>
		<img id="qr-code" alt="QR-Code" width="<?php echo SELF::IMG_SIZE; ?>" height="<?php echo SELF::IMG_SIZE; ?>"
			src="<?php echo $src; ?>"
			title="<?php echo $provisioningUri; ?>"
		/>
		<figcaption><?php $this->lang('OTP_SCAN'); ?></figcaption>
	</figure>
	<input type="text" id="clipboard" class="<?php echo __CLASS__; ?> off-screen" />
	<script type="text/javascript">
		(function() {
			'use strict';
			const qrCode = document.getElementById('qr-code');
			const clp = document.getElementById('clipboard');
			if(qrCode != null && clp != null) {
				qrCode.addEventListener('click', function(event) {
					clp.value = event.target.title;
					clp.select();
					document.execCommand('copy');
					event.preventDefault();
					alert('<?php $this->lang("COPIED"); ?>');
				})
			}
		})();
	</script>
<?php
		}
	}

	const PLXADMIN_EDITPROFIL_CODE = <<< 'PLXADMIN_EDITPROFIL_CODE'
<?php
if(array_key_exists('##FIELDNAME##', $content)) {
	if($content['##FIELDNAME##'] == '1') {
		$this->plxPlugins->aPlugins['##CLASS##']->createSecret($this);
	} elseif($content['##FIELDNAME##'] == '0') {
		$this->plxPlugins->aPlugins['##CLASS##']->delSecret();
	}
}
?>
PLXADMIN_EDITPROFIL_CODE;

	/**
	 * Generate the secret if required,
	 * Otherwise delete the secret if desactivation.
	 * */
	public function plxAdminEditProfil() {
		$replaces = array(
			'##FIELDNAME##'		=> self::FIELDNAME,
			'##CLASS##'			=> __CLASS__
		);
		echo str_replace(array_keys($replaces), array_values($replaces), self::PLXADMIN_EDITPROFIL_CODE);
	}

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<?php
const TITLE_PAGE = 'Test Spomky-Labs';
?>
<head>
	<title><?php echo TITLE_PAGE; ?></title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<style>
		figure { margin: 0 0.5rem; }
		figcaption { text-align: center; }
	</style>
</head>
<body>
<pre>
Most applications on smartphones only support md5, sha1, sha256 and sha512 (FreeOTP, Sophos Authentificator, ...).
<?php
# https://github.com/Spomky-Labs/otphp/blob/v8.3/doc/Use.md

require 'vendor/autoload.php';
use OTPHP\TOTP;

# function __construct($label = null, $secret = null, $period = 30, $digest = 'sha1', $digits = 6)
$totp = new TOTP(
	'alice@wonderland.com'
);
$totp->setIssuer(TITLE_PAGE);
$secret = $totp->getSecret();
echo 'Digits in use : '.$totp->getDigits()."\n";
echo 'Digest : '.$totp->getDigest()."\n";
echo "The secret is $secret\n";
echo 'The current OTP is: '.$totp->now()."\n";
$provisioningUri = $totp->getProvisioningUri();
echo "The provisioningUri is $provisioningUri\n";

# function getQrCodeUri($uri = 'https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl={PROVISIONING_URI}', $placeholder = '{PROVISIONING_URI}')
# Other choices
# 'http://api.qrserver.com/v1/create-qr-code/?color=5330FF&bgcolor=70FF7E&data=[DATA]&qzone=2&margin=0&size=300x300&ecc=H', '[DATA]'
# https://www.qrcode-monkey.com/qr-code-api-with-logo
# composer require bacon/bacon-qr-code

const IMG_SIZE = 200;

$googleChartUri = $totp->getQrCodeUri();
$qrserver = $totp->getQrCodeUri('http://api.qrserver.com/v1/create-qr-code/?qzone=0&margin=0&size=200x200&ecc=M&data=[DATA]', '[DATA]');
$qrickit = $totp->getQrCodeUri('http://qrickit.com/api/qr.php?d=[DATA]&qrsize=200', '[DATA]');

# internal QR-Code builder
$renderer = new \BaconQrCode\Renderer\Image\Png();
$renderer->setHeight(IMG_SIZE);
$renderer->setWidth(IMG_SIZE);
$renderer->setMargin(0);
$writer = new \BaconQrCode\Writer($renderer);
$imgData = $writer->writeString($provisioningUri);
?>
</pre>
<div style="display: flex;">
	<figure>
		<img src="<?php echo $googleChartUri; ?>" alt="qrcode" width="200" height="200" />
		<figcaption>Google Chart</figcaption>
	</figure>
	<figure>
		<img src="<?php echo $qrserver; ?>" alt="qrcode" width="200" height="200" />
		<figcaption>http://qrserver.com</figcaption>
	</figure>
	<figure>
		<img src="<?php echo $qrickit; ?>" alt="qrcode" width="200" height="200" />
		<figcaption>http://qrickit.com</figcaption>
	</figure>
	<figure>
		<img src="data:image/png;base64,<?php echo base64_encode($imgData); ?>" alt="qrcode" width="200" height="200" />
		<figcaption>Internal builder</figcaption>
	</figure>
</div>
<pre>
List of registered hashing algorithms :
<?php
print_r(hash_algos());
?>
</pre>
</body>
</html>
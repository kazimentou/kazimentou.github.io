<?php
if (! defined('PLX_ROOT')) exit;
 
# Control du token du formulaire
plxToken::validateFormToken($_POST);
 
if (!empty($_POST)) {
	// Saving parameters
	foreach (array_keys($plxPlugin->networks) as $id) {
		$value = (isset($_POST[$id])) ? 1 : 0;
		$plxPlugin->setParam($id, $value, 'numeric');
		$accountName = 'account_'.$id;
		if (isset($_POST[$accountName]))
			$plxPlugin->setParam($accountName, trim($_POST[$accountName]), 'string');		
	}
	$value = (isset($_POST[SHARE_ME_TAGS])) ? 1 : 0;
	$plxPlugin->setParam(SHARE_ME_TAGS, $value, 'numeric');
	$plxPlugin->saveParams();
}
?>
		<h2><?php echo($plxPlugin->getInfo('title')); ?></h2>
		<p><?php echo($plxPlugin->getInfo('description')); ?></p>
		<form id="form_<?php echo $plugin; ?>" method="post">
			<?php echo plxToken::getTokenPostMethod(); echo "\n"; ?>
<?php	$use_tags = ($plxPlugin->getParam(SHARE_ME_TAGS) > 0) ? ' checked' : '';
		foreach (array_keys($plxPlugin->networks) as $id) {
			$value = $plxPlugin->getParam($id);
			$checked = ($value > 0) ? ' checked' : ''; ?>
			<p>
				<label for="id_<?php echo $id; ?>"><?php echo ($id != 'google_p') ? ucfirst($id): 'Google+'; ?></label>
				<input id="id_<?php echo $id; ?>" name="<?php echo $id; ?>" type="checkbox" value="1"<?php echo $checked; ?> />
<?php	if (in_array($id, $plxPlugin->account_networks)) {
				$param_name = 'account_'.$id;
				$value = $plxPlugin->getParam($param_name); ?>
				<?php plxUtils::printInput($param_name, $value, 'text', 40, false, '', 'Nom du compte'); ?>
<?php	} ?>
			</p>
<?php	}
?>			
			<p>
				<label for="id_<?php echo SHARE_ME_TAGS; ?>"><?php echo $plxPlugin->lang('L_'.strtoupper($plugin).'_TAGS'); ?></label>
				<input id="id_<?php echo SHARE_ME_TAGS; ?>" name="<?php echo SHARE_ME_TAGS; ?>" type="checkbox" value="1"<?php echo $use_tags; ?> />
			</p>
			<p>
				<label>&nbsp;</label>
				<input type="submit" value="<?php echo $plxPlugin->lang('L_'.strtoupper($plugin).'_SAVE'); ?>"/>
			</p>
		</form>

<?php
if (! defined('PLX_ROOT')) exit;

/*
 * Some useful links:
 * https://github.com/Ohax/Boutons-sociaux-sans-tracking
 * http://ohax.fr/ajouter-les-boutons-de-partage-des-reseaux-sociaux-sans-le-tracking-de-vos-visiteurs
 * https://github.com/alexandre-lg/aplxSocialImg
 * https://github.com/adamfairhead/webicons
 * https://dev.twitter.com/web/tweet-button/web-intent
 * https://dev.twitter.com/cards/overview
 * https://developers.facebook.com/docs/sharing/webmasters
 * https://developers.pinterest.com/docs/rich-pins/articles/
 * https://wiki.diasporafoundation.org/FAQ_for_web_developers
 * https://github.com/sharetodiaspora/sharetodiaspora.github.io
 * http://www.cnil.fr/vos-obligations/sites-web-cookies-et-autres-traceurs/outils-et-codes-sources/les-boutons-sociaux/
 * http://sassmeister.com/
 * */

define('SHARE_ME_TAGS', 'tags');

class share_me extends plxPlugin {

	private $media = false;

	public $networks = array( // href, height, width
		'twitter'	=> array('https://twitter.com/intent/tweet?text=#title##account#&url=#url#&hashtags=#tags#', 480, 750),
		'facebook'	=> array('https://www.facebook.com/sharer.php?u=#url#&t=#title#', 500, 500),
		'diaspora'	=> array('#diaspora/?title=#title#&url=#url#&notes=#notes#', 500, 800),
		'google_p'	=> array('https://plus.google.com/share?url=#url#&hl=#lang#', 450, 600),
		'linkedin'	=> array('https://www.linkedin.com/shareArticle?mini=true&url=#url#&title=#title#', 550, 700),
		'pinterest'	=> array('https://www.pinterest.com/pin/create/button/?url=#url#&media=#media#&description=#notes#', 450, 850),
		'mail'		=> array('mailto:?subject=#title#&body=#url#', false, false)
	);

	public $account_networks = array('twitter');

	public function __construct($default_lang) {

		# appel du constructeur de la classe plxPlugin (obligatoire)
		parent::__construct($default_lang);

		# droits pour accéder à la page config.php du plugin
		$this->setConfigProfil(PROFIL_ADMIN);

		$this->addHook('ThemeEndHead', 'ThemeEndHead');
		$this->addHook('share_me', 'share_me');
	}

	private function ok() {
		global $plxMotor;

		return ($plxMotor->mode == 'article') or (($plxMotor->mode == 'static') and (($plxMotor->aStats[ $plxMotor->cible ]['readable'] > 0)));
	}

	private function getTitlePage() {
		global $plxMotor;

		switch ($plxMotor->mode) {
			case 'article' :
				$result = $plxMotor->plxRecord_arts->f('title');
				break;
			case 'static' :
				$result = plxUtils::strCheck($plxMotor->aStats[ $plxMotor->cible ]['name']);
				break;
			default :
				$result = '';
		}
		return $result;
	}

	private function getDescription() {

		global $plxMotor;

		$result = $plxMotor->aConf['description'];
		switch ($plxMotor->mode) {
			case 'article' :
				$chapo = $plxMotor->plxRecord_arts->f('chapo');
				if (! empty($chapo))
					$result = $chapo;
				break;
			case 'static' :
				$description = $plxMotor->aStats[ $plxMotor->cible ]['meta_description'];
				if (! empty($description))
					$result = $description;
				break;
		}
		return preg_replace(array('#<br\s*/?>\n*#', '#</?[^>]+>#'), array(' ',''), $result);
	}

	private function getMedia() {

		if (! empty($this->media))
			$content = $this->media;
		else {
			// look for a picture in the content of article or the static page
			global $plxMotor;
			switch ($plxMotor->mode) {
				case 'article' :
					$content = $plxMotor->plxRecord_arts->f('content');
					break;
				case 'static' :
					$filename = PLX_ROOT.$plxMotor->aConf['racine_statiques'].$plxMotor->cible;
					$filename .= '.'.$plxMotor->aStats[ $plxMotor->cible ]['url'].'.php';
					$content = file_get_contents($filename);
					break;
				default :
					$content = false;
			}
			if ($content !== false) {
				if (preg_match('/<img\s.*src="([^"]+)"/', $content, $matches))
					$content = str_replace('tb.', '', $matches[1]);
				else
					$content = false;
			}
		}
		if (! empty($content)) {
			$result = $plxMotor->racine;
			if (! preg_match('#^[a-z]+://#', $result)) {
				$protocol = (isset($_SERVER['HTTPS']) and ! empty($_SERVER['HTTPS'])) ? 'https://' : 'http://';
				$result = $protocol.$_SERVER['HTTP_HOST'].$result;
			}
			$result .= $content;
		} else
			$result = '';
		return $result;
	}

	private function getTags() {
		global $plxMotor;

		$result = false;
		if ($this->getParam(SHARE_ME_TAGS) > 0) {
			switch ($plxMotor->mode) {
				case 'article':
					$result = str_replace(' ', '',$plxMotor->plxRecord_arts->f('tags'));
					break;
				case 'static' :
					$result = str_replace(' ', '', $plxMotor->aStats[ $plxMotor->cible ]['meta_keywords']);
					break;
			}
		}
		return $result;
	}

	private function date2iso8601() {
		global $plxMotor;

		$result = '';
		switch ($plxMotor->mode) {
			case 'article' :
				if (preg_match('/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})/', $plxMotor->plxRecord_arts->f('date'), $k))
					$result = date(DATE_ISO8601, mktime($k[4], $k[5], 0, $k[2], $k[3], $k[1]));
				break;
			case 'static' :
				$filename = PLX_ROOT.$plxMotor->aConf['racine_statiques'].$plxMotor->cible;
				$filename .= '.'.$plxMotor->aStats[ $plxMotor->cible ]['url'].'.php';
				$result = date(DATE_ISO8601, filemtime($filename));
		}

		return $result;
	}

	public function ThemeEndHead() {
		// meta-datas for open graph. See http://opengraphprotocol.org/. Used by Facebook, Google+, Pinterest, Diaspora, ...
		global $plxMotor;

		if ($this->ok()) {
			$titlePage = $this->getTitlePage();
			$description = $this->getDescription(); ?>
	<meta property="og:type" content="article" />
<?php		if (!empty($titlePage)) { ?>
	<meta property="og:title" content="<?php echo $titlePage ?>" />
<?php		} ?>
	<meta property="og:site_name" content="<?php echo $plxMotor->aConf['title']; ?>" />
	<meta property="og:locale" content="<?php echo $plxMotor->aConf['default_lang']; ?>" />
	<meta property="article:published_time" content="<?php echo $this->date2iso8601(); ?>" />
<?php		if ($buf = $this->getTags()) {
				$tags = explode(',', $buf);
				foreach ($tags as $key) { ?>
	<meta property="article:tag" content="<?php echo trim($key); ?>" />
<?php			}
			}
			if (! empty($description)) { ?>
	<meta property="og:description" content="<?php echo $description; ?>" />
<?php		}
			if ($src = $this->getMedia()) { ?>
	<meta property="og:image" content="<?php echo $src; ?>" />
<?php		} ?>
<?php	}

	}

	public function share_me($params='') {
		global $plxMotor;

		if ($this->ok()) {
			if (! empty($param)) {
				$this->media = $param;
			} ?>
		<script type="text/javascript">
			function openShare(href, height, width) {
				var top = (screen.height - height) / 2;
				var left = (screen.width - width) / 2;
				var options = 'menubar=no, toolbar=no, resizable=yes, scrollbars=no, width='+width+', height='+height+', top='+top+', left='+left;
				window.open(href, '', options);
				return false;
			}
		</script>
		<ul id="social-buttons">
<?php
			$patterns = array('#url#', '#title#', '#lang#', '#tags#', '#notes#', '#account#', '#media#');
			$url = (isset($_SERVER['HTTPS']) and ! empty($_SERVER['HTTPS'])) ? 'https://' : 'http://';
			$url .= $_SERVER['HTTP_HOST'];
			$url .= $_SERVER['REQUEST_URI'];
			$media = $this->getMedia();
			$titlePage = $this->getTitlePage();
			$replaces = array(
				rawurlencode($url), // #url#
				rawurlencode($titlePage), // #title#
				$plxMotor->aConf['default_lang'], // #lang#
				rawurlencode($this->getTags()), // #tags#
				rawurlencode($this->getDescription()) // #notes#
			);
			foreach ($this->networks as $id=>$params) {
				if (($this->getParam($id) > 0) and (($id != 'pinterest') or ($media = $this->getMedia()))) {
					$title = ucfirst($id);
					list($link, $width, $height) = $params;
					if ($id != 'mail') {
						if ($id == 'diaspora') {
							// Diaspora utilise un popup sur le serveur
							$folder = '/sharetodiaspora';
							$new_url = $plxMotor->racine.$plxMotor->aConf['racine_plugins'].__CLASS__.$folder;
							$link = str_replace('#diaspora', $new_url, $link);
						}
						$buf = $replaces;
						$account = $this->getParam('account_'.$id);
						$buf[] = (strlen($account) > 0) ? '&via='.$account : ''; // #account#
						if ($id == 'pinterest')
							$buf[] = rawurlencode($media); // #media#
					} else {
						// pas d'utilisation de rawurlencode pour le mail
						$buf = array($url, $titlePage);
					}
					$href = htmlspecialchars(str_replace($patterns, $buf, $link));
					$onclick = ($width == false) ? '' :  ' onclick="return openShare(this.href, '.$width.', '.$height.');"';
					echo <<< BUTTONS
			<li><a class="$id" href="$href"$onclick title="Partager sur $title" rel="nofollow">&nbsp;</a></li>

BUTTONS;
				}
			} ?>
		</ul>
<?php
		}
	}

}

?>
<?php if(!defined('PLX_ROOT')) { exit; } ?>

<pre>
Format du fichier csv:

La 1ère ligne non vide doit contenir le nom des champs.
Seuls les champs reconnus par PluXml sont pris en compte, à savoir:
login,name,active,profil,password,lang,email,infos
Seul le champ login est obligatoire.
Il n'est pas tenu compte des majuscules et minuscules.

Pour chaque utilisateur :
Si le champ name est nul, il sera initialisé avec la valeur du champ login.
Si le champ password est nul, sa valeur sera initialisée à : PluXml.
Si le champ email n'a pas un format correct, il sera mis à nul
les caractères &lt; et &gt; seront remplacés par leurs entités respectives.

Les lignes vides ne sont pas prises en compte, ni celles dont la valeur login est nulle.

S'il existe déjà un utilisateur avec le login indiqué, ses autres valeurs seront actualisées.
</pre>
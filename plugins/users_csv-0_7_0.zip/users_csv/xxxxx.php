<?php

/* The original name of this script is xxxxx.php.
 * If you want to display an entry inside the admin menu, rename it into admin.php.
 *
 * */

const KZ_USERS_CSV_WARNING = 'Rename this file into "admin.php" and return to PluXml after logging.';
const FIELDS_PLUXML = 'login,name,active,profil,password,lang,email,infos';

if(!empty($_POST['users-csv'])) {
	# import users from csv file
	// fork de core/admin/plugin.php
	include(realpath(__DIR__.'/../../core/admin/prepend.php'));
	$plugin = plxUtils::nullbyteRemove('users_csv');
	if(isset($plxAdmin->plxPlugins->aPlugins[$plugin])) {
		$plxPlugin = $plxAdmin->plxPlugins->aPlugins[$plugin];
		$plxAdmin->checkProfil($plxPlugin->getAdminProfil());
	}
	$location = '../../core/admin/parametres_users.php';
} elseif(!empty($plxPlugin)) {
	$location = 'plugin.php?p='.$plugin;
} else {
	exit(KZ_USERS_CSV_WARNING);
}

if(! defined('PLX_ROOT')) { exit(KZ_USERS_CSV_WARNING); }

if(isset($_POST['users-csv']) and filter_input(INPUT_POST, 'users-csv', FILTER_SANITIZE_NUMBER_INT) == $plxPlugin->signature) {

	$separator = ($_POST['separator'] != 'tab') ? $_POST['separator'] : "\t";
	$enclosure = ($_POST['enclosure'] != '&quot;') ? $_POST['enclosure'] : '"';

	if(isset($_POST['users-csv-export'])) {
		$rows = array(
			explode(',', FIELDS_PLUXML)
		);
		$plxFields = explode(',', FIELDS_PLUXML);
		foreach($plxAdmin->aUsers as $idUser=>$propUsers) {
			if(empty($propUsers['delete']) or ($propUsers['delete'] == '0')) {
				$cells = array();
				foreach($plxFields as $fld) {
					$cells[] = (isset($propUsers[$fld]) and ($fld != 'password')) ? $propUsers[$fld] : '';
				}
				$rows[] = $cells;
			}
		}

		// http://code.stephenmorley.org/php/creating-downloadable-csv-files/
		if(ob_end_clean()) {
			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename=pluxml-users_'.strftime('%F_%H-%M').'.csv');
			if(! empty($enclosure)) {
				$output = fopen('php://output', 'w');
				foreach($rows as $record) {
					fputcsv($output, $record, $separator, $enclosure);
				}
				fclose($output);
			} else {
				foreach($rows as $record) {
					echo implode($separator, $record)."\n";
				}
			}
		} else {
			header('HTTP/1.0 500 Unable to export .csv file');
		}
		exit;

	} elseif(isset($_FILES['users-csv-file']) and (! empty($_FILES['users-csv-file']['tmp_name']))) {

		// drop empty lines and lines starting with '#' (comments)
		$lines = array_filter(
			file($_FILES['users-csv-file']['tmp_name']),
			function($item) { return (! empty(strlen(trim($item))) and ($item[0] != '#')); }
		);
		// get title of columns  in 1st line
		if(! empty($enclosure)) {
			$cols = str_getcsv(strtolower(array_shift($lines)), $separator, $enclosure);
		} else {
			$cols = explode($separator, strtolower(array_shift($lines)));
		}
		$fields = array();
		for($i=0; $i < count($cols); $i++) {
			$fields[$cols[$i]] = $i;
		}
		// check if column for login exists
		if(array_key_exists('login', $fields)) {
			// get the list of logins already presents
			$used_logins = array();
			foreach($plxAdmin->aUsers as $id_user=>$infos) {
				$used_logins[$infos['login']] = $id_user;
			}
			$bad_logins = array();
			// init datas for plxAdmin::editUsers()
			$datas = array(
				'update' => true,
				'userNum' => array()
			);
			# get the top of id users
			$a = array_keys($plxAdmin->aUsers);
			if($plxAdmin->aUsers) {
				rsort($a);
			} else {
				$a['0'] = 0;
			}
			$userId = $a[0] + 1;
			$langs = plxUtils::getLangs();
			// fields used by PluXml. Notice: login is required
			$plxFields = explode(',', FIELDS_PLUXML);
			// some values for active or deleted users
			$actifs = array('1', 'y', 'o', 't', 'true', 'vrai', 'oui');
			// loop for every line of the input file
			$countUsers = 0;
			foreach($lines as $line) {
				$update = false;
				if(! empty($enclosure)) {
					$cells = str_getcsv($line, $separator, $enclosure);
				} else {
					$cells = explode($separator, $line);
				}
				// First, get the login
				$col0 = $fields['login'];
				if(!empty(trim($cells[$col0]))) {
					if(array_key_exists(trim($cells[$col0]), $used_logins)) {
						$bad_logins[] = $cells[$col0];
						$id = str_pad($used_logins[$cells[$col0]], 3, '0', STR_PAD_LEFT);
						$update = true;
					} else {
		 				$id = str_pad($userId, 3, '0', STR_PAD_LEFT);
					}
					$datas['userNum'][] = $id; // requested by plxAdmin::editUsers()
					// loop for each cell of the line
					foreach($plxFields as $fld) {
						if(array_key_exists($fld, $fields)) {
							$key = $id.'_'.$fld;
							$value = filter_var(trim($cells[$fields[$fld]]), FILTER_SANITIZE_STRING);
							if(! empty($value)) { $datas[$key] = $value; }
						}
					}

					// post-checking
					if(!$update) {
						if(empty($datas[$id.'_name'])) { $datas[$id.'_name'] = $datas[$id.'_login']; }
						if(empty($datas[$id.'_password'])) { $datas[$id.'_password'] = users_csv::DEFAULT_PASSWORD; }
					} else {
						if(! isset($datas[$id.'_password'])) { $datas[$id.'_password'] = ''; } // required by plxAdmin::editUsers()
					}
					$datas[$id.'_active'] = (! empty($datas[$id.'_active']) && in_array(strtolower($datas[$id.'_active']), $actifs)) ? 1 : 0;
					$datas[$id.'_delete'] = (! empty($datas[$id.'_delete']) && in_array(strtolower($datas[$id.'_active']), $actifs)) ? 1 : 0;
					if(!empty($datas[$id.'_profil'])) {
						$level = intval($datas[$id.'_profil']);
					} elseif(!empty($plxAdmin->aUsers[$id]['profil'])) {
						$level = intval($plxAdmin->aUsers[$id]['profil']);
					} else {
						$level = PROFIL_WRITER;
					}
					if(($level < PROFIL_ADMIN) or ($level > PROFIL_WRITER)) {
						$level = PROFIL_WRITER;
					}
					$datas[$id.'_profil'] = ($level == PROFIL_ADMIN) ? PROFIL_MANAGER : $level;
					if(! empty($datas[$id.'_lang'])) {
						$lang = strtolower(substr($datas[$id.'_lang'], 0, 2));
						if(in_array($lang, $langs)) {
							$datas[$id.'_lang'] = $lang;
						} else {
							unset($datas[$id.'_lang']);
						}
					}
					if(empty($datas[$id.'_email']) or ! filter_var($datas[$id.'_email'], FILTER_VALIDATE_EMAIL)) {
						$datas[$id.'_email'] = '';
					}

					$countUsers++;

					// next user, please
					$userId++;
				}
			}
			// Save $datas in PluXml
			if($plxAdmin->editUsers($datas)) {
				$_SESSION[$plugin] = str_replace('##COUNT##', $countUsers, $plxPlugin->getLang('MESSAGE'));
			}
		} else {
			$_SESSION[$plugin]['warning'] = $plxPlugin->getLang('LOGIN_REQUIRED');
		}
		header('Location: '.$location);
		exit;

	} else {
		header('HTTP/1.0 404');
		exit;
	} // end of process for form

}

if(isset($_GET['p']) and (filter_input(INPUT_GET, 'p', FILTER_SANITIZE_STRING) == get_class($plxPlugin))) {
	// the script is called by core/admin/plugin.php?p=xxxx with xxxx as class of plugin
	$plxPlugin->printForm(true);
}
?>
